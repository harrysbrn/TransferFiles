package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.test.AndroidTestCase;

import org.mockito.ArgumentCaptor;

import java.util.Arrays;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;

public class TransmitterScannerAndroidTest extends AndroidTestCase {

    public static final byte[] SENSEONICS_SCAN_RECORD = new byte[]{2, 1, 4, 17, 7, 17, -94, -110, 8, 3, 61, 18, -84, -82, 71, 8, -109, 1, 0, 35, -61, 9, 9, 84, 82, 50, 52, 56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    protected BluetoothAdapterWrapper mockBluetoothAdapterWrapper;
    protected Handler handler;
    private BluetoothManager bluetoothManager;

    protected ConnectedTransmitterAsyncQueryHandler mockConnectedTransmitterAsyncQueryHandler;

    @Override
    protected void setUp() throws Exception {
        super.setUp();

        System.setProperty("dexmaker.dexcache", getContext().getCacheDir().getPath());


        mockConnectedTransmitterAsyncQueryHandler = mock(ConnectedTransmitterAsyncQueryHandler.class);
        mockBluetoothAdapterWrapper = mock(BluetoothAdapterWrapper.class);
        handler = new Handler(Looper.getMainLooper());
        bluetoothManager = (BluetoothManager)  getContext().getSystemService(Context.BLUETOOTH_SERVICE);
    }


    public void testService_StartDiscovery_StartsScan_WithCallback() {
        ArgumentCaptor<BluetoothAdapter.LeScanCallback> leScanCallbackArgumentCaptor = ArgumentCaptor.forClass(BluetoothAdapter.LeScanCallback.class);
        ArgumentCaptor<ConnectedTransmitterAsyncQueryHandler.Callback> callbackArgumentCaptor = ArgumentCaptor.forClass(ConnectedTransmitterAsyncQueryHandler.Callback.class);

        TransmitterScanner testObject = new TransmitterScanner(mockBluetoothAdapterWrapper, handler, 1, mockConnectedTransmitterAsyncQueryHandler);
        DiscoverCallback discoverCallback = mock(DiscoverCallback.class);
        testObject.scan(discoverCallback);

        verify(mockConnectedTransmitterAsyncQueryHandler).startQuery(callbackArgumentCaptor.capture());
        callbackArgumentCaptor.getValue().noLastConnectedTransmitter();

        verify(mockBluetoothAdapterWrapper).startLeScan(leScanCallbackArgumentCaptor.capture());

        BluetoothAdapter.LeScanCallback leScanCallback = leScanCallbackArgumentCaptor.getValue();

        String expectedAddress = "00:07:80:78:A4:81";
        BluetoothDevice notSenseonicsDevice = generateBluetoothDevice("00:07:80:78:A4:00");
        BluetoothDevice device = generateBluetoothDevice(expectedAddress);
        leScanCallback.onLeScan(notSenseonicsDevice, 0, new byte[]{2, 1, 4, 17, 7, 17, 94, -110, 8, 3, 61, 18, -84, -82, 71, 8, -109, 1, 0, 35, -61, 9, 9, 84, 82, 50, 52, 56});
        leScanCallback.onLeScan(device, 0, SENSEONICS_SCAN_RECORD);
        leScanCallback.onLeScan(device, 0, SENSEONICS_SCAN_RECORD);

        verify(discoverCallback, timeout(50)).onDevice(Arrays.asList(new Transmitter(expectedAddress, "not part of equals so does not matter")));
    }

    public void testScan_CalledWhileAScanIsInProgress_StopsTheOldScan() {
        ArgumentCaptor<BluetoothAdapter.LeScanCallback> leScanCallbackArgumentCaptor = ArgumentCaptor.forClass(BluetoothAdapter.LeScanCallback.class);

        TransmitterScanner testObject = new TransmitterScanner(mockBluetoothAdapterWrapper, new Handler(), 1, mockConnectedTransmitterAsyncQueryHandler);
        DiscoverCallback discoverCallback = mock(DiscoverCallback.class);
        testObject.scan(discoverCallback);
        verify(mockBluetoothAdapterWrapper, never()).stopLeScan(any(BluetoothAdapter.LeScanCallback.class));

        testObject.scan(discoverCallback);
        verify(mockBluetoothAdapterWrapper).stopLeScan(any(BluetoothAdapter.LeScanCallback.class));
    }

    public void testScan_AddsAnyTransmitter_ReturnedByTheQueryHandler_ToTheListOfAvailableDevices() {
        ArgumentCaptor<ConnectedTransmitterAsyncQueryHandler.Callback> queryHandlerCallbackCaptor = ArgumentCaptor.forClass(ConnectedTransmitterAsyncQueryHandler.Callback.class) ;
        TransmitterScanner testObject = new TransmitterScanner(mockBluetoothAdapterWrapper, handler, 1, mockConnectedTransmitterAsyncQueryHandler);
        DiscoverCallback discoverCallback = mock(DiscoverCallback.class);
        Transmitter transmitter = new Transmitter("address", "name", Transmitter.CONNECTION_STATE.DISCONNECTED);


        testObject.scan(discoverCallback);

        verify(mockConnectedTransmitterAsyncQueryHandler).startQuery(queryHandlerCallbackCaptor.capture());
        ConnectedTransmitterAsyncQueryHandler.Callback  queryHandlerCallback = queryHandlerCallbackCaptor.getValue();
        queryHandlerCallback.lastConnectedTransmitter(transmitter);

        verify(mockBluetoothAdapterWrapper).startLeScan(any(BluetoothAdapter.LeScanCallback.class));
        verify(discoverCallback, timeout(500)).onDevice(Arrays.asList(transmitter));
    }

    public void testStopLeScanIfCurrentlyScanning_DoesNotCallStopLeScan_IfNoScanIsInProgress() {
        TransmitterScanner testObject = new TransmitterScanner(mockBluetoothAdapterWrapper, handler, 1, mockConnectedTransmitterAsyncQueryHandler);

        testObject.stopLeScanIfCurrentlyScanning();

        verify(mockBluetoothAdapterWrapper, never()).stopLeScan(any(BluetoothAdapter.LeScanCallback.class));
    }

    public void testStopLeScanIfCurrentlyScanning_CallStopLeScan_WhenScanIsInProgress() {
        TransmitterScanner testObject = new TransmitterScanner(mockBluetoothAdapterWrapper, handler, 1000, mockConnectedTransmitterAsyncQueryHandler);

        testObject.scan(mock(DiscoverCallback.class));
        testObject.stopLeScanIfCurrentlyScanning();

        verify(mockBluetoothAdapterWrapper).stopLeScan(any(BluetoothAdapter.LeScanCallback.class));
    }

    private BluetoothDevice generateBluetoothDevice(String expectedAddress) {
        Parcel deviceParcel = Parcel.obtain();
        deviceParcel.writeString(expectedAddress);
        deviceParcel.setDataPosition(0);
        return BluetoothDevice.CREATOR.createFromParcel(deviceParcel);
    }
}
