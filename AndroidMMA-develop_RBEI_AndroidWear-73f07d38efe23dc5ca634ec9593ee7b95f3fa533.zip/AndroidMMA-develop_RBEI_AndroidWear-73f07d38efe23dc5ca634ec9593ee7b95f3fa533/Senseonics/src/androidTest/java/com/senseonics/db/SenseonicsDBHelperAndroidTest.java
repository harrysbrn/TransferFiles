package com.senseonics.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

public class SenseonicsDBHelperAndroidTest extends AndroidTestCase {

    private static final String TEST_FILE_PREFIX = SenseonicsDBHelperAndroidTest.class.getSimpleName();
    private SenseonicsDBHelper testObject;

    public void setUp() throws Exception {
        super.setUp();
        RenamingDelegatingContext context = new RenamingDelegatingContext(getContext(), TEST_FILE_PREFIX);
        testObject = new SenseonicsDBHelper(context);
    }

    public void testDatabaseTablesAreCreated() {
        SQLiteDatabase database = testObject.getReadableDatabase();

        String[] selectionArgs = {ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, SenseonicsDBHelper.GLUCOSE_READINGS_TABLE};
        Cursor cursor = database.query(true, "sqlite_master", new String[]{"tbl_name"}, "tbl_name in (?, ?)", selectionArgs, null, null, null, null);

        assertEquals(selectionArgs.length, cursor.getCount());
    }

}