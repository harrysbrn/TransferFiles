package com.senseonics.bluetoothle;

import android.net.Uri;
import android.os.Handler;

import com.senseonics.gen12androidapp.BuildConfig;

import org.mockito.Mockito;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import de.greenrobot.event.EventBus;

import static com.senseonics.gen12androidapp.Constants.IS_FOREGROUND;
import static org.mockito.Mockito.mock;

@Module(
        library = true,
        addsTo = ServiceModule.class,
        overrides = true,
        injects = {BluetoothServiceAndroidTest.class}
)
class MockingModule {
    private final BluetoothAdapterWrapper mockBluetoothWrapper;
    private final Handler mockHandler;
    private final TransmitterScanner mockTransmitterScanner;
    private final EventBus mockEventBus;
    private ConnectedTransmitterAsyncQueryHandler mockConnectedTransmitterAsyncQueryHandler;
    private ConnectionStateModifier mockConnectionStateModifier;
    private BluetoothCommunicator mockBluetoothCommunicator;

    public MockingModule() {
        this.mockBluetoothWrapper = mock(BluetoothAdapterWrapper.class);
        this.mockHandler = mock(Handler.class);
        this.mockTransmitterScanner = mock(TransmitterScanner.class);
        this.mockConnectionStateModifier = mock(ConnectionStateModifier.class);
        this.mockConnectedTransmitterAsyncQueryHandler = mock(ConnectedTransmitterAsyncQueryHandler.class);
        this.mockBluetoothCommunicator = mock(BluetoothCommunicator.class);
        this.mockEventBus = mock(EventBus.class);
    }

    @Provides
    @Singleton
    protected BluetoothAdapterWrapper provideBluetoothAdapterWrapper() {
        return mockBluetoothWrapper;
    }

    @Provides
    protected TransmitterScanner provideTransmitterScanner() {
        return mockTransmitterScanner;
    }

    @Provides
    protected ConnectionStateModifier provideConnectionStateModifiter() {
        return mockConnectionStateModifier;
    }

    @Provides
    @Named("SCAN_PERIOD_MILLISECONDS")
    protected long provideScanPeriodMilliseconds() {
        return 1;
    }

    @Provides
    protected ConnectedTransmitterAsyncQueryHandler providesConnectedTransmitterAsyncQueryHandler() {
        return mockConnectedTransmitterAsyncQueryHandler;
    }

    @Provides
    protected BluetoothCommunicator provideBluetoothCommunicator() {
        return mockBluetoothCommunicator;
    }

    @Provides
    protected EventBus provideEventBus() {
        return mockEventBus;
    }

    @Provides @Named(IS_FOREGROUND) boolean provideIsForeground() {
        return false; // See: https://code.google.com/p/android/issues/detail?id=12122
    }

    @Provides
    @Named("transmitter")
    protected Uri provideTransmitterContentProviderUri() {
        return Uri.parse("content://" + BuildConfig.APPLICATION_ID + ".transmitter");
    }

    public void reset() {
        Mockito.reset(mockBluetoothWrapper, mockHandler, mockTransmitterScanner, mockConnectedTransmitterAsyncQueryHandler, mockConnectionStateModifier, mockBluetoothCommunicator, mockEventBus);
    }
}
