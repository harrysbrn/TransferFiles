package com.senseonics.test;

import android.os.Bundle;
import android.test.InstrumentationTestRunner;

public class CustomInstrumentationTestRunner extends InstrumentationTestRunner {

    @Override
    public void onCreate(Bundle arguments) {
        System.setProperty("dexmaker.dexcache", getTargetContext().getCacheDir().toString());
        super.onCreate(arguments);
    }
}
