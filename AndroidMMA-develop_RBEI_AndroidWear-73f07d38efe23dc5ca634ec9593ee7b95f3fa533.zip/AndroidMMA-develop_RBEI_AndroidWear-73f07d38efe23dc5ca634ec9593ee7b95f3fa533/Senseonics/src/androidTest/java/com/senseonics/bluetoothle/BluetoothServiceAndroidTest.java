package com.senseonics.bluetoothle;

import android.app.Application;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcel;
import android.test.ServiceTestCase;

import com.senseonics.gen12androidapp.AndroidModule;
import com.senseonics.gen12androidapp.ApplicationModule;
import com.senseonics.gen12androidapp.ObjectGraphApplication;

import org.mockito.ArgumentCaptor;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.inject.Named;

import dagger.ObjectGraph;
import de.greenrobot.event.EventBus;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

class TestableBluettothService extends BluetoothService {
}

public class BluetoothServiceAndroidTest extends ServiceTestCase<BluetoothService> {
    private static MockingModule mockingModule = new MockingModule();

    @Inject
    protected TransmitterScanner mockTransmitterScanner;
    @Inject
    protected BluetoothAdapterWrapper mockBluetoothWrapper;
    @Inject
    protected ConnectedTransmitterAsyncQueryHandler mockConnectedTransmitterAsyncQueryHandler;
    @Inject
    protected ConnectionStateModifier mockConnectionStateModifier;
    @Inject
    protected BluetoothCommunicator mockBluetoothCommunicator;
    @Inject
    protected EventBus mockEventBus;


    @Inject
    @Named("transmitter")
    protected Uri transmitterAuthorityUri;

    public BluetoothServiceAndroidTest() {
        super(BluetoothService.class);
    }

    @Override
    protected void setUp() throws Exception {
        mockingModule.reset();
        MyApplication application = new MyApplication(getContext());
        setApplication(application);
        application.inject(this);
        super.setUp();

    }

    private void startService() {
        super.startService(new Intent(getContext(), BluetoothService.class));

    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testStartDiscover_Delegates() {
        startService();

        BluetoothService testObject = getService();
        DiscoverCallback discoverCallback = mock(DiscoverCallback.class);

        when(mockBluetoothWrapper.isBluetoothEnabled()).thenReturn(true);
        testObject.startDiscovery(discoverCallback);

        verify(mockTransmitterScanner).scan(discoverCallback);
    }

    public void testConnect_StopsScanning_AndSetsStateToConnecting_AndPostsAConnectionEvent() {
        startService();
        BluetoothService testObject = getService();
        Transmitter transmitter = new Transmitter("00:07:80:78:A4:69", "name");
        BluetoothDevice device = generateBluetoothDevice(transmitter.getAddress());
        when(mockBluetoothWrapper.getRemoteDevice(transmitter.getAddress())).thenReturn(device);

        testObject.connect(transmitter, true);

        verify(mockTransmitterScanner).stopLeScanIfCurrentlyScanning();

        verify(mockConnectionStateModifier).setConnectionStateAndPublish(eq(transmitter),
            eq(Transmitter.CONNECTION_STATE.CONNECTING));
    }

    public void testDisconnect_SetConnectionState_ToDisconnected_AndPostsAConnectionEvent() {
        startService();
        Transmitter transmitter = new Transmitter("00:07:80:78:A4:69", "name", Transmitter.CONNECTION_STATE.CONNECTED);

        BluetoothService testObject = getService();
        testObject.disconnect(transmitter);

        verify(mockBluetoothCommunicator).disconnect();
    }

    public void testOnCreate_FindsOutCurrentBluetoothEnabledState_FromTheAdapterWrapper_AndPostsStickyEvent() {
        ArgumentCaptor<BluetoothConnectionEvent> bluetoothConnectionEventArgumentCaptor = ArgumentCaptor.forClass(BluetoothConnectionEvent.class);
        when(mockBluetoothWrapper.isBluetoothEnabled()).thenReturn(true);
        startService();
        getService();
        verify(mockBluetoothWrapper).isBluetoothEnabled();
        verify(mockEventBus).postSticky(bluetoothConnectionEventArgumentCaptor.capture());

        assertTrue(bluetoothConnectionEventArgumentCaptor.getValue().isBluetoothEnabled());

    }

    public void testCreateService_CallsConnectToPreviouslyConnectedDevice_AndInvokesStartQueryOnHandler_AndOnCallback_DoesConnect() {
        Transmitter transmitter = new Transmitter("00:07:80:78:A4:69", "name", Transmitter.CONNECTION_STATE.DISCONNECTED);
        when(mockBluetoothWrapper.isBluetoothEnabled()).thenReturn(true);
        startService();
        BluetoothService testObject = getService();
        ArgumentCaptor<ConnectedTransmitterAsyncQueryHandler.Callback> callbackArgumentCaptor = ArgumentCaptor.forClass(ConnectedTransmitterAsyncQueryHandler.Callback.class);

        verify(mockConnectedTransmitterAsyncQueryHandler).startQuery(callbackArgumentCaptor.capture());
        callbackArgumentCaptor.getValue().lastConnectedTransmitter(transmitter);

        verify(mockTransmitterScanner).stopLeScanIfCurrentlyScanning();
        verify(mockConnectionStateModifier).setConnectionStateAndPublish(eq(transmitter),
            eq(Transmitter.CONNECTION_STATE.CONNECTING));
    }

    public void testCreateService_DoesNotCallConnectToPreviouslyConnectedDevice_IfBluetoothIsNotEnabled() {
        when(mockBluetoothWrapper.isBluetoothEnabled()).thenReturn(false);
        startService();
        BluetoothService testObject = getService();

        verifyNoMoreInteractions(mockConnectedTransmitterAsyncQueryHandler);
    }

    private BluetoothDevice generateBluetoothDevice(String expectedAddress) {
        Parcel deviceParcel = Parcel.obtain();
        deviceParcel.writeString(expectedAddress);
        deviceParcel.setDataPosition(0);
        return BluetoothDevice.CREATOR.createFromParcel(deviceParcel);
    }

    private static class MyApplication extends Application implements ObjectGraphApplication {
        private final ObjectGraph objectGraph;

        public MyApplication(Context context) {
            objectGraph = ObjectGraph.create(new AndroidModule(context), new ApplicationModule(), mockingModule);
        }

        @Override
        public ObjectGraph plus(Object... objects) {
            ArrayList list = new ArrayList(objects.length +1);
            for(Object object : objects) {
                list.add(object);
            }
            list.add(mockingModule);
            return objectGraph.plus(list.toArray());

        }

        @Override
        public void inject(Object object) {
            objectGraph.inject(object);
        }
    }
}