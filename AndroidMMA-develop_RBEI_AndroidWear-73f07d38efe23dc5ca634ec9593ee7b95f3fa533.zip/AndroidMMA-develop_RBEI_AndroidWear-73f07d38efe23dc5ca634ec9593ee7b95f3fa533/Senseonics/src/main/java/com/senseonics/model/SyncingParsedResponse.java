package com.senseonics.model;

import android.content.SharedPreferences;
import android.util.Log;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.HexHelper;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.ModelChangedRefreshGraphEvent;
import com.senseonics.events.SyncingProgressUpdateEvent;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class SyncingParsedResponse implements ParsedResponse {

    private SyncModel syncModel;
    private EventBus eventBus;
    private DatabaseManager databaseManager;
    private SharedPreferences sharedPreferences;

    @Inject
    public SyncingParsedResponse(SyncModel syncModel, EventBus eventBus, DatabaseManager databaseManager, SharedPreferences sharedPreferences) {
        this.syncModel = syncModel;
        this.eventBus = eventBus;
        this.databaseManager = databaseManager;
        this.sharedPreferences = sharedPreferences;
    }

    @Override
    public int getExpectedResponseId() {
        return 0;
    }

    @Override
    public boolean check(int[] data) {
        int responseID = data[0];
        if ((responseID == CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeResponseID && ResponseOperations.isReadAllSensorGlucoseDataRecordResponseCorrect(data))
                || (responseID == CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID && ResponseOperations.isReadAllSensorGlucoseAlertsInSpecifiedRangeResponseCorrect(data))
                || (responseID == CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID && ResponseOperations.isReadLogOfBloodGlucoseDataInSpecifiedRangeResponseCorrect(data))) {
            Log.d(SyncingParsedResponse.class.getSimpleName(), "check true: " + HexHelper.intArrayToString(data));
            return true;
        }
        Log.d(SyncingParsedResponse.class.getSimpleName(), "check false: " + HexHelper.intArrayToString(data));
        return false;
    }

    @Override
    public void apply(int[] responseData, TransmitterStateModel model) {
        int responseID = responseData[0];
        if (syncModel.isSyncing()) {

            ResponseOperations.Response response = new ResponseOperations.Response(responseID, true, responseData);
            syncModel.setCurrentSyncingResponseId(response);

            // Check recording interval state
            int glucoseRecordNumber = responseData[1] | (responseData[2] << 8) | (responseData[3] << 16);
            Log.d(SyncingParsedResponse.class.getSimpleName(), "RECORDED GLUCOSE NUMBER " + glucoseRecordNumber + " at request " + HexHelper.intArrayToString(responseData) + " with response " + responseData);

            Log.d(SyncingParsedResponse.class.getSimpleName(), "sync response being parsed 0x" + Integer.toHexString(response.getResponseId()) + ", data: " + HexHelper.intArrayToString(response.getData()) + ", on thread " + Thread.currentThread().getName());

            switch (response.getResponseId()) {
                case CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeResponseID:
                    parseReadAllSensorGlucoseDataInSpecifiedRangeResponseData(response.getData(), model);
                    break;
                case CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID:
                    parseReadAllSensorGlucoseAlertsInSpecifiedRangeResponseData(response.getData(), model);
                    break;
                case CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID:
                    parseReadLogOfBloodGlucoseDataInSpecifiedRangeResponseData(response.getData(), model);
                    break;
            }

        }
    }
    private void parseReadLogOfBloodGlucoseDataInSpecifiedRangeResponseData(int[] response,  TransmitterStateModel model) {

        int recordNr = response[1] | (response[2] << 8);

        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{
                response[3], response[4]});
        int[] time = BinaryOperations.calculateTimeFromBytes(new int[]{
                response[5], response[6]});
        int bloodGlucoseValue = response[7] | (response[8] << 8);
        int meterIdentifier = response[9] | (response[10] << 8);
        int calUseFlags = response[11];
        int closestSensorGlucoseEntryRecordNr = response[12]
                | (response[13] << 8) | (response[14] << 16);

        /** Increment the max synced record if needed */
        if (recordNr == (model.getMaxSyncedBloodGlucoseRecord() + 1)) {
            model.setMaxSyncedBloodGlucoseRecord(recordNr);
        }

        parsedReadLogOfBloodGlucoseDataInSpecifiedRangeResponse(
                recordNr, date, time, bloodGlucoseValue, meterIdentifier,
                calUseFlags, closestSensorGlucoseEntryRecordNr);
    }

    private void parsedReadLogOfBloodGlucoseDataInSpecifiedRangeResponse(
            int recordNr, int[] date, int[] time, int bloodGlucoseValue,
            int meterIdentifier, int calUseFlags,
            int closestSensorGlucoseEntryRecordNr) {
        Log.d(SyncingParsedResponse.class.getSimpleName(), "---------------------------------");

        Calendar calendar = Utils.getGMTCalendarFrom(date, time);
        Log.d(SyncingParsedResponse.class.getSimpleName(),
                Utils.formatDate_TimeZone(calendar, TimeZone.getTimeZone("GMT")));

        Utils.CALIBRATION_USE_FLAG useFlag = Utils.CALIBRATION_USE_FLAG.values()[calUseFlags];

        Log.d(SyncingParsedResponse.class.getSimpleName(), "BGM-> recordNumber: " + recordNr + ", bloodGlucoseValue: " + bloodGlucoseValue + ", meterIdentifier: " + meterIdentifier + ", calUseFlags: " + calUseFlags + "");

        /** if the synced bgm record has flag not used => check in the app's database to see if there is a Used calibration at tha almost the same time */
        String calibrationNotes = "";
        if (useFlag == Utils.CALIBRATION_USE_FLAG.NOT_ENTERED_FOR_CALIBRATION) {
            // create an expected event to search in the database
            CalibrationEventPoint expectedEvent = new CalibrationEventPoint(calendar, bloodGlucoseValue, true);

            calibrationNotes = databaseManager.hideCalibrationEventAndGetNotesDuringSync(expectedEvent);
            Log.d(SyncingParsedResponse.class.getSimpleName(), "BGM-> calibrationNotes: " + calibrationNotes);
        }

        /** #3209 Suspicious fingerstick that are accepted in the following fingerstick should be marked */
        if (useFlag == Utils.CALIBRATION_USE_FLAG.ACTUALLY_USED_FOR_CALIBRATION) { // if it's THIS_ONE_USED_PREVIOUS_ONE_DELETED, no need to convert the suspicious glucose since it's not used in the transmitter

            // Check the database with -1 record index
            int recordNumberToSearch = recordNr - 1;

            // create an expected event to search in the database
            GlucoseEventPoint expectedEvent = new GlucoseEventPoint(calendar, 0, Utils.CALIBRATION_USE_FLAG.MARKED_SUSPICIOUS.ordinal()); // glucose value would not be used for searching
            expectedEvent.setRecordNumber(recordNumberToSearch);

            int eventsUpdated = databaseManager.convertSuspiciousGlucoseIntoCalibrationDuringSync(expectedEvent);
            Log.d(SyncingParsedResponse.class.getSimpleName(), "BGM->SuspiciousCheck | no of events updated : " + eventsUpdated);
        }

        /** Add Tx Synced BGM events to database: add none-duplicates and update record number for the duplicated events that are already in database */
        if (useFlag == Utils.CALIBRATION_USE_FLAG.ACTUALLY_USED_FOR_CALIBRATION ||
                useFlag == Utils.CALIBRATION_USE_FLAG.THIS_ONE_USED_PREVIOUS_ONE_DELETED) /** #3209 */
        {
            CalibrationEventPoint calibrationEventPoint = new CalibrationEventPoint(calendar, bloodGlucoseValue, true);
            calibrationEventPoint.setEventHidden(false);
            calibrationEventPoint.setRecordNumber(recordNr);
            databaseManager.addSyncedCalibrationAndGlucoseEvent(calibrationEventPoint, true);
        } else {
            GlucoseEventPoint glucoseEventPoint = new GlucoseEventPoint(calendar, bloodGlucoseValue, calUseFlags, calibrationNotes); /** APPDEV-4032 */
            glucoseEventPoint.setEventHidden(false);
            glucoseEventPoint.setRecordNumber(recordNr);
            databaseManager.addSyncedCalibrationAndGlucoseEvent(glucoseEventPoint, true);
        }

        afterSyncDataParsed();
    }

    private void parseReadAllSensorGlucoseAlertsInSpecifiedRangeResponseData(int[] response, TransmitterStateModel model) {

        int recordNumberOfSensorGlucoseAlertRecord = response[1] | (response[2] << 8);

        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{
                response[3], response[4]});
        int[] time = BinaryOperations.calculateTimeFromBytes(new int[]{
                response[5], response[6]});
        int sensorGlucoseAlertLogRecordType = response[7];
        int sensorGlucoseValue = response[8] | (response[9] << 8);
        int sensorGlucoseRateValue = response[10] | (response[11] << 8);
        int alertThresholdOrTimeInterval = response[12] | (response[13] << 8);

        /** Increment the max synced record if needed */
        if (recordNumberOfSensorGlucoseAlertRecord == (model.getMaxSyncedAlertRecord() + 1)) {
            model.setMaxSyncedAlertRecord(recordNumberOfSensorGlucoseAlertRecord);
        }

        parsedReadAllSensorGlucoseAlertsInSpecifiedRangeResponse(
                recordNumberOfSensorGlucoseAlertRecord, date, time,
                sensorGlucoseAlertLogRecordType, sensorGlucoseValue,
                sensorGlucoseRateValue, alertThresholdOrTimeInterval);
    }

    private void parsedReadAllSensorGlucoseAlertsInSpecifiedRangeResponse(
            int recordNumber, int[] date, int[] time,
            int sensorGlucoseAlertLogRecordType, int sensorGlucoseValue,
            int sensorGlucoseRateValue, int alertThresholdOrTimeInterval) {

        Calendar calendar = Utils.getGMTCalendarFrom(date, time);
        Log.d(SyncingParsedResponse.class.getSimpleName(),
                Utils.formatDate_TimeZone(calendar, TimeZone.getTimeZone("GMT")));

        Log.d(SyncingParsedResponse.class.getSimpleName(), "sensorGlucoseAlertLogRecordType: " + sensorGlucoseAlertLogRecordType + " ");
        Log.d(SyncingParsedResponse.class.getSimpleName(), "sensorGlucoseValue: " + sensorGlucoseValue + " ");
        Log.d(SyncingParsedResponse.class.getSimpleName(), "sensorGlucoseRateValue: " + sensorGlucoseRateValue + " ");
        Log.d(SyncingParsedResponse.class.getSimpleName(), "alertThresholdOrTimeInterval: " + alertThresholdOrTimeInterval + " ");

        Log.d(SyncingParsedResponse.class.getSimpleName(), recordNumber + " ");

        try {
            ALERT_LOG_RECORD_TYPE.findBy(sensorGlucoseAlertLogRecordType).save(databaseManager, sensorGlucoseValue, calendar, alertThresholdOrTimeInterval, recordNumber, sensorGlucoseRateValue);
        } catch (IllegalArgumentException e) {
            Log.w(SyncingParsedResponse.class.getSimpleName(), "unexpected code from transmitter : " + sensorGlucoseAlertLogRecordType);
        }

        afterSyncDataParsed();
    }

    private void afterSyncDataParsed() {
        if (syncModel.shouldPostSyncingProgress()) {
            Log.d("#3640_2", "afterSyncDataParsed, sync percent 1:" + syncModel.getSyncingPercent());
            eventBus.post(new SyncingProgressUpdateEvent());
        }

        if (syncModel.shouldPostRefreshGraph()) {
            Log.d("#3640_2", "afterSyncDataParsed, sync percent 2:" + syncModel.getSyncingPercent());
            eventBus.post(new ModelChangedRefreshGraphEvent());
        }

        /** Moved the logic from SyncProgressManager */
        boolean shouldUpdateLastSyncTime = false;
        if (syncModel.isSyncFinished()) {
            shouldUpdateLastSyncTime = true;
        }
        else {
            if (!syncModel.isSyncing()) {
                shouldUpdateLastSyncTime = true;
            }
        }

        if (shouldUpdateLastSyncTime) {
            long timezoneOffset = Utils.getLocalTimeInMillisAdjustedToGMT();
            sharedPreferences.edit().putLong(Utils.prefLastSyncingMillis, timezoneOffset).apply();
        }
    }

    private void saveAlert(Utils.EVENT_TYPE eventType, Utils.ALERT_TYPE type,
                           Calendar calendar, int glucoseValue, float rateValue,
                           int predictiveMinutes, int recordNumber, boolean hidden) {
        AlertEventPoint alertEvent = new AlertEventPoint(eventType, calendar,
                glucoseValue, type, Utils.GLUCOSE_TYPE.SENSOR_GLUCOSE);
        alertEvent.setRecordNumber(recordNumber);
        alertEvent.setRateValue(rateValue);
        alertEvent.setPredictiveMinutes(predictiveMinutes);
        alertEvent.setEventHidden(hidden);
        databaseManager.addEvent(alertEvent, true);
    }

    private void parseReadAllSensorGlucoseDataInSpecifiedRangeResponseData(int[] response, TransmitterStateModel model) {

        int glucoseRecordNumber = response[1] | (response[2] << 8) | (response[3] << 16);
        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{response[4], response[5]});
        int[] time = BinaryOperations.calculateTimeFromBytes(new int[]{response[6], response[7]});
        int value = response[8] | (response[9] << 8);
        int sensorGlucoseAlertFlags = response[10];

        /** Increment the max synced record if needed */
        if (glucoseRecordNumber == (model.getMaxSyncedSensorRecord() + 1)) {
            model.setMaxSyncedSensorRecord(glucoseRecordNumber);
        }

        parsedReadAllSensorGlucoseDataInSpecifiedRangeResponse(glucoseRecordNumber, date, time, value, sensorGlucoseAlertFlags);
    }

    // Read all sensor glucose data in specified range 0x70
    private void parsedReadAllSensorGlucoseDataInSpecifiedRangeResponse(
            final int glucoseRecordNumber, int[] date, int[] time,
            final int value, int sensorGlucoseAlertFlags) {

        Log.d(SyncingParsedResponse.class.getSimpleName(), "<<<<<>>>>>");

        int year = date[0];
        int month = date[1];
        int day = date[2];
        int hour = time[0];
        int minute = time[1];
        int second = time[2];

        final Calendar calendar = Utils.getGMTCalendarFrom(date, time);
        long calendarTimestamp = calendar.getTimeInMillis();

        TimeZone mTimeZone = calendar.getTimeZone();
        int mGMTOffset = mTimeZone.getRawOffset();
        int GMTHours = (int) TimeUnit.HOURS.convert(mGMTOffset,
                TimeUnit.MILLISECONDS);

        long timeZoneDiff = GMTHours * GraphUtils.HOUR;
        Log.d(SyncingParsedResponse.class.getSimpleName(), timeZoneDiff + " ");
        long glucoseTime = calendar.getTimeInMillis() + timeZoneDiff;

        Calendar eventCalendar = Calendar.getInstance();
        eventCalendar.setTimeZone(TimeZone.getDefault());
        eventCalendar.setTimeInMillis(glucoseTime);
        long DSToffset = eventCalendar.get(Calendar.DST_OFFSET);
        Log.d(SyncingParsedResponse.class.getSimpleName(), " ---- " + DSToffset);
        eventCalendar.setTimeInMillis(eventCalendar.getTimeInMillis()
                + DSToffset);

        Log.d(SyncingParsedResponse.class.getSimpleName(), calendar.get(Calendar.DAY_OF_MONTH)
                + " //// " + year + " " + month + " " + day + " " + hour
                + ":" + minute + ":" + second + " - " + value + " recordNumber: "
                + glucoseRecordNumber);

        // Test syncing: tag:AddReading|NEW_GLUCOSE_DATA|RECORDED_GLUCOSE_DATA
        try {
            if (databaseManager.allowAddingGlucoseReading(calendarTimestamp, glucoseRecordNumber)) {
                Log.d("Add Glucose Database", "Sync: ADD NEW " + calendar
                        .getTimeInMillis() + "|" + value + "|record:"
                        + glucoseRecordNumber);

                databaseManager.addReadingInGMT(new Glucose(calendar.getTimeInMillis(), value, -1, glucoseRecordNumber));

                Utils.GLUCOSE_TYPE glucoseType = Utils.GLUCOSE_TYPE.SENSOR_GLUCOSE;
                Utils.ALERT_TYPE type = null;
                switch (sensorGlucoseAlertFlags) {
                    case 1:
                        type = Utils.ALERT_TYPE.LOW_GLUCOSE;
                        break;
                    case 2:
                        type = Utils.ALERT_TYPE.HIGH_GLUCOSE;
                        break;
                }
                if (type != null) {
                    AlertEventPoint alertEvent = new AlertEventPoint(
                            Utils.EVENT_TYPE.ALERT_EVENT, eventCalendar, value,
                            type, glucoseType);
                    databaseManager.addEvent(alertEvent, true);
                }
            }
        } catch (IllegalStateException e) {
            if (e.getMessage() != null)
                Log.d(SyncingParsedResponse.class.getSimpleName(), e.getMessage());
        }
        Log.d(SyncingParsedResponse.class.getSimpleName(), "glucoseRecordNumber: " + glucoseRecordNumber);

        afterSyncDataParsed();

    }

}
