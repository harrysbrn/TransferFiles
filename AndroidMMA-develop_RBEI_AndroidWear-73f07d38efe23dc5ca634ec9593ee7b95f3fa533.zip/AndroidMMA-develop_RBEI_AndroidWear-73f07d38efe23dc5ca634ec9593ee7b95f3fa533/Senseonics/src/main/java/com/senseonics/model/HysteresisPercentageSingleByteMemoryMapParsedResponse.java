package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

//0093 High Level Alarm/Alert Hysteresis Percent
public class HysteresisPercentageSingleByteMemoryMapParsedResponse implements  SingleByteMemoryMapParsedResponse {

    @Inject
    public HysteresisPercentageSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {return MemoryMap.hysteresisPercentageAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {

        model.setHysteresisHighGlocosePercent(data);
    }


}
