package com.senseonics.events;

public class InvalidUserCredentialEvent {
}
