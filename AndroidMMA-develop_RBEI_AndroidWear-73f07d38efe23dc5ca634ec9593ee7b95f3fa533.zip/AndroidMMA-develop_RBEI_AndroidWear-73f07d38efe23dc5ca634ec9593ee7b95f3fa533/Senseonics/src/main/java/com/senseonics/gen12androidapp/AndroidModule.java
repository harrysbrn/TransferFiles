package com.senseonics.gen12androidapp;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import com.senseonics.bluetoothle.ApplicationForegroundState;
import com.senseonics.db.DatabaseManager;
import com.senseonics.graph.GraphCache;
import com.senseonics.util.Utils;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import de.greenrobot.event.EventBus;

@Module(
        library = true,
        injects = {SenseonicsApplication.class}
)
public class AndroidModule {

    private Context context;

    public AndroidModule(Context context) {
        this.context = context;
    }

    @Provides
    @Singleton
    protected Context provideContext() {
        return context;
    }

    @Provides
    @Singleton
    protected DatabaseManager provideDatabaseManager() {
        DatabaseManager databaseManager = new DatabaseManager(context);
        databaseManager.open();
        return databaseManager;
    }

    @Provides
    protected SharedPreferences provideSharedPreferences() {
        return context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
    }

    @Provides
    protected Handler provideHandler() {
        return new Handler(Looper.getMainLooper());
    }

    @Provides
    protected NotificationManager provideNotificationManager() {
        return (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @Provides protected EventBus provideEventBus() {
        return EventBus.getDefault();
    }

    @Provides @Singleton ApplicationForegroundState provideApplicationForegroundState() {
        return new ApplicationForegroundState();
    }

    @Provides @Singleton GraphCache provideGraphCache(EventBus eventBus,
        DatabaseManager databaseManager) {
        return new GraphCache(eventBus, databaseManager);
    }
}
