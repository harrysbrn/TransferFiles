package com.senseonics.util;

public class Range {
    private int from;
    private int to;

    public Range(int from, int to) {
        this.from = from;
        this.to = to;
    }

    public int getFrom() {
        return from;
    }

    public int getTo() {
        return to;
    }

    public int getCount() {
        return to-from+1;
    }

    /**
     * positive, negative logic like Comparable
     * @param candidate
     * @return
     */
    public int compareTo(int candidate) {
        if (candidate > to) {
            return -1;
        }
        if (candidate < from) {
            return 1;
        }

        return 0;
    }

    @Override
    public String toString() {
        return "(" + from + ", " + to + ")";
    }
}
