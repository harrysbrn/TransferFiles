package com.senseonics.graph.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.TypedValue;

import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

public class GraphUtils {

	public static int SECOND = 1000;
	public static long MINUTE = 1000 * 60;
	public static long HOUR = MINUTE * 60;
	public static long DAY = HOUR * 24;

	//TODO: should be 2*samplingInterval+10 (seconds)
    // #1980 set if the timeDiff is greater than 6 mins, form a new section
    public static int GRAPH_CONNECTING_INTERVAL = 10; /** update from 6 minutes to 10 */

	public static boolean listPopUpIsVisible = false;
	public static float popUpX = -1, popUpY = -1;
	public static Calendar popUpCalendar;

	public static Map<Integer, COLOR> glucoseLevels;
	public static int glucoseMinimumLevel, glucoseMaximumLevel;

	public static long glucoseDataInterval;
	public static boolean glucoseDataIntervalChanged = false;
	public static double viewportStart = -1;
	public static double viewportSize;
	public static float minViewPortSize, maxViewPortSize;

	public static Bitmap calibrationEventBitmapRed, calibrationEventBitmapBlue,
			groupEventBitmap, glucoseEventBitmap, mealEventBitmap,
			insulinEventBitmap, healthEventBitmap, exerciseEventBitmap,
			alertEventBitmap, alarmEventBitmap, predFallingBitmap,
			predRisingBitmap, edrAlertBitmap;
	public static int eventBitmapSize;

	public static Bitmap disruptionBitmap;
	public static int disruptionBitmapSize;

	public static long disruptionTime = GraphUtils.MINUTE * 3;

	public enum COLOR {
		RED_MIN, YELLOW_MIN, GREEN_MIN, GREEN_MAX, YELLOW_MAX, RED_MAX, COLOR_MAX, COLOR_MIN
	}

	public enum DIRECTION {
		ASCENDANT, DESCENDANT
	}

	public static float getTextSize(String text, int maxWidth, int maxHeight,
			Paint paint) {

		float textSize = 0f;
		paint.setStyle(Paint.Style.FILL);
		paint.setTextSize(textSize);
		paint.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

		int width, height;
		while (true) {
			textSize += 0.25f;
			paint.setTextSize(textSize);

			Rect rect = measureText(text, paint);
			width = rect.width();
			height = rect.height();
			if ((maxWidth == 0 || width >= maxWidth)
					&& (maxHeight == 0 || height >= maxHeight)) {
				textSize -= 0.25f;

				if (textSize < 25)
					return textSize;
				else
					return 25;
			}
		}
	}

	public static Rect measureText(String text, Paint paint) {
		Rect rect = new Rect();
		paint.getTextBounds(text, 0, text.length(), rect);
		return rect;
	}

	public static float getPositionYForGlucose(int value, Rect rect) {

		return (float) (value * rect.height())
				/ (float) (glucoseMaximumLevel - glucoseMinimumLevel);
	}

	public static COLOR getGlucoseLevelColor(int value, DIRECTION direction) {

		int v1 = -1, v2 = -1;

		if (direction == DIRECTION.ASCENDANT)

			for (Map.Entry<Integer, COLOR> entry : glucoseLevels.entrySet()) {
				v2 = entry.getKey();

				if (v1 != -1)
					if (value >= v1 && value < v2)
						return glucoseLevels.get(v1);
				v1 = v2;
			}

		if (direction == DIRECTION.DESCENDANT)

			for (Map.Entry<Integer, COLOR> entry : glucoseLevels.entrySet()) {
				v2 = entry.getKey();

				if (v1 != -1)
					if (value > v1 && value <= v2)
						return glucoseLevels.get(v1);
				v1 = v2;
			}

		return COLOR.GREEN_MIN;
	}

	public static int getGlucoseLevelBetween(float y1, float y2, Rect rect) {

		if (y1 < y2) { // --> ASCENDANT

			for (Map.Entry<Integer, COLOR> entry : glucoseLevels.entrySet()) {
				int level = entry.getKey();
				if (y1 == level)
					return level;
				if (y1 < level && y2 >= level)
					return level;
			}
		}

		if (y1 > y2) { // --> DESCENDANT

			Map<Integer, COLOR> reversedMap = new TreeMap<Integer, COLOR>(
					Collections.reverseOrder());
			reversedMap.putAll(glucoseLevels);
			for (Map.Entry<Integer, COLOR> entry : reversedMap.entrySet()) {
				int level = entry.getKey();
				if (y1 == level)
					return level;
				if (y1 > level && y2 <= level)
					return level;
			}
		}
		return 0;
	}

	public static float getXOnLine(float lineStartX, float lineStartY,
			float lineEndX, float lineEndY, float Y) {

		if (lineStartX == lineEndX)
			return lineEndX;

		float m = (lineEndY - lineStartY) / (lineEndX - lineStartX);
		float x = (Y - lineStartY + m * lineStartX) / m;

		return x;
	}

	public static float getYOnLine(float lineStartX, float lineStartY,
			float lineEndX, float lineEndY, float X) {

		if (lineStartY == lineEndY)
			return lineEndY;

		float m = (lineEndY - lineStartY) / (lineEndX - lineStartX);
		float y = m * X - m * lineStartX + lineStartY;
		return y;
	}

	public static long getDiffTime() {
		int percent = (int) ((viewportSize * 100) / (maxViewPortSize - minViewPortSize));
        long diffTime = GraphUtils.MINUTE;

        //Log.d("graphing","diffTime:"+diffTime + " | glucoseDataInterval:"+glucoseDataInterval);

		if (diffTime != glucoseDataInterval)
			glucoseDataIntervalChanged = true;

		return diffTime;
	}

	public static int getColorId(COLOR color) {
		switch (color) {

		case YELLOW_MAX:
			return R.color.graph_red_alpha;
		case YELLOW_MIN:
		case GREEN_MAX:
			return R.color.graph_yellow_alpha;
		case RED_MIN:
		case RED_MAX:
			return R.color.graph_red_alpha;
		case GREEN_MIN:
			return R.color.graph_green_alpha;
		case COLOR_MAX:
		case COLOR_MIN:
			return R.color.graph_red_alpha;
		default:
			return android.R.color.black;
		}
	}

	public static int getLineColorId(COLOR color) {
		switch (color) {

		case YELLOW_MIN:
		case YELLOW_MAX:
			return R.color.graph_red;
		case COLOR_MAX:
		case COLOR_MIN:
			return R.color.transparent;
		case RED_MIN:
		case RED_MAX:
			return R.color.transparent;
		case GREEN_MIN:
		case GREEN_MAX:
			return R.color.graph_green;
		default:
			return android.R.color.black;
		}
	}

	public static String getTime(Calendar calendar) {
		return (String) DateFormat.format("hh:mm a", calendar);
	}

	public static int getDayCountInMonth(int year, int month) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, month);
		return calendar.getActualMaximum(Calendar.DATE);
	}

	public static String getMonthName(int month) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, month);

		return (String) DateFormat.format("MMMM", calendar.getTime());
	}

	// Utility function for converting onScreenX to global X which is same as getX() in Glucose.java
	public static float getCurrentPointXfromOnScreenX(float xOnScreen, double maxX, double minX, float graphwidth) {
		double diffX = maxX - minX;

		float ratX = xOnScreen / graphwidth;
		float valX = (float)(ratX * diffX);
		float currentPointX = (float)(valX + minX);

		return currentPointX;
	}

	public static Calendar getCalendarFromPositionX(int width, Calendar startDate,
									 Calendar endDate, float x) {

		long startSeconds = startDate.getTimeInMillis() / 1000;
		long endSeconds = endDate.getTimeInMillis() / 1000;

		long secondsDisplayed = endSeconds - startSeconds;
		float secondWidth = (float) width / secondsDisplayed;

		long time = (long)(x / secondWidth);
		long timeInSeconds = time + startSeconds;
		long timeInMills = timeInSeconds * 1000;

		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(timeInMills);

		return currentDate;
	}

	public static float getPositionX(int width, long startDate, long endDate, long currentDate) {
		// int endDateOffset = endDate.get(Calendar.DST_OFFSET);
		long startSeconds = startDate / 1000;
		long endSeconds = endDate / 1000;
		long timeInSeconds = currentDate / 1000;

		long time = timeInSeconds - startSeconds;
		long secondsDisplayed = endSeconds - startSeconds;
		float secondWidth = (float) width / secondsDisplayed;

		return secondWidth * time;
	}

	public static float getPositionX(int width, Calendar startDate,
			Calendar endDate, Calendar currentDate) {

		// int endDateOffset = endDate.get(Calendar.DST_OFFSET);

		long startSeconds = startDate.getTimeInMillis() / 1000;
		long endSeconds = endDate.getTimeInMillis() / 1000;
		long timeInSeconds = currentDate.getTimeInMillis() / 1000;

		long time = timeInSeconds - startSeconds;
		long secondsDisplayed = endSeconds - startSeconds;
		float secondWidth = (float) width / secondsDisplayed;

		return secondWidth * time;
	}

	public static Calendar getDateForPositionX(int width, Calendar startDate,
			Calendar endDate, float currentX) {

		// Log.d(" width startDate endDate currentDate", width + " "
		// + DateFormat.format("dd/MM/yyyy", startDate).toString() + " "
		// + DateFormat.format("dd/MM/yyyy", endDate).toString() + " "
		// + DateFormat.format("dd/MM/yyyy", currentDate).toString());

		long startSeconds = startDate.getTimeInMillis() / 1000;
		long endSeconds = endDate.getTimeInMillis() / 1000;

		long secondsDisplayed = endSeconds - startSeconds;
		float secondWidth = (float) width / secondsDisplayed;

		// Log.d("x", " " + secondWidth * time);
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis((long) ((startSeconds + (currentX / secondWidth)) * 1000));
		return calendar;
	}

	// ---------------------- Events ---------------------------------

	public static float convertPixelsToDp(float px, Context context) {
		Resources resources = context.getResources();
		DisplayMetrics metrics = resources.getDisplayMetrics();
		float dp = px / (metrics.densityDpi / 160f);
		return dp;
	}

	public static void loadBitmaps(Context context, int width) {

		width = (int) convertPixelsToDp(width, context);

		// Calculate the event and disruption icon sizes based on screen size.
		// Bigger size for the calibration icon
		eventBitmapSize = width / 14;
		eventBitmapSize = (int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, eventBitmapSize, context
						.getResources().getDisplayMetrics());
		
		disruptionBitmapSize = width / 16 / 3;
		disruptionBitmapSize = (int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, disruptionBitmapSize, context
						.getResources().getDisplayMetrics());

		Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_calibrate);
		GraphUtils.calibrationEventBitmapRed = Bitmap.createScaledBitmap(
				bitmap, eventBitmapSize, eventBitmapSize, true);

		// Calculate the event and disruption icon sizes based on screen size.
		// Smaller size for other icons
		eventBitmapSize = width / 16;
		eventBitmapSize = (int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, eventBitmapSize, context
						.getResources().getDisplayMetrics());
		
		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_glucose);
		GraphUtils.calibrationEventBitmapBlue = Bitmap.createScaledBitmap(
				bitmap, eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_multi);
		GraphUtils.groupEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_glucose);
		GraphUtils.glucoseEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_meal);
		GraphUtils.mealEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_insulin);
		GraphUtils.insulinEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_health);
		GraphUtils.healthEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.icon_graph_exercise);
		GraphUtils.exerciseEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.alert_icon_yellow);
		GraphUtils.alertEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.alert_icon_yellow); /** #3214 */ //alarm_icon_red);
				GraphUtils.alarmEventBitmap = Bitmap.createScaledBitmap(bitmap,
						eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.disruption_icon);
		GraphUtils.disruptionBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize / 2, eventBitmapSize / 2, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.alert_icon_yellow); /** #3214 */ //alarm_icon_red);
		GraphUtils.alarmEventBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.alert_dropping);
		GraphUtils.predFallingBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.alert_rising);
		GraphUtils.predRisingBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.disruption_icon);
		GraphUtils.disruptionBitmap = Bitmap.createScaledBitmap(bitmap,
				disruptionBitmapSize, disruptionBitmapSize, true);

		bitmap = BitmapFactory.decodeResource(context.getResources(), /** #3224 */
				R.drawable.icon_edr_alert);
		GraphUtils.edrAlertBitmap = Bitmap.createScaledBitmap(bitmap,
				eventBitmapSize, eventBitmapSize, true);

		bitmap.recycle();
	}

	public static Bitmap getBitmapForEvent(EventPoint event) {

		EVENT_TYPE eventType = event.getEventType();
		switch (eventType) {
		case CALIBRATION:
			CalibrationEventPoint calibrationEvent = (CalibrationEventPoint) event;
			if (calibrationEvent.isCalibrationUsed())
				return calibrationEventBitmapRed;
			else
				return calibrationEventBitmapBlue;
		case GROUP_EVENT:
			return groupEventBitmap;
		case GLUCOSE_EVENT:
			return glucoseEventBitmap;
		case MEAL_EVENT:
			return mealEventBitmap;
		case INSULIN_EVENT:
			return insulinEventBitmap;
		case HEALTH_EVENT:
			return healthEventBitmap;
		case EXERCISE_EVENT:
			return exerciseEventBitmap;
		case PREDICTIVE_ALERT_EVENT_FALLING:
			return predFallingBitmap;
		case PREDICTIVE_ALERT_EVENT_RISING:
			return predRisingBitmap;
		case RATE_ALERT_EVENT_FALLING:
			return predFallingBitmap;
		case RATE_ALERT_EVENT_RISING:
			return predRisingBitmap;
		case ALERT_EVENT:
			return alertEventBitmap;
		case ALARM_EVENT:
		case NOTIFICATION_EVENT_RED:
			return alarmEventBitmap;

		case NOTIFICATION_EVENT_YELLOW:
			Utils.TransmitterMessageCode msgCodeYellow = event.getNotificationEventType();
			if (msgCodeYellow == Utils.TransmitterMessageCode.EDRAlarm4) { /** #3920 */
				return edrAlertBitmap;
			}

		default:
			return null;
		}
	}
}
