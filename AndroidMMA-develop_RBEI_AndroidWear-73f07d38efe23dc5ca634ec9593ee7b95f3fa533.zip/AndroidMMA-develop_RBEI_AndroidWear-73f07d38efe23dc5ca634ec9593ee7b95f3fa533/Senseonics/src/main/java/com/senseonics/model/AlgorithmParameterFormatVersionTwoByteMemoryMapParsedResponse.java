package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class AlgorithmParameterFormatVersionTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public AlgorithmParameterFormatVersionTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.algorithmParameterFormatVersion;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int value = dataOne | (dataTwo << 8);
        Log.d("Algo format version", "Received from Tx: " + value);
        model.setAlgorithmParameterFormatVersion(value);
    }
}
