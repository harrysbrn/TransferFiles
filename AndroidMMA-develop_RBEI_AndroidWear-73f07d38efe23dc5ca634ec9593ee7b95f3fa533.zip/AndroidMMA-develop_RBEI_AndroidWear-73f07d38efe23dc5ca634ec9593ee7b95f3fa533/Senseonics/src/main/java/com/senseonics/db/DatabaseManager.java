package com.senseonics.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.util.Log;
import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.events.EventUtils;
import com.senseonics.events.EventUtils.EXERCISE_INTENSITY;
import com.senseonics.events.EventUtils.HEALTH_CONDITION;
import com.senseonics.events.EventUtils.HEALTH_SEVERITY;
import com.senseonics.events.EventUtils.INSULIN_TYPE;
import com.senseonics.events.EventUtils.MEAL_TYPE;
import com.senseonics.events.ExerciseEventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.HealthEventPoint;
import com.senseonics.events.InsulinEventPoint;
import com.senseonics.events.MealEventPoint;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Notification;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.ALERT_TYPE;
import com.senseonics.util.Utils.EVENT_TYPE;
import com.senseonics.util.Utils.GLUCOSE_TYPE;
import com.senseonics.util.Utils.TransmitterMessageCode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class DatabaseManager {

	private SenseonicsDBHelper sqlLiteHelper;
	private SQLiteDatabase database;
	private long threeDaysTimestamp = 0;
	private long ninetyDaysTimestamp = 0;


	public DatabaseManager(Context context) {
		sqlLiteHelper = new SenseonicsDBHelper(context);

		Calendar calThreeDaysBack = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		calThreeDaysBack.add(Calendar.DAY_OF_YEAR, - 3);
		threeDaysTimestamp = calThreeDaysBack.getTimeInMillis();

		Calendar calNinetyDaysBack = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		calNinetyDaysBack.add(Calendar.DAY_OF_YEAR, - 90);
		ninetyDaysTimestamp = calNinetyDaysBack.getTimeInMillis();
	}

	public void open() throws SQLException {
		database = sqlLiteHelper.getWritableDatabase();
	}

	public void close() {
		sqlLiteHelper.close();
	}

	// -------------------- glucose readings -------------------------------
	public class GroupInfo {
		private int startRecordNr, endRecordNr;

		public GroupInfo(int startRecordNr, int endRecordNr) {
			super();
			this.setStartRecordNr(startRecordNr);
			this.setEndRecordNr(endRecordNr);
		}

		public int getStartRecordNr() {
			return startRecordNr;
		}

		public void setStartRecordNr(int startRecordNr) {
			this.startRecordNr = startRecordNr;
		}

		public int getEndRecordNr() {
			return endRecordNr;
		}

		public void setEndRecordNr(int endRecordNr) {
			this.endRecordNr = endRecordNr;
		}
	}

	public boolean allowAddingGlucoseReading(long timestamp, int recordNo) {
		if((timestamp <= ninetyDaysTimestamp)) /** Prepare Sync might request data that are more than 3 days old which results in duplicated sync */
		{
			return false;
		}
		if (glucoseTimestampExists(timestamp) && recordNumberExists(recordNo)) {
			// Do not add glucose point
			Log.d("Add Glucose Database", "DO NOT ADD " + timestamp + "|record:" + recordNo);
			return false;
		}
		else {
			Log.d("Add Glucose Database", "ADD NEW " + timestamp + "|record:" + recordNo);
			return true;
		}
	}

	public boolean glucoseTimestampExists(long timestampToCheck) {
		long distance = 1 * GraphUtils.SECOND;
		long timestampStart = timestampToCheck - distance;
		long timestampEnd = timestampToCheck + distance;

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND " +
				SenseonicsDBHelper.TIMESTAMP_FIELD + " <= ?";
		String[] whereArgs = new String[] { String.valueOf(timestampStart), String.valueOf(timestampEnd) };

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						SenseonicsDBHelper.TIMESTAMP_FIELD}, whereClause,
				whereArgs, null, null, null);

		if (cursor.getCount() >= 1) {
			cursor.moveToFirst();

			long timestampFromCursor = cursor.getLong(0);
			Log.d("Add Glucose Database", "Glucose timestamp exists " + timestampFromCursor + " --------------");
			cursor.close();
			return true;
		}
		cursor.close();
		return false;
	}

	public ArrayList<Glucose> getGlucoseNear(int recordNumber) {

		int v1 = recordNumber - 1;
		int v2 = recordNumber + 1;
		String value = "(" + v1 + "," + v2 + ")";

		String whereClause = SenseonicsDBHelper.RECORD_NUMBER_FIELD + " IN "
				+ value;

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.GROUP_ID_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD }, whereClause,
				null, null, null, SenseonicsDBHelper.TIMESTAMP_FIELD, null);

		ArrayList<Glucose> glucosePoints = new ArrayList<Glucose>();
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				glucosePoints.add(getGlucose(cursor));
			} while (cursor.moveToNext());
		}
		cursor.close();
		return glucosePoints;
	}

	public int getMaxGroupId() {

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE,
				new String[] { "max( " + SenseonicsDBHelper.GROUP_ID_FIELD
						+ " )" }, null, null, null, null, null, null);

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			int value = cursor.getInt(0);
			cursor.close();
			return value;
		} else {
			cursor.close();
			return 0;
		}
	}

	public void changeGroupId(int fromId, int toId) {

		ContentValues values = new ContentValues();
		values.put(SenseonicsDBHelper.GROUP_ID_FIELD, toId);
		String whereClause = SenseonicsDBHelper.GROUP_ID_FIELD + " = ? ";
		String[] whereArgs = new String[] { String.valueOf(fromId) };

		database.update(SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, values,
				whereClause, whereArgs);
	}

	public void addReadingInGMT(Glucose glucose) throws SQLException {
		Log.d(DatabaseManager.class.getSimpleName(), "addReadingInGMT " + glucose);
        ContentValues values = new ContentValues();
		values.put(SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD, glucose.getGlucoseLevel());
		values.put(SenseonicsDBHelper.TIMESTAMP_FIELD, glucose.getTimestamp());
		values.put(SenseonicsDBHelper.RECORD_NUMBER_FIELD, glucose.getRecordNumber());
		/** #3194 */
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_1_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_2_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_3_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_4_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_5_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_6_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_7_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7));
		values.put(SenseonicsDBHelper.GLUCOSE_RAW_8_FIELD, glucose.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8));

		// Get glucose records next to current glucose
        ArrayList<Glucose> glucosePoints = getGlucoseNear(glucose.getRecordNumber());
        int groupId = 0;
        if (glucosePoints != null && glucosePoints.size() > 0) {
            if (glucosePoints.size() == 1) {
                values.put(SenseonicsDBHelper.GROUP_ID_FIELD, glucosePoints.get(0).getGroupId());
            } else {
                groupId = glucosePoints.get(0).getGroupId();
                values.put(SenseonicsDBHelper.GROUP_ID_FIELD, groupId);
                for (int i = 1; i < glucosePoints.size(); ++i) {
                    changeGroupId(glucosePoints.get(i).getGroupId(), groupId);
                }
            }
        } else {
            groupId = getMaxGroupId() + 1;
            values.put(SenseonicsDBHelper.GROUP_ID_FIELD, groupId);
        }

		try {
			long id = database.insertOrThrow(SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, null, values);
            Log.d(DatabaseManager.class.getSimpleName(), "GLUCOSE ADDED: row: " + id + ", groupId: " + glucose.getGroupId() + ", thread: " + Thread.currentThread().getName() + ", " + glucose);
		} catch (SQLException e) {
			Log.e("SQLException", e.getMessage());
		}

	}

	public Glucose getGlucose(Cursor cursor) {
		int glucoseLevel = cursor.getInt(0);

		Calendar calendar = Calendar.getInstance();
		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		// convert GMT time to in default time
		long timestamp = cursor.getLong(1) + timeZoneDiff;
		int groupId = cursor.getInt(2);
		int recordNumber = cursor.getInt(3);

		return new Glucose(timestamp, glucoseLevel, groupId, recordNumber);
	}

	public int getGlucoseLevelAt(Calendar cal, boolean gmtTime) {
		long time;
		if (!gmtTime) {
			// convert default time to GMT
			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(cal.getTimeInMillis());
			long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
			time = calendar.getTimeInMillis() - timeZoneDiff;
			calendar.setTimeInMillis(time);
			long DSToffset = calendar.get(Calendar.DST_OFFSET);
			time -= DSToffset;
		} else
			time = cal.getTimeInMillis();
		long start = time - GraphUtils.MINUTE * 6;
		long end = time + GraphUtils.MINUTE * 6;

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " < ?";
		String[] whereArgs = new String[] { String.valueOf(start),
				String.valueOf(end) };
		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[]{
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD}, whereClause,
				whereArgs, null, null, null);

		int glucoseLevel = -1;
		long closestTimestamp = GraphUtils.MINUTE * 6;

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				long timestamp = cursor.getLong(1);

				Calendar glucoseCal = Calendar.getInstance();
				glucoseCal.setTimeInMillis(timestamp);
				glucoseCal.setTimeZone(TimeZone.getDefault());

				if (Math.abs(time - timestamp) < closestTimestamp) {
					closestTimestamp = Math.abs(time - timestamp);
					if(cursor.getInt(0) >= Utils.GLUCOSE_VALID_MIN && cursor.getInt(0) <= Utils.GLUCOSE_VALID_MAX) {
						glucoseLevel = cursor.getInt(0);
					}
				}
			} while (cursor.moveToNext());
		}
		Log.d("GLUCOSE LEVEL ", glucoseLevel + " ");
		cursor.close();
		return glucoseLevel;
	}

	public void refreshGroupIds() {

		String minTimestamp = "MIN(" + SenseonicsDBHelper.TIMESTAMP_FIELD + ")";
		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[]{
						minTimestamp, SenseonicsDBHelper.GROUP_ID_FIELD},
				null, null, SenseonicsDBHelper.GROUP_ID_FIELD, null,
				minTimestamp);

		int xId = -2, position = 0;

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				// long timestamp = cursor.getLong(0);
				int id = cursor.getInt(1);
				if (id != position) {
					changeGroupId(position, xId);
					changeGroupId(id, position);
					changeGroupId(xId, id);
				}
				++position;
				// Log.d(" GROUP MIN TIMESTAMP AND ID", timestamp + " " + id +
				// " "
				// + "position");
			} while (cursor.moveToNext());
		}
		cursor.close();
		//
	}

	public Glucose getGlucosePointWithMaxRecordNumberSinceTime(long timeStampStart) {
		Log.d("Sync_max_record_glucose", "timestamp In:" + timeStampStart);

		// timeStampStart might be 0 -> fetch all records
		String newWhereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " > ?";
		String[] whereArgs = new String[] { String.valueOf(timeStampStart) };
		String orderByString = SenseonicsDBHelper.RECORD_NUMBER_FIELD + " ASC";

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.GROUP_ID_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD }, newWhereClause,
				whereArgs, null, null, orderByString);

		Glucose retGlucose = null;
		if (cursor.moveToLast()) {
			int glucoseLevel = cursor.getInt(0);
			// convert GMT time to default time
			long timestamp = cursor.getLong(1);
			int groupId = cursor.getInt(2);
			int recordNumber = cursor.getInt(3);
			retGlucose = new Glucose(timestamp, glucoseLevel, groupId,
					recordNumber);
		}
		cursor.close();
		return retGlucose;
	}

	public ArrayList<GroupInfo> getGroups(long firstRecordNr, long lastRecordNr, long timestampMin) {
		ArrayList<GroupInfo> groupInfos = new ArrayList<DatabaseManager.GroupInfo>();

		try {
			refreshGroupIds();

			String whereString = SenseonicsDBHelper.RECORD_NUMBER_FIELD
					+ " >= " + firstRecordNr + " AND "
					+ SenseonicsDBHelper.RECORD_NUMBER_FIELD + " <= "
					+ lastRecordNr;

			if (timestampMin > 0L) {
				whereString += " AND " + SenseonicsDBHelper.TIMESTAMP_FIELD + " > " + timestampMin;
			}
			Log.d("Sync_getgroup", "whereString:" + whereString);

			Cursor cursor = database.query(
					SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
							"MIN(" + SenseonicsDBHelper.RECORD_NUMBER_FIELD
									+ ")",
							"MAX(" + SenseonicsDBHelper.RECORD_NUMBER_FIELD
									+ ")" }, whereString, null,
					SenseonicsDBHelper.GROUP_ID_FIELD, null,
					SenseonicsDBHelper.RECORD_NUMBER_FIELD);

			if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
				do {
					int recordNr1 = cursor.getInt(0);
					int recordNr2 = cursor.getInt(1);
					groupInfos.add(new GroupInfo(recordNr1, recordNr2));

					Log.d("DATABASE GROUPS :", recordNr1 + " -> " + recordNr2);
				} while (cursor.moveToNext());
			}
			cursor.close();
		} catch (IllegalStateException e) {
			if (e != null && e.getMessage() != null) {
				Log.d("Senseonics", e.getMessage());
			}
		}
		return groupInfos;
	}

	public List<List<Glucose>> getGlucoseBetween(Calendar startDate,
			Calendar endDate, long timeDiff) {

		long start = startDate.getTimeInMillis();
		long end = endDate.getTimeInMillis();

		String groupBy = "( " + SenseonicsDBHelper.TIMESTAMP_FIELD + " / "
				+ timeDiff + " ) ";
		// , " + SenseonicsDBHelper.GROUP_ID_FIELD

		String havingString = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= "
				+ start + " AND " + SenseonicsDBHelper.TIMESTAMP_FIELD + " < "
				+ end;

		String whereString = SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
				+ Utils.GLUCOSE_MIN + " AND "
				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
				+ Utils.GLUCOSE_MAX;

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						" AVG ( " + SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
								+ " )",
						" AVG ( " + SenseonicsDBHelper.TIMESTAMP_FIELD + " )",
						SenseonicsDBHelper.GROUP_ID_FIELD }, whereString, null,
				groupBy, havingString, SenseonicsDBHelper.TIMESTAMP_FIELD);

		ArrayList<List<Glucose>> readings = new ArrayList<>();
		ArrayList<Glucose> glucosePoints = new ArrayList<>();
		long lastGlucoseTime = 0;
		// int id = -1;
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {

				int glucoseLevel = (int) cursor.getFloat(0);
				// convert GMT time to default time
				long timestamp = cursor.getLong(1);

				Calendar calendar = Calendar.getInstance();
				calendar.setTimeInMillis(timestamp);

                // #1980 set if the timeDiff is greater than x mins, form a new section
				if (timestamp - lastGlucoseTime > timeDiff * GraphUtils.GRAPH_CONNECTING_INTERVAL) {
//                    Log.i("Graph Gap Debug","timeDiff:"+timeDiff);
					lastGlucoseTime = timestamp;
					// id = groupId;
					if (glucosePoints.size() > 0) {
						readings.add(glucosePoints);
						glucosePoints = new ArrayList<Glucose>();
					}
				} else
					lastGlucoseTime = timestamp;
				glucosePoints.add(new Glucose(timestamp, glucoseLevel, 0, 0));

			} while (cursor.moveToNext());
		}

		if (glucosePoints.size() > 0) {
			readings.add(glucosePoints);
		}
		cursor.close();
		return readings;
	}
	
	private String getStatisticsBetweenWhereClause (MealTimeDataHandler.MealType mealType, int minGlucoseLevel,
													int maxGlucoseLevel, Context context, String tabId) {
		MealTimeDataHandler mealTimeDataHandler = new MealTimeDataHandler(context);

		long startTimestampInSec = 0, endTimestampInSec = 0;
		int minutesInSeconds = 60;
		int hourInSeconds = 60 * 60;
		switch (mealType) {

			case BREAKFAST:
				startTimestampInSec = (mealTimeDataHandler.getBreakfastStartHour() * hourInSeconds) + (mealTimeDataHandler.getBreakfastStartMinute() * minutesInSeconds);
				endTimestampInSec = (mealTimeDataHandler.getBreakfastEndHour() * hourInSeconds) + (mealTimeDataHandler.getBreakfastEndMinute() * minutesInSeconds);
				break;
			case LUNCH:
				startTimestampInSec = (mealTimeDataHandler.getLunchStartHour() * hourInSeconds) + (mealTimeDataHandler.getLunchStartMinute() * minutesInSeconds);
				endTimestampInSec = (mealTimeDataHandler.getLunchEndHour() * hourInSeconds) + (mealTimeDataHandler.getLunchEndMinute() * minutesInSeconds);
				break;
			case SNACK:
				startTimestampInSec = (mealTimeDataHandler.getSnackStartHour() * hourInSeconds) + (mealTimeDataHandler.getSnackStartMinute() * minutesInSeconds);
				endTimestampInSec = (mealTimeDataHandler.getSnackEndHour() * hourInSeconds) + (mealTimeDataHandler.getSnackEndMinute() * minutesInSeconds);
				break;
			case DINNER:
				startTimestampInSec = (mealTimeDataHandler.getDinnerStartHour() * hourInSeconds) + (mealTimeDataHandler.getDinnerStartMinute() * minutesInSeconds);
				endTimestampInSec = (mealTimeDataHandler.getDinnerEndHour() * hourInSeconds) + (mealTimeDataHandler.getDinnerEndMinute() * minutesInSeconds);
				break;
			case SLEEP:
				startTimestampInSec = (mealTimeDataHandler.getSleepStartHour() * hourInSeconds) + (mealTimeDataHandler.getSleepStartMinute() * minutesInSeconds);
				endTimestampInSec = (mealTimeDataHandler.getSleepEndHour() * hourInSeconds) + (mealTimeDataHandler.getSleepEndtMinute() * minutesInSeconds);
				break;
			case ALL:
				startTimestampInSec = 0;
				endTimestampInSec = 24 * 60 * 60 * 1000-1;
				break;
		}

		long timeZoneDiff = Utils.getTimeZoneOffset(Calendar.getInstance());
		long DSToffset = Calendar.getInstance().get(Calendar.DST_OFFSET);
		long startHourInMilliActual = startTimestampInSec * 1000 - timeZoneDiff - DSToffset;
		long endHourInMillisActual = endTimestampInSec * 1000 - timeZoneDiff - DSToffset;

		Calendar startHour = Calendar.getInstance();
		startHour.setTimeInMillis(startHourInMilliActual);


		long lastTime = 24 * 60 * 60 * 1000-1;
		long firstTime = 0;
		if(mealType == MealTimeDataHandler.MealType.ALL)
		{
			endHourInMillisActual = lastTime;
		}
		String newWhereClause="";

			if(mealType == MealTimeDataHandler.MealType.ALL) {

				newWhereClause = "(datetime(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN datetime('now', '" + tabId + " day') AND datetime('now')) AND "
						+SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
						+ minGlucoseLevel + " AND "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
						+ maxGlucoseLevel;
			}
			else {

			long modBase = 24 * 60 * 60 * 1000;
			// Remove the negative number and number bigger than modBase
			startHourInMilliActual = ((startHourInMilliActual % modBase) + modBase) % modBase;
			endHourInMillisActual = ((endHourInMillisActual % modBase) + modBase) % modBase;

			if (startHourInMilliActual <= endHourInMillisActual) {
				newWhereClause = "(datetime(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN datetime('now', '" + tabId + " day') AND datetime('now')) AND "
						+ " time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN time(" + startHourInMilliActual + "/1000,'unixepoch') AND time(" + endHourInMillisActual + "/1000,'unixepoch') AND "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
						+ minGlucoseLevel + " AND "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
						+ maxGlucoseLevel;
			} else {

				newWhereClause =  "(datetime(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN datetime('now', '" + tabId + " day') AND datetime('now')) AND "
						+ " ((time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN time(" + startHourInMilliActual + "/1000,'unixepoch') AND time(" + lastTime + "/1000,'unixepoch')) OR "
						+ " (time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
						+ " BETWEEN time(" + firstTime + "/1000,'unixepoch') AND time(" + endHourInMillisActual + "/1000,'unixepoch'))) AND "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
						+ minGlucoseLevel + " AND "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
						+ maxGlucoseLevel;
			}
		}
		Log.i("NewWhereClause", "newWhere:" + newWhereClause);
		return newWhereClause;
	}

	private String getStatisticsBetweenWhereClause (int hour, int minGlucoseLevel,
													int maxGlucoseLevel, Context context, String tabId) {

		long startTimestampInSec = 0, endTimestampInSec = 0;
		int minutesInSeconds = 60;
		int hourInSeconds = 60 * 60;

		startTimestampInSec = (hour * hourInSeconds);


		endTimestampInSec = ((hour+1) * hourInSeconds);

		long timeZoneDiff = Utils.getTimeZoneOffset(Calendar.getInstance());
		long DSToffset = Calendar.getInstance().get(Calendar.DST_OFFSET);
		long startHourInMilliActual = startTimestampInSec * 1000 - timeZoneDiff - DSToffset;
		long endHourInMillisActual = endTimestampInSec * 1000 - timeZoneDiff - DSToffset;

		Calendar startHour = Calendar.getInstance();
		startHour.setTimeInMillis(startHourInMilliActual);
		long lastTime = 24 * 60 * 60 * 1000;

		String newWhereClause="";

		if(endHourInMillisActual == lastTime)
		{
			endHourInMillisActual = lastTime -1;
		}

		long modBase = lastTime;
		// Remove the negative number and number bigger than modBase
		startHourInMilliActual = ((startHourInMilliActual % modBase) + modBase) % modBase;
		endHourInMillisActual = ((endHourInMillisActual % modBase) + modBase) % modBase;

		if (startHourInMilliActual <= endHourInMillisActual) {
			newWhereClause = "(datetime(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN datetime('now', '" + tabId + " day') AND datetime('now')) AND "
					+ " time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN time(" + startHourInMilliActual + "/1000,'unixepoch') AND time(" + endHourInMillisActual + "/1000,'unixepoch') AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
					+ minGlucoseLevel + " AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
					+ maxGlucoseLevel;
		}
		else {
			lastTime = lastTime - 1;
			long firstTime = 0;

			newWhereClause =  "(datetime(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN datetime('now', '" + tabId + " day') AND datetime('now')) AND "
					+ " ((time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN time(" + startHourInMilliActual + "/1000,'unixepoch') AND time(" + lastTime + "/1000,'unixepoch')) OR "
					+ " (time(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN time(" + firstTime + "/1000,'unixepoch') AND time(" + endHourInMillisActual + "/1000,'unixepoch'))) AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
					+ minGlucoseLevel + " AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
					+ maxGlucoseLevel;
		}
		return newWhereClause;
	}


	public double[] getStatisticsBetween(MealTimeDataHandler.MealType mealType, int minGlucoseLevel,
									  int maxGlucoseLevel, Context context, String tabId) {
		double[] statistics = new double[5];

		String newWhereClause = getStatisticsBetweenWhereClause(mealType, minGlucoseLevel,
				maxGlucoseLevel, context, tabId);

		String sql = "select AVG( "+SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD+"), " +
				"MIN( " +SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD+ "), " +
				"MAX( "+SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD+" ), " +
				"COUNT( " +SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD+ "), " +
				"AVG ((glucosereadings.glucoseLevel - sub.a) * (glucosereadings.glucoseLevel " +
				"- sub.a)) as var from glucosereadings, " +
				"(SELECT AVG("+SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD+")  as a FROM " + SenseonicsDBHelper.GLUCOSE_READINGS_TABLE +" where "+ newWhereClause +" ) AS sub " +
				"where " + newWhereClause;

		Cursor cursor = database.rawQuery(sql, null);

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			int count = cursor.getInt(3);
			if (count > 0) {
				statistics[0] = (int) cursor.getFloat(0);
				statistics[1] = cursor.getInt(1);
				statistics[2] = cursor.getInt(2);
				statistics[3] = cursor.getInt(3);
				statistics[4] = cursor.getInt(4);
				cursor.close();
				return statistics;
			}
		}
		cursor.close();

		return null;
	}


	public int[] getStatisticsBetween(int hour, int minGlucoseLevel,
									  int maxGlucoseLevel, Context context, String tabId) {
		int[] statistics = new int[4];

		String newWhereClause = getStatisticsBetweenWhereClause(hour, minGlucoseLevel,
				maxGlucoseLevel, context, tabId);

		Cursor cursor = database
				.query(SenseonicsDBHelper.GLUCOSE_READINGS_TABLE,
						new String[]{

								"AVG( "
										+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
										+ " )",
								"MIN( "
										+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
										+ " )",
								"MAX( "
										+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
										+ " )",
								"COUNT( "
										+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
										+ " )"}, newWhereClause, null, null,
						null, null);

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			int count = cursor.getInt(3);
			if (count > 0) {
				statistics[0] = (int) cursor.getFloat(0);
				statistics[1] = cursor.getInt(1);
				statistics[2] = cursor.getInt(2);
				statistics[3] = cursor.getInt(3);
				cursor.close();
				return statistics;
			}
		}
		cursor.close();

		return null;
	}

	public List<Integer> getGlucoseArrayBetweenForReport(MealTimeDataHandler.MealType mealType, int minGlucoseLevel,
									  int maxGlucoseLevel, Context context, String tabId) {
		List<Integer> glucoseList = new ArrayList<Integer>();

		String newWhereClause = getStatisticsBetweenWhereClause(
				mealType, minGlucoseLevel,
				maxGlucoseLevel, context,tabId);

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[]{
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD
				}, newWhereClause,
				null, null, null, null);

		if (cursor.moveToFirst()) {
			for (int i = 0; i < cursor.getCount(); i++) {
				int glucoseLevel = cursor.getInt(0);
				glucoseList.add(glucoseLevel);
				cursor.moveToNext();
			}
		}

		cursor.close();

		return glucoseList;
	}

	public int getStatistics2Between(Calendar startCal, Calendar endCal,
			int higherThanLevel, int lowerThanLevel) {

		Calendar startDate = Calendar.getInstance();
		startDate.setTimeInMillis(startCal.getTimeInMillis());
		Calendar endDate = Calendar.getInstance();
		endDate.setTimeInMillis(endCal.getTimeInMillis());

		// convert default time to GMT
		long timeZoneDiff = Utils.getTimeZoneOffset(startDate);
		startDate.setTimeInMillis(startDate.getTimeInMillis() - timeZoneDiff);
		endDate.setTimeInMillis(endDate.getTimeInMillis() - timeZoneDiff);
		long DSToffsetStart = startDate.get(Calendar.DST_OFFSET);
		long DSToffsetEnd = endDate.get(Calendar.DST_OFFSET);
		long start = startDate.getTimeInMillis() - DSToffsetStart;
		long end = endDate.getTimeInMillis() - DSToffsetEnd;
		
//		long start = startDate.getTimeInMillis();
//		long end = endDate.getTimeInMillis();

		String newWhereClause = "";
			newWhereClause = "date(" + SenseonicsDBHelper.TIMESTAMP_FIELD + "/1000,'unixepoch')"
					+ " BETWEEN date(" + start + "/1000,'unixepoch') AND date(" + end + "/1000,'unixepoch') AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
					+ lowerThanLevel + " AND "
					+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
					+ higherThanLevel;


		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE,
				new String[]{"COUNT( "
						+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " )"},
				newWhereClause, null, null, null, null);

		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			int value = cursor.getInt(0);
			cursor.close();
			return value;
		}
		cursor.close();
		return 0;
	}

	public ArrayList<Glucose> getSensorLogsStartingFrom(Calendar startCal, Calendar endCal) {
		long start = getTimeMillsInDBfromCalendar(startCal);
		long end = getTimeMillsInDBfromCalendar(endCal);

		String newWhereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " <= ? AND "
				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= "
				+ 40 + " AND "
				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " <= "
				+ 400;
		String[] whereArgs = new String[] { String.valueOf(start),
				String.valueOf(end) };
		String orderByString = SenseonicsDBHelper.TIMESTAMP_FIELD + " ASC";

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.GROUP_ID_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_1_FIELD,/** #3194 */
						SenseonicsDBHelper.GLUCOSE_RAW_2_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_3_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_4_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_5_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_6_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_7_FIELD,
						SenseonicsDBHelper.GLUCOSE_RAW_8_FIELD
				}, newWhereClause,
				whereArgs, null, null, orderByString);

		ArrayList<Glucose> glucoselogs = new ArrayList<Glucose>();

		if (cursor.moveToFirst()) {
			for (int i = 0; i < cursor.getCount(); i++) {
				int glucoseLevel = cursor.getInt(0);
				// convert GMT time to default time
				long timestamp = cursor.getLong(1);
				int groupId = cursor.getInt(2);
				int recordNumber = cursor.getInt(3);
				int raw1 = cursor.getInt(4); /** #3194 */
				int raw2 = cursor.getInt(5);
				int raw3 = cursor.getInt(6);
				int raw4 = cursor.getInt(7);
				int raw5 = cursor.getInt(8);
				int raw6 = cursor.getInt(9);
				int raw7 = cursor.getInt(10);
				int raw8 = cursor.getInt(11);
				Glucose glucose = new Glucose(timestamp, glucoseLevel, groupId,
						recordNumber,
						new int[] {raw1, raw2, raw3, raw4, raw5, raw6, raw7, raw8});
				glucoselogs.add(glucose);

				cursor.moveToNext();
			}
		}

		cursor.close();

		return glucoselogs;
	}
	
	private Calendar getCalendarFromTimeStampInDatabase(long timeStamp){
		Calendar calendar = Calendar.getInstance();
		
	    calendar.setTimeInMillis(timeStamp);
	    calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		
		return calendar;
	}

	public ArrayList<EventPoint> getAllDMSEventPointsStartingFrom(Calendar startCal) {
		long start = getTimeMillsInDBfromCalendar(startCal);

		// Get ALL events
		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? ";
				
		String[] whereArgs = new String[] { String.valueOf(start) };
		String orderByString = SenseonicsDBHelper.TIMESTAMP_FIELD + " ASC";

		Cursor cursor = database.query(
				SenseonicsDBHelper.EVENTS_TABLE, new String[]{
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.EVENT_TYPE_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD,
						SenseonicsDBHelper.EVENT_SYNCED,
						SenseonicsDBHelper.EVENT_HIDDEN,
						SenseonicsDBHelper.TRANSMITTER_NAME,
						SenseonicsDBHelper.CUSTOM_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD2,
						SenseonicsDBHelper.UNKNOWN_ERROR_CODE
				}, whereClause,
				whereArgs, null, null, orderByString);

		ArrayList<EventPoint> allLogs = new ArrayList<EventPoint>();
		
		if (cursor.moveToFirst()) {
			for (int i = 0; i < cursor.getCount(); i++) {
				int glucoseLevel = cursor.getInt(0);
				// convert GMT time to default time
				long timestamp = cursor.getLong(1);
				EVENT_TYPE eventType = EVENT_TYPE.values()[cursor.getInt(2)];
				long recordNumber = cursor.getLong(3);
				boolean synced = (cursor.getInt(4)==SenseonicsDBHelper.SYNCED) ? true : false;
				boolean hidden = (cursor.getInt(5)==SenseonicsDBHelper.HIDDEN) ? true : false;
				String txName = cursor.getString(6);
				int customField = cursor.getInt(7);
				int customField2 = cursor.getInt(8);
				int unknownErrorCode = cursor.getInt(9);
				
				// note that the event point below has GMT calendar
				EventPoint event = new EventPoint(getCalendarFromTimeStampInDatabase(timestamp)
						, glucoseLevel, eventType, recordNumber, synced, hidden, txName
						, customField, customField2, unknownErrorCode);
				allLogs.add(event);
				
				cursor.moveToNext();				
			}
		}
		
		cursor.close();
		
		return allLogs;
	}
	
	public boolean recordNumberExists(int recordNumber) {

		String whereClause = SenseonicsDBHelper.RECORD_NUMBER_FIELD + " = ?";
		String[] whereArgs = new String[] { String.valueOf(recordNumber) };

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[]{
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD,
						SenseonicsDBHelper.GROUP_ID_FIELD}, whereClause,
				whereArgs, null, null, null);

		if (cursor.getCount() >= 1) {
			cursor.moveToFirst();

			int recordNumberFromCursor = cursor.getInt(2);
			int groupId = cursor.getInt(3);
			Log.d("Add Glucose Database", " record number exists " + recordNumberFromCursor + " --------------" + groupId);
			cursor.close();
			return true;
		}
		cursor.close();
		return false;

	}

	public Glucose getLatestGlucoseReading() {

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD
				+ " = ( select max(" + SenseonicsDBHelper.TIMESTAMP_FIELD
				+ ") from " + SenseonicsDBHelper.GLUCOSE_READINGS_TABLE + " )";

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[]{
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.GROUP_ID_FIELD,
						SenseonicsDBHelper.RECORD_NUMBER_FIELD}, whereClause,
				null, null, null, null);

		if (cursor.getCount() >= 1) {
			cursor.moveToFirst();
			Glucose glucose = getGlucose(cursor);
			cursor.close();
			return glucose;
		}
		cursor.close();
		return null;

	}

	public long getEarliestEventDate() {
		long earliestEventTime = getEarliestEventGMTTime();
		long earliestGlucoseTime = getEarliestGlucoseReadingGMTTime();

		if(earliestEventTime <= earliestGlucoseTime) {
			return earliestEventTime;
		}
		else {
			return earliestGlucoseTime;
		}
	}

	public long getEarliestEventGMTTime() {
		long retVal = Calendar.getInstance().getTimeInMillis();

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD
				+ " = ( select min(" + SenseonicsDBHelper.TIMESTAMP_FIELD
				+ ") from " + SenseonicsDBHelper.EVENTS_TABLE + " )";

		Cursor cursor = database.query(
				SenseonicsDBHelper.EVENTS_TABLE, new String[] {
						SenseonicsDBHelper.TIMESTAMP_FIELD}, whereClause,
				null, null, null, null);

		if (cursor.getCount() >= 1) {
			cursor.moveToFirst();
			retVal = cursor.getLong(0);
			Log.d("getEarliestEvent", "Timestamp: " + retVal + "--------------");
		}
		cursor.close();
		return retVal;
	}

	public long getEarliestGlucoseReadingGMTTime() {
		long retVal = Calendar.getInstance().getTimeInMillis();

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD
				+ " = ( select min(" + SenseonicsDBHelper.TIMESTAMP_FIELD
				+ ") from " + SenseonicsDBHelper.GLUCOSE_READINGS_TABLE + " )";

		Cursor cursor = database.query(
				SenseonicsDBHelper.GLUCOSE_READINGS_TABLE, new String[] {
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD}, whereClause,
				null, null, null, null);

		if (cursor.getCount() >= 1) {
			cursor.moveToFirst();
			retVal = cursor.getLong(0);
			Log.d("getEarliestGlucose", "Timestamp: " + retVal + " | glucose: " + cursor.getInt(1) + "--------------");
		}
		cursor.close();
		return retVal;
	}

	/** APPDEV-4032: retrieve match CalibrationEventPoint notes and store into GlucoseEventPoint since these CalibrationEventPoint will be hidden which takes the user entered notes away */
	public String hideCalibrationEventAndGetNotesDuringSync(CalibrationEventPoint event) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		calendar.setTimeInMillis(event.getTimestamp());

		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		calendar.setTimeInMillis(calendar.getTimeInMillis() - timeZoneDiff);
		long DSToffset = calendar.get(Calendar.DST_OFFSET);

		// convert default time to GMT
		long timestamp = event.getTimestamp() - timeZoneDiff - DSToffset;

		long distance = GraphUtils.MINUTE;
		long value1 = timestamp - distance;
		long value2 = timestamp + distance;

		String whereClause = SenseonicsDBHelper.EVENT_TYPE_FIELD + " == ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " <= ? AND "
				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " == ? AND "
				+ SenseonicsDBHelper.CUSTOM_FIELD + " == ? AND "
				+ SenseonicsDBHelper.EVENT_SYNCED + " == " + SenseonicsDBHelper.SYNCED + " AND "
				+ SenseonicsDBHelper.EVENT_HIDDEN + " == " + SenseonicsDBHelper.NOT_HIDDEN;
		String[] whereArgs = new String[] {
				String.valueOf(event.getEventType().ordinal()),
				String.valueOf(value1),
				String.valueOf(value2),
				String.valueOf(event.getGlucoseLevel()),
				String.valueOf((event.isCalibrationUsed()) ? 1 : 0)};

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[] {"id", SenseonicsDBHelper.NOTES_FIELD}, whereClause, whereArgs, null, null, null);

		Log.d("BGM->", "cursor count:" + cursor.getCount());

		ArrayList<String> ids = new ArrayList<>();
		String lastMatchNotes = "";
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				String dbID = cursor.getString(0);
				ids.add(dbID);
				lastMatchNotes = cursor.getString(1);
				Log.d("BGM->", "dbID:" + dbID + "|notes:" + lastMatchNotes);
			} while (cursor.moveToNext());
		}
		cursor.close();

		int rowUpdated = 0;
		for (int i=0; i<ids.size(); i++) {
			ContentValues values = new ContentValues();
			values.put(SenseonicsDBHelper.EVENT_HIDDEN, SenseonicsDBHelper.HIDDEN);
			String whereClauseUpdate = "id == ?";
			String[] whereArgsUpdate = new String[]{ids.get(i)};

			rowUpdated = database.update(SenseonicsDBHelper.EVENTS_TABLE, values,
					whereClauseUpdate, whereArgsUpdate);
		}

		Log.d(DatabaseManager.class.getSimpleName(), "BGM-> no of events updated : " + rowUpdated);
		return lastMatchNotes;
	}

	/** #3209 */
	public int convertSuspiciousGlucoseIntoCalibrationDuringSync(GlucoseEventPoint event) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		calendar.setTimeInMillis(event.getTimestamp());

		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		calendar.setTimeInMillis(calendar.getTimeInMillis() - timeZoneDiff);
		long DSToffset = calendar.get(Calendar.DST_OFFSET);

		// convert default time to GMT
		long timestamp = event.getTimestamp() - timeZoneDiff - DSToffset;

		String whereClause = SenseonicsDBHelper.EVENT_TYPE_FIELD + " == ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " < ? AND "
				+ SenseonicsDBHelper.CUSTOM_FIELD + " == ? AND "
				+ SenseonicsDBHelper.RECORD_NUMBER_FIELD + " == ? AND "
				+ SenseonicsDBHelper.EVENT_SYNCED + " == " + SenseonicsDBHelper.SYNCED + " AND "
				+ SenseonicsDBHelper.EVENT_HIDDEN + " == " + SenseonicsDBHelper.NOT_HIDDEN;
		String[] whereArgs = new String[] {
				String.valueOf(event.getEventType().ordinal()),
				String.valueOf(timestamp),
				String.valueOf(event.getCalibrationFlag()),
				String.valueOf(event.getRecordNumber())
		};
		String orderBy = SenseonicsDBHelper.TIMESTAMP_FIELD + " DESC";

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[] {
						SenseonicsDBHelper.TIMESTAMP_FIELD,
						"id",
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
						SenseonicsDBHelper.NOTES_FIELD
				}, whereClause, whereArgs, null, null, orderBy);

		Log.d("BGM->SuspiciousCheck", "cursor count:" + cursor.getCount());

		int rowUpdated = 0;
		if (cursor.getCount() >= 1) {
			/** Update the most recent event */
			cursor.moveToFirst();

			String dbID = cursor.getString(1);
			Log.d("BGM->SuspiciousCheck", "dbID:" + dbID);

			ContentValues values = new ContentValues();
			values.put(SenseonicsDBHelper.EVENT_HIDDEN, SenseonicsDBHelper.HIDDEN); // hide the suspicious glucose event
			String whereClauseUpdate = "id == ?";
			String[] whereArgsUpdate = new String[]{dbID};

			rowUpdated = database.update(SenseonicsDBHelper.EVENTS_TABLE, values,
					whereClauseUpdate, whereArgsUpdate);

			/** Add a new calibration event */
			long eventTime = cursor.getLong(0);
			Calendar eventCalendar = Calendar.getInstance();
			eventCalendar.setTimeInMillis(eventTime);

			int eventGlucose = cursor.getInt(2);
			String notes = cursor.getString(3); /** APPDEV-4032 */
			CalibrationEventPoint newEvent = new CalibrationEventPoint(eventCalendar, eventGlucose, true, notes);
			newEvent.setEventHidden(false);
			newEvent.setRecordNumber(event.getRecordNumber());
			addSyncedCalibrationAndGlucoseEvent(newEvent, true);
		}
		cursor.close();

		return rowUpdated;
	}

	public int updateCalibrationAndGlucoseEventRecordNo(EventPoint event) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		calendar.setTimeInMillis(event.getTimestamp());

		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		calendar.setTimeInMillis(calendar.getTimeInMillis() - timeZoneDiff);
		long DSToffset = calendar.get(Calendar.DST_OFFSET);

		// convert default time to GMT
		long timestamp = event.getTimestamp() - timeZoneDiff - DSToffset;

		long distance = GraphUtils.MINUTE;
		long value1 = timestamp - distance;
		long value2 = timestamp + distance;

		String whereClause = SenseonicsDBHelper.EVENT_TYPE_FIELD + " == ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " <= ? AND "
				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " == ? AND "
				+ SenseonicsDBHelper.EVENT_SYNCED + " == " + SenseonicsDBHelper.SYNCED + " AND "
				+ SenseonicsDBHelper.RECORD_NUMBER_FIELD + " < 0";
		String[] whereArgs = new String[] {
				String.valueOf(event.getEventType().ordinal()),
				String.valueOf(value1),
				String.valueOf(value2),
				String.valueOf(event.getGlucoseLevel())};

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[]{"id"}, whereClause,
				whereArgs, null, null, null);

		Log.d("BGM->Update Record #", "cursor count:" + cursor.getCount());

		ArrayList<String> ids = new ArrayList<>();
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				String dbID = cursor.getString(0);
				ids.add(dbID);
				Log.d("BGM->Update Record #", "dbID:" + dbID);
			} while (cursor.moveToNext());
		}
		cursor.close();

		int rowUpdated = 0;
		for (int i=0; i<ids.size(); i++) {
			ContentValues values = new ContentValues();
			values.put(SenseonicsDBHelper.RECORD_NUMBER_FIELD, event.getRecordNumber());
			String whereClauseUpdate = "id == ?";
			String[] whereArgsUpdate = new String[]{ids.get(i)};

			rowUpdated = database.update(SenseonicsDBHelper.EVENTS_TABLE, values,
					whereClauseUpdate, whereArgsUpdate);
		}

		Log.d("BGM->Update Record #", "rowUpdated:" + rowUpdated);
		return rowUpdated;
	}

	// -------------------------------- Events --------------------------
	public boolean eventExists(EventPoint event, boolean flagSync) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		calendar.setTimeInMillis(event.getTimestamp());


		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		calendar.setTimeInMillis(calendar.getTimeInMillis() - timeZoneDiff);
		long DSToffset = calendar.get(Calendar.DST_OFFSET);

		// convert default time to GMT
		long timestamp = event.getTimestamp() - timeZoneDiff - DSToffset;

		if((timestamp < threeDaysTimestamp) && flagSync)
			return true;
		long distance = 0;
		// Set 1 minute as distance for calibration event
		if(event instanceof CalibrationEventPoint) {
			distance = GraphUtils.MINUTE;
		}
		// others with 2 seconds
		else {
			distance = 2 * GraphUtils.SECOND;
		}
		
		long value1 = timestamp - distance;
		long value2 = timestamp + distance;

		ContentValues contentValues = createValuesFrom(event, true);
		String amount_field = String.valueOf(contentValues.get(SenseonicsDBHelper.AMOUNT_FIELD));
		String custom_field = String.valueOf(contentValues.get(SenseonicsDBHelper.CUSTOM_FIELD));
		String custom_field2 = String.valueOf(contentValues.get(SenseonicsDBHelper.CUSTOM_FIELD2));
		String health_severity = String.valueOf(contentValues.get(SenseonicsDBHelper.HEALTH_SEVERITY_FIELD));
		String exercise_intensity = String.valueOf(contentValues.get(SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD));

		String whereClause = SenseonicsDBHelper.EVENT_TYPE_FIELD + " == ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " <= ? AND "
				+ SenseonicsDBHelper.AMOUNT_FIELD + " == ? AND "
				+ SenseonicsDBHelper.CUSTOM_FIELD + " == ? AND "
				+ SenseonicsDBHelper.CUSTOM_FIELD2 + " == ? AND "
				+ SenseonicsDBHelper.HEALTH_SEVERITY_FIELD + " == ? AND "
				+ SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD + " == ?";
		String[] whereArgs = new String[] {
				String.valueOf(event.getEventType().ordinal()),
				String.valueOf(value1), String.valueOf(value2), amount_field,
				custom_field, custom_field2, health_severity,
				exercise_intensity };

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[]{SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.EVENT_TYPE_FIELD,
						SenseonicsDBHelper.NOTES_FIELD,
						SenseonicsDBHelper.AMOUNT_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD2,
						SenseonicsDBHelper.HEALTH_SEVERITY_FIELD,
						SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD,
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD, "id",
						SenseonicsDBHelper.EVENT_SYNCED}, whereClause,
				whereArgs, null, null, SenseonicsDBHelper.TIMESTAMP_FIELD);

		if (cursor.getCount() >= 1) {
			Log.d("EVENT EXISTS", "-----------------");
			return true;
		} else
			Log.d("EVENT NOT EXISTS", "-----------------");
		return false;
	}

	public ContentValues createValuesFrom(EventPoint event, boolean eventSynced) {

		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
		calendar.setTimeInMillis(event.getTimestamp());

		long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
		calendar.setTimeInMillis(calendar.getTimeInMillis() - timeZoneDiff);
		long DSToffset = calendar.get(Calendar.DST_OFFSET);

		// convert default time to GMT
		long timestamp = event.getTimestamp() - timeZoneDiff - DSToffset;

		ContentValues values = new ContentValues();
		values.put(SenseonicsDBHelper.TIMESTAMP_FIELD, timestamp);
		values.put(SenseonicsDBHelper.EVENT_TYPE_FIELD, event.getEventType()
				.ordinal());
		values.put(SenseonicsDBHelper.NOTES_FIELD, event.getNotes());
		values.put(SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD,
				event.getGlucoseLevel());
		values.put(SenseonicsDBHelper.RECORD_NUMBER_FIELD,
				event.getRecordNumber());

		if (eventSynced)
			values.put(SenseonicsDBHelper.EVENT_SYNCED,
					SenseonicsDBHelper.SYNCED);
		else
			values.put(SenseonicsDBHelper.EVENT_SYNCED,
					SenseonicsDBHelper.NOT_SYNCED);

		if (event.isEventHidden()) {
			values.put(SenseonicsDBHelper.EVENT_HIDDEN,
					SenseonicsDBHelper.HIDDEN);

			// Get event hidden since time in GMT
			if (event.getCalendarEventHidden() != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				cal.setTimeInMillis(event.getCalendarEventHidden()
						.getTimeInMillis());

				timeZoneDiff = Utils.getTimeZoneOffset(calendar);
				cal.setTimeInMillis(cal.getTimeInMillis() - timeZoneDiff);
				DSToffset = cal.get(Calendar.DST_OFFSET);

				long timestampHidden = event.getCalendarEventHidden()
						.getTimeInMillis() - timeZoneDiff - DSToffset;
				values.put(SenseonicsDBHelper.EVENT_HIDDEN_TIMESTAMP,
						timestampHidden);
			} else
				values.put(SenseonicsDBHelper.EVENT_HIDDEN_TIMESTAMP, -1);
		} else
			values.put(SenseonicsDBHelper.EVENT_HIDDEN,
					SenseonicsDBHelper.NOT_HIDDEN);

		calendar.setTimeInMillis(timestamp);

		values.put(SenseonicsDBHelper.AMOUNT_FIELD, -1);
		values.put(SenseonicsDBHelper.CUSTOM_FIELD, -1);
		values.put(SenseonicsDBHelper.CUSTOM_FIELD2, -1);
		values.put(SenseonicsDBHelper.HEALTH_SEVERITY_FIELD, -1);
		values.put(SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD, -1);

		// Save transmitter name for this event
		if (event.getTransmitterName() != null)
			values.put(SenseonicsDBHelper.TRANSMITTER_NAME,
					event.getTransmitterName());
		else
			values.put(SenseonicsDBHelper.TRANSMITTER_NAME, "");
		
		// Add unknown error code entry
		values.put(SenseonicsDBHelper.UNKNOWN_ERROR_CODE, -1);

		EVENT_TYPE eventType = event.getEventType();
		switch (eventType) {
		case CALIBRATION:
			CalibrationEventPoint calibrationEvent = (CalibrationEventPoint) event;
			if (calibrationEvent.isCalibrationUsed()) {
				values.put(SenseonicsDBHelper.CUSTOM_FIELD, 1);
			} else {
				values.put(SenseonicsDBHelper.CUSTOM_FIELD, 0);
			}
			break;
		case GLUCOSE_EVENT:
			GlucoseEventPoint glucoseEvent = (GlucoseEventPoint) event;
			values.put(SenseonicsDBHelper.CUSTOM_FIELD,
					glucoseEvent.getCalibrationFlag());
			break;
		case MEAL_EVENT:
			MealEventPoint mealEvent = (MealEventPoint) event;
			values.put(SenseonicsDBHelper.CUSTOM_FIELD, mealEvent.getMealType()
					.ordinal());
			values.put(SenseonicsDBHelper.AMOUNT_FIELD, mealEvent.getCarbs());
			break;
		case INSULIN_EVENT:
			InsulinEventPoint insulinEvent = (InsulinEventPoint) event;
			values.put(SenseonicsDBHelper.AMOUNT_FIELD, insulinEvent.getUnits());
			values.put(SenseonicsDBHelper.CUSTOM_FIELD, insulinEvent
					.getInsulinType().ordinal());
			break;
		case HEALTH_EVENT:
			HealthEventPoint healthEvent = (HealthEventPoint) event;
			values.put(SenseonicsDBHelper.CUSTOM_FIELD2, healthEvent
					.getHealthCondition().ordinal());
			values.put(SenseonicsDBHelper.HEALTH_SEVERITY_FIELD, healthEvent
					.getHealthSeverity().ordinal());
			break;
		case EXERCISE_EVENT:
			ExerciseEventPoint exerciseEvent = (ExerciseEventPoint) event;
			values.put(SenseonicsDBHelper.AMOUNT_FIELD,
					exerciseEvent.getDuration());
			values.put(SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD,
					exerciseEvent.getIntensity().ordinal());
			break;
		case ALERT_EVENT:
		case ALARM_EVENT:
			AlertEventPoint alertEvent = (AlertEventPoint) event;
			values.put(SenseonicsDBHelper.CUSTOM_FIELD, alertEvent
					.getGlucoseType().ordinal());
			values.put(SenseonicsDBHelper.CUSTOM_FIELD2, alertEvent
					.getAlertType().ordinal());
			break;

		case PREDICTIVE_ALERT_EVENT_FALLING:
		case PREDICTIVE_ALERT_EVENT_RISING:
		case RATE_ALERT_EVENT_FALLING:
		case RATE_ALERT_EVENT_RISING:
			AlertEventPoint predAlertEvent = (AlertEventPoint) event;
			values.put(SenseonicsDBHelper.CUSTOM_FIELD, predAlertEvent
					.getGlucoseType().ordinal());
			if (eventType == EVENT_TYPE.RATE_ALERT_EVENT_RISING
					|| eventType == EVENT_TYPE.RATE_ALERT_EVENT_FALLING)
				values.put(SenseonicsDBHelper.AMOUNT_FIELD,
						event.getRateValue());
			else
				values.put(SenseonicsDBHelper.CUSTOM_FIELD2,
						event.getPredictiveMinutes());
			break;
		case NOTIFICATION_EVENT_RED:
		case NOTIFICATION_EVENT_YELLOW:
		case NOTIFICATION_EVENT_BLUE:
			TransmitterMessageCode notificationEventType = event
					.getNotificationEventType();
			// Store the unknown error code
			int unknownErrorCode = event.getUnknownErrorCode();
			if(unknownErrorCode != -1)
			{
				values.put(SenseonicsDBHelper.UNKNOWN_ERROR_CODE, unknownErrorCode);
			}
			
			if (notificationEventType != null)
				values.put(SenseonicsDBHelper.CUSTOM_FIELD,
						notificationEventType.ordinal());
			break;
		case CALIBRATE_NOW_EVENT:
		case CALIBRATE_GRACE_EVENT:
		case CALIBRATE_EXPIRED_EVENT:
			break;
		case GROUP_EVENT:
			break;

		default:
			break;
		}
		return values;
	}

	public long addEvent(EventPoint event, boolean eventSynced) {
		Log.d(DatabaseManager.class.getSimpleName(), "addEvent " + event);
		try {
			if (!eventExists(event, eventSynced)) {
				ContentValues values = createValuesFrom(event, eventSynced);
				return database.insertOrThrow(SenseonicsDBHelper.EVENTS_TABLE,
						null, values);
			}
		} catch (SQLiteDatabaseLockedException e) {
			e.printStackTrace();
		}
		return -1;
	}

	/** #3209 */
	public long addSyncedCalibrationAndGlucoseEvent(EventPoint event, boolean eventSynced) {
		Log.d(DatabaseManager.class.getSimpleName(), "addEvent " + event);
		try {
			if (!eventExists(event, eventSynced)) {
				ContentValues values = createValuesFrom(event, eventSynced);
				return database.insertOrThrow(SenseonicsDBHelper.EVENTS_TABLE,
						null, values);
			}
			else {
				/** Update the record number */
				updateCalibrationAndGlucoseEventRecordNo(event);
			}
		} catch (SQLiteDatabaseLockedException e) {
			e.printStackTrace();
		}
		return -1;
	}

	public void deleteEvent(EventPoint event) {

		String whereClause = "id = ? ";
		String[] whereArgs = new String[] { String.valueOf(event
				.getDatabaseId()) };

		database.delete(SenseonicsDBHelper.EVENTS_TABLE, whereClause, whereArgs);
	}

	public void updateEvent(EventPoint event) {

		String whereClause = "id = ? ";
		String[] whereArgs = new String[] { String.valueOf(event
				.getDatabaseId()) };

		// Do not change the glucose value if it's a manual glucose
		if (!(event instanceof GlucoseEventPoint)) {
			int glucoseLevel = getGlucoseLevelAt(event.getCalendar(), true);//false);
			if (glucoseLevel < 0 || glucoseLevel >= Utils.INT_MAX)
				glucoseLevel = Utils.EVENT_POSITION;
			else if (glucoseLevel > 0)
				event.setGlucoseLevel(glucoseLevel);

			Log.d("glucose level", glucoseLevel + " -----");
		}

		ContentValues values = createValuesFrom(event, event.isEventSynced());
		int i = database.update(SenseonicsDBHelper.EVENTS_TABLE, values,
				whereClause, whereArgs);
		Log.d("updated", i + " rows");
	}

	// Get not synchronized events
	public ArrayList<EventPoint> getNotSyncedEventsBetween(Calendar startCal,
			Calendar endCal, int minGlucose, int maxGlucose) {
		return getEventsWithWhereClauseBetween(startCal, endCal, minGlucose,
				maxGlucose, " AND " + SenseonicsDBHelper.EVENT_SYNCED + " == "
						+ SenseonicsDBHelper.NOT_SYNCED);
	}

	// Get all events
	public ArrayList<EventPoint> getEventsBetween(Calendar startCal,
			Calendar endCal, int minGlucose, int maxGlucose) {
		return getEventsWithWhereClauseBetween(startCal, endCal, minGlucose,
				maxGlucose, "");
	}

	public ArrayList<EventPoint> getEventsWithWhereClauseBetween(
			Calendar startCal, Calendar endCal, int minGlucose, int maxGlucose,
			String customClause) {

		long start = getTimeMillsInDBfromCalendar(startCal);
		long end = getTimeMillsInDBfromCalendar(endCal);

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " < ? AND "
//				+ SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " >= " + minGlucose
//				+ " AND " + SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD + " < "
//				+ maxGlucose
//				+ " AND "
				+ SenseonicsDBHelper.EVENT_HIDDEN
				+ " == " + String.valueOf(SenseonicsDBHelper.NOT_HIDDEN)
				+ customClause;

		String[] whereArgs = new String[] { String.valueOf(start),
				String.valueOf(end) };

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[] { SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.EVENT_TYPE_FIELD,
						SenseonicsDBHelper.NOTES_FIELD,
						SenseonicsDBHelper.AMOUNT_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD2,
						SenseonicsDBHelper.HEALTH_SEVERITY_FIELD,
						SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD,
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD, "id",
						SenseonicsDBHelper.EVENT_SYNCED,
						SenseonicsDBHelper.EVENT_HIDDEN,
						SenseonicsDBHelper.EVENT_HIDDEN_TIMESTAMP,
						SenseonicsDBHelper.TRANSMITTER_NAME
						}, whereClause,
				whereArgs, null, null, SenseonicsDBHelper.TIMESTAMP_FIELD);

		ArrayList<EventPoint> events = new ArrayList<>();
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {
			do {
				// convert GMT time to default time
				long timestamp = cursor.getLong(0);
				Calendar calendar = Calendar.getInstance();
				calendar.setTimeInMillis(timestamp);

				// Log.d(" event time ",
				// Utils.formatDate(calendar, TimeZone.getTimeZone("GMT"))
				// + " " + Utils.formatDate(calendar) + " "
				// + timestamp);

				int typeId = cursor.getInt(1);
				String notes = cursor.getString(2);
				int glucoseLevel = cursor.getInt(8);
				int id = cursor.getInt(9);
				int eventSyncedCode = cursor.getInt(10);
				int hiddenId = cursor.getInt(11);
				long timestampHidden = cursor.getLong(12);
				String transmitterName = cursor.getString(13);
				Calendar calendarHidden = null;
				if (timestampHidden != -1) {
					calendarHidden = Calendar.getInstance();
					calendarHidden.setTimeInMillis(timestampHidden);
				}

				boolean eventSynced;
				if (eventSyncedCode == SenseonicsDBHelper.SYNCED)
					eventSynced = true;
				else
					eventSynced = false;

				boolean eventHidden;
				if (hiddenId == SenseonicsDBHelper.HIDDEN)
					eventHidden = true;
				else
					eventHidden = false;

				EVENT_TYPE type = EVENT_TYPE.values()[typeId];
				EventPoint eventPoint = null;
				int glucoseTypeId;
				switch (type) {
				case CALIBRATION:
					int value = cursor.getInt(4);
					boolean isCalibrationUsed;
					if (value == 1)
						isCalibrationUsed = true;
					else
						isCalibrationUsed = false;
					eventPoint = new CalibrationEventPoint(id, calendar,
							glucoseLevel, isCalibrationUsed, notes);
					break;
				case GLUCOSE_EVENT:
					int calibrationFlag = cursor.getInt(4);
					eventPoint = new GlucoseEventPoint(id, calendar,
							glucoseLevel, calibrationFlag, notes);
					break;
				case MEAL_EVENT:
					int mealTypeId = cursor.getInt(4);
					MEAL_TYPE mealType = MEAL_TYPE.values()[mealTypeId];
					int carbs = cursor.getInt(3);
					eventPoint = new MealEventPoint(id, calendar, glucoseLevel,
							mealType, carbs, notes);
					break;
				case INSULIN_EVENT:
					int insulinTypeId = cursor.getInt(4);
					INSULIN_TYPE insulinType = INSULIN_TYPE.values()[insulinTypeId];
					float units = cursor.getFloat(3);
					eventPoint = new InsulinEventPoint(id, calendar,
							glucoseLevel, units, insulinType, notes);
					break;
				case HEALTH_EVENT:
					int healthConditionId = cursor.getInt(5);
					HEALTH_CONDITION condition = HEALTH_CONDITION.values()[healthConditionId];
					int healthSeverityId = cursor.getInt(6);
					HEALTH_SEVERITY severity = HEALTH_SEVERITY.values()[healthSeverityId];
					eventPoint = new HealthEventPoint(id, calendar,
							glucoseLevel, condition, severity, notes);
					break;
				case EXERCISE_EVENT:
					int exerciseIntensityId = cursor.getInt(7);
					EXERCISE_INTENSITY intensity = EXERCISE_INTENSITY.values()[exerciseIntensityId];
					int duration = cursor.getInt(3);
					eventPoint = new ExerciseEventPoint(id, calendar,
							glucoseLevel, duration, intensity, notes);
					break;
				case ALERT_EVENT:
				case ALARM_EVENT:
					glucoseTypeId = cursor.getInt(4);
					int alertTypeId = cursor.getInt(5);
					ALERT_TYPE alertType = ALERT_TYPE.values()[alertTypeId];
					GLUCOSE_TYPE glucoseType = GLUCOSE_TYPE.values()[glucoseTypeId];
					eventPoint = new AlertEventPoint(type, id, calendar,
							glucoseLevel, alertType, glucoseType);
					break;
				case PREDICTIVE_ALERT_EVENT_FALLING:
				case PREDICTIVE_ALERT_EVENT_RISING:
					glucoseTypeId = cursor.getInt(4);
					int predictiveMinutes = cursor.getInt(5);
					ALERT_TYPE predAlertType;
					if (type == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING)
						predAlertType = ALERT_TYPE.LOW_GLUCOSE;
					else
						predAlertType = ALERT_TYPE.HIGH_GLUCOSE;
					GLUCOSE_TYPE predGlucoseType = GLUCOSE_TYPE.values()[glucoseTypeId];
					eventPoint = new AlertEventPoint(type, id, calendar,
							glucoseLevel, predAlertType, predGlucoseType);
					eventPoint.setPredictiveMinutes(predictiveMinutes);
					break;
				case RATE_ALERT_EVENT_FALLING:
				case RATE_ALERT_EVENT_RISING:
					float rateValue = cursor.getFloat(3);
					glucoseTypeId = cursor.getInt(4);
					if (type == EVENT_TYPE.RATE_ALERT_EVENT_FALLING)
						predAlertType = ALERT_TYPE.LOW_GLUCOSE;
					else
						predAlertType = ALERT_TYPE.HIGH_GLUCOSE;
					predGlucoseType = GLUCOSE_TYPE.values()[glucoseTypeId];
					eventPoint = new AlertEventPoint(type, id, calendar,
							glucoseLevel, predAlertType, predGlucoseType);
					eventPoint.setRateValue(rateValue);
					break;

				case NOTIFICATION_EVENT_RED: // only for out of range high and low
					int notificationEventType = cursor.getInt(4); // CUSTOM_FIELD
					if ((notificationEventType == TransmitterMessageCode.SeriouslyLowAlarm.ordinal()) ||
							(notificationEventType == TransmitterMessageCode.SeriouslyHighAlarm.ordinal())
							) {
						eventPoint = new EventPoint(calendar, glucoseLevel, type);
						eventPoint.setNotes("");
						eventPoint.setNotificationEventType(TransmitterMessageCode.values()[notificationEventType]);
						eventPoint.setRecordNumber(-1);
						eventPoint.setEventHidden(false);
					}

					break;

				case NOTIFICATION_EVENT_YELLOW:
					int msgCodeYellow = cursor.getInt(4);
					if (msgCodeYellow == TransmitterMessageCode.EDRAlarm4.ordinal()) { /** #3920 */
						eventPoint = new EventPoint(calendar, glucoseLevel, type);
						eventPoint.setNotes("");
						eventPoint.setNotificationEventType(TransmitterMessageCode.values()[msgCodeYellow]);
						eventPoint.setRecordNumber(-1);
						eventPoint.setEventHidden(false);
					}

					break;

				case NOTIFICATION_EVENT_BLUE:
				case GROUP_EVENT:
				default:
					break;
				}
				if (eventPoint != null) {
					eventPoint.setEventSynced(eventSynced);
					eventPoint.setEventHidden(eventHidden);
					eventPoint.setCalendarEventHidden(calendarHidden);
					eventPoint.setTransmitterName(transmitterName);
					events.add(eventPoint);
				}
			} while (cursor.moveToNext());
		}
		cursor.close();

		return events;
	}

	public ArrayList<Notification> getNotificationsBetween(Context context,
			Calendar startDate, Calendar endDate, List<EVENT_TYPE> eventTypes,
			int order, boolean fetchBattery, boolean onlyNotHiddenNotifications, String FetchLimit, boolean needTranslatedTitle) {

		long start = startDate.getTimeInMillis();
		long end = endDate.getTimeInMillis();

		String value = "(";
		for (int i = 0; i < eventTypes.size(); ++i) {
			if (i == eventTypes.size() - 1)
				value += eventTypes.get(i).ordinal();
			else
				value += eventTypes.get(i).ordinal() + ",";
		}
		value += ")";

		String customWhereClause = "";
		if (onlyNotHiddenNotifications)
			customWhereClause = " AND " + SenseonicsDBHelper.EVENT_HIDDEN
					+ " == " + SenseonicsDBHelper.NOT_HIDDEN;

		String whereClause = SenseonicsDBHelper.TIMESTAMP_FIELD + " >= ? AND "
				+ SenseonicsDBHelper.TIMESTAMP_FIELD + " < ? AND "
				+ SenseonicsDBHelper.EVENT_TYPE_FIELD + " IN " + value
				+ customWhereClause;

		String[] whereArgs = new String[] { String.valueOf(start),
				String.valueOf(end) };

		String orderBy = SenseonicsDBHelper.TIMESTAMP_FIELD;
		if (order == 1)
			orderBy += " DESC";

		Cursor cursor = database.query(SenseonicsDBHelper.EVENTS_TABLE,
				new String[] { SenseonicsDBHelper.TIMESTAMP_FIELD,
						SenseonicsDBHelper.EVENT_TYPE_FIELD,
						SenseonicsDBHelper.NOTES_FIELD,
						SenseonicsDBHelper.AMOUNT_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD,
						SenseonicsDBHelper.CUSTOM_FIELD2,
						SenseonicsDBHelper.HEALTH_SEVERITY_FIELD,
						SenseonicsDBHelper.EXERCISE_INTENSITY_FIELD,
						SenseonicsDBHelper.GLUCOSE_LEVEL_FIELD, "id",
						SenseonicsDBHelper.EVENT_SYNCED,
						SenseonicsDBHelper.EVENT_HIDDEN,
						SenseonicsDBHelper.EVENT_HIDDEN_TIMESTAMP,
						SenseonicsDBHelper.TRANSMITTER_NAME,
						SenseonicsDBHelper.UNKNOWN_ERROR_CODE}, whereClause,
				whereArgs, null, null, orderBy, FetchLimit);

		ArrayList<Notification> notifications = new ArrayList<Notification>();
		if (cursor.getCount() >= 1 && cursor.moveToFirst()) {

			do {
				// convert GMT time to default time
				long timestamp = cursor.getLong(0);
				Calendar calendar = Calendar.getInstance();
				calendar.setTimeInMillis(timestamp);
				int typeId = cursor.getInt(1);
				String notes = cursor.getString(2);
				int glucoseLevel = cursor.getInt(8);
				int id = cursor.getInt(9);
				String transmitterName = cursor.getString(13);
				int unknownErrorCode = cursor.getInt(14);

				EVENT_TYPE type = EVENT_TYPE.values()[typeId];
				Notification notification = null;
				EventPoint eventPoint = null;
				String glucoseLevelString = "";
				switch (type) {
				case CALIBRATION:
					int calUsedValue = cursor.getInt(4);
					boolean isCalibrationUsed;
					if (calUsedValue == 1) {
						isCalibrationUsed = true;
					} else {
						isCalibrationUsed = false;
					}
					eventPoint = new CalibrationEventPoint(id, calendar,
							glucoseLevel, isCalibrationUsed, notes);
					eventPoint.setTransmitterName(transmitterName);
					glucoseLevelString = Utils.getGlucoseLevelString(context,
							glucoseLevel);
					notification = new Notification(Utils.getEventName(context,
							type), glucoseLevelString,
							calendar.getTimeInMillis(), eventPoint);
					break;
				case GLUCOSE_EVENT:
					int calibrationFlag = cursor.getInt(4);
					eventPoint = new GlucoseEventPoint(id, calendar,
							glucoseLevel, calibrationFlag, notes);
					eventPoint.setTransmitterName(transmitterName);
					glucoseLevelString = Utils.getGlucoseLevelString(context,
							glucoseLevel);
					notification = new Notification(Utils.getEventName(context,
							type), glucoseLevelString,
							calendar.getTimeInMillis(), eventPoint);
					break;
				case MEAL_EVENT:
					int mealTypeId = cursor.getInt(4);
					MEAL_TYPE mealType = MEAL_TYPE.values()[mealTypeId];
					int carbs = cursor.getInt(3);

					eventPoint = new MealEventPoint(id, calendar, glucoseLevel,
							mealType, carbs, notes);
					eventPoint.setTransmitterName(transmitterName);
					String gramsString = context.getResources().getString(
							R.string.grams);
					notification = new Notification(EventUtils.getMealTypeName(context, mealType), 
							carbs + " " + gramsString,
							calendar.getTimeInMillis(), eventPoint);
					break;
				case INSULIN_EVENT:
					int insulinTypeId = cursor.getInt(4);
					INSULIN_TYPE insulinType = INSULIN_TYPE.values()[insulinTypeId];
					float units = cursor.getFloat(3);

					eventPoint = new InsulinEventPoint(id, calendar,
							glucoseLevel, units, insulinType, notes);
					eventPoint.setTransmitterName(transmitterName);
					String unitsString = context.getResources().getString(
							R.string.units);
					notification = new Notification(Utils.getEventName(context,
							type), units + " " + unitsString,
							calendar.getTimeInMillis(), eventPoint);
					break;
				case HEALTH_EVENT:
					int healthConditionId = cursor.getInt(5);
					HEALTH_CONDITION condition = HEALTH_CONDITION.values()[healthConditionId];
					int healthSeverityId = cursor.getInt(6);
					HEALTH_SEVERITY severity = HEALTH_SEVERITY.values()[healthSeverityId];

					eventPoint = new HealthEventPoint(id, calendar,
							glucoseLevel, condition, severity, notes);
					eventPoint.setTransmitterName(transmitterName);
					notification = new Notification(Utils.getEventName(context,
							type), EventUtils.getHealthConditionName(context,
							condition), calendar.getTimeInMillis(), eventPoint);
					break;
				case EXERCISE_EVENT:
					int exerciseIntensityId = cursor.getInt(7);
					EXERCISE_INTENSITY intensity = EXERCISE_INTENSITY.values()[exerciseIntensityId];
					int duration = cursor.getInt(3);

					eventPoint = new ExerciseEventPoint(id, calendar,
							glucoseLevel, duration, intensity, notes);
					eventPoint.setTransmitterName(transmitterName);
					String durationString = ((ExerciseEventPoint) eventPoint)
							.getDurationText(context);
					notification = new Notification(Utils.getEventName(context,
							type), durationString, calendar.getTimeInMillis(),
							eventPoint);
					break;
				case GROUP_EVENT:
				case ALERT_EVENT:
				case ALARM_EVENT:
					int glucoseTypeId = cursor.getInt(4);
					int alertTypeId = cursor.getInt(5);
					ALERT_TYPE alertType = ALERT_TYPE.values()[alertTypeId];

					GLUCOSE_TYPE glucoseType = GLUCOSE_TYPE.values()[glucoseTypeId];
					eventPoint = new AlertEventPoint(type, id, calendar,
							glucoseLevel, alertType, glucoseType);
					eventPoint.setTransmitterName(transmitterName);
					String eventName;
					if (type == EVENT_TYPE.ALARM_EVENT) {
						if (needTranslatedTitle) {
							eventName = Utils
									.getAlarmEventTitle(context, alertType);
						}
						else {
							eventName = Utils
									.getAlarmEventTitleNotTranslated(context, alertType);
						}

						if (alertType == ALERT_TYPE.HIGH_GLUCOSE) {
							eventPoint.setNotificationEventType(TransmitterMessageCode.HighGlucoseAlarm);
						}
						else if(alertType == ALERT_TYPE.LOW_GLUCOSE) {
							eventPoint.setNotificationEventType(TransmitterMessageCode.LowGlucoseAlarm);
						}
					}
					else if (type == EVENT_TYPE.ALERT_EVENT)
						eventName = Utils
								.getAlertEventTitle(context, alertType);
					else
						eventName = Utils.getEventName(context, type);

					if (glucoseLevel <= Utils.GLUCOSE_LEVEL_UNKNOWN)
						glucoseLevelString = Utils.unknownString;
					else
						glucoseLevelString = Utils.getGlucoseLevelString(
								context, glucoseLevel);

					notification = new Notification(eventName,
							glucoseLevelString, calendar.getTimeInMillis(),
							eventPoint);
					break;

				case PREDICTIVE_ALERT_EVENT_FALLING:
				case PREDICTIVE_ALERT_EVENT_RISING:
				case RATE_ALERT_EVENT_FALLING:
				case RATE_ALERT_EVENT_RISING:
					int predAlertTypeId = cursor.getInt(4);

					ALERT_TYPE predAlertType = ALERT_TYPE.values()[predAlertTypeId];

					if (glucoseLevel <= Utils.GLUCOSE_LEVEL_UNKNOWN) {
						glucoseLevelString = Utils.unknownString;
					} else
						glucoseLevelString = Utils.getGlucoseLevelString(
								context, glucoseLevel);
					eventPoint = new AlertEventPoint(type, id, calendar,
							glucoseLevel, predAlertType,
							GLUCOSE_TYPE.SENSOR_GLUCOSE);
					eventPoint.setTransmitterName(transmitterName);
					String predEventName = "";
					if (type == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING
							|| type == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
						int predictiveMinutes = cursor.getInt(5);
						eventPoint.setPredictiveMinutes(predictiveMinutes);
						predEventName = Utils.getPredictiveAlertTitle(context,
								type);
					} else {
						float rateValue = cursor.getFloat(3);
						eventPoint.setRateValue(rateValue);
						predEventName = Utils.getRateAlertTitle(context, type);
					}

					notification = new Notification(predEventName,
							glucoseLevelString, calendar.getTimeInMillis(),
							eventPoint);
					break;
				case CALIBRATE_NOW_EVENT:
				case CALIBRATE_GRACE_EVENT:
				case CALIBRATE_EXPIRED_EVENT:
					eventPoint = new EventPoint(id, calendar, glucoseLevel);
					eventPoint.setTransmitterName(transmitterName);
					eventPoint.setEventType(type);
					eventPoint.setNotes(notes);
					if (type == EVENT_TYPE.CALIBRATE_NOW_EVENT) {
						eventPoint.setNotificationEventType(TransmitterMessageCode.CalibrationRequiredAlarm);
					}
					else if (type == EVENT_TYPE.CALIBRATE_GRACE_EVENT) {
						eventPoint.setNotificationEventType(TransmitterMessageCode.CalibrationGracePeriodAlarm);
					}
					else if (type == EVENT_TYPE.CALIBRATE_EXPIRED_EVENT) {
						eventPoint.setNotificationEventType(TransmitterMessageCode.CalibrationExpiredAlarm);
					}

					if (needTranslatedTitle) {
						notification = new Notification(Utils.getEventName(context,
								type), eventPoint.getNotes(),
								calendar.getTimeInMillis(), eventPoint);
					}
					else {
						notification = new Notification(Utils.getEventNameNotTranslated(context,
								type), eventPoint.getNotes(),
								calendar.getTimeInMillis(), eventPoint);
					}
					break;
				case NOTIFICATION_EVENT_RED:
				case NOTIFICATION_EVENT_YELLOW:
				case NOTIFICATION_EVENT_BLUE:
					eventPoint = new EventPoint(id, calendar, glucoseLevel);
					eventPoint.setTransmitterName(transmitterName);
					eventPoint.setUnknownErrorCode(unknownErrorCode);
					eventPoint.setEventType(type);
					int notificationEventTypeId = cursor.getInt(4);
					TransmitterMessageCode notificationEventType = TransmitterMessageCode
							.values()[notificationEventTypeId];
					eventPoint.setNotificationEventType(notificationEventType);
					
					// Set unknown error code
					if((notificationEventType == TransmitterMessageCode.NumberOfMessages) &&
							(unknownErrorCode != -1))
					{
						eventPoint.setUnknownErrorCode(unknownErrorCode);
					}

					int titleId = Utils
							.getNotificationDialogMessageTitleStringId(notificationEventType);
					String title = "";
					if (titleId > 0) {
						if (needTranslatedTitle) {
							title = context.getString(titleId);
						}
						else {
							title = Utils
									.getNotificationDialogMessageTitleStringNoTranslated(notificationEventType);
						}

						if (titleId == R.string.unknown_error_alert_title)
						{
							int unknowErrorCode = eventPoint.getUnknownErrorCode();
							if(unknowErrorCode != -1)
							{
								title = Utils.replaceUnknownErrorCodeString(context, title, unknowErrorCode);
							}
						}
					}
					int textId = Utils
							.getNotificationDialogTextStringId(notificationEventType);
					String text = "";
					if (textId > 0) {
						if (transmitterName.equals(""))
							text = Utils.replaceTransmitterNameFromString(
									context.getString(textId),
									Utils.NotAvailable);
						else
							text = Utils.replaceTransmitterNameFromString(
									context.getString(textId), transmitterName);

						// Check if it's out of range glucose alarm
						if (textId == R.string.out_of_range_low_glucose_alarm_message
								|| textId == R.string.out_of_range_high_glucose_alarm_message) {
							text = Utils.replaceOutOfRangeThresholdString(
									context, text, textId);
						}
					}

					// Check if it's battery event
					if (fetchBattery == true) {
						// Check the note in the notification
						if (notes.equals(Utils.BATTERY_EVENT_TAG)) {
							notification = new Notification(title, text,
									calendar.getTimeInMillis(), eventPoint);
						}
					} else {
						notification = new Notification(title, text,
								calendar.getTimeInMillis(), eventPoint);
					}
					break;
				default:
					break;
				}
				if (notification != null)
					notifications.add(notification);
			} while (cursor.moveToNext());
		}
		cursor.close();

		return notifications;
	}

	private long getTimeMillsInDBfromCalendar(Calendar cal) {
		Calendar dateVal = Calendar.getInstance();
		dateVal.setTimeZone(TimeZone.getTimeZone("GMT"));
		dateVal.setTimeInMillis(cal.getTimeInMillis());

		long timeZoneDiff = Utils.getTimeZoneOffset(dateVal);

		dateVal.setTimeInMillis(dateVal.getTimeInMillis() - timeZoneDiff);

		long DSToffset = dateVal.get(Calendar.DST_OFFSET);
		long retVa = dateVal.getTimeInMillis() - DSToffset;

		return retVa;
	}

}
