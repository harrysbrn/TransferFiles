package com.senseonics.fragments;

import android.content.Context;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.MealTimeStatistics;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.WeeklyStatGraph;
import com.senseonics.graph.util.WeeklyStatValue;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class StatisticsWeeklyGraphFragment extends BaseStatisticsFragment {

	View view;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		view = inflater.inflate(R.layout.fragment_statistics_weekly,
				container, false);
		noStatisticsLayout = (RelativeLayout) view
				.findViewById(R.id.noStatisticsLayout);
		contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
		TextView tvDateRange = (TextView) view
				.findViewById(R.id.tvDateRange);
		tvDateRange.setTypeface(Typeface.DEFAULT_BOLD);

		Calendar cal = Utils.getDayStart(Calendar.getInstance());
		cal.add(Calendar.DAY_OF_YEAR, -7);
		String strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
		tvDateRange.setText(strDateRange);

		TextView titleTextView = (TextView) view
				.findViewById(R.id.titleTextView);
		String glucoseUnit = Utils.getGlucoseUnitString(getActivity());
		String title = getString(R.string.weekly_statistics, glucoseUnit);
		titleTextView.setText(title);
		titleTextView.setTypeface(Typeface.DEFAULT_BOLD);

		Context contex = getActivity();
		if ((contex != null) && ((MainActivity)contex).getStatisticsFragment() != null) {
			createProgressDialogIfNeeded();
			showProgressDialogIfNeeded();
			new ValidDataCheckTask().execute(contex);
		}

		return view;
	}

	private class ValidDataCheckTask extends AsyncTask<Context, Void, ArrayList<WeeklyStatValue>> {
		@Override
		protected ArrayList<WeeklyStatValue> doInBackground(Context... params) {
			Context context = params[0];

			if ((databaseManager != null) && (context != null)) {
				Calendar calendar = Calendar.getInstance();
				ArrayList<WeeklyStatValue> statValues = new ArrayList<WeeklyStatValue>();

//				Log.d("#3640_4", "1. getWeeklyStatValue START | " + Thread.currentThread());
				statValues.add(getWeeklyStatValue(calendar, MealTimeDataHandler.MealType.BREAKFAST, context));
				statValues.add(getWeeklyStatValue(calendar, MealTimeDataHandler.MealType.LUNCH, context));
				statValues.add(getWeeklyStatValue(calendar, MealTimeDataHandler.MealType.SNACK, context));
				statValues.add(getWeeklyStatValue(calendar, MealTimeDataHandler.MealType.DINNER, context));
				statValues.add(getWeeklyStatValue(calendar, MealTimeDataHandler.MealType.SLEEP, context));
//				Log.d("#3640_4", "1. getWeeklyStatValue END | " + Thread.currentThread());

				return statValues;
			}
			else {
				return null;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<WeeklyStatValue> result) {
			Context context = getActivity();

			if ((result != null) && (result.size() == 5) && (context != null)) {
				// check if there is data
				boolean thereIsData = false;
				for (WeeklyStatValue weeklyStatValue: result) {
					if ((weeklyStatValue != null) && (weeklyStatValue.getAvg() != WeeklyStatValue.INVALID_AVG)) {
						thereIsData = true;
					}
				}

				if (thereIsData) {
					Log.i("weekly debug","there is data");
					noStatisticsLayout.setVisibility(View.GONE);
					contentLayout.setVisibility(View.VISIBLE);

					new FetchAndDisplayTable().execute(context);
					new FetchAndDisplayGraph().execute(context);
				}
				else {
					Log.i("weekly debug","there is no data");
					noStatisticsLayout.setVisibility(View.VISIBLE);
					contentLayout.setVisibility(View.GONE);

					dismissProgressDialogIfNeeded();
				}
			}
			else {
				dismissProgressDialogIfNeeded();
			}
		}
	}

	private class FetchAndDisplayTable extends AsyncTask<Context, Void, ArrayList<MealTimeStatistics>> {
		@Override
		protected ArrayList<MealTimeStatistics> doInBackground(Context... params) {
			Context context = params[0];

			if ((databaseManager != null) && (context != null)) {
//				Log.d("#3640_4", "1. getBreakFastReport db START | " + Thread.currentThread());
				MealTimeStatistics mealTimeStatisticsBreakFast = new MealTimeStatistics(getGlucoseArrayValue(Calendar.getInstance(),MealTimeDataHandler.MealType.BREAKFAST, context),
						transmitterStateModel.getHighGlucoseAlarmThreshold(),transmitterStateModel.getHighGlucoseTarget(),
						transmitterStateModel.getLowGlucoseTarget(),transmitterStateModel.getLowGlucoseAlarmThreshold());

				MealTimeStatistics mealTimeStatisticsLunch = new MealTimeStatistics(getGlucoseArrayValue(Calendar.getInstance(),MealTimeDataHandler.MealType.LUNCH, context),
						transmitterStateModel.getHighGlucoseAlarmThreshold(),transmitterStateModel.getHighGlucoseTarget(),
						transmitterStateModel.getLowGlucoseTarget(),transmitterStateModel.getLowGlucoseAlarmThreshold());

				MealTimeStatistics mealTimeStatisticsSnack = new MealTimeStatistics(getGlucoseArrayValue(Calendar.getInstance(),MealTimeDataHandler.MealType.SNACK, context),
						transmitterStateModel.getHighGlucoseAlarmThreshold(),transmitterStateModel.getHighGlucoseTarget(),
						transmitterStateModel.getLowGlucoseTarget(),transmitterStateModel.getLowGlucoseAlarmThreshold());

				MealTimeStatistics mealTimeStatisticsDinner = new MealTimeStatistics(getGlucoseArrayValue(Calendar.getInstance(),MealTimeDataHandler.MealType.DINNER, context),
						transmitterStateModel.getHighGlucoseAlarmThreshold(),transmitterStateModel.getHighGlucoseTarget(),
						transmitterStateModel.getLowGlucoseTarget(),transmitterStateModel.getLowGlucoseAlarmThreshold());

				MealTimeStatistics mealTimeStatisticsSleep = new MealTimeStatistics(getGlucoseArrayValue(Calendar.getInstance(),MealTimeDataHandler.MealType.SLEEP, context),
						transmitterStateModel.getHighGlucoseAlarmThreshold(),transmitterStateModel.getHighGlucoseTarget(),
						transmitterStateModel.getLowGlucoseTarget(),transmitterStateModel.getLowGlucoseAlarmThreshold());
//				Log.d("#3640_4", "5. getSleepReport db END | " + Thread.currentThread());

				ArrayList<MealTimeStatistics> results = new ArrayList<MealTimeStatistics>();
				results.add(mealTimeStatisticsBreakFast);
				results.add(mealTimeStatisticsLunch);
				results.add(mealTimeStatisticsSnack);
				results.add(mealTimeStatisticsDinner);
				results.add(mealTimeStatisticsSleep);

				return results;
			}
			else {
				return null;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<MealTimeStatistics> result) {
			Context context = getActivity();

			if ((result != null) && (result.size() == 5) && (context != null)) {
				TextView avgBreakfastTextView = (TextView) view.findViewById(R.id.avgBreakfast);
				TextView stdDevBreakfastTextView = (TextView) view.findViewById(R.id.stdDevBreakfast);
				TextView withinBreakfastTextView = (TextView) view.findViewById(R.id.withinBreakfast);
				TextView aboveBreakfastTextView = (TextView) view.findViewById(R.id.aboveBreakfast);
				TextView belowBreakfastTextView = (TextView) view.findViewById(R.id.belowBreakfast);
				TextView lowBreakfastTextView = (TextView) view.findViewById(R.id.lowBreakfast);
				TextView highBreakfastTextView = (TextView) view.findViewById(R.id.highBreakfast);

				TextView avgLunchTextView = (TextView) view.findViewById(R.id.avgLunch);
				TextView stdDevLunchTextView = (TextView) view.findViewById(R.id.stdDevLunch);
				TextView withinLunchTextView = (TextView) view.findViewById(R.id.withinLunch);
				TextView aboveLunchTextView = (TextView) view.findViewById(R.id.aboveLunch);
				TextView belowLunchTextView = (TextView) view.findViewById(R.id.belowLunch);
				TextView highLunchTextView = (TextView) view.findViewById(R.id.highLunch);
				TextView lowLunchTextView = (TextView) view.findViewById(R.id.lowLunch);

				TextView avgtSnackTextView = (TextView) view.findViewById(R.id.avgSnack);
				TextView stdDevSnackTextView = (TextView) view.findViewById(R.id.stdDevSnack);
				TextView withinSnackTextView = (TextView) view.findViewById(R.id.withinSnack);
				TextView aboveSnackTextView = (TextView) view.findViewById(R.id.aboveSnack);
				TextView belowSnackTextView = (TextView) view.findViewById(R.id.belowSnack);
				TextView highSnackTextView = (TextView) view.findViewById(R.id.highSnack);
				TextView lowSnackTextView = (TextView) view.findViewById(R.id.lowSnack);

				TextView avgDinnerTextView = (TextView) view.findViewById(R.id.avgDinner);
				TextView stdDevDinnerTextView = (TextView) view.findViewById(R.id.stdDevDinner);
				TextView withinDinnerTextView = (TextView) view.findViewById(R.id.withinDinner);
				TextView aboveDinnerTextView = (TextView) view.findViewById(R.id.aboveDinner);
				TextView belowDinnerTextView = (TextView) view.findViewById(R.id.belowDinner);
				TextView lowDinnerTextView = (TextView) view.findViewById(R.id.lowDinner);
				TextView highDinnerTextView = (TextView) view.findViewById(R.id.highDinner);

				TextView avgSleepTextView = (TextView) view.findViewById(R.id.avgSleep);
				TextView stdDevSleepTextView = (TextView) view.findViewById(R.id.stdDevSleep);
				TextView withinSleepTextView = (TextView) view.findViewById(R.id.withinSleep);
				TextView aboveSleepTextView = (TextView) view.findViewById(R.id.aboveSleep);
				TextView belowSleepTextView = (TextView) view.findViewById(R.id.belowSleep);
				TextView lowSleepTextView = (TextView) view.findViewById(R.id.lowSleep);
				TextView highSleepTextView = (TextView) view.findViewById(R.id.highSleep);

				MealTimeStatistics mealTimeStatisticsBreakFast = result.get(0);
				MealTimeStatistics mealTimeStatisticsLunch = result.get(1);
				MealTimeStatistics mealTimeStatisticsSnack = result.get(2);
				MealTimeStatistics mealTimeStatisticsDinner = result.get(3);
				MealTimeStatistics mealTimeStatisticsSleep = result.get(4);

				if(mealTimeStatisticsBreakFast.getAverage() !=-1)
					avgBreakfastTextView.setText(Utils.getGlucoseLevelValueNoDecs(mealTimeStatisticsBreakFast.getAverage()));
				if(mealTimeStatisticsBreakFast.getFirstStdDev() !=-1)
					stdDevBreakfastTextView.setText(String.format(Locale.US, "%.1f", mealTimeStatisticsBreakFast.getFirstStdDev()));
				if(mealTimeStatisticsBreakFast.getPercentWithin() !=-1)
					withinBreakfastTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsBreakFast.getPercentWithin())+"%");
				if(mealTimeStatisticsBreakFast.getPercentAboveTarget() !=-1)
					aboveBreakfastTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsBreakFast.getPercentAboveTarget())+"%");
				if(mealTimeStatisticsBreakFast.getPercentBelowTarget() !=-1)
					belowBreakfastTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsBreakFast.getPercentBelowTarget())+"%");
				if(mealTimeStatisticsBreakFast.getPercentBelowLow() !=-1)
					lowBreakfastTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsBreakFast.getPercentBelowLow()) + "%");
				if(mealTimeStatisticsBreakFast.getPercentAboveHigh() !=-1)
					highBreakfastTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsBreakFast.getPercentAboveHigh())+"%");

				if(mealTimeStatisticsLunch.getAverage() !=-1)
					avgLunchTextView.setText(Utils.getGlucoseLevelValueNoDecs(mealTimeStatisticsLunch.getAverage()));
				if(mealTimeStatisticsLunch.getFirstStdDev() !=-1)
					stdDevLunchTextView.setText(String.format(Locale.US, "%.1f", mealTimeStatisticsLunch.getFirstStdDev()));
				if(mealTimeStatisticsLunch.getPercentWithin() !=-1)
					withinLunchTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsLunch.getPercentWithin())+"%");
				if(mealTimeStatisticsLunch.getPercentAboveTarget() !=-1)
					aboveLunchTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsLunch.getPercentAboveTarget())+"%");
				if(mealTimeStatisticsLunch.getPercentBelowTarget() !=-1)
					belowLunchTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsLunch.getPercentBelowTarget())+"%");
				if(mealTimeStatisticsLunch.getPercentBelowLow() !=-1)
					lowLunchTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsLunch.getPercentBelowLow())+"%");
				if(mealTimeStatisticsLunch.getPercentAboveHigh() !=-1)
					highLunchTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsLunch.getPercentAboveHigh())+"%");

				if(mealTimeStatisticsSnack.getAverage() !=-1)
					avgtSnackTextView.setText(Utils.getGlucoseLevelValueNoDecs( mealTimeStatisticsSnack.getAverage()));
				if(mealTimeStatisticsSnack.getFirstStdDev() !=-1)
					stdDevSnackTextView.setText(String.format(Locale.US, "%.1f", mealTimeStatisticsSnack.getFirstStdDev()));
				if(mealTimeStatisticsSnack.getPercentWithin() !=-1)
					withinSnackTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSnack.getPercentWithin())+"%");
				if(mealTimeStatisticsSnack.getPercentAboveTarget() !=-1)
					aboveSnackTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSnack.getPercentAboveTarget())+"%");
				if(mealTimeStatisticsSnack.getPercentBelowTarget() !=-1)
					belowSnackTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSnack.getPercentBelowTarget())+"%");
				if(mealTimeStatisticsSnack.getPercentBelowLow() !=-1)
					lowSnackTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSnack.getPercentBelowLow()) + "%");
				if(mealTimeStatisticsSnack.getPercentAboveHigh() !=-1)
					highSnackTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSnack.getPercentAboveHigh()) +"%");

				if(mealTimeStatisticsDinner.getAverage() !=-1)
					avgDinnerTextView.setText(Utils.getGlucoseLevelValueNoDecs(mealTimeStatisticsDinner.getAverage()));
				if(mealTimeStatisticsDinner.getFirstStdDev() !=-1)
					stdDevDinnerTextView.setText(String.format(Locale.US, "%.1f", mealTimeStatisticsDinner.getFirstStdDev()));
				if(mealTimeStatisticsDinner.getPercentWithin() !=-1)
					withinDinnerTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsDinner.getPercentWithin())+"%");
				if(mealTimeStatisticsDinner.getPercentAboveTarget() !=-1)
					aboveDinnerTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsDinner.getPercentAboveTarget())+"%");
				if(mealTimeStatisticsDinner.getPercentBelowTarget() !=-1)
					belowDinnerTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsDinner.getPercentBelowTarget())+"%");
				if(mealTimeStatisticsDinner.getPercentBelowLow() !=-1)
					lowDinnerTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsDinner.getPercentBelowLow()) + "%");
				if(mealTimeStatisticsDinner.getPercentAboveHigh() !=-1)
					highDinnerTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsDinner.getPercentAboveHigh()) +"%");

				if(mealTimeStatisticsSleep.getAverage() !=-1)
					avgSleepTextView.setText(Utils.getGlucoseLevelValueNoDecs(mealTimeStatisticsSleep.getAverage()));
				if(mealTimeStatisticsSleep.getFirstStdDev() !=-1)
					stdDevSleepTextView.setText(String.format(Locale.US, "%.1f", mealTimeStatisticsSleep.getFirstStdDev()));
				if(mealTimeStatisticsSleep.getPercentWithin() !=-1)
					withinSleepTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSleep.getPercentWithin())+"%");
				if(mealTimeStatisticsSleep.getPercentAboveTarget() !=-1)
					aboveSleepTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSleep.getPercentAboveTarget())+"%");
				if(mealTimeStatisticsSleep.getPercentBelowTarget() !=-1)
					belowSleepTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSleep.getPercentBelowTarget())+"%");
				if(mealTimeStatisticsSleep.getPercentBelowLow() !=-1)
					lowSleepTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSleep.getPercentBelowLow()) + "%");
				if(mealTimeStatisticsSleep.getPercentAboveHigh() !=-1)
					highSleepTextView.setText(String.format(Locale.US, "%.0f", mealTimeStatisticsSleep.getPercentAboveHigh()) +"%");
			}
		}
	}

	private class FetchAndDisplayGraph extends AsyncTask<Context, Void, ArrayList<WeeklyStatValue>> {
		@Override
		protected ArrayList<WeeklyStatValue> doInBackground(Context... params) {
			Context context = params[0];

			if ((databaseManager != null) && (context != null)) {
//				Log.d("#3640_4", "2. getWeeklyStatValue START | " + Thread.currentThread());
				ArrayList<WeeklyStatValue> statValuesFullDay = new ArrayList<WeeklyStatValue>();
				Calendar calendar = Calendar.getInstance();
				for(int i=0;i<=23;i++)
				{
					statValuesFullDay.add(getWeeklyStatValue(calendar, i, context));
				}
//				Log.d("#3640_4", "2. getWeeklyStatValue END | " + Thread.currentThread());

				return statValuesFullDay;
			}
			else {
				return null;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<WeeklyStatValue> result) {
			Context context = getActivity();

			if ((result != null) && (result.size() == 24) && (context != null)) {
				WeeklyStatGraph graph = new WeeklyStatGraph(context, Calendar.getInstance(), result);

				LinearLayout graphLayout = (LinearLayout) view
						.findViewById(R.id.graphLayout);
				LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.MATCH_PARENT,
						LinearLayout.LayoutParams.MATCH_PARENT);

				graphLayout.addView(graph, params);
			}

			dismissProgressDialogIfNeeded();
		}
	}

	public List<Integer> getGlucoseArrayValue(Calendar calendar, MealTimeDataHandler.MealType mealType, Context context) {
		Calendar calendar1 = Utils.getDayStart(calendar);
		calendar1.add(Calendar.DAY_OF_YEAR, 1);
		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTimeInMillis(calendar1.getTimeInMillis());
		calendar1.add(Calendar.DAY_OF_YEAR, -7);
		List<Integer> values = databaseManager.getGlucoseArrayBetweenForReport(mealType,
				Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
				context,"-7");
		return values;
	}

	public WeeklyStatValue getWeeklyStatValue(Calendar calendar, MealTimeDataHandler.MealType mealType, Context context) {
		Calendar calendar1 = Utils.getDayStart(calendar);
		calendar1.add(Calendar.DAY_OF_YEAR, 1);
		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTimeInMillis(calendar1.getTimeInMillis());
		calendar1.add(Calendar.DAY_OF_YEAR, -7);

		double[] values = databaseManager.getStatisticsBetween(mealType,
				Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
				context,"-7");

		int avgValue = WeeklyStatValue.INVALID_AVG;
		if(values != null) {
			avgValue = (int)values[0];
		}
		int minValue = WeeklyStatValue.INVALID_MIN;
		if(values != null) {
			minValue = (int)values[1];
		}

		int maxValue = WeeklyStatValue.INVALID_MAX;
		if(values != null) {
			maxValue = (int)values[2];
		}
		return new WeeklyStatValue(avgValue, minValue, maxValue);
	}

	public WeeklyStatValue getWeeklyStatValue(Calendar calendar, int hour, Context context) {
		Calendar calendar1 = Utils.getDayStart(calendar);
		calendar1.add(Calendar.DAY_OF_YEAR, 1);
		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTimeInMillis(calendar1.getTimeInMillis());
		calendar1.add(Calendar.DAY_OF_YEAR, -7);

		int[] values = databaseManager.getStatisticsBetween(hour,
				Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
				context,"-7");

		int avgValue = WeeklyStatValue.INVALID_AVG;
		if(values != null) {
			avgValue = values[0];
		}
		int minValue = WeeklyStatValue.INVALID_MIN;
		if(values != null) {
			minValue = values[1];
		}

		int maxValue = WeeklyStatValue.INVALID_MAX;
		if(values != null) {
			maxValue = values[2];
		}
		return new WeeklyStatValue(avgValue, minValue, maxValue);
	}


	@Override
	protected String getEmailTitle() {
		return  getResources().getString(R.string.email_subject_weekly);
	}

	@Override
	protected String getEmailBody() {
		return getResources().getString(R.string.email_body_weekly);
	}


}
