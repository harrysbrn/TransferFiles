package com.senseonics.fragments;

import android.content.Context;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ReportTabSelectionHandler;
import com.senseonics.util.Statistics;
import com.senseonics.util.StatisticsAdapter;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Calendar;

public class StatisticsListFragment extends BaseStatisticsFragment {

	private ListView listView;
	private StatisticsAdapter adapter;
	private ArrayList<Statistics> statistics;
	private TextView tvDateRange;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		View view = inflater.inflate(R.layout.fragment_statistics_list, null);
		noStatisticsLayout = (RelativeLayout) view
				.findViewById(R.id.noStatisticsLayout);
		contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
		listView = (ListView) view.findViewById(R.id.listView);

		TextView titleTextView = (TextView) view
				.findViewById(R.id.titleTextView);
		tvDateRange = (TextView) view
				.findViewById(R.id.tvDateRange);
		tvDateRange.setTypeface(Typeface.DEFAULT_BOLD);

		String glucoseUnit = Utils.getGlucoseUnitString(getActivity());
		String title = getString(R.string.one_day_distribution, glucoseUnit);
		titleTextView.setText(title);
		titleTextView.setTypeface(Typeface.DEFAULT_BOLD);

		statistics = new ArrayList<Statistics>();

		initTabs(view);
		updateTabSelection();

		adapter = new StatisticsAdapter(getActivity(), statistics);
		listView.setAdapter(adapter);

		return view;
	}

	@Override
	public void setSelected(int tabId, LinearLayout tabLayout) {
		if (selectedState != null && selectedState[tabId] == 0) {
			generateStatistics(tabId);
		}
		super.setSelected(tabId, tabLayout);
	}

	public void generateStatistics(int tabId) {

		String tabid = "";
		String strDateRange = "";
		switch (tabId) {
			case ReportTabSelectionHandler.TAB1:
				tabid = "-1";
				Calendar cal = Utils.getDayStart(Calendar.getInstance());
				cal.add(Calendar.DAY_OF_YEAR, -1);
				strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
				break;
			case ReportTabSelectionHandler.TAB2:
				tabid = "-7";
				cal = Utils.getDayStart(Calendar.getInstance());
				cal.add(Calendar.DAY_OF_YEAR, -7);
				strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
				break;
			case ReportTabSelectionHandler.TAB3:
				tabid = "-14";
				cal = Utils.getDayStart(Calendar.getInstance());
				cal.add(Calendar.DAY_OF_YEAR, -14);
				strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";

				break;
			case ReportTabSelectionHandler.TAB4:
				tabid = "-30";
				cal = Utils.getDayStart(Calendar.getInstance());
				cal.add(Calendar.DAY_OF_YEAR, -30);
				strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";

				break;
			case ReportTabSelectionHandler.TAB5:
				tabid = "-90";
				cal = Utils.getDayStart(Calendar.getInstance());
				cal.add(Calendar.DAY_OF_YEAR, -90);
				strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
				break;
		}

		tvDateRange.setText(strDateRange);

		if ((getActivity() != null) && ((MainActivity)getActivity()).getStatisticsFragment() != null) {
			createProgressDialogIfNeeded();
			showProgressDialogIfNeeded();
			new FetchAndDisplayListDataTask().execute(tabid);
		}
	}

	private class FetchAndDisplayListDataTask extends AsyncTask<String, Void, ArrayList<double[]>> {
		@Override
		protected ArrayList<double[]> doInBackground(String... params) {
			Context context = getActivity();

			if ((databaseManager != null) && (context != null)) {
				Log.d("#3640_4", "1. list generateStatistics START | " + Thread.currentThread());
				double[] values8AM = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.BREAKFAST,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context, params[0]);
				double[] values12PM = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.LUNCH,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context,params[0]);
				double[] values4PM = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.SNACK,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context,params[0]);
				double[] values8PM = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.DINNER,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context,params[0]);
				double[] values12AM = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.SLEEP,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context,params[0]);
				double[] valuesALL = databaseManager.getStatisticsBetween(MealTimeDataHandler.MealType.ALL,
						Utils.STATISTICS_GLUCOSE_MIN, Utils.STATISTICS_GLUCOSE_MAX,
						context,params[0]);
				Log.d("#3640_4", "1. list generateStatistics START | " + Thread.currentThread());

				ArrayList<double[]> result = new ArrayList<double[]>();
				result.add(values8AM);
				result.add(values12PM);
				result.add(values4PM);
				result.add(values8PM);
				result.add(values12AM);
				result.add(valuesALL);

				return result;
			}
			else {
				return null;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<double[]> result) {
			Context context = getActivity();

			if ((result != null) && (result.size() == 6) && (context != null)) {
				double[] values8AM = result.get(0);
				double[] values12PM = result.get(1);
				double[] values4PM = result.get(2);
				double[] values8PM = result.get(3);
				double[] values12AM = result.get(4);
				double[] valuesALL = result.get(5);

				if (values8AM == null && values12PM == null
						&& values4PM == null && values8PM == null && values12AM == null
						&& valuesALL == null) {
					noStatisticsLayout.setVisibility(View.VISIBLE);
					contentLayout.setVisibility(View.GONE);
				} else {
					noStatisticsLayout.setVisibility(View.GONE);
					contentLayout.setVisibility(View.VISIBLE);
					statistics.clear();
					addStatistics(MealTimeDataHandler.MealType.BREAKFAST, values8AM);
					addStatistics(MealTimeDataHandler.MealType.LUNCH, values12PM);
					addStatistics(MealTimeDataHandler.MealType.SNACK, values4PM);
					addStatistics(MealTimeDataHandler.MealType.DINNER, values8PM);
					addStatistics(MealTimeDataHandler.MealType.SLEEP, values12AM);
					addStatistics(MealTimeDataHandler.MealType.ALL, valuesALL);
					if (adapter != null) {
						adapter.notifyDataSetChanged();
					}
				}
			}

			dismissProgressDialogIfNeeded();
		}
	}

	public void addStatistics(MealTimeDataHandler.MealType mealType, double[] values) {
		if (values != null) {
			statistics.add(new Statistics(mealType, (int) values[0], (int) values[1],
					(int) values[2], (double) Math.sqrt((values[4]))));
		}
		else {
			statistics.add(new Statistics(mealType, -1, -1, -1, -1));
		}
	}

	@Override
	protected String getEmailTitle() {
		String strTabName = returnTabNameString(reportTabSelectionHandler.getSelectedTab());
		return getResources().getString(R.string.email_subject_pie_table).replace("%d", strTabName.toLowerCase());
	}

	@Override
	protected String getEmailBody() {
		String strTabName = returnTabNameString(reportTabSelectionHandler.getSelectedTab());
		return getResources().getString(R.string.email_body_table).replace("%d", strTabName.toLowerCase());
	}

}