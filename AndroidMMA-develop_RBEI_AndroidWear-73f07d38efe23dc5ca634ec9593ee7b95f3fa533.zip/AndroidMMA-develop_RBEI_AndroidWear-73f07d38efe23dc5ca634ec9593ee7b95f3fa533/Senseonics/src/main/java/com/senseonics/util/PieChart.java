package com.senseonics.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class PieChart extends View {

	private Paint paint;
	private int[] value_degree;

	private int[] colors;
	private RectF rectf;
	int temp = 0;

	public PieChart(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public PieChart(Context context, RectF rectf, int[] colors, int[] values) {

		super(context);

		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		this.colors = new int[colors.length];
		for (int i = 0; i < colors.length; ++i)
			this.colors[i] = colors[i];

		this.rectf = rectf;

		value_degree = new int[values.length];
		for (int i = 0; i < values.length; i++) {
			value_degree[i] = values[i];
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		for (int i = 0; i < value_degree.length; i++) {
			if (i == 0) {
				paint.setColor(colors[i]);
				if (value_degree[i] != 0) {
					canvas.drawArc(rectf, 0, (float) value_degree[i], true, paint);
				}
			} else {
				temp += (int) value_degree[i - 1];
				paint.setColor(colors[i]);
				if (value_degree[i] != 0) {
					canvas.drawArc(rectf, temp, (float) value_degree[i], true,
							paint);
				}
			}
		}
		temp = 0;
	}

}
