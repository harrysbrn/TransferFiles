package com.senseonics.util;

import java.util.Calendar;

import javax.inject.Inject;

public class TimeProvider {
    @Inject
    TimeProvider() {
    }

    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

    public long getCurrentSystemTime() {
        return System.currentTimeMillis();
    }
}
