package com.senseonics.bluetoothle;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.PatientEventPoint;
import com.senseonics.model.SyncModel;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.Range;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PrepareSyncingRequestTask extends
        AsyncTask<Object, Void, List<TransmitterSyncRequest>> {

    private final DatabaseManager databaseManager;
    private int countOfRecordsToSync;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;
    private SyncModel syncModel;
    private TransmitterStateModel transmitterStateModel;
    private SharedPreferences sharedPreferences;

    public enum SYNC_DATA_TYPE {
        READ_ALERTS, READ_SENSOR_GLUCOSE, READ_BLOOD_GLUCOSE
    }

    public PrepareSyncingRequestTask(DatabaseManager databaseManager, int countOfRecordsToSync, BluetoothServiceCommandClient bluetoothServiceCommandClient, SyncModel syncModel, TransmitterStateModel transmitterStateModelIn, SharedPreferences sharedPreferences) {
        this.databaseManager = databaseManager;
        this.countOfRecordsToSync = countOfRecordsToSync;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;

        this.syncModel = syncModel;
        this.transmitterStateModel = transmitterStateModelIn;

        this.sharedPreferences = sharedPreferences;
    }

    @Override
    protected List<TransmitterSyncRequest> doInBackground(Object... params) {
        List<TransmitterSyncRequest> result = new ArrayList<>();

        Range sensorGlucoseRecordRange = transmitterStateModel.getSensorGlucoseRecordRange();
        if ((sensorGlucoseRecordRange != null) && (sensorGlucoseRecordRange.getFrom() >= 1)) {

            int syncFrom = sensorGlucoseRecordRange.getTo() - countOfRecordsToSync + 1;
            if (sensorGlucoseRecordRange.getFrom() < syncFrom) {
                sensorGlucoseRecordRange = new Range(syncFrom, sensorGlucoseRecordRange.getTo());
            }

            /** RESET stored max */
            if (transmitterStateModel.getMaxSyncedSensorRecord() > sensorGlucoseRecordRange.getTo()) {
                transmitterStateModel.resetSyncRecordNumbersIfNeeded();
            }

            if (transmitterStateModel.getMaxSyncedSensorRecord() < sensorGlucoseRecordRange.getFrom()) {
                transmitterStateModel.setMaxSyncedSensorRecord(sensorGlucoseRecordRange.getFrom() - 1);
            }
            else if (transmitterStateModel.getMaxSyncedSensorRecord() == sensorGlucoseRecordRange.getTo()) {
                sensorGlucoseRecordRange = null; /** Have all the records */
            }
            else {
                sensorGlucoseRecordRange = new Range(transmitterStateModel.getMaxSyncedSensorRecord() + 1, sensorGlucoseRecordRange.getTo());
            }

            Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "**** SENSOR whole range:" + ((sensorGlucoseRecordRange != null) ? sensorGlucoseRecordRange.toString() : sensorGlucoseRecordRange));
            result.addAll(createSyncingGroupsFrom(sensorGlucoseRecordRange, SYNC_DATA_TYPE.READ_SENSOR_GLUCOSE));
        }

        Range alertRecordRange = transmitterStateModel.getAlertRecordRange();
        if ((alertRecordRange != null) && (alertRecordRange.getFrom() >= 1)) {

            int syncFrom = alertRecordRange.getTo() - Utils.NO_OF_ALARMS_TO_SYNC + 1;
            if (alertRecordRange.getFrom() < syncFrom) {
                alertRecordRange = new Range(syncFrom, alertRecordRange.getTo());
            }

            /** RESET stored max */
            if (transmitterStateModel.getMaxSyncedAlertRecord() > alertRecordRange.getTo()) {
                transmitterStateModel.resetSyncRecordNumbersIfNeeded();
            }

            if (transmitterStateModel.getMaxSyncedAlertRecord() < alertRecordRange.getFrom()) {
                transmitterStateModel.setMaxSyncedAlertRecord(alertRecordRange.getFrom() - 1);
            }
            else if (transmitterStateModel.getMaxSyncedAlertRecord() == alertRecordRange.getTo()) {
                alertRecordRange = null; /** Have all the records */
            }
            else {
                alertRecordRange = new Range(transmitterStateModel.getMaxSyncedAlertRecord() + 1, alertRecordRange.getTo());
            }

            Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "**** ALERT whole range:" + ((alertRecordRange != null) ? alertRecordRange.toString() : alertRecordRange));
            result.addAll(createSyncingGroupsFrom(alertRecordRange, SYNC_DATA_TYPE.READ_ALERTS));
        }

        Range bloodGlucoseRecordRange = transmitterStateModel.getBloodGlucoseRecordRange();
        if ((bloodGlucoseRecordRange != null) && (bloodGlucoseRecordRange.getFrom() >= 1)) {

            int syncFrom = bloodGlucoseRecordRange.getTo() - Utils.NO_OF_EVENTS_TO_SYNC + 1;
            if (bloodGlucoseRecordRange.getFrom() < syncFrom) {
                bloodGlucoseRecordRange = new Range(syncFrom, bloodGlucoseRecordRange.getTo());
            }

            /** RESET stored max */
            if (transmitterStateModel.getMaxSyncedBloodGlucoseRecord() > bloodGlucoseRecordRange.getTo()) {
                transmitterStateModel.resetSyncRecordNumbersIfNeeded();
            }

            if (transmitterStateModel.getMaxSyncedBloodGlucoseRecord() < bloodGlucoseRecordRange.getFrom()) {
                transmitterStateModel.setMaxSyncedBloodGlucoseRecord(bloodGlucoseRecordRange.getFrom() - 1);
            }
            else if (transmitterStateModel.getMaxSyncedBloodGlucoseRecord() == bloodGlucoseRecordRange.getTo()) {
                bloodGlucoseRecordRange = null; /** Have all the records */
            }
            else {
                bloodGlucoseRecordRange = new Range(transmitterStateModel.getMaxSyncedBloodGlucoseRecord() + 1, bloodGlucoseRecordRange.getTo());
            }

            Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "**** BGM whole range:" + ((bloodGlucoseRecordRange != null) ? bloodGlucoseRecordRange.toString() : bloodGlucoseRecordRange));
            result.addAll(createSyncingGroupsFrom(bloodGlucoseRecordRange, SYNC_DATA_TYPE.READ_BLOOD_GLUCOSE));
        }

        ArrayList<EventPoint> eventPoints = databaseManager
                .getNotSyncedEventsBetween(Utils.getStartDate(),
                        Utils.getEndDateFinished(), Utils.GLUCOSE_LEVEL_UNKNOWN,
                        Utils.GLUCOSE_MAX);
        if (eventPoints != null) {
            for (EventPoint eventPoint : eventPoints) {
                /** #3700 Duplicated patient events are uploaded to Transmitter (Android): mark those events as SYNCED since BluetoothPairBaseActivity.patientEventPoints might not exist in WritePatientEventParsedResponse and parsedSendBloodGlucoseDataResponse() might not be called in BluetoothPairBaseActivity when the UI does not exist */
                eventPoint.setEventSynced(true);
                databaseManager.updateEvent(eventPoint);

                if (eventPoint instanceof GlucoseEventPoint) {
                    bluetoothServiceCommandClient.postWriteGlucoseEvent((GlucoseEventPoint)eventPoint);
                } else if (eventPoint instanceof PatientEventPoint) {
                    bluetoothServiceCommandClient.postWritePatientEvent((PatientEventPoint)eventPoint);
                }
            }
        }

        // Start the synchronizing
        Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "Count of Sync Requests: " + result.size());
        return result;
    }

    @Override
    protected void onPostExecute(List<TransmitterSyncRequest> transmitterSyncRequests) {
        List<TransmitterSyncRequest> syncingRequests = new ArrayList<TransmitterSyncRequest>(transmitterSyncRequests);

        if (syncingRequests.size() == 0) { /** no records to sync */
            long timezoneOffset = Utils.getLocalTimeInMillisAdjustedToGMT();
            sharedPreferences.edit().putLong(Utils.prefLastSyncingMillis, timezoneOffset).apply();
        }
        else {
            Collections.sort(syncingRequests);

            for (TransmitterSyncRequest request : syncingRequests) {
                bluetoothServiceCommandClient.postSync(request);
            }
            syncModel.addSyncingRequests(syncingRequests);
        }
    }

    private List<TransmitterSyncRequest> createSyncingGroupsFrom(Range range,
                                                                 SYNC_DATA_TYPE syncDataType) {
        List<TransmitterSyncRequest> result = new ArrayList<>();
        if (range != null) {
            List<Range> rangeList = new ArrayList<Range>();
            rangeList.add(new Range(range.getFrom(), range.getTo()));

            result = createSyncingGroupsFromRanges(rangeList, syncDataType);

            Log.d(PrepareSyncingRequestTask.class.getSimpleName(), syncDataType + " requests for range : " + range);
        }

        return result;
    }

    private List<TransmitterSyncRequest> createSyncingGroupsFromRanges(List<Range> rangeList,
                                                                       SYNC_DATA_TYPE syncDataType) {
        List<TransmitterSyncRequest> result = new ArrayList<>();
        for (Range range : rangeList) {
            result.addAll(createSyncingGroups(range.getFrom(), range.getTo(), syncDataType));
        }

        return result;
    }

    private List<TransmitterSyncRequest> createSyncingGroups(int first, int second,
                                                             final SYNC_DATA_TYPE syncDataType) {

        List<TransmitterSyncRequest> resultList = new ArrayList<>();

        if (first <= second) {
            int expectedResponseCount = 1; /** 1 record per request for Phoenix */ //56; /** Change to 56 to be consistent with iOS: commandGroupSize */
            int inclusiveDiff = (second - first) + 1;
            if (inclusiveDiff < expectedResponseCount)
                expectedResponseCount = inclusiveDiff;

            for (int j = first; j <= second; j += expectedResponseCount) {

                int value1 = j;
                int value2 = j + expectedResponseCount - 1;

                if (value2 > second)
                    value2 = second;

                int[] startNumber, endNumber;
                if (syncDataType == SYNC_DATA_TYPE.READ_SENSOR_GLUCOSE) {
                    startNumber = BinaryOperations.data24BitsFromIntLSByteFirst(value1);
                    endNumber = BinaryOperations.data24BitsFromIntLSByteFirst(value2);
                } else {
                    startNumber = BinaryOperations.data16BitsFromIntLSByteFirst(value1);
                    endNumber = BinaryOperations.data16BitsFromIntLSByteFirst(value2);
                }

                TransmitterSyncRequest request = null;
                switch (syncDataType) {
                    case READ_SENSOR_GLUCOSE:
                        Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "Glucose - Send range: " + value1 + " to " + value2);

                        request = getRequestReadAllSensorGlucoseDataInSpecifiedRange(
                                startNumber, endNumber, value2, value2-value1+1);
                        break;
                    case READ_ALERTS:
                        Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "Alert - Send range: " + value1 + " to " + value2);

                        request = getRequestReadSensorGlucoseAlertInSpecifiedRange(
                                startNumber, endNumber, value2, value2-value1+1);
                        break;
                    case READ_BLOOD_GLUCOSE:
                        Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "BGM - Send range: " + value1 + " to " + value2);
                        request = getRequestReadBloodGlucoseDataInSpecifiedRange(
                                startNumber, endNumber, value2, value2-value1+1);
                        break;
                }

                if (request != null && request.getData() != null) {
                    Log.d(PrepareSyncingRequestTask.class.getSimpleName(), "adding request: " + request.toString());

                    resultList.add(request);
                }
            }
        }

        return resultList;
    }

    // GET REQUEST for reading all sensor glucose 0x70
    private TransmitterSyncRequest getRequestReadAllSensorGlucoseDataInSpecifiedRange(
            int[] startNumber, int[] endNumber, int recordNumber, int expectedResponseCount) {

        int expectedResponseId = CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeResponseID;
        int[] data = CommandOperations.operationToReadAllSensorGlucoseDataInSpecifiedRange(startNumber, endNumber);

        return new TransmitterSyncRequest(expectedResponseId, data, recordNumber, expectedResponseCount);
    }

    // GET REQUEST for reading sensor glucose alert 0x71
    private TransmitterSyncRequest getRequestReadSensorGlucoseAlertInSpecifiedRange(
            int[] startNumber, int[] endNumber, int recordNumber, int expectedResponseCount) {
        int expectedResponseId = CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID;
        int[] data = CommandOperations.operationToReadSensorGlucoseAlertLogInSpecifiedRange(startNumber, endNumber);
        return new TransmitterSyncRequest(expectedResponseId, data, recordNumber, expectedResponseCount);
    }


    // GET REQUEST for reading blood glucose 0x72
    private TransmitterSyncRequest getRequestReadBloodGlucoseDataInSpecifiedRange(
            int[] startNumber, int[] endNumber, int recordNumber, int expectedResponseCount) {
        int expectedResponseId = CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID;
        int[] data = CommandOperations.operationToReadLogOfBloodGlucoseDataInSpecifiedRange(startNumber, endNumber);
        return new TransmitterSyncRequest(expectedResponseId, data, recordNumber, expectedResponseCount);
    }

}
