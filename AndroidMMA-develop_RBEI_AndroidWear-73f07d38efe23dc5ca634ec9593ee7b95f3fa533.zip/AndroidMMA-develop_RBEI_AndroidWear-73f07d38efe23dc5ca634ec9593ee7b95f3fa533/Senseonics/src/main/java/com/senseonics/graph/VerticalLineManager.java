package com.senseonics.graph;

public interface VerticalLineManager {
    void drawVerticalLine(float positionX);

    void hideVerticalLine();

    boolean verticalLineIsVisible();
}
