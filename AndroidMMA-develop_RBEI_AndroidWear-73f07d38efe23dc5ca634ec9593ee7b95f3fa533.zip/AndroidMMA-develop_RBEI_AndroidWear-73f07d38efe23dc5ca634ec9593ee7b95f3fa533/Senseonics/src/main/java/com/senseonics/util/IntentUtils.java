package com.senseonics.util;

import android.content.Context;
import android.content.Intent;
import com.senseonics.graph.GraphCacheIntentService;
import java.util.Calendar;
import javax.inject.Inject;

import static com.senseonics.gen12androidapp.Constants.END_DATE;
import static com.senseonics.gen12androidapp.Constants.NEW_START_END_DATES;
import static com.senseonics.gen12androidapp.Constants.START_DATE;

public class IntentUtils {
  private final Context context;

  @Inject public IntentUtils(Context context) {
    this.context = context;
  }

  public void refreshGraphFromCache(Calendar beginDate, Calendar endDate,
      boolean newStartEndDates) {
    Intent intent = new Intent(context, GraphCacheIntentService.class);
    intent.putExtra(NEW_START_END_DATES, newStartEndDates);
    intent.putExtra(START_DATE, beginDate);
    intent.putExtra(END_DATE, endDate);
    context.startService(intent);
  }
}
