package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.os.Handler;
import android.util.Log;

import com.senseonics.bluetoothle.event.BluetoothCommunicatorReadyEvent;
import com.senseonics.bluetoothle.event.BluetoothGattErrorEvent;
import com.senseonics.bluetoothle.event.LegacyResponseHandlingEvent;
import com.senseonics.bluetoothle.event.TransportConnectionEvent;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class BluetoothCommunicator {
    private final static int TIMEOUT = 5;
    private final RequestBlockingSet requestBlockingSet;
    private TransmitterStateSyncer transmitterStateSyncer;
    private LegacyResponseHandlingEventBroadcaster broadcaster;
    private final ConsumerRunnable consumerRunnable;
    private final EventBus eventBus;
    private final Handler handler;
    private final ConnectionStateModifier connectionStateModifier;
    private TransmitterCommunicationEstablishedEvent transmitterCommunicationEstablishedEvent;
    private final CommandRequestTimer commandRequestTimer;
    private BluetoothService bluetoothService;
    private boolean amIConnected = false;
    private boolean iAmWaitingForReconnect;
    private int currentCommandId;

    @Inject
    public BluetoothCommunicator(EventBus eventBus, Handler handler, ConnectionStateModifier connectionStateModifier, RequestBlockingSet queue, CommandRequestTimer commandRequestTimer, TransmitterStateSyncer transmitterStateSyncer, LegacyResponseHandlingEventBroadcaster broadcaster, BluetoothService bluetoothService) {
        this.eventBus = eventBus;
        this.handler = handler;
        this.connectionStateModifier = connectionStateModifier;
        this.requestBlockingSet = queue;
        this.transmitterStateSyncer = transmitterStateSyncer;
        this.broadcaster = broadcaster;
        this.consumerRunnable = new ConsumerRunnable();
        this.commandRequestTimer = commandRequestTimer;
        this.bluetoothService = bluetoothService;
        this.iAmWaitingForReconnect = false;
        new Thread(consumerRunnable).start();
        eventBus.register(this);
    }

    protected boolean read(int commandId, byte[] command) {
        boolean didInitiateWrite = false;
        if (isConnected()) {
            currentCommandId = commandId;
            transmitterCommunicationEstablishedEvent.getCommandCharacteristic().setValue(command);
            didInitiateWrite = transmitterCommunicationEstablishedEvent.getBluetoothGatt().writeCharacteristic(transmitterCommunicationEstablishedEvent.getCommandCharacteristic());
        } else {
            Log.i(BluetoothCommunicator.class.getSimpleName(), "not writing because not connected");
        }
        return didInitiateWrite;
    }

    public void onEvent(final TransmitterCommunicationEstablishedEvent event) {
        Log.d("Bluetooth", "~~~~ TransmitterCommunicationEstablishedEvent: " + event.toString());
        Log.d("Bluetooth", "~~~~ TransmitterCommunicationEstablishedEvent commandChar: " + event.getCommandCharacteristic());
        Log.d("Bluetooth", "~~~~ TransmitterCommunicationEstablishedEvent: bleGatt" + event.getBluetoothGatt());
        Log.d("Bluetooth", "~~~~ TransmitterCommunicationEstablishedEvent: received E9? " + commandRequestTimer.haveReceivedE9());

        if (!commandRequestTimer.haveReceivedE9()) {
            this.transmitterCommunicationEstablishedEvent = event;
            amIConnected = true;
            Log.i(BluetoothCommunicator.class.getSimpleName(), "onTransmitterCommunicationEstablishedEvent received in " + toString());
            commandRequestTimer.setupTaskSchedule();
        }
    }

    public void onEvent(final CharacteristicChangedEvent characteristicChangedEvent) {
        boolean shouldPostEvent = true;
        if (transmitterStateSyncer.isTransmitterSynced(currentCommandId, false)) {
            syncCompleted();
        } else if (ResponseOperations.isSaveBLEBondingInformationResponseCorrect(characteristicChangedEvent.getData())) {
            Log.d(BluetoothCommunicator.class.getSimpleName(), "we just got the 0xE9 so beginning to sync transmitter state, transmitter WAS in state " + characteristicChangedEvent.getTransmitter().getConnectionState());
            commandRequestTimer.receivedE9();
            if (iAmWaitingForReconnect) {
                transmitterStateSyncer.syncTransmitterStateUponReconnect();
            } else {
                transmitterStateSyncer.syncTransmitterState();
            }
            shouldPostEvent = false;
        }

        if (shouldPostEvent) {
            broadcaster.broadcast(new LegacyResponseHandlingEvent(characteristicChangedEvent.getData()));
        }
        consumerRunnable.checkForExpectedResponse(characteristicChangedEvent.getData()[0]);
    }

    public void onEvent(TransmitterConnectionEvent event) {
        Transmitter.CONNECTION_STATE connectionState = event.getTransmitter().getConnectionState();
        Log.i(BluetoothCommunicator.class.getSimpleName(), "onTransmitterConnectionEvent " + connectionState + " isReadyToCommunicate? " + isReadyToCommunicate() + ", iAmWaitingForReconnect: " + iAmWaitingForReconnect + ", amIConnected? " + amIConnected);
        if (connectionState == Transmitter.CONNECTION_STATE.DISCONNECTED) {
            Log.d("Bluetooth", "DISCONNECT >> QUEUE size:" + requestBlockingSet.size());
            commandRequestTimer.notReceivedE9();
            commandRequestTimer.cancel();
            requestBlockingSet.clear();
            Log.d("Bluetooth", "DISCONNECT >> Clear QUEUE: " + requestBlockingSet.size());

            if (isReadyToCommunicate()) {
                Log.d("Bluetooth", "******* TRYING TO RECONNECT AFTER DISCONNECT ******");
                this.transmitterCommunicationEstablishedEvent.getBluetoothGatt().connect();
                connectionStateModifier.setConnectionStateAndPublish(event.getTransmitter(), Transmitter.CONNECTION_STATE.SEARCHING);
            } else {
                Log.d("Bluetooth", "******* ALREADY DISCONNECTED ******");
            }
        } else if (connectionState == Transmitter.CONNECTION_STATE.NEGOTIATING) {
            if (isReadyToCommunicate()) {
                Log.d("Bluetooth", "++++++++ Communicator: onEvent->NEGOTIATING");

                iAmWaitingForReconnect = false;

                this.transmitterCommunicationEstablishedEvent.getBluetoothGatt().connect();
            } else {
                Log.d("Bluetooth", "+++++++ PANIC: transmitterCommunicationEstablishedEvent->" + transmitterCommunicationEstablishedEvent);

                connectionStateModifier.setConnectionStateAndPublish(event.getTransmitter(), Transmitter.CONNECTION_STATE.DISCONNECTED);
            }
        } else if (connectionState == Transmitter.CONNECTION_STATE.CONNECTED) {
            iAmWaitingForReconnect = false;
            Log.i(BluetoothCommunicator.class.getSimpleName(), "reset iAmWaitingForReconnect due to state " + connectionState);
        }
    }

    public void onEvent(TransportConnectionEvent event) {
        Log.d("Bluetooth", "^^ TransportConnectionEvent received: txCommuEstabEvent->" + transmitterCommunicationEstablishedEvent);

        if (transmitterCommunicationEstablishedEvent == null) { // update to use isReadyToCommunicate()
            Log.d("Bluetooth", "^^ Clear QUEUE :" + requestBlockingSet.size());

            commandRequestTimer.cancel();
            requestBlockingSet.clear();

            Log.d("Bluetooth", "^^ QUEUE size:" + requestBlockingSet.size());
        }

//        if (transmitterCommunicationEstablishedEvent != null && !iAmWaitingForReconnect) {
//            connectionStateModifier.setConnectionStateAndPublish(event.getTransmitter(), Transmitter.CONNECTION_STATE.TRANSPORT_CONNECTED);
//        }

        connectionStateModifier.setConnectionStateAndPublish(event.getTransmitter(), Transmitter.CONNECTION_STATE.TRANSPORT_CONNECTED);
        amIConnected = true;
    }

    public void onEvent(BluetoothGattErrorEvent event) {
        /** Disconnect then close the gatt first */
        disconnect();

        final BluetoothDevice bluetoothDevice = event.getBluetoothDevice();

        /** Reconnect */
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (bluetoothDevice.getBondState() == BluetoothDevice.BOND_BONDED) {
                    bluetoothService.connect(new Transmitter(bluetoothDevice.getAddress(), bluetoothDevice.getName()), false);
                }
            }
        }, 500L);
    }

    public boolean disconnect() {
        if (isReadyToCommunicate()) {
            final BluetoothGatt gatt = transmitterCommunicationEstablishedEvent.getBluetoothGatt();
            Log.d("Bluetooth", "--------------- BLEComm: disconnect() --------------");
            transmitterCommunicationEstablishedEvent = null;
            amIConnected = false;
            final String transmitterName = gatt.getDevice().getName();
            Log.i(BluetoothCommunicator.class.getSimpleName(), "disconnect from " + transmitterName);
            final Transmitter transmitter = new Transmitter(gatt.getDevice().getAddress(), transmitterName, Transmitter.CONNECTION_STATE.DISCONNECTED);

            if (transmitterName != null) {
                gatt.disconnect();
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (transmitterName != null) {
                        //delay between disconnect and close recommended here: https://code.google.com/p/android/issues/detail?id=58607
                        gatt.close();
                    }
                    eventBus.postSticky(new TransmitterConnectionEvent(transmitter));
                }
            });
            commandRequestTimer.notReceivedE9();
            commandRequestTimer.cancel();
            requestBlockingSet.clear();
            return true;
        } else {
            // TODO?
        }

        Log.d(BluetoothCommunicator.class.getSimpleName(), "nothing to disconnect, return false");
        return false;
    }

    private boolean isReadyToCommunicate() {
        return transmitterCommunicationEstablishedEvent != null;
    }

    private boolean isConnected() {
        return isReadyToCommunicate() && amIConnected;
    }

    public void readRemoteRSSI() {
        if (isReadyToCommunicate()) {
            transmitterCommunicationEstablishedEvent.getBluetoothGatt().readRemoteRssi();
        }
    }

    protected void commandTimedOut(int timedOutCommandId) {
        if (transmitterStateSyncer.isTransmitterSynced(timedOutCommandId, true)) {
            syncCompleted();
        }
    }

    private void syncCompleted() {
        /** If transmitterCommunicationEstablishedEvent is null, then a disconnection event has happened */
        if (isReadyToCommunicate()) {
            commandRequestTimer.scheduleIntervalCommands();
            Transmitter transmitter = transmitterCommunicationEstablishedEvent.getTransmitter();
            if (transmitter != null) {
                connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.CONNECTED);
                eventBus.post(new BluetoothCommunicatorReadyEvent());
            }
        }
    }

    class ConsumerRunnable implements Runnable {
        private final Condition condition;
        private Request currentRequest;
        private Timer timer;
        private boolean canRetry;
        private final ReentrantLock theLock = new ReentrantLock();

        public ConsumerRunnable() {
            condition = theLock.newCondition();
            timer = new Timer();
        }

        public void checkForExpectedResponse(int responseId) {
            Log.i(ConsumerRunnable.class.getSimpleName(), "testing response (0x" + Integer.toHexString(responseId) + "), against request " + currentRequest);

            if (currentRequest != null) {
                theLock.lock();
                try {
                    // #2055 add 0x80 error code; if 0x80 is received, end the timeout and proceed to the next command
                    if (responseId == CommandAndResponseIDs.ErrorResponseID || (currentRequest.isResponseIdTheLastExpectedResponse(responseId))) {
                        canRetry = false;
                        timer.cancel();
                        condition.signal();
                    } else {
                        //push notifications are falling into restartTimer()
                        if (currentRequest.getExpectedResponseId() == responseId) {
                            restartTimer();
                        }
                    }
                } finally {
                    theLock.unlock();
                }
            }
        }

        private void restartTimer() {
            timer.cancel();
            timer = new Timer();
            timer.schedule(new TimerTask() {

                @Override
                public void run() {
                    theLock.lock();
                    try {
                        if (canRetry) {
                            sendCurrentRequest();
                            canRetry = false;
                        } else {
                            Log.d("Bluetooth", "************** Timeout command:" + currentRequest.getData()[0] + " **************");
                            commandTimedOut(currentRequest.getData()[0]);
                            condition.signal();
                        }
                    } finally {
                        theLock.unlock();
                    }
                }
            }, TimeUnit.SECONDS.toMillis(TIMEOUT));
        }

        @Override
        public void run() {

            while (true) {
                try {
                    Log.i(ConsumerRunnable.class.getSimpleName(), "top of run loop");
                    requestBlockingSet.blockingPeek();
                    if (isConnected()) {
                        theLock.lockInterruptibly();
                        try {
                            currentRequest = requestBlockingSet.take();
                            Log.i(ConsumerRunnable.class.getSimpleName(), "have request " + currentRequest);

                            canRetry = true;
                            sendCurrentRequest();

                            condition.await();
                        } finally {
                            theLock.unlock();
                        }

                    } else {
                        Log.i(ConsumerRunnable.class.getSimpleName(), "not connected, so take a nap: " + currentRequest);
                        TimeUnit.SECONDS.sleep(10);
                    }
                } catch (InterruptedException e) {
                    Log.i(ConsumerRunnable.class.getSimpleName(), "leaving due to interrupted exception");
                    canRetry = false;
                    currentRequest = null;
                    break;
                }
            }
        }

        private void sendCurrentRequest() {
            read(currentRequest.getData()[0], currentRequest.getDataBytes());
            restartTimer();
        }
    }
}