package com.senseonics.model;

public enum SIGNAL_STRENGTH {EXCELLENT(1600), GOOD(1300), LOW(800), VERY_LOW(500), POOR(350), NO_SIGNAL(0);
    private int threshold;

    SIGNAL_STRENGTH(int threshold) {
        this.threshold = threshold;
    }

    public int getThreshold() {
        return threshold;
    }
}
