package com.senseonics.events;

import com.senseonics.util.Utils;

public class ModelChangedCurrentCalibrationPhaseEvent {
    private Utils.CAL_PHASE currentCalibrationPhase;

    public ModelChangedCurrentCalibrationPhaseEvent(Utils.CAL_PHASE currentCalibrationPhase){
        this.currentCalibrationPhase = currentCalibrationPhase;
    }

    public Utils.CAL_PHASE getCurrentCalibrationPhase() {
        return currentCalibrationPhase;
    }
}
