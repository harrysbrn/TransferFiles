package com.senseonics.events;

public class RateAlertEvent {
    private final AlertEventPoint aep;
    private int notificationId;

    public RateAlertEvent(AlertEventPoint aepIn, int notificationId) {
        this.aep = aepIn;
        this.notificationId = notificationId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RateAlertEvent)) return false;

        RateAlertEvent that = (RateAlertEvent) o;

        if (Float.compare(that.aep.getRateValue(), aep.getRateValue()) != 0) return false;
        return aep.getEventType() == that.aep.getEventType();

    }

    public AlertEventPoint getAlertEventPoint() {
        return this.aep;
    }

    @Override
    public int hashCode() {
        int result = aep.getEventType().hashCode();
        result = 31 * result + (aep.getRateValue() != +0.0f ? Float.floatToIntBits(aep.getRateValue()) : 0);
        return result;
    }

    public int getNotificationId() {
        return notificationId;
    }
}
