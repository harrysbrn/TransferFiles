package com.senseonics.util;

import com.senseonics.events.EventPoint;

public class Notification {
	private String title;
	private String description;
	private long timestamp;
	private EventPoint eventPoint;

	public Notification() {
		super();
	}

	public Notification(String title, String description, long timestamp,  EventPoint eventPoint) {
		super();
		this.title = title;
		this.description = description;
		this.timestamp = timestamp;

		this.eventPoint = eventPoint;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}


	public EventPoint getEventPoint() {
		return eventPoint;
	}

	public void setEventPoint(EventPoint eventPoint) {
		this.eventPoint = eventPoint;
	}
	
	

}
