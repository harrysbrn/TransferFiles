package com.senseonics.fragments;

import android.content.Context;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ReportTabSelectionHandler;
import com.senseonics.util.PieChart;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.STATISTIC_TYPE2;

import java.util.ArrayList;
import java.util.Calendar;

public class StatisticsPieChartFragment extends BaseStatisticsFragment {

	private RelativeLayout pieChartLayout;
	private String types[];
	private int colors[];
	private LayoutInflater inflater;
	private int chartSize, paddingHorizontal;
	private TextView tvDateRange;
	private RectF rectf;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		View view = inflater.inflate(R.layout.fragment_statistics_chart,
				container, false);
		noStatisticsLayout = (RelativeLayout) view
				.findViewById(R.id.noStatisticsLayout);
		contentLayout = (LinearLayout) view.findViewById(R.id.contentLayout);
		pieChartLayout = (RelativeLayout) view.findViewById(R.id.pieChartLayout);

		TextView titleTextView = (TextView) view
				.findViewById(R.id.titleTextView);

		tvDateRange = (TextView) view
				.findViewById(R.id.tvDateRange);
		tvDateRange.setTypeface(Typeface.DEFAULT_BOLD);

		String glucoseUnit = Utils.getGlucoseUnitString(getActivity());
		String title = getString(R.string.glucose_level_distribution, glucoseUnit);
		titleTextView.setText(title);
		titleTextView.setTypeface(Typeface.DEFAULT_BOLD);

		int screenWidth = Utils.screenWidth;

        chartSize = (int)(screenWidth * (6.5 / 10));

        paddingHorizontal = 0;
		rectf = new RectF(paddingHorizontal, paddingHorizontal,
				paddingHorizontal + chartSize, paddingHorizontal + chartSize);

		colors = new int[3];
		colors[0] = getResources().getColor(R.color.gray_darker);
		colors[1] = getResources().getColor(R.color.graph_red);
		colors[2] = getResources().getColor(R.color.graph_green);

		types = new String[3];
        types[0] = Utils.getStatistics2String(getActivity(),
                STATISTIC_TYPE2.ABOVE_TARGET_LEVEL);
        types[1] = Utils.getStatistics2String(getActivity(),
                STATISTIC_TYPE2.BELOW_TARGET_LEVEL);
        types[2] = Utils.getStatistics2String(getActivity(),
				STATISTIC_TYPE2.WITHIN_TARGET_LEVELS);

		initTabs(view);
		updateTabSelection();

		return view;
	}

	@Override
	public void setSelected(int tabId, LinearLayout tabLayout) {
		if (selectedState != null && selectedState[tabId] == 0) {
			generateStatistics(tabId);
		}
		super.setSelected(tabId, tabLayout);
	}

	public void generateStatistics(int tabId) {
		Calendar calendar1 = Calendar.getInstance();

		String strDateRange = "";
		switch (tabId) {
		case ReportTabSelectionHandler.TAB1:
			calendar1.add(Calendar.DAY_OF_YEAR, -1);
			Calendar cal = Utils.getDayStart(Calendar.getInstance());
			cal.add(Calendar.DAY_OF_YEAR, -1);
			strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
			break;
		case ReportTabSelectionHandler.TAB2:
			calendar1.add(Calendar.DAY_OF_YEAR, -7);
			cal = Utils.getDayStart(Calendar.getInstance());
			cal.add(Calendar.DAY_OF_YEAR, -7);
			strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
			break;
		case ReportTabSelectionHandler.TAB3:
			calendar1.add(Calendar.DAY_OF_YEAR, -14);
			cal = Utils.getDayStart(Calendar.getInstance());
			cal.add(Calendar.DAY_OF_YEAR, -14);
			strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
			break;
		case ReportTabSelectionHandler.TAB4:
			calendar1.add(Calendar.DAY_OF_YEAR, -30);
			cal = Utils.getDayStart(Calendar.getInstance());
			cal.add(Calendar.DAY_OF_YEAR, -30);
			strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
			break;
		case ReportTabSelectionHandler.TAB5:
			calendar1.add(Calendar.DAY_OF_YEAR, -90);
			cal = Utils.getDayStart(Calendar.getInstance());
			cal.add(Calendar.DAY_OF_YEAR, -90);
			strDateRange =  "(" + Utils.formatDate(cal)+ " - " + Utils.formatDate(Calendar.getInstance()) + ")";
			break;
		}

		tvDateRange.setText(strDateRange);

		if ((getActivity() != null) && ((MainActivity)getActivity()).getStatisticsFragment() != null) {
			createProgressDialogIfNeeded();
			showProgressDialogIfNeeded();
			new FetchAndDisplayPieChartDataTask().execute(calendar1);
		}
	}

	private class FetchAndDisplayPieChartDataTask extends AsyncTask<Calendar, Void, ArrayList<Integer>> {
		@Override
		protected ArrayList<Integer> doInBackground(Calendar... params) {
			if (databaseManager != null) {
				Calendar calendar2 = Calendar.getInstance();

				Log.d("#3640_4", "1. pie generateStatistics START | " + Thread.currentThread());
				// Green: Within Target Levels
				int withinTargetLevels = databaseManager.getStatistics2Between(
						params[0], calendar2,
						Utils.GLUCOSE_TARGET_HIGH, Utils.GLUCOSE_TARGET_LOW);

				// Gray: Above Target Level
				int aboveTargetLevel = databaseManager.getStatistics2Between(params[0],
						calendar2, Utils.STATISTICS_GLUCOSE_MAX, Utils.GLUCOSE_TARGET_HIGH);

				// Red: Below Target Level
				int belowTargetLevel = databaseManager.getStatistics2Between(params[0],
						calendar2, Utils.GLUCOSE_TARGET_LOW, Utils.STATISTICS_GLUCOSE_MIN);
				Log.d("#3640_4", "1. pie generateStatistics END | " + Thread.currentThread());

				ArrayList<Integer> values = new ArrayList<Integer>();
				values.add(aboveTargetLevel);
				values.add(belowTargetLevel);
				values.add(withinTargetLevels);

				Log.i("Piechart debug", "aboveTargetLevel:"+aboveTargetLevel);
				Log.i("Piechart debug", "belowTargetLevel:"+belowTargetLevel);
				Log.i("Piechart debug", "withinTargetLevels:"+withinTargetLevels);

				return values;
			}
			else {
				return null;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<Integer> result) {
			Context context = getActivity();

			if ((result != null) && (result.size() == 3) && (context != null)) {
				int aboveTargetLevel = result.get(0);
				int belowTargetLevel = result.get(1);
				int withinTargetLevels = result.get(2);

				if (withinTargetLevels == 0 && aboveTargetLevel == 0
						&& belowTargetLevel == 0 ) {
					noStatisticsLayout.setVisibility(View.VISIBLE);
					contentLayout.setVisibility(View.GONE);
				} else {
					noStatisticsLayout.setVisibility(View.GONE);
					contentLayout.setVisibility(View.VISIBLE);
					refreshContent(new int[]{aboveTargetLevel, belowTargetLevel, withinTargetLevels}, context);
				}
			}

			dismissProgressDialogIfNeeded();
		}
	}

	public void refreshContent(int[] values, Context context) {
		pieChartLayout.removeAllViews();

		int percentsBase[] = new int[values.length];
		percentsBase = calculatePercentBase(values);
		values = timesData(percentsBase, 360);
		int percents[] = percentsBase;
		PieChart pieChart = new PieChart(context, rectf, colors, values);
		RelativeLayout.LayoutParams chartParams = new RelativeLayout.LayoutParams(
				chartSize, chartSize);
		pieChart.setLayoutParams(chartParams);
		pieChartLayout.addView(pieChart);

		// Pie chart list
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				chartSize, RelativeLayout.LayoutParams.WRAP_CONTENT);
		params.topMargin = paddingHorizontal + chartSize + chartSize / 10;

		LinearLayout listLayout = new LinearLayout(context);
		listLayout.setBackgroundResource(R.drawable.pie_chart_list_bg);
		listLayout.setOrientation(LinearLayout.VERTICAL);
		for (int i = 0; i < values.length; ++i) {
			addListItem(listLayout, colors[i], types[i], percents[i]);
		}
		listLayout.setLayoutParams(params);
		pieChartLayout.addView(listLayout);
		pieChartLayout.invalidate();
	}

	public void addListItem(LinearLayout layout, int color, String type,
			int percent) {
		if (inflater == null)
			inflater = getActivity().getLayoutInflater();

		View view = inflater.inflate(R.layout.pie_chart_listitem, null);

		TextView typeTextView = (TextView) view.findViewById(R.id.typeTextView);
		typeTextView.setText(type);

		TextView percentTextView = (TextView) view
				.findViewById(R.id.percentTextView);
		percentTextView.setText(String.valueOf(percent) + " %");

		typeTextView.setTextColor(color);
		percentTextView.setTextColor(color);

		layout.addView(view);
	}

	private int[] timesData(int[] data, int times) {
		int[] data2 = new int[data.length];
		int totalPercent = 0;
		for (int i =0; i<data.length; i++) {
			data2[i] = (times * data[i])/100;
			totalPercent +=data2[i];
		}

		if(totalPercent != times)
		{
			data2[0] += times-totalPercent;
		}
		return data2;
	}

	private int[] calculatePercentBase(int[] data) {
		int[] data3 = new int[data.length];
		double total = 0;

		for (int i = 0; i < data.length; i++) {
			total += data[i];
		}

		double totalCheck = 0;
		for (int i = 0; i < data.length; i++) {
			data3[i] = (int) Math.round((data[i] *100 / total));
			totalCheck += data3[i];
		}

		/** Use same logic as timesData() */
		if (totalCheck != 100) {
			data3[0] += 100 - totalCheck;
		}

		return data3;
	}

	@Override
	protected String getEmailTitle() {
		String strTabName = returnTabNameString(reportTabSelectionHandler.getSelectedTab());
		return  getResources().getString(R.string.email_subject_pie_chart);
	}

	@Override
	protected String getEmailBody() {
		String strTabName = returnTabNameString(reportTabSelectionHandler.getSelectedTab());
		return getResources().getString(R.string.email_body_pie).replace("%d", strTabName.toLowerCase());
	}
}
