package com.senseonics.events;

public class ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent {
    private int newValue;

    public ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
