package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

public class BluetoothAdapterWrapper {
    private BluetoothAdapter bluetoothAdapter;

    public BluetoothAdapterWrapper(BluetoothAdapter bluetoothAdapter) {
        this.bluetoothAdapter = bluetoothAdapter;
    }

    public void startLeScan(BluetoothAdapter.LeScanCallback leScanCallback) {
        bluetoothAdapter.startLeScan(leScanCallback);
    }

    public void stopLeScan(BluetoothAdapter.LeScanCallback leScanCallback) {
        bluetoothAdapter.stopLeScan(leScanCallback);
    }

    public BluetoothDevice getRemoteDevice(String address) {
        return bluetoothAdapter.getRemoteDevice(address);
    }

    public boolean isBluetoothEnabled() {
        return isBluetoothAdapterAvailable() && bluetoothAdapter.isEnabled();
    }

    public boolean isBluetoothAdapterAvailable() {
        return bluetoothAdapter != null;
    }

    public boolean isDiscovering() {
        return bluetoothAdapter.isDiscovering();
    }
}
