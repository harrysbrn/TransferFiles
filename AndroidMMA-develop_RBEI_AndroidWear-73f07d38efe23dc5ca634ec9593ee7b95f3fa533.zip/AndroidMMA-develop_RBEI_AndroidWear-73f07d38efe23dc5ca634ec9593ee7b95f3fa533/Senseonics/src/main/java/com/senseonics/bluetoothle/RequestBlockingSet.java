package com.senseonics.bluetoothle;

import android.util.Log;

import java.util.List;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class RequestBlockingSet {
    private final ReentrantLock takeLock = new ReentrantLock();
    private final Condition notEmpty = takeLock.newCondition();
    private PriorityBlockingQueue<Request> requestsQueue;

    @Inject
    public RequestBlockingSet() {
        requestsQueue = new PriorityBlockingQueue<>();
    }

    public Request blockingPeek() throws InterruptedException {
        Log.d(RequestBlockingSet.class.getSimpleName(), "blocking peek");
        Request x;
        final AtomicInteger count = new AtomicInteger(this.requestsQueue.size());
        takeLock.lockInterruptibly();
        try {
            while (this.requestsQueue.size() == 0) {
                Log.v(RequestBlockingSet.class.getSimpleName(), "about to wait in thread: " + Thread.currentThread().getId());
                notEmpty.await();
            }
            Log.v(RequestBlockingSet.class.getSimpleName(), "peeking");
            x = this.requestsQueue.peek();
        } finally {
            takeLock.unlock();
        }
        Log.v(RequestBlockingSet.class.getSimpleName(), "returning " + x);
        return x;

    }

    public void put(Request request) {
        if (!this.requestsQueue.contains(request)) {
            request.setInsertionTime(System.nanoTime());
            Log.d(RequestBlockingSet.class.getSimpleName(), "putting in thread " + Thread.currentThread().getId());
            this.requestsQueue.put(request);
            if (this.requestsQueue.size() > 0) {
                signalNotEmpty();
            }
        }
    }

    private void signalNotEmpty() {
        Log.i(RequestBlockingSet.class.getSimpleName(), "signaling with size " + this.requestsQueue.size());
        takeLock.lock();
        try {
            notEmpty.signal();
        } finally {
            takeLock.unlock();
        }
    }

    public Request take() throws InterruptedException {
        return this.requestsQueue.take();
    }

    public int size() {
        return this.requestsQueue.size();
    }

    public void clear() {
        this.requestsQueue.clear();
    }

    public boolean contains(Request request) {
        return this.requestsQueue.contains(request);
    }

    // Note: Not worried about Atomicity of these requests
    public void putAll(List<Request> requestList) {
        for (Request request : requestList) {
            put(request);
        }
    }
}
