package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class ReadWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.eveningCalibrationTime;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] data = {dataOne, dataTwo};
        int[] time = BinaryOperations.calculateTimeFromBytes(data);

        /** #4080 */
        int[] timeLocal = Utils.convertHourFromGMTtoLocal(time[0], time[1]);
        model.setEveningCalibrationLocalTimeHour(timeLocal[0]);
        model.setEveningCalibrationLocalTimeMinute(timeLocal[1]);

        model.setEveningCalibrationTimeHour(time[0]);
        model.setEveningCalibrationTimeMinute(time[1]);
    }
}
