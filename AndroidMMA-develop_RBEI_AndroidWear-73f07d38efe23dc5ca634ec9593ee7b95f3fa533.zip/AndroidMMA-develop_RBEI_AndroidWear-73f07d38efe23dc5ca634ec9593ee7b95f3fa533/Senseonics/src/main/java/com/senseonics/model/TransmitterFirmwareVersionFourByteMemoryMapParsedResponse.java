package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class TransmitterFirmwareVersionFourByteMemoryMapParsedResponse implements FourByteMemoryMapParsedResponse {

    @Inject
    public TransmitterFirmwareVersionFourByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.transmitterSoftwareVersionAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        String versionNumber = "" + Character.toString((char) dataOne)
                + Character.toString((char) dataTwo)
                + Character.toString((char) dataThree)
                + Character.toString((char) dataFour);

        model.setTransmitterVersionNumber(versionNumber);
    }
}
