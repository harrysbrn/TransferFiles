package com.senseonics.bluetoothle;

import android.util.Log;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

class TransmitterConnectionStates {
    Set<Transmitter> transmitters = new HashSet<>();

    @Inject
    TransmitterConnectionStates(EventBus eventBus) {
        eventBus.registerSticky(this);
    }

    public void onEvent(TransmitterConnectionEvent event) {
        boolean modified = transmitters.remove(event.getTransmitter());
        transmitters.add(event.getTransmitter());
        Log.i(TransmitterConnectionStates.class.getSimpleName(), "did modify set? (" + modified + ") save transmitter " + event.getTransmitter());
    }

    public List<Transmitter> transmittersThatNeedDisconnecting() {
        Log.i(TransmitterConnectionStates.class.getSimpleName(), "look for tx that need disconnecing among " + transmitters);
        return Lists.newArrayList(Iterables.filter(transmitters, new Predicate<Transmitter>() {
            @Override
            public boolean apply(Transmitter tx) {
                return tx.getConnectionState() != Transmitter.CONNECTION_STATE.DISCONNECTED;
            }
        }));
    }
}
