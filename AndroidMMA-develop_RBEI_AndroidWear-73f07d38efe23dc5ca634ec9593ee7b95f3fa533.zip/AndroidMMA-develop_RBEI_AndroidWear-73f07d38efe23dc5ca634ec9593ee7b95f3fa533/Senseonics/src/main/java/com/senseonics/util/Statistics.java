package com.senseonics.util;

import com.senseonics.gen12androidapp.MealTimeDataHandler;

public class Statistics {
	private MealTimeDataHandler.MealType mealType;
	private int average, low, high;
	double count;

	public Statistics(MealTimeDataHandler.MealType mealType, int average, int low, int high, double count) {
		super();
		this.setStatType(mealType);
		this.average = average;
		this.low = low;
		this.high = high;
		this.count = count;
	}

	public MealTimeDataHandler.MealType getMealType() {
		return mealType;
	}

	public void setStatType(MealTimeDataHandler.MealType mealType) {
		this.mealType = mealType;
	}

	public int getAverage() {
		return average;
	}

	public void setAverage(int average) {
		this.average = average;
	}

	public int getLow() {
		return low;
	}

	public void setLow(int low) {
		this.low = low;
	}

	public int getHigh() {
		return high;
	}

	public void setHigh(int high) {
		this.high = high;
	}

	public double getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
