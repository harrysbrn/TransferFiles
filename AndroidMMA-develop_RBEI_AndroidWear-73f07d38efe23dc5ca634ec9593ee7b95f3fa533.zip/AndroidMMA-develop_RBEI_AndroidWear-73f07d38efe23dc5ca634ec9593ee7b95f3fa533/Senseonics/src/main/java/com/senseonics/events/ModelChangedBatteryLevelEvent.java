package com.senseonics.events;

import com.senseonics.model.BATTERY_LEVEL;

public class ModelChangedBatteryLevelEvent {
    private BATTERY_LEVEL batteryLevel;

    public ModelChangedBatteryLevelEvent(BATTERY_LEVEL batteryLevel){
        this.batteryLevel = batteryLevel;
    }

    public BATTERY_LEVEL getBatteryLevel() {return batteryLevel;}
}
