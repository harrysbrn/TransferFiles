package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadEEP24MSPTwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse{
    @Inject
    public ReadEEP24MSPTwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.eep24MSPAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        // MSB:dataTwo is what we need
        float MSP = (1-((float)dataTwo)/255);
        model.setEEP24MSP(MSP);
    }
}
