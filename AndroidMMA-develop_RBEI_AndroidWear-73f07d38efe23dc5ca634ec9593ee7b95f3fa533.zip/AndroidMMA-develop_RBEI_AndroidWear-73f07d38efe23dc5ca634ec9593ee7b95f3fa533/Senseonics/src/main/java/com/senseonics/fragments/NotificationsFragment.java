package com.senseonics.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.DialogUtils.DateDialogManager;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.AlertOrAlarmEvent;
import com.senseonics.events.NotificationDialogEvent;
import com.senseonics.events.PredictiveRateAlertEvent;
import com.senseonics.events.RateAlertEvent;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Notification;
import com.senseonics.util.NotificationsAdapter;
import com.senseonics.util.TabView;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TimeZone;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class NotificationsFragment extends BaseFragment {

    private TabView tabView;
    private ListView notificationsList;
    private TextView date;
    @Inject
    protected DatabaseManager databaseManager;
    @Inject
    protected EventBus eventBus;
    public final static int GROUP_1 = 22;
    public final static int GROUP_2 = 33;
    public final static int GROUP_3 = 44;
    public final static int GROUP_4 = 55;
    public final static int GROUP_5 = 66;
    protected ArrayList<Notification> list1, list2, list3, list4, list5;

    protected ArrayList<Notification> redAlertList, yellowAlertList, batteryAlertList, batteryAlarmList,
            batteryNotificationList;

    protected Calendar minDate, maxDate, currentSelectedDate;

    protected ArrayList<Integer> selections = new ArrayList<Integer>();

    protected NotificationsAdapter adapter;
    protected RelativeLayout noStatisticsLayout;
    private Dialog dialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_notifications, container, false);

        initView(view);

        /** #3214 Hide the red tab */
        LinearLayout tabviewLayout = (LinearLayout)tabView.findViewById(R.id.tabviewLinearLayout);
        tabviewLayout.setWeightSum(10);
        LinearLayout tab1 = (LinearLayout)tabView.findViewById(R.id.tab1);
        tab1.setVisibility(View.GONE);

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();

        initData();
        eventBus.register(this);
        date.setText(formatDateForCurrentDate(currentSelectedDate));
        if (notificationsList != null && notificationsList.getAdapter().getCount() > 0) {
            notificationsList.setSelection(0);
        }

        /** #3664 */
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).refreshAfterFragmentChanged();
        }
    }

    @Override
    public void onPause() {
        eventBus.unregister(this);

        super.onPause();
    }

    public OnItemClickListener getOnItemClickListener(
            final NotificationsAdapter adapter) {
        return new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {
                Notification notification = (Notification) adapter
                        .getItem(position);
                Utils.showEventDetails(NotificationsFragment.this,
                        notification.getEventPoint());
            }
        };
    }

    protected void initView(final View view) {

        minDate = Calendar.getInstance();
        minDate.setTimeInMillis(Utils.startDate.getTimeInMillis());
        maxDate = Utils.sanitizeDate(Calendar.getInstance());

        noStatisticsLayout = (RelativeLayout) view.findViewById(R.id.noStatisticsLayout);

        tabView = (TabView) view.findViewById(R.id.tabView1);
        notificationsList = (ListView) view.findViewById(R.id.notificationsList);
        adapter = new NotificationsAdapter(getActivity(), tabView.getDrawables());
        notificationsList.setAdapter(adapter);
        notificationsList.setOnItemClickListener(getOnItemClickListener(adapter));

        notificationsList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

                if (notificationsList.getAdapter().getCount() > 0) {
                    Notification n = (Notification) notificationsList.getAdapter().getItem(firstVisibleItem);

                    Calendar calendarCurrent = Calendar.getInstance();
                    calendarCurrent.setTimeInMillis(n.getTimestamp());
                    String newString = formatDateForCurrentDate(calendarCurrent);
                    if (!date.getText().equals(newString)) {
                        currentSelectedDate.setTimeInMillis(calendarCurrent.getTimeInMillis());
                        date.setText(newString);
                    }
                }
            }
        });
        currentSelectedDate = Calendar.getInstance();
        currentSelectedDate = Utils.getDayStart(currentSelectedDate);

        initData();

        date = (TextView) view.findViewById(R.id.textDate);
        final DateDialogManager dateManager = new DateDialogManager() {

            @Override
            public void onDateSelected(Calendar calendar) {

                for (int i = 0; i < notificationsList.getAdapter().getCount(); i++) {

                    Notification n = (Notification) notificationsList.getAdapter().getItem(i);
                    Calendar calendarCurrent = Calendar.getInstance();
                    calendarCurrent.setTimeInMillis(n.getTimestamp());

                    if (Utils.formatDateOnlyForTimeZone(calendar, TimeZone.getDefault()).equals(Utils.formatDateOnlyForTimeZone(calendarCurrent, TimeZone.getDefault()))) {
                        currentSelectedDate.setTimeInMillis(calendarCurrent.getTimeInMillis());
                        date.setText(formatDateForCurrentDate(calendarCurrent));
                        notificationsList.setSelection(i);
                        break;
                    }
                }
            }
        };
        dateManager.onDateSelected(currentSelectedDate);

        RelativeLayout bottomLayout = (RelativeLayout) view
                .findViewById(R.id.bottomLayout);
        bottomLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (dialog != null && dialog.isShowing())
                    dialog.dismiss();

                dialog = dialogUtils.createDatePickerDialog(getActivity(),
                        currentSelectedDate, minDate, maxDate, dateManager);
                dialog.show();
            }
        });

        tabView.allTabClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                selections.clear();
                adapter.setNotifications(getAll());
            }
        });

        tabView.tab1ClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (selections.contains(GROUP_1)) {
                    selections.remove((Integer) GROUP_1);
                    checkIfSelectionsIsEmpty();
                } else
                    selections.add(GROUP_1);

                adapter.setNotifications(addSelection());
            }
        });

        tabView.tab2ClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (selections.contains(GROUP_2)) {
                    selections.remove((Integer) GROUP_2);
                    checkIfSelectionsIsEmpty();
                } else
                    selections.add(GROUP_2);

                adapter.setNotifications(addSelection());
            }
        });

        tabView.tab3ClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (selections.contains(GROUP_3)) {
                    selections.remove((Integer) GROUP_3);
                    checkIfSelectionsIsEmpty();
                } else
                    selections.add(GROUP_3);

                adapter.setNotifications(addSelection());
            }
        });

        tabView.tab4ClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (selections.contains(GROUP_4)) {
                    selections.remove((Integer) GROUP_4);
                    checkIfSelectionsIsEmpty();
                } else
                    selections.add(GROUP_4);

                adapter.setNotifications(addSelection());

            }
        });

        tabView.tab5ClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (selections.contains(GROUP_5)) {
                    selections.remove((Integer) GROUP_5);
                    checkIfSelectionsIsEmpty();
                } else
                    selections.add(GROUP_5);

                adapter.setNotifications(addSelection());
            }
        });

        tabView.performClick();
    }

    public void checkIfSelectionsIsEmpty() {
        if (selections.size() == 0) {
            selections.clear();
            adapter.setNotifications(getAll());
        }
    }

    private String formatDateForCurrentDate(Calendar dateIn) {
        return DateFormat.format("EEE dd MMMM, yyyy", dateIn).toString();
    }


    public void initData() {
        boolean notHiddenNotifications = false;
//        list1 = getList(Arrays.asList(
//                        EVENT_TYPE.CALIBRATE_EXPIRED_EVENT,
//                        EVENT_TYPE.CALIBRATE_GRACE_EVENT,
//                        EVENT_TYPE.NOTIFICATION_EVENT_RED), GROUP_1, false,
//                notHiddenNotifications);
        list1 = new ArrayList<>(); /** #3214 */

        list2 = getList(Arrays.asList(
                        EVENT_TYPE.CALIBRATE_EXPIRED_EVENT, /** #3214 */
                        EVENT_TYPE.CALIBRATE_GRACE_EVENT,
                        EVENT_TYPE.NOTIFICATION_EVENT_RED,
                        EVENT_TYPE.NOTIFICATION_EVENT_YELLOW), GROUP_1, false,
                notHiddenNotifications);

        list3 = getList(Arrays.asList(
                        EVENT_TYPE.CALIBRATE_NOW_EVENT,
                        EVENT_TYPE.NOTIFICATION_EVENT_BLUE), GROUP_1, false,
                notHiddenNotifications);

        list4 = new ArrayList<Notification>();

        list5 = new ArrayList<Notification>();

//        redAlertList = getList(Arrays.asList(EVENT_TYPE.ALARM_EVENT), GROUP_1,
//                false, notHiddenNotifications);
        redAlertList = new ArrayList<>(); /** #3214 */

        yellowAlertList = getList(Arrays.asList(
                        EVENT_TYPE.ALARM_EVENT, /** #3214 */
                        EVENT_TYPE.ALERT_EVENT,
                        EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING,
                        EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING,
                        EVENT_TYPE.RATE_ALERT_EVENT_FALLING,
                        EVENT_TYPE.RATE_ALERT_EVENT_RISING), GROUP_1, false,
                notHiddenNotifications);

//        batteryAlarmList = getList(
//                Arrays.asList(EVENT_TYPE.NOTIFICATION_EVENT_RED), GROUP_1,
//                true, notHiddenNotifications);
        batteryAlarmList = new ArrayList<>(); /** #3214 */

        batteryAlertList = getList(
                Arrays.asList(
                        EVENT_TYPE.NOTIFICATION_EVENT_RED, /** #3214 */
                        EVENT_TYPE.NOTIFICATION_EVENT_YELLOW), GROUP_1,
                true, notHiddenNotifications);

        batteryNotificationList = getList(
                Arrays.asList(EVENT_TYPE.NOTIFICATION_EVENT_BLUE), GROUP_1,
                true, notHiddenNotifications);

        adapter.setNotifications(addSelection());
        adapter.notifyDataSetChanged();
    }

    protected ArrayList<Notification> addSelection() {
        ArrayList<Notification> selection = new ArrayList<Notification>();
        if (selections.size() == 0)
            selection.addAll(getAll());
        else {
            if (selections.contains(GROUP_1))
                selection.addAll(list1);
            if (selections.contains(GROUP_2))
                selection.addAll(list2);
            if (selections.contains(GROUP_3))
                selection.addAll(list3);
            if (selections.contains(GROUP_4))
                selection.addAll(list4);
            if (selections.contains(GROUP_5))
                selection.addAll(list5);

            if (selections.contains(GROUP_1) || selections.contains(GROUP_4))
                selection.addAll(redAlertList);
            if (selections.contains(GROUP_2) || selections.contains(GROUP_4))
                selection.addAll(yellowAlertList);

            if (!selections.contains(GROUP_1) && selections.contains(GROUP_5))
                selection.addAll(batteryAlarmList);
            if (!selections.contains(GROUP_2) && selections.contains(GROUP_5))
                selection.addAll(batteryAlertList);
            if (!selections.contains(GROUP_3) && selections.contains(GROUP_5))
                selection.addAll(batteryNotificationList);

        }
        Collections.sort(selection, new Comparator<Notification>() {

            @Override
            public int compare(Notification lhs, Notification rhs) {
                long timestampeRHS = rhs.getTimestamp();
                long timestampeLHS = lhs.getTimestamp();

                if (timestampeRHS - timestampeLHS > 0) {
                    return 1;
                } else if (timestampeRHS - timestampeLHS < 0) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });

        if (selection.size() == 0) {
            noStatisticsLayout.setVisibility(View.VISIBLE);
        } else {
            noStatisticsLayout.setVisibility(View.GONE);
        }

        return selection;
    }

    protected ArrayList<Notification> getAll() {
        ArrayList<Notification> selection = new ArrayList<Notification>();
        selection.addAll(list1);
        selection.addAll(list2);
        selection.addAll(list3);
        selection.addAll(list4);
        selection.addAll(list5);
        selection.addAll(redAlertList);
        selection.addAll(yellowAlertList);

        Collections.sort(selection, new Comparator<Notification>() {

            @Override
            public int compare(Notification lhs, Notification rhs) {
                long timestampeRHS = rhs.getTimestamp();
                long timestampeLHS = lhs.getTimestamp();

                if (timestampeRHS - timestampeLHS > 0) {
                    return 1;
                } else if (timestampeRHS - timestampeLHS < 0) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });

        if (selection.size() == 0) {
            noStatisticsLayout.setVisibility(View.VISIBLE);
        } else {
            noStatisticsLayout.setVisibility(View.GONE);
        }
        return selection;
    }

    protected ArrayList<Notification> getList(List<EVENT_TYPE> eventTypes,
                                           int groupId, boolean fetchBattery,
                                           boolean onlyNotHiddenNotifications) {
        if (getActivity() != null) {
            Calendar currentDateEnd = Calendar.getInstance();
            currentSelectedDate = Utils.getDayStart(currentSelectedDate);
            currentDateEnd.add(Calendar.DAY_OF_YEAR, 1);

            return databaseManager.getNotificationsBetween(getActivity(),
                Utils.getDayStart(Utils.startDate), currentDateEnd, eventTypes, 1,
                    fetchBattery, onlyNotHiddenNotifications, null, true);

        } else {
            return new ArrayList<Notification>();
        }
    }

    public void onEventMainThread(RateAlertEvent event) {
        initData();
    }

    public void onEventMainThread(PredictiveRateAlertEvent event) {
        initData();
    }

    public void onEventMainThread(AlertOrAlarmEvent event) {
        initData();
    }

    public void onEventMainThread(NotificationDialogEvent event) {
        initData();
    }

}