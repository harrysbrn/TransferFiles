package com.senseonics.gen12androidapp;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

import com.senseonics.fragments.MealTimesFragment;
import com.senseonics.fragments.MealTimesFragment.MealTimesManager;

public class MealTimesActivity extends BaseActivity {

	protected MealTimesFragment mealTimesFragment;


    protected MealTimesManager mealTimesManager = new MealTimesManager() {
	};


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_simple_fragment, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.meal_times);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);
		

		mealTimesFragment = new MealTimesFragment();
		mealTimesFragment.setMealTimesManager(mealTimesManager);
		getFragmentManager().beginTransaction()
				.replace(R.id.fragment, mealTimesFragment)
				.commitAllowingStateLoss();
		
	}
	
	public void setNaviBarRightItemTextViewOnClick(OnClickListener listener) {
		naviBarRightItemTextView.setOnClickListener(listener);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}


}
