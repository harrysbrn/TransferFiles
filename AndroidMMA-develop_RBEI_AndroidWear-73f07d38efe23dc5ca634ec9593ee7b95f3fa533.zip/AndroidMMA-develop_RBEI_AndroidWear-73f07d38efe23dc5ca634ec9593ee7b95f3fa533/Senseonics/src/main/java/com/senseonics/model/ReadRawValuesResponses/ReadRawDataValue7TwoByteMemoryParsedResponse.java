package com.senseonics.model.ReadRawValuesResponses;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.model.TwoByteMemoryMapParsedResponse;

import javax.inject.Inject;

public class ReadRawDataValue7TwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadRawDataValue7TwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.RawDataValue7Address;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int intVal = (dataTwo << 8) | (dataOne);
        Log.d("RawValue", "raw 7:" + intVal);
        model.setRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7, intVal);
    }
}
