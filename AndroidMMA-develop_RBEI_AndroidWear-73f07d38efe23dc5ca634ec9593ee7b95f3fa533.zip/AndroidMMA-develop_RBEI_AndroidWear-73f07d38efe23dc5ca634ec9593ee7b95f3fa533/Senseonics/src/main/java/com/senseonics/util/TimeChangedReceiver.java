package com.senseonics.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.gen12androidapp.ObjectGraphApplication;
import com.senseonics.model.TransmitterStateModel;

import javax.inject.Inject;

public class TimeChangedReceiver extends BroadcastReceiver {
    @Inject
    protected BluetoothServiceCommandClient bluetoothServiceCommandClient;

    @Inject
    protected TransmitterStateModel transmitterStateModel;

    @Override
    public void onReceive(Context context, Intent intent) {
        ((ObjectGraphApplication) context.getApplicationContext()).inject(this);

//        Log.d("#3734", TimeChangedReceiver.class.getSimpleName() + ": onReceive() " + intent.getAction());

        if (intent.getAction().equals("android.intent.action.TIME_SET")) {
//            Log.d("#3734", "Time Change");
            transmitterStateModel.adjustLastReadDateTimeWhenSendingReadCommand();
            bluetoothServiceCommandClient.postReadCurrentTransmitterDateAndTime();
        }
        else if (intent.getAction().equals("android.intent.action.TIMEZONE_CHANGED")) {
//            Log.d("#3734", "Timezone Change");
            transmitterStateModel.adjustLastReadDateTimeWhenSendingReadCommand();
            bluetoothServiceCommandClient.postReadCurrentTransmitterDateAndTime();

            /** #4080 */
            int morningLocalHour = transmitterStateModel.getMorningCalibrationLocalTimeHour();
            int morningLocalMinute = transmitterStateModel.getMorningCalibrationLocalTimeMinute();
            if (morningLocalHour != -1 && morningLocalMinute != -1) {
                int[] morningGMT = Utils.convertHourFromLocaltoGMT(morningLocalHour, morningLocalMinute);
                bluetoothServiceCommandClient.postWriteMorningCalibrationTime(morningGMT[0], morningGMT[1]);
            }

            int eveningLocalHour = transmitterStateModel.getEveningCalibrationLocalTimeHour();
            int eveningLocalMinute = transmitterStateModel.getEveningCalibrationLocalTimeMinute();
            if (eveningLocalHour != -1 && eveningLocalMinute != -1) {
                int[] eveningGMT = Utils.convertHourFromLocaltoGMT(eveningLocalHour, eveningLocalMinute);
                bluetoothServiceCommandClient.postWriteEveningCalibrationTime(eveningGMT[0], eveningGMT[1]);
            }
        }
    }

}
