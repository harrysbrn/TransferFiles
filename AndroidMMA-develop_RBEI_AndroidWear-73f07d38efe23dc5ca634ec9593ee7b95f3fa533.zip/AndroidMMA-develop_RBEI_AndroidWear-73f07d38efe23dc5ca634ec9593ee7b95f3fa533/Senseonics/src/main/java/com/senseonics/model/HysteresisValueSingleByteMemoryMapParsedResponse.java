package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

// 0x0094 Low Level Alarm/Alert Hysteresis - MG/DL
public class HysteresisValueSingleByteMemoryMapParsedResponse implements  SingleByteMemoryMapParsedResponse {

    @Inject
    public HysteresisValueSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.hysteresisValueAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {

        model.setHysteresisLowGlucoseValueMgDl(data);

    }


}
