package com.senseonics.fragments;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.events.EventUtils;
import com.senseonics.events.ExerciseEventPoint;
import com.senseonics.events.HealthEventPoint;
import com.senseonics.events.InsulinEventPoint;
import com.senseonics.events.MealEventPoint;
import com.senseonics.graph.util.Glucose;
import com.senseonics.util.TypefaceFetcher;
import com.senseonics.util.Utils;
import com.senseonics.view.Arrow;

import java.util.GregorianCalendar;
import java.util.TimeZone;

public class PopupGraphManagerView extends RelativeLayout {


    public PopupGraphManagerView(Context context, int topLayoutHeight) {
        super(context);

        View.inflate(context, R.layout.glucose_event_popup, this);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, topLayoutHeight);
        setLayoutParams(params);

        Log.d(PopupGraphManagerView.class.getSimpleName(), "ctor height: " + topLayoutHeight + ", my: " + getHeight());

    }

    void putPopUp(final float x, String glucoseValueString,
                  String time, String notificationText, String value1, int notificationTextColorId,
                  int notificationBgColorId, int notificationIconId, int currentTopLayoutHeight, int alertInfoHeight) {

        int arrowSize = alertInfoHeight;
        int popUpEventHeight = currentTopLayoutHeight + arrowSize;
        Log.d(PopupGraphManagerView.class.getSimpleName(), "current height: " + currentTopLayoutHeight + ", my: " + getHeight() + ", alert: " + alertInfoHeight + ", arrowSize: " + arrowSize);


        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, popUpEventHeight);
        setLayoutParams(params);

        TextView glucoseValue = (TextView) findViewById(R.id.glucoseValue);
        glucoseValue.setText(glucoseValueString);
        // Set the popup glucose text color all to Black color
        glucoseValue.setTextColor(getResources().getColor(R.color.black));
        setDashTextBold(glucoseValue);

        TextView timeTextView = (TextView) findViewById(R.id.time);
        timeTextView.setText(time);

        String unitString = Utils.getGlucoseUnitString(getContext());
        TextView glucoseUnitTextView = (TextView) findViewById(R.id.glucoseUnit);
        glucoseUnitTextView.setText(unitString);

        RelativeLayout.LayoutParams paramsTop = new RelativeLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, currentTopLayoutHeight);
        ViewGroup content = (ViewGroup) findViewById(R.id.popUpContentLayout);
        content.setLayoutParams(paramsTop);

        LinearLayout notificationBar = (LinearLayout) findViewById(R.id.notificationBar);

        LinearLayout.LayoutParams paramsAlert = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, alertInfoHeight);
        notificationBar.setLayoutParams(paramsAlert);

        // Set the gradient for the popup top panel to be from white to respective color
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFFFFFFF, Color.parseColor(getResources().getString(notificationBgColorId))});
        gd.setCornerRadius(0f);
        content.setBackground(gd); /** this works >= JELLY_BEAN (4.1) */

        ImageView imageView = (ImageView) notificationBar
                .findViewById(R.id.imageView);
        if (notificationIconId != -1) {
            imageView.setImageResource(notificationIconId);
//            imageView.setVisibility(View.VISIBLE);
            imageView.setVisibility(View.GONE); /** #3214 */
        } else {
            // #2069 "No Sensor Glucose Reading" should have no icon, set View to GONE
            imageView.setVisibility(View.GONE);
        }

        TextView textView = (TextView) notificationBar
                .findViewById(R.id.textView);
        textView.setTextColor(getResources().getColor(notificationTextColorId));
        textView.setText(notificationText);


        TextView tvValue1 = (TextView) notificationBar
                .findViewById(R.id.value_1);
        tvValue1.setTextColor(getResources().getColor(notificationTextColorId));
        tvValue1.setText(value1);
        setVisibility(View.VISIBLE);

        Arrow arrow = (Arrow) findViewById(R.id.popupArrow);
        RelativeLayout.LayoutParams arrowParams = new RelativeLayout.LayoutParams(
                arrowSize, arrowSize);

        arrowParams.topMargin = currentTopLayoutHeight;
        arrowParams.leftMargin = (int) (x - arrowSize / 2);
        arrow.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        arrow.setTriangleColor(Color.parseColor(getResources().getString(notificationBgColorId)));
        arrow.setLayoutParams(arrowParams);

    }

    public void putGlucosePopUp(final float x, Glucose glucose, int currentTopLayoutHeight, int alertInfoHeight) {

        String glucoseValue = Utils.getGlucoseLevelValue(glucose.getGlucoseLevel());
        int colorId = Utils.getBackgroundColorForGlucose(glucose.getGlucoseLevel());

        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(glucose.getTimestamp());
        String time = Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getContext());

        int notificationTextId = Utils.getGlucoseLevelAlertText(glucose.getGlucoseLevel());
        String notificationText;
        if (notificationTextId != -1)
            notificationText = getResources().getString(notificationTextId);
        else
            notificationText = " ";
        int notificationIconId = Utils.getNotificationIconForGlucose(glucose.getGlucoseLevel());

        int textColorId = Utils.getTextColorForGlucose(glucose.getGlucoseLevel());
        putPopUp(x, glucoseValue, time, notificationText, "", textColorId,
                colorId, notificationIconId, currentTopLayoutHeight, alertInfoHeight);
    }


    public void putNoSensorGlucosePopUp(final float x, int currentTopLayoutHeight, int alertInfoHeight) {
        String glucoseValue = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
        String time = "";
        int colorId = android.R.color.black;
        String notificationText = getResources()
                .getString(R.string.no_sensor_glucose_reading);
        // #2069 "No Sensor Glucose Reading" should have no icon, set to -1
        int notificationIconId = -1;
        int textColorId = R.color.black;
        int notificationBgColorId = android.R.color.white;

        putPopUp(x, glucoseValue, time, notificationText, "", textColorId,
                notificationBgColorId, notificationIconId, currentTopLayoutHeight, alertInfoHeight);
    }
    
    public void putEventPopUp(final float x, EventPoint eventPoint, int currentTopLayoutHeight, int alertInfoHeight) {

        String glucoseValue;
        if (eventPoint.getGlucoseLevel() == Utils.GLUCOSE_LEVEL_UNKNOWN) {
            glucoseValue = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
        } else
            glucoseValue = Utils.getGlucoseLevelValue(eventPoint
                    .getGlucoseLevel());
        int colorId = R.color.black;
        String time = Utils.getTime24HrFormat(eventPoint.getCalendar(), TimeZone.getDefault(), getContext());

        String notificationText, value1="";
        int notificationTextColorId, notificationBgColorId;
        int notificationIconId = -1;
        Utils.EVENT_TYPE eventType = eventPoint.getEventType();
        switch (eventType) {
            case CALIBRATION:
                notificationText = getResources().getString(R.string.calibration);
                notificationIconId = Utils.getEventImageResId(eventPoint);
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            case PREDICTIVE_ALERT_EVENT_FALLING:
                notificationText = getResources().getString(
                        R.string.predicted_low_glucose_alert_title);
                notificationIconId = R.drawable.alert_dropping;
                notificationTextColorId = android.R.color.black;
                notificationBgColorId = R.color.graph_yellow;
                break;
            case PREDICTIVE_ALERT_EVENT_RISING:
                notificationText = getResources().getString(
                        R.string.predicted_high_glucose_alert_title);
                notificationIconId = R.drawable.alert_rising;
                notificationTextColorId = android.R.color.black;
                notificationBgColorId = R.color.graph_yellow;
                break;

            case RATE_ALERT_EVENT_FALLING:
                notificationText = getResources().getString(
                        R.string.rate_falling_alert_title);
                notificationIconId = R.drawable.alert_dropping;
                notificationTextColorId = android.R.color.black;
                notificationBgColorId = R.color.graph_yellow;
                break;
            case RATE_ALERT_EVENT_RISING:
                notificationText = getResources().getString(
                        R.string.rate_rising_alert_title);
                notificationIconId = R.drawable.alert_rising;
                notificationTextColorId = android.R.color.black;
                notificationBgColorId = R.color.graph_yellow;
                break;
            case ALERT_EVENT:

                notificationBgColorId = R.color.graph_yellow;

                AlertEventPoint alertEvent = (AlertEventPoint) eventPoint;
                notificationText = Utils.getAlertEventTitle(getContext(), alertEvent.getAlertType());

                notificationIconId = R.drawable.white_glucose_warning_icon;
                notificationTextColorId = android.R.color.black;

                break;

            case ALARM_EVENT:

                notificationBgColorId = R.color.graph_red;

                AlertEventPoint alarmEvent = (AlertEventPoint) eventPoint;
                notificationText = Utils.getAlarmEventTitle(getContext(), alarmEvent.getAlertType());

                notificationIconId = R.drawable.white_glucose_warning_icon;
                notificationTextColorId = android.R.color.white;

                break;
            case GLUCOSE_EVENT:
                notificationText = getResources().getString(R.string.glucose_event);
                notificationIconId = R.drawable.icon_graph_glucose;
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            case MEAL_EVENT:
                notificationText = EventUtils.getMealTypeName(getContext(), ((MealEventPoint) eventPoint).getMealType())+":";
                value1 =((MealEventPoint)eventPoint).getCarbs()+ " " + getContext().getResources().getString(R.string.grams);
                notificationIconId = R.drawable.icon_graph_meal;
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            case INSULIN_EVENT:
                notificationText = EventUtils.getInsulinTypeName(getContext(), ((InsulinEventPoint) eventPoint).getInsulinType())+":";
                value1 =((InsulinEventPoint)eventPoint).getUnits()+" "+ getContext().getResources().getString(
                        R.string.units);
                notificationIconId = R.drawable.icon_graph_insulin;
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            case HEALTH_EVENT:
                notificationText = EventUtils.getHealthConditionName(getContext(), ((HealthEventPoint) eventPoint).getHealthCondition())+":";
                value1 =EventUtils.getHealthSeverityName(getContext(), ((HealthEventPoint) eventPoint).getHealthSeverity());
                notificationIconId = R.drawable.icon_graph_health;
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            case EXERCISE_EVENT:
                notificationText  = EventUtils.getExerciseIntensityName(getContext(),((ExerciseEventPoint)eventPoint).getIntensity())+":";
                value1 =((ExerciseEventPoint)eventPoint).getDurationText(getContext());
                notificationIconId = R.drawable.icon_graph_exercise;
                notificationTextColorId = R.color.graph_white;
                notificationBgColorId = R.color.blue;
                break;
            default:
                notificationText = " ";
                notificationIconId = -1;
                notificationTextColorId = android.R.color.black;
                notificationBgColorId = android.R.color.white;
                break;
        }

        putPopUp(x, glucoseValue, time, notificationText, value1,
                notificationTextColorId, notificationBgColorId,
                notificationIconId, currentTopLayoutHeight, alertInfoHeight);
    }

    private void setDashTextBold(TextView tv) {
        if (tv.getText().equals(Utils.GLUCOSE_LEVEL_UNKNOWN_STRING))
            tv.setTypeface(TypefaceFetcher.get(getContext(), "Fonts/Roboto-Bold.ttf"));
        else
            tv.setTypeface(TypefaceFetcher.get(getContext(), "Fonts/Roboto-Regular.ttf"));
    }
}
