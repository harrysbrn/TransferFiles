package com.senseonics.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SenseonicsDBHelper extends SQLiteOpenHelper {

	private static final String DATABASE_NAME = "milan.db";
	private static final int DATABASE_VERSION = 23;
	public static final String GLUCOSE_READINGS_TABLE = "glucoseReadings",
			EVENTS_TABLE = "events", ALERTS_TABLE = "alerts";

	// Index name
	private static final String IdxGlucoseTG = "IdxGlucoseTG";
	private static final String IdxGlucoseG = "IdxGlucoseG";
	private static final String IdxGlucoseT = "IdxGlucoseT";
	private static final String IdxEventsET = "IdxEventsET";
	private static final String IdxEventsT = "IdxEventsT";
	private static final String IdxEventsE = "IdxEventsE";

	// glucose readings fields
	public static final String GLUCOSE_LEVEL_FIELD = "glucoseLevel";
	public static final String GROUP_ID_FIELD = "groupId";
	public static final String GLUCOSE_RAW_1_FIELD = "glucoseRaw1"; /** #3194 */
	public static final String GLUCOSE_RAW_2_FIELD = "glucoseRaw2";
	public static final String GLUCOSE_RAW_3_FIELD = "glucoseRaw3";
	public static final String GLUCOSE_RAW_4_FIELD = "glucoseRaw4";
	public static final String GLUCOSE_RAW_5_FIELD = "glucoseRaw5";
	public static final String GLUCOSE_RAW_6_FIELD = "glucoseRaw6";
	public static final String GLUCOSE_RAW_7_FIELD = "glucoseRaw7";
	public static final String GLUCOSE_RAW_8_FIELD = "glucoseRaw8";

	// event fields
	public static final String EVENT_TYPE_FIELD = "eventType";
	public static final String NOTES_FIELD = "notes";
	public static final String AMOUNT_FIELD = "amount";
	public static final String CUSTOM_FIELD = "customType";
	public static final String CUSTOM_FIELD2 = "customType2";
	public static final String HEALTH_SEVERITY_FIELD = "healthSeverity";
	public static final String EXERCISE_INTENSITY_FIELD = "exerciseIntensity";

	// alerts field
	public static final String START_TIME_FIELD = "startTime";
	public static final String END_TIME_FIELD = "endTime";
	public static final String ALERT_CODE_FIELD = "alertCode";
	public static final String TIMESTAMP_FIELD = "timestamp";
	public static final String RECORD_NUMBER_FIELD = "recordNumber";

	public static final String EVENT_SYNCED = "event_synced";
	public static final String EVENT_HIDDEN = "event_hidden";
	public static final String EVENT_HIDDEN_TIMESTAMP = "event_hidden_timestamp";
	public static final String TRANSMITTER_NAME = "transmitter_name";
	public static final String UNKNOWN_ERROR_CODE = "unknown_error_code";

	public static final int NOT_SYNCED = 0, SYNCED = 1, NOT_HIDDEN = 0, HIDDEN = 1;

    public SenseonicsDBHelper(Context context) {
		this(context, DATABASE_NAME);
	}

    SenseonicsDBHelper(Context context, String name) {
        super(context, name, null, DATABASE_VERSION);
    }

	@Override
	public void onCreate(SQLiteDatabase db) {

		String CREATE_READINGS_TABLE = "create table if not exists "
				+ GLUCOSE_READINGS_TABLE + " ("
				+ TIMESTAMP_FIELD + " LONG primary key , "
				+ GLUCOSE_LEVEL_FIELD + " INTEGER, "
				+ GROUP_ID_FIELD + " INTEGER, "
				+ RECORD_NUMBER_FIELD + " LONG, "
				+ GLUCOSE_RAW_1_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_2_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_3_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_4_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_5_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_6_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_7_FIELD + " INTEGER DEFAULT 0, "
				+ GLUCOSE_RAW_8_FIELD + " INTEGER DEFAULT 0 "
				+ ")";

		String CREATE_EVENTS_TABLE = "create table if not exists "
				+ EVENTS_TABLE + " (id integer primary key autoincrement, "
				+ TIMESTAMP_FIELD + " LONG, "
				+ GLUCOSE_LEVEL_FIELD + " INTEGER, "
				+ EVENT_TYPE_FIELD + " INTEGER, "
				+ NOTES_FIELD + " TEXT, "
				+ AMOUNT_FIELD + " FLOAT ,"
				+ CUSTOM_FIELD + " INTEGER, "
				+ CUSTOM_FIELD2 + " INTEGER, "
				+ HEALTH_SEVERITY_FIELD + " INTEGER, "
				+ EXERCISE_INTENSITY_FIELD + " INTEGER, "
				+ EVENT_SYNCED + " SMALLINT, "
				+ EVENT_HIDDEN + " SMALLINT, "
				+ EVENT_HIDDEN_TIMESTAMP + " LONG, " 
				+ TRANSMITTER_NAME + " TEXT, " 
				+ UNKNOWN_ERROR_CODE + " INTEGER, "
				+ RECORD_NUMBER_FIELD + " LONG "
				+ ")";

        String CREATE_CONNECTED_TRANSMITTER_TABLE = "create table if not exists "
                + ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE + " (_id integer primary key, "
                + ConnectedTransmitterTableInfo.NAME_FIELD + " TEXT, "
                + ConnectedTransmitterTableInfo.ADDRESS_FIELD + " TEXT, "
                + ConnectedTransmitterTableInfo.STATUS_FIELD + " TEXT )";

		db.execSQL(CREATE_READINGS_TABLE);
		db.execSQL(CREATE_EVENTS_TABLE);
        db.execSQL(CREATE_CONNECTED_TRANSMITTER_TABLE);

		createIndicies(db);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		if ( oldVersion < DATABASE_VERSION ) {
			if (oldVersion == 22) {
				// add new columns for database version 22
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_1_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_2_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_3_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_4_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_5_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_6_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_7_FIELD + " INTEGER DEFAULT 0");
				db.execSQL("ALTER TABLE " + GLUCOSE_READINGS_TABLE + " ADD COLUMN " + GLUCOSE_RAW_8_FIELD + " INTEGER DEFAULT 0");
			}

			db.execSQL("DROP INDEX IF EXISTS " + IdxGlucoseTG);
			db.execSQL("DROP INDEX IF EXISTS " + IdxGlucoseG);
			db.execSQL("DROP INDEX IF EXISTS " + IdxGlucoseT);
			db.execSQL("DROP INDEX IF EXISTS " + IdxEventsET);
			db.execSQL("DROP INDEX IF EXISTS " + IdxEventsT);
			db.execSQL("DROP INDEX IF EXISTS " + IdxEventsE);
			createIndicies(db);
		}
		else {
			db.execSQL("DROP TABLE IF EXISTS " + GLUCOSE_READINGS_TABLE);
			db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE);
			db.execSQL("DROP TABLE IF EXISTS " + ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE);
			onCreate(db);
		}
	}

	private void createIndicies(SQLiteDatabase db) {
		db.execSQL("CREATE INDEX " + IdxGlucoseTG + " on " + GLUCOSE_READINGS_TABLE + "(" + TIMESTAMP_FIELD + ", " + GLUCOSE_LEVEL_FIELD + ")");
		db.execSQL("CREATE INDEX " + IdxGlucoseG + " on " + GLUCOSE_READINGS_TABLE + "(" + GLUCOSE_LEVEL_FIELD + ")");
		db.execSQL("CREATE INDEX " + IdxGlucoseT + " on " + GLUCOSE_READINGS_TABLE + "(" + TIMESTAMP_FIELD + ")");
		db.execSQL("CREATE INDEX " + IdxEventsET + " on " + EVENTS_TABLE + "(" + TIMESTAMP_FIELD + ", " + EVENT_TYPE_FIELD + ")");
		db.execSQL("CREATE INDEX " + IdxEventsT + " on " + EVENTS_TABLE + "(" + TIMESTAMP_FIELD + ")");
		db.execSQL("CREATE INDEX " + IdxEventsE + " on " + EVENTS_TABLE + "(" + EVENT_TYPE_FIELD  + ")");
	}

}
