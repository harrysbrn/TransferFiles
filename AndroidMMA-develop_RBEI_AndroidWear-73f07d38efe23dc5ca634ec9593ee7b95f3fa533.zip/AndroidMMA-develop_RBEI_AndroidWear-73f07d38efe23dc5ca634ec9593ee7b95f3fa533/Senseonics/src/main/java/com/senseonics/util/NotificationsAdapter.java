package com.senseonics.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class NotificationsAdapter extends BaseAdapter {

	private ArrayList<Notification> notifications = new ArrayList<Notification>();
	private LayoutInflater inflater;

	public NotificationsAdapter(Context context, ArrayList<Integer> drawables) {
		super();
		inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	private class ViewHolder {
        public RelativeLayout dateLayout;
		public TextView title, separator, description, time;
		public ImageView icon;
	}

	@Override
	public int getCount() {
		return notifications.size();
	}

	@Override
	public Object getItem(int position) {
		return notifications.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;
        boolean needSeparator = false;
		if (convertView == null) {

			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.notification_list_item,
					parent, false);
			holder.title = (TextView) convertView.findViewById(R.id.title);
			holder.separator = (TextView) convertView.findViewById(R.id.separator);
			holder.description = (TextView) convertView
					.findViewById(R.id.description);
			holder.time = (TextView) convertView.findViewById(R.id.time);
			holder.icon = (ImageView) convertView.findViewById(R.id.icon);
            holder.dateLayout = (RelativeLayout) convertView.findViewById(R.id.notificationDateLayout);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Notification notification = notifications.get(position);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(notification.getTimestamp());
        String dateTextCurrent = Utils.formatWeekDateYearForTimeZone(calendar, TimeZone.getDefault());

        if (position == 0) {
            needSeparator = true;
        }
        else {
            needSeparator = false;

            Notification notificationPrevious = notifications.get(position-1);
            Calendar calendarPrevious = Calendar.getInstance();
            calendarPrevious.setTimeInMillis(notificationPrevious.getTimestamp());
            String dateTextPrevious = Utils.formatWeekDateYearForTimeZone(calendarPrevious, TimeZone.getDefault());

            // other conditions to true
            if(!dateTextCurrent.equals(dateTextPrevious)) {
                needSeparator = true;
            }
        }

        if (needSeparator == true) {
            TextView dateTextView = (TextView)convertView.findViewById(R.id.separator_new);
            dateTextView.setText(dateTextCurrent);
            holder.dateLayout.setVisibility(View.VISIBLE);
        }
        else {
            holder.dateLayout.setVisibility(View.GONE);
        }

		holder.title.setText(notification.getTitle());
		
		// Only show the description if it's an event, not a notification
		EVENT_TYPE eventType = notification.getEventPoint().getEventType();
		if(eventType == EVENT_TYPE.GLUCOSE_EVENT || 
				eventType == EVENT_TYPE.CALIBRATION || 
				eventType == EVENT_TYPE.MEAL_EVENT || 
				eventType == EVENT_TYPE.INSULIN_EVENT || 
				eventType == EVENT_TYPE.HEALTH_EVENT || 
				eventType == EVENT_TYPE.EXERCISE_EVENT)
		{
			holder.separator.setText(",");
			holder.description.setText(notification.getDescription());
		}

		holder.time.setText(Utils.getTime24HrFormat(calendar,TimeZone.getDefault(), parent.getContext()));

		//holder.time.setText(DateFormat.format("hh:mm a",
		//		notification.getTimestamp()).toString());
		if (notification.getEventPoint().getEventType() != null) 
			holder.icon.setImageResource(Utils.getEventImageResId(notification
					.getEventPoint()));
		
		return convertView;
	}

	public ArrayList<Notification> getNotifications() {
		return notifications;
	}

	public void setNotifications(ArrayList<Notification> notifications) {
		this.notifications = notifications;
		notifyDataSetChanged();
	}

}
