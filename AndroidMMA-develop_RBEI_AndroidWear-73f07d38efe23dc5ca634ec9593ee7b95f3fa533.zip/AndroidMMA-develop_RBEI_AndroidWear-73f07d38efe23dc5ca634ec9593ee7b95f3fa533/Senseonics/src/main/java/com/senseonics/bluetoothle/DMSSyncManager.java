package com.senseonics.bluetoothle;

import android.content.Context;
import android.util.Log;
import com.senseonics.model.SyncModel;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.DMSUploadTask;
import com.senseonics.util.NotificationUtility;
import com.senseonics.util.Utils;
import de.greenrobot.event.EventBus;
import java.util.Calendar;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DMSSyncManager {
    private final String Tag = "DMS(DMSSyncManager)";
//    private final int SYNC_DELAY = 150 * 1000; // 2mins + 30s
    private final int DMS_UPLOADING_INTERVAL = 2 * 60; // 120 minutes
    private final int DMS_UPLOAD_ALLOW_NEXT_OPERATION_MINUTES = 30;
    private final int HOURS_BACK_DEFAULT = 4 * 24; // 4 days

    private AccountConstants accountConstants;
    private Context context;
    private EventBus eventBus;
    private ApplicationForegroundState applicationForegroundState;
    private NotificationUtility notificationUtility;
    private SyncModel syncModel;

    @Inject
    public DMSSyncManager(
            AccountConstants accountConstants, Context context, EventBus eventBus, ApplicationForegroundState applicationForegroundState, NotificationUtility notificationUtility, SyncModel syncModelIn) {
        this.accountConstants = accountConstants;
        this.context = context;
        this.eventBus = eventBus;
        this.applicationForegroundState = applicationForegroundState;
        this.notificationUtility = notificationUtility;
        this.syncModel = syncModelIn;
    }

    public void startSync() {
        /** #3707 */
        if (accountConstants.getMigrationPasswordUpdated()) {
            Log.d(Tag, "-- RESET last sync time UPON detecting password updated --");
            accountConstants.setMigrationPasswordUpdated(false); /** Set back to NO */
            accountConstants.resetLastSyncedOnInPreference(); /** Reset last sync time */
        }

        long lastSyncTimeInMills = accountConstants.getLastSyncedOnDateTimeFromPreference();

        if (lastSyncTimeInMills == 0L) {
            // Never synced before
            Log.d(Tag, "no last upload DMS time -> SYNC NOW");
            syncNow();
        }
        else {
            long currentTimeInMills = Calendar.getInstance().getTimeInMillis();
            long diffTimeInMills = currentTimeInMills - lastSyncTimeInMills;
            Log.d(Tag, "currentTimeInMills:" + currentTimeInMills + "|lastSyncTimeInMills:" + lastSyncTimeInMills + "|diff:"+diffTimeInMills);

            if (diffTimeInMills < 0) {
                Log.d(Tag, "DMS Auto: invalid time");
                accountConstants.resetLastSyncedOnInPreference();
                return;
            }

            if (diffTimeInMills < (DMS_UPLOADING_INTERVAL * 60L * 1000L)) {
                Log.d(Tag, "Less than (" + DMS_UPLOADING_INTERVAL + " minutes)");
                return;
            }

            syncNow();
        }
    }

    private void syncNow() {
        // Need to have condition check if it's good to execute the upload task

        if (Utils.haveNetworkConnection(context) == false) {
            Log.d(Tag, "PANIC: No Internet");
            return;
        }

        if (Utils.checkIfFirstRun(context) || !Utils.checkIfLoggedIn(context)) {
            Log.d(Tag, "PANIC: Initial Launch | not loggin in");
            return;
        }

        if (accountConstants.getAccountEnableAutoSync() == false) {
            Log.d(Tag, "PANIC: Auto Sync is not enabled");
            return;
        }

        if (syncModel.isSyncing()) {
            Log.d(Tag, "PANIC: Sync Tx is in progress");
            return;
        }

        /** #3628 Check last sync START time - automatic */
        if (allowNextOperation() == false) {
            Log.d(Tag, "PANIC: not allow next operation");
            return;
        }

        /** #3640 do not upload the data in foreground if too much data needs to be fetched */
        int hoursBack = calculateHoursBack();
        if (hoursBack > 6) {
            if (applicationForegroundState.isForeground()) {
                Log.d(Tag, "PANIC: foreground upload not allowed (hours:" + hoursBack + ")");
                return;
            }
        }

        Log.d(Tag, ">>> Sync Now <<<");

        new DMSUploadTask(
				false,
				accountConstants,
				applicationForegroundState,
                notificationUtility,
                hoursBack,
                eventBus
        ).execute();
    }

    private int calculateHoursBack() {
        int hoursBack;

        long lastSyncTimeInMills = accountConstants.getLastSyncedOnDateTimeFromPreference();

        if (lastSyncTimeInMills == 0L) {
            // Never synced before
            hoursBack = HOURS_BACK_DEFAULT;
        }
        else {
            long currentTimeInMills = Calendar.getInstance().getTimeInMillis();
            long diffTimeInMills = currentTimeInMills - lastSyncTimeInMills;
            Log.d(Tag, "currentTimeInMills:" + currentTimeInMills + "|lastSyncTimeInMills:" + lastSyncTimeInMills + "|diff:"+diffTimeInMills);
            hoursBack = (int)(diffTimeInMills / 1000L / 60L / 60L) + 2; // add 2 more hours
        }

        Log.d(Tag,"Should sync last # of hours:" + hoursBack);

        return hoursBack;
    }

    private boolean allowNextOperation() {
        boolean retValue = true;
        long lastSyncStartTimeInMills = accountConstants.getLastSyncedStartDateTimeFromPreference();

        if (lastSyncStartTimeInMills == 0L) {
            // Never started before
            Log.d(Tag, "allowNextOperation: no last upload start DMS time");
        }
        else {
            long currentTimeInMills = Calendar.getInstance().getTimeInMillis();
            long diffTimeInMills = currentTimeInMills - lastSyncStartTimeInMills;
            Log.d(Tag, "currentTimeInMills:" + currentTimeInMills + "|lastSyncStartTimeInMills:" + lastSyncStartTimeInMills + "|diff:"+diffTimeInMills);

            if (diffTimeInMills < 0) {
                Log.d(Tag, "allowNextOperation: DMS Auto: invalid time");
                accountConstants.resetLastSyncedStartInPreference();
                retValue = false;
            }

            if (diffTimeInMills < (DMS_UPLOAD_ALLOW_NEXT_OPERATION_MINUTES * 60L * 1000L)) {
                Log.d(Tag, "allowNextOperation: Less than (" + DMS_UPLOAD_ALLOW_NEXT_OPERATION_MINUTES + " minutes)");
                retValue = false;
            }
        }

        Log.d(Tag, "allowNextOperation? :" + retValue);
        return retValue;
    }

}
