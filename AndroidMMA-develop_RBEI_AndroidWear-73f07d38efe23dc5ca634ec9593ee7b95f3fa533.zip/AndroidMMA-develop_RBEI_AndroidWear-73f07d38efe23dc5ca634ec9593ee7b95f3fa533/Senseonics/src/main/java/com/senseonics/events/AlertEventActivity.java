package com.senseonics.events;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.ALERT_TYPE;
import com.senseonics.util.Utils.EVENT_TYPE;
import com.senseonics.util.Utils.GLUCOSE_TYPE;

import java.util.Locale;
import java.util.TimeZone;

public class AlertEventActivity extends EventActivity {

	protected TextView eventTypeTextView;
	private TextView dateTextView,notificationECNoTextView,
			unitGlucoseTextView, thresholdTextView;
	private ImageView notificationImageView;
	private String glucoseUnit = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.details);
		
		hasSaveButton = false;
		inflater.inflate(R.layout.layout_alert_details, contentLayout);
		dateTextView = (TextView) findViewById(R.id.eventDate);
		eventTypeTextView = (TextView) findViewById(R.id.eventType);
		notificationECNoTextView = (TextView) findViewById(R.id.notificationECNo);
		thresholdTextView = (TextView) findViewById(R.id.thresHoldLevelValue);
		notificationImageView = (ImageView) findViewById(R.id.notificationImageView);
		unitGlucoseTextView = (TextView) findViewById(R.id.glucoseUnit);

		if (currentDate != null && eventPoint != null)
			dateTextView.setText(Utils.formatWeekDateTimeForTimeZone(eventPoint.getCalendar(), TimeZone.getDefault(),AlertEventActivity.this));

		glucoseUnit = Utils.getGlucoseUnitString(this,
				Utils.currentGlucoseUnit);
		String glucoseLevelString = "";
		if (eventPoint.getGlucoseLevel() <= Utils.GLUCOSE_LEVEL_UNKNOWN) {
			glucoseLevelString = Utils.unknownString;
		} else
			glucoseLevelString = String.valueOf(Utils.getGlucoseLevelString(this, eventPoint.getGlucoseLevel()));

		unitGlucoseTextView.setText(glucoseLevelString);
		
		update();
	}

	public void update() {

		AlertEventPoint alertEventPoint = (AlertEventPoint) eventPoint;
		ALERT_TYPE alertType = alertEventPoint.getAlertType();
		GLUCOSE_TYPE glucoseType = alertEventPoint.getGlucoseType();

		int highGlucoseHysteresis = transmitterStateModel.getHysteresisHighGlocosePercent();
		int lowGlucoseHysteresis = transmitterStateModel.getHysteresisLowGlucoseValueMgDl();
		int predictiveHighGlucoseHysteresis = transmitterStateModel.getHysteresisHighPredictiveGlocosePercent();
		int predictiveLowGlucoseHysteresis = transmitterStateModel.getHysteresisLowPredictiveGlucoseValueMgDl();

		// Alert events
		if (eventPoint.getEventType() == EVENT_TYPE.ALERT_EVENT) {
			eventTypeTextView.setText(Utils.getAlertEventTitle(AlertEventActivity.this, alertType) + " " + getString(R.string.alert));

			if(alertType == ALERT_TYPE.HIGH_GLUCOSE) {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.HighGlucoseAlert));

				float percentageThresholdFloat = (Utils.getGlucoseLevelFloatValue(transmitterStateModel.getHighGlucoseAlertThreshold()) * highGlucoseHysteresis/100);
				String percentageThreshold = String.format(Locale.US, "%.1f", percentageThresholdFloat);
				String strPercentageThreshold = "";
				if(percentageThresholdFloat > 0.01 )
				{
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlertThreshold()) + "(+/- " + percentageThreshold + " " + glucoseUnit + ")";
				} else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlertThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}
			else {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.LowGlucoseAlert));
				String strPercentageThreshold = "";
				if(lowGlucoseHysteresis > 0.01) {
					strPercentageThreshold = Utils.getGlucoseLevelString(this, transmitterStateModel.getLowGlucoseAlertThreshold()) + "(+/- " + Utils.getGlucoseLevelString(this, lowGlucoseHysteresis) + ")";
				}
				else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this, transmitterStateModel.getLowGlucoseAlertThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}
		} else
		// Alarm events
		if (eventPoint.getEventType() == EVENT_TYPE.ALARM_EVENT) {
			eventTypeTextView.setText(Utils.getAlarmEventTitle(AlertEventActivity.this, alertType) + " " + getString(R.string.alert)); /** #3214 */ //getString(R.string.alarm));
			if(alertType == ALERT_TYPE.HIGH_GLUCOSE) {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.HighGlucoseAlarm));

				float percentageThresholdFloat = (Utils.getGlucoseLevelFloatValue(transmitterStateModel.getHighGlucoseAlarmThreshold()) * highGlucoseHysteresis/100);
				String percentageThreshold = String.format(Locale.US, "%.1f", percentageThresholdFloat);
				String strPercentageThreshold = "";
				if(percentageThresholdFloat > 0.01)	{
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlarmThreshold()) + "(+/- " + percentageThreshold + " " + glucoseUnit + ")";
				} else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlarmThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}
			else {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.LowGlucoseAlarm));
				String strPercentageThreshold = "";
				if(lowGlucoseHysteresis > 0.01) {
					strPercentageThreshold = Utils.getGlucoseLevelString(this, transmitterStateModel.getLowGlucoseAlarmThreshold()) + "(+/- " + Utils.getGlucoseLevelString(this, lowGlucoseHysteresis) + ")";
				}
				else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this, transmitterStateModel.getLowGlucoseAlarmThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}

		} else
		// Predictive events
		if (eventPoint.getEventType() == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING
				|| eventPoint.getEventType() == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
			eventTypeTextView.setText(Utils.getPredictiveAlertTitle(AlertEventActivity.this, eventPoint.getEventType()) + " " + getString(R.string.alert));
			if(eventPoint.getEventType() == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.PredictiveHighAlarm));

				float percentageThresholdFloat = (Utils.getGlucoseLevelFloatValue(transmitterStateModel.getHighGlucoseAlarmThreshold()) * predictiveHighGlucoseHysteresis/100);
				String percentageThreshold = String.format(Locale.US, "%.1f", percentageThresholdFloat);
				String strPercentageThreshold = "";
				if(percentageThresholdFloat > 0.01)	{
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlarmThreshold())+"(+/- " + percentageThreshold + " " + glucoseUnit + ")";
				} else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getHighGlucoseAlarmThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}
			else {
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(Utils.TransmitterMessageCode.PredictiveLowAlarm));
				String strPercentageThreshold = "";
				if(predictiveLowGlucoseHysteresis > 0.01) {
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getLowGlucoseAlarmThreshold()) + "(+/- " + Utils.getGlucoseLevelString(this, predictiveLowGlucoseHysteresis) + ")";
				}
				else {
					strPercentageThreshold = Utils.getGlucoseLevelString(this,transmitterStateModel.getLowGlucoseAlarmThreshold());
				}
				thresholdTextView.setText(strPercentageThreshold);
			}
		}

		int iconResID = Utils.getEventImageResId(eventPoint);
		notificationImageView.setImageResource(iconResID);
	}
}
