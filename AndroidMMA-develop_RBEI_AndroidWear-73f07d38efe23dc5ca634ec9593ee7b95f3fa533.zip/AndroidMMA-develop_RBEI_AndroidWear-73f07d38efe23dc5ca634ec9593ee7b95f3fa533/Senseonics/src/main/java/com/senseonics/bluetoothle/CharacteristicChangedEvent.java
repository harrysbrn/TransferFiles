package com.senseonics.bluetoothle;

public class CharacteristicChangedEvent {
    private final int[] data;
    private Transmitter transmitter;

    public CharacteristicChangedEvent(int[] data, Transmitter transmitter) {
        this.data = data;
        this.transmitter = transmitter;
    }

    public int[] getData() {
        return data;
    }

    public Transmitter getTransmitter() {
        return transmitter;
    }
}
