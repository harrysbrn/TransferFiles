package com.senseonics.model;

import java.util.HashMap;

public class DefaultedHashMap<K, V> extends HashMap<K, V> {

    private V defaultValue;

    public DefaultedHashMap(V defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public V get(Object key) {
        V response = super.get(key);
        if (response == null) {
            response = defaultValue;
        }
        return response;
    }
}
