package com.senseonics.events;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.DialogUtils.DoublePickerManager;
import com.senseonics.events.EventUtils.INSULIN_TYPE;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.util.ArrayList;

public class InsulinEventActivity extends EventActivity {

	private PickerManager insulinTypeManager;
	private String insulinTypeName;
	private INSULIN_TYPE insulinType = INSULIN_TYPE.RAPID_ACTING;
	private TextView typeTextView, unitsTextView;
	private ArrayList<Item> list_integer, list_decimal;
	private Dialog dialog;

	private float selectedUnit = 0.0f;
	private int minUnit = 0, maxUnit = 200; // #2640 Increase the Insulin unit intake upto 200U (Android)
	private int minDecimal = 0, maxDecimal = 9;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.insulin_event);
		
		LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.dialog_insulin_event, contentLayout);

		list_integer = dialogUtils.getNumbersBetween(minUnit, maxUnit, 1);
		list_decimal = dialogUtils.getDecimalsBetween(minDecimal, maxDecimal, 1);

		RelativeLayout typeLayout = (RelativeLayout) findViewById(R.id.insulinTypeLayout);
		RelativeLayout unitsLayout = (RelativeLayout) findViewById(R.id.insulinUnitsLayout);
		typeTextView = (TextView) findViewById(R.id.insulinType);
		unitsTextView = (TextView) findViewById(R.id.units);

		insulinTypeManager = new PickerManager() {

			@Override
			public void selected(int id) {
				setInsulinType(id);
			}
		};
		typeLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventUtils.createInsulinTypePicker(InsulinEventActivity.this,
						getResources().getString(R.string.insulin_type),
						insulinTypeManager, insulinType.ordinal());
			}
		});

		final DoublePickerManager pickerManager = new DoublePickerManager() {

			@Override
			public void selected(int id1, int id2) {
				selectedUnit = Float.parseFloat(String.valueOf(list_integer
						.get(id1).getValue())
						+ String.valueOf(list_decimal.get(id2).getValue()));
				unitsTextView.setText(String.valueOf(selectedUnit));
			}
		};
		unitsLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (dialog != null && dialog.isShowing())
					dialog.dismiss();

				String value = String.valueOf(selectedUnit).replace(",", ".");
				String[] nums = value.split("[.]");
				int position1 = 0, position2 = 0;
				if (nums.length == 2) {
					position1 = Utils.getItemPosition(list_integer,
							Integer.valueOf(nums[0]));
					position2 = Utils.getItemPosition(list_decimal, "."
							+ nums[1]);
				}

				dialog = dialogUtils.createPickerDialog(InsulinEventActivity.this,
						getString(R.string.units), list_integer, list_decimal,
						null, pickerManager, position1, position2, true, false);
				dialog.show();

			}
		});

		if (eventPoint != null) {
			setInsulinType(((InsulinEventPoint) eventPoint).getInsulinType()
					.ordinal());
			selectedUnit = ((InsulinEventPoint) eventPoint).getUnits();
		} else
			setInsulinType(insulinType.ordinal());

		String value = String.valueOf(selectedUnit).replace(",", ".");
		String[] nums = value.split("[.]");
		if (nums.length == 2) {
			int position1 = Utils.getItemPosition(list_integer,
					Integer.valueOf(nums[0]));
			int position2 = Utils.getItemPosition(list_decimal, "." + nums[1]);
			if (position1 != -1 && position2 != -1)
				pickerManager.selected(position1, position2);
		}

	}

	public void setInsulinType(int id) {
		insulinType = EventUtils.INSULIN_TYPE.values()[id];
		insulinTypeName = EventUtils.getInsulinTypeName(
				InsulinEventActivity.this, insulinType);
		typeTextView.setText(insulinTypeName);
	}

	@Override
	public void onSavePressed() {
		super.onSavePressed();

		InsulinEventPoint insulinEventPoint = null;
		if (isEditing) {
			insulinEventPoint = new InsulinEventPoint(
					eventPoint.getDatabaseId(), currentDate, glucoseLevel,
					selectedUnit, insulinType, notesEditText.getText()
							.toString());
			databaseManager.updateEvent(insulinEventPoint);
		} else {
			insulinEventPoint = new InsulinEventPoint(currentDate,
					glucoseLevel, selectedUnit, insulinType, notesEditText
							.getText().toString());
			int rowId = (int) databaseManager.addEvent(insulinEventPoint, false);
			insulinEventPoint.setDatabaseId(rowId);
		}

		BluetoothPairBaseActivity.patientEventPoints.add(insulinEventPoint);
		getService().postWritePatientEventPoint(insulinEventPoint);

		finish();
	}
}
