package com.senseonics.model.StateModelUpload;

public class DMSStateModelThresholdInfo {
    private DMSStateModelUserInfo UserInfo;
    private int GlucoseUnit; // mg/dL=1; mmol/L=2 => same as MLTransmitterUnits
    private int TargetLow; // always integer, in mg/dL
    private int TargetHigh;
    private int AlertLow;
    private int AlertHigh;
    private int AlarmLow;
    private int AlarmHigh;
    private boolean PredictiveAlertEnabled;
    private boolean RateAlertEnabled;
    private int PredictiveMins;
    private String RateSlope; //float string: needs convertion from fallingRateAlertSlope; depend on unit

    public DMSStateModelThresholdInfo(
            DMSStateModelUserInfo userInfo,
            int glucoseUnit,
            int targetLow,
            int targetHigh,
            int alertLow,
            int alertHigh,
            int alarmLow,
            int alarmHigh,
            boolean predictiveAlertEnabled,
            boolean rateAlertEnabled,
            int predictiveMins,
            String rateSlope
    ) {
        AlarmHigh = alarmHigh;
        AlarmLow = alarmLow;
        AlertHigh = alertHigh;
        AlertLow = alertLow;
        GlucoseUnit = glucoseUnit;
        PredictiveAlertEnabled = predictiveAlertEnabled;
        PredictiveMins = predictiveMins;
        RateAlertEnabled = rateAlertEnabled;
        RateSlope = rateSlope;
        TargetHigh = targetHigh;
        TargetLow = targetLow;
        UserInfo = userInfo;
    }

    public int getAlarmHigh() {
        return AlarmHigh;
    }

    public int getAlarmLow() {
        return AlarmLow;
    }

    public int getAlertHigh() {
        return AlertHigh;
    }

    public int getAlertLow() {
        return AlertLow;
    }

    public int getGlucoseUnit() {
        return GlucoseUnit;
    }

    public boolean isPredictiveAlertEnabled() {
        return PredictiveAlertEnabled;
    }

    public int getPredictiveMins() {
        return PredictiveMins;
    }

    public boolean isRateAlertEnabled() {
        return RateAlertEnabled;
    }

    public String getRateSlope() {
        return RateSlope;
    }

    public int getTargetHigh() {
        return TargetHigh;
    }

    public int getTargetLow() {
        return TargetLow;
    }

    public DMSStateModelUserInfo getUserInfo() {
        return UserInfo;
    }
}
