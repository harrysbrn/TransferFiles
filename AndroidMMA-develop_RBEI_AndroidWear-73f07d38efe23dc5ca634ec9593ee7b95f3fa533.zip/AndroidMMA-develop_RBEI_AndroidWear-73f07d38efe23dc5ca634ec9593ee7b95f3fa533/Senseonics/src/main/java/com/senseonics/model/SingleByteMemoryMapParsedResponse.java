package com.senseonics.model;

public interface SingleByteMemoryMapParsedResponse {

    int[] getMemoryAddress();
    void apply(int data, TransmitterStateModel model);
}
