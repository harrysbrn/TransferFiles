package com.senseonics.gen12androidapp;

import android.os.CountDownTimer;

import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.CalibrationCountdownEvent;

import de.greenrobot.event.EventBus;

public class CustomCountDownTimer extends CountDownTimer {

    private EventBus eventBus;

    public CustomCountDownTimer( EventBus eventBus, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        this.eventBus = eventBus;
        this.eventBus.registerSticky(this);
    }

    @Override
    public void onFinish() {
        eventBus.post(new CalibrationCountdownEvent(0));
        this.eventBus.unregister(this);
    }

    @Override
    public void onTick(long millisUntilFinished) {
        eventBus.post(new CalibrationCountdownEvent(millisUntilFinished));
    }

    public void onEvent(TransmitterConnectionEvent event) {
        if(event.getTransmitter().getConnectionState() == Transmitter.CONNECTION_STATE.DISCONNECTED) {
            cancel();
            eventBus.unregister(this);
        }
    }

}
