package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.events.EventUtils;
import com.senseonics.events.ExerciseEventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.HealthEventPoint;
import com.senseonics.events.InsulinEventPoint;
import com.senseonics.events.MealEventPoint;
import com.senseonics.graph.util.Glucose;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class MyReportsActivity extends BaseActivity{
	ArrayList<Item> values = new ArrayList<Item>();
	private Dialog dialog;
	private ProgressDialog progressDialog;
	private String Tag = "MyReports";
	private TextView tvLastSyncedOnLabel, tvLastSyncedOn, btnShare, tvExportDaysLabel, tvExportDays;
	private String folderName = "/Senseonics";
	private String fileNameGlobal = null;
	private String fileNameOnlyGlobal = null;
	private static final int REQUEST_CODE = 5846;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Initialize the preferences if needed
		initPreferences();

		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_my_reports, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.my_reports);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);

		// Find the views
		tvLastSyncedOnLabel = (TextView) findViewById(R.id.tvLastSyncedOnLabel);
		tvLastSyncedOn = (TextView) findViewById(R.id.tvLastSyncedOn);

		tvExportDaysLabel = (TextView) findViewById(R.id.tvDefaultSyncDaysText);
		tvExportDays = (TextView) findViewById(R.id.tvDefaultSyncDaysValue);

		btnShare = (TextView) findViewById(R.id.btnShare);

		// Fetch the preferences
		setViewsFromPreferences();
		
		// Configure the views
		tvLastSyncedOnLabel.setText(getString(R.string.file_format));
		tvLastSyncedOnLabel.setTypeface(null, Typeface.BOLD);
		tvExportDaysLabel.setText(getString(R.string.export_days));
		tvExportDaysLabel.setTypeface(null, Typeface.BOLD);
		tvExportDays.setTypeface(null, Typeface.BOLD);
		tvLastSyncedOn.setText(getString(R.string.csv_format));
        tvLastSyncedOn.setTextColor(getResources().getColor(R.color.light_gray));
		tvLastSyncedOn.setTypeface(null, Typeface.BOLD);

		RelativeLayout layoutDefaultSyncDays = (RelativeLayout) findViewById(R.id.layoutDefaultSyncDays);

		final EventUtils.PickerManager pickerManager = new EventUtils.PickerManager() {

			@Override
			public void selected(int id) {
				String[] strings = values.get(id).getValue().split(" ");
				if (strings.length > 0) {
					tvExportDays
							.setText(strings[0]);
					sharedPreferences
							.edit()
							.putInt(Utils.prefExportDays,
									Integer.valueOf(strings[0])).apply();

				}
			}
		};

		layoutDefaultSyncDays.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				String dialogTitle = getResources().getString(
						R.string.export_days);
				values.addAll(Arrays.asList(new Item(0, "1"),
						new Item(1, "3"), new Item(2, "7"), new Item(
								3, "14"), new Item(4, "30")));

				int position = getMinuteItemPosition(values,sharedPreferences.getInt(Utils.prefExportDays, Utils.DEFAULT_SYNC_DAYS));
				showDialog(dialogTitle, values, pickerManager, position);
			}


		});


		btnShare.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d(Tag, "on click");
				prepareForExport();
			}		
			
		});

		progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
		progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
		progressDialog.setCancelable(false);
	}

	private void exportReport() {
		progressDialog.show();
		new getSensorLogAsynctask().execute();
	}

	public void prepareForExport() {
		/** For Android M and above to request permission
		 * if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isStorageAccessNeeded()) {
			requestPermissions(
					new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
					REQUEST_CODE);
		} else {
			exportReport();
		}*/
		exportReport();
	}

	/** For Android M and above to request permission
	@TargetApi(Build.VERSION_CODES.M)
	private boolean isStorageAccessNeeded() {
		return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
				checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED;
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		switch (requestCode) {
			case REQUEST_CODE:
				if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
					exportReport();
				}
				break;
		}
	}*/

	private void initPreferences()
	{
		SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
				Utils.SHARED_PREF, Context.MODE_PRIVATE);


		if (!sharedPreferences.contains(Utils.prefExportDays)) {
			Utils.saveSettings(MyReportsActivity.this, Utils.prefExportDays, Utils.DEFAULT_SYNC_DAYS);
		}
	}

	private void setViewsFromPreferences() {
		tvExportDays.setText(Utils.getSettingsForDefault(MyReportsActivity.this, Utils.prefExportDays, Utils.DEFAULT_SYNC_DAYS)+"");
	}

	public void showDialog(String title, ArrayList<Item> items,
						   final EventUtils.PickerManager pickerManager, int currentSelected) {
		if (items.size() > 1) {
			if (dialog != null && dialog.isShowing())
				dialog.hide();
			dialog = dialogUtils.createPickerDialog(MyReportsActivity.this,
					title, items, pickerManager, currentSelected);
			dialog.show();
		}
	}

	public int getMinuteItemPosition(ArrayList<Item> items, int value) {
		for (int i = 0; i < items.size(); ++i) {
			String[] strings = items.get(i).getValue().split(" ");
			if (strings.length > 0) {
				int minute = Integer.valueOf(strings[0]);
				if (minute == value)
					return i;
			}
		}
		return -1;
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private String getCSVFileName() {
		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(TimeZone.getDefault());
		
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		int minute = cal.get(Calendar.MINUTE);
		int second = cal.get(Calendar.SECOND);

		String fileName = String.format(Locale.US, "%04d.%02d.%02dT%02d.%02d.%02d.csv", 
				year, month, day, hour, minute, second);
		
		return fileName;
	}

	private String getAllSensorGlucoseLogs() {
		String logContent = "SENSOR GLUCOSE,Date and Time(Local),Sensor Glucose,Unit,Record No\n";
		// get all sensor glucose data
		Calendar calendarStart = Calendar.getInstance();
		calendarStart.add(Calendar.DAY_OF_YEAR, -(Integer.parseInt(tvExportDays.getText().toString())));
		ArrayList<Glucose> sensorLogs = databaseManager.getSensorLogsStartingFrom(calendarStart, Calendar.getInstance());

		for (int i = 0; i < sensorLogs.size(); i++) {
			Glucose thisRecord = sensorLogs.get(i);

			// Get the values
		    long recordGMTTimeStamp = thisRecord.getTimestamp();
		    int glucoseValue = thisRecord.getGlucoseLevel();
		    int recordNumber = thisRecord.getRecordNumber();
		    
		    String thisRecordString = "SENSOR GLUCOSE,"+Utils.formatDateISO8601(recordGMTTimeStamp)
					+","+ Utils.getGlucoseLevelValue(glucoseValue)+","+ Utils.getGlucoseUnitString(MyReportsActivity.this) + "," +(i+1);

//			/** #3194 TEST: Raw values for Notes field */
//			thisRecordString += ",|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7)
//								+ "|" + thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8) + "|";
		    
		    logContent += thisRecordString + "\n";
		}
		return logContent;
	}

	private String getAllSensorEventsLogs() {
		// get all sensor glucose data
		Calendar calendarStart = Calendar.getInstance();
		calendarStart.add(Calendar.DAY_OF_YEAR, -(Integer.parseInt(tvExportDays.getText().toString())));

		int recordNumberBG = 1;
		ArrayList<EventPoint> eventsLog = databaseManager
				.getEventsBetween(calendarStart, Calendar.getInstance(), 40, 400);

		String logContent = "BLOOD GLUCOSE,Date and Time(Local),SBGM Glucose Value,Unit,Calibration Use Flags,Notes,Record No\n";
		String logContent2 = "PATIENT EVENT,Date and Time(Local),Event Type,Information 1,Information 2,Notes\n";

		for (int i = 0; i < eventsLog.size(); i++) {
			// Get the values
			if((eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.CALIBRATION) ) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				boolean isCalibrationUsed = false;
				if(thisRecord instanceof CalibrationEventPoint)  {
					isCalibrationUsed = ((CalibrationEventPoint) thisRecord).isCalibrationUsed();
				}
				String thisRecordString = "BLOOD GLUCOSE," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getGlucoseLevelValue(thisRecord.getGlucoseLevel())+ "," +
						Utils.getGlucoseUnitString(MyReportsActivity.this) + "," +
						(isCalibrationUsed?getString(R.string.cal_used_flag_accepted):getString(R.string.cal_used_flag_rejected)) + "," + thisRecord.getNotes() + "," + recordNumberBG++;
				logContent += thisRecordString + "\n";
			}
		else if((eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.GLUCOSE_EVENT) ) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				int isCalibrationUsed = 0;
				if(thisRecord instanceof GlucoseEventPoint)  {
					isCalibrationUsed = ((GlucoseEventPoint) thisRecord).getCalibrationFlag();
				}
				String thisRecordString = "BLOOD GLUCOSE," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getGlucoseLevelValue(thisRecord.getGlucoseLevel())+ "," +
						Utils.getGlucoseUnitString(MyReportsActivity.this) + "," +
						getString(Utils.getTitleIdForCalibrationUseFlagForEventActivity(isCalibrationUsed))+ "," + thisRecord.getNotes() + ","  + recordNumberBG++;
				logContent += thisRecordString + "\n";
			}
			else if(eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.INSULIN_EVENT) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				String thisRecordString = "PATIENT EVENT," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getEventName(MyReportsActivity.this, thisRecord.getEventType()) + "," +
						EventUtils.getInsulinTypeName(MyReportsActivity.this, ((InsulinEventPoint) thisRecord).getInsulinType()) + "," +
						((InsulinEventPoint) thisRecord).getUnits()+","+ thisRecord.getNotes();
				logContent2 += thisRecordString + "\n";
			}
			else if(eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.MEAL_EVENT) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				String thisRecordString = "PATIENT EVENT," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getEventName(MyReportsActivity.this, thisRecord.getEventType()) + ","
						+ EventUtils.getMealTypeName(MyReportsActivity.this, ((MealEventPoint) thisRecord).getMealType())
						+ "," + ((MealEventPoint)thisRecord).getCarbs() + " grams," + thisRecord.getNotes();
				logContent2 += thisRecordString + "\n";
			}
			else if(eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.EXERCISE_EVENT) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				String thisRecordString = "PATIENT EVENT," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getEventName(MyReportsActivity.this, thisRecord.getEventType()) + ","
						+ EventUtils.getExerciseIntensityName(MyReportsActivity.this, ((ExerciseEventPoint) thisRecord).getIntensity())
						+ "," + ((ExerciseEventPoint)thisRecord).getDurationText(MyReportsActivity.this) + "," + thisRecord.getNotes();
				logContent2 += thisRecordString + "\n";
			}
			else if(eventsLog.get(i).getEventType() == Utils.EVENT_TYPE.HEALTH_EVENT) {
				EventPoint thisRecord =  eventsLog.get(i);
				long recordGMTTimeStamp = thisRecord.getTimestamp();
				String thisRecordString = "PATIENT EVENT," + Utils.formatDateISO8601(recordGMTTimeStamp) +
						"," + Utils.getEventName(MyReportsActivity.this, thisRecord.getEventType()) + ","
						+ EventUtils.getHealthConditionName(MyReportsActivity.this, ((HealthEventPoint) thisRecord).getHealthCondition())
						+ "," + EventUtils.getHealthSeverityName(MyReportsActivity.this, ((HealthEventPoint) thisRecord).getHealthSeverity()) + "," + thisRecord.getNotes();
				logContent2 += thisRecordString + "\n";
			}
		}

		logContent +=logContent2;
		return logContent;
	}

	public class getSensorLogAsynctask extends AsyncTask<Void, Void, Void> {

		private boolean operationResult;

		@Override
		protected Void doInBackground(Void... params) {

			try {
				operationResult = exportLogInCSV();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			
			if(operationResult) {		
				
				final List<Intent> targetedShareIntents = new ArrayList<Intent>();

				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.setType("text/csv");

				List<ResolveInfo> resInfo = getPackageManager()
						.queryIntentActivities(intent, 0);
				
				if (!resInfo.isEmpty()) {
					for (ResolveInfo info : resInfo) {
						Intent targetedShare = new Intent(
								android.content.Intent.ACTION_VIEW);
						targetedShare.setType("text/csv");

						if (info.activityInfo.packageName.toLowerCase(Locale.US)
								.contains("mail")
								|| info.activityInfo.name.toLowerCase(Locale.US)
										.contains("mail")) {
							Uri data = Uri
									.parse("mailto:?subject=" + fileNameOnlyGlobal);
							String filePath = "file://"+fileNameGlobal;
							Log.d(Tag, "filePath:" + filePath);
							Uri filedata = Uri.parse(filePath);
							targetedShare.putExtra(Intent.EXTRA_STREAM, filedata); 
							targetedShare.setData(data);
							targetedShare.setPackage(info.activityInfo.packageName);
							targetedShareIntents.add(targetedShare);
						}
					}
				}
				
				if (targetedShareIntents.size() == 0) {
					Toast.makeText(getApplicationContext(),
							"There are no email clients installed.", Toast.LENGTH_SHORT)
							.show();
				} else {
					Intent chooserIntent = Intent.createChooser(
							targetedShareIntents.remove(0), getString(R.string.my_reports));
					chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
							targetedShareIntents.toArray(new Parcelable[] {}));
					startActivity(chooserIntent);
				}
			}
			
			if (progressDialog.isShowing())
			{
				progressDialog.dismiss();
			}
			
			super.onPostExecute(result);
		}
	}
	
	private boolean exportLogInCSV() throws IOException {

		File folder = new File(Environment.getExternalStorageDirectory()
				+ folderName);

		if (!folder.exists()) {
			if (!folder.mkdir()) {
				return false;
			}
		}

		try {
			fileNameOnlyGlobal = getCSVFileName();
			fileNameGlobal = folder.toString() + "/" + fileNameOnlyGlobal;
			String fileContent = getAllSensorEventsLogs();
			fileContent +=  getAllSensorGlucoseLogs();
			FileWriter fw = new FileWriter(fileNameGlobal);
			fw.append(fileContent);
			fw.flush();
			fw.close();
			
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
