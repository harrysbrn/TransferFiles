package com.senseonics.events;

import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

import com.senseonics.util.Utils;
import com.senseonics.util.Utils.ALERT_TYPE;
import com.senseonics.util.Utils.EVENT_TYPE;
import com.senseonics.util.Utils.GLUCOSE_TYPE;

public class AlertEventPoint extends EventPoint {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ALERT_TYPE alertType;
	private GLUCOSE_TYPE glucoseType;

	public AlertEventPoint(EVENT_TYPE eventType, Calendar calendar,
			int glucoseLevel, ALERT_TYPE type, GLUCOSE_TYPE glucoseType) {
		super(calendar, glucoseLevel);
		this.setAlertType(type);
		this.setGlucoseType(glucoseType);
		this.setEventType(eventType);
	}

	public AlertEventPoint(EVENT_TYPE eventType, int databaseId,
			Calendar calendar, int glucoseLevel, ALERT_TYPE type,
			GLUCOSE_TYPE glucoseType) {
		super(databaseId, calendar, glucoseLevel);
		this.setAlertType(type);
		this.setGlucoseType(glucoseType);
		this.setEventType(eventType);
	}

	public ALERT_TYPE getAlertType() {
		return alertType;
	}

	public void setAlertType(ALERT_TYPE alertType) {
		this.alertType = alertType;
	}

	public GLUCOSE_TYPE getGlucoseType() {
		return glucoseType;
	}

	public void setGlucoseType(GLUCOSE_TYPE glucoseType) {
		this.glucoseType = glucoseType;
	}

	public String toString()
	{
		String output = "<AlertEventPoint>" + super.toString();
		output += "|AlertType:"+this.alertType;
		output += "|GlucoseType:"+this.glucoseType;
		output += "</AlertEventPoint>";

		return output;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		AlertEventPoint that = (AlertEventPoint) o;
		return Objects.equals(getAlertType(), that.getAlertType()) &&
				Objects.equals(getEventType(), that.getEventType());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getAlertType(), getEventType());
	}
}