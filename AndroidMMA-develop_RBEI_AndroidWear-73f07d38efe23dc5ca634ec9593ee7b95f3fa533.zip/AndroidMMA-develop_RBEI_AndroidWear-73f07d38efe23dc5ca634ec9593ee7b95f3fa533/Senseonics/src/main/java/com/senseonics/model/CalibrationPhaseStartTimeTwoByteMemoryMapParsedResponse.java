package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import java.util.Calendar;

import javax.inject.Inject;

public class CalibrationPhaseStartTimeTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public CalibrationPhaseStartTimeTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.startTimeOfCalibrationPhaseAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] time = BinaryOperations.calculateTimeFromBytes(new int[]{dataOne, dataTwo});
        Calendar deviceCalibrationDate = model.getStartCalibrationPhaseDateAndTime();
        if (deviceCalibrationDate != null) {
            deviceCalibrationDate.set(Calendar.HOUR_OF_DAY, time[0]);
            deviceCalibrationDate.set(Calendar.MINUTE, time[1]);
            deviceCalibrationDate.set(Calendar.SECOND, time[2]);
            model.setStartCalibrationPhaseDateAndTime(deviceCalibrationDate);
        }
        else {
            model.setStartCalibrationPhaseDateAndTime(null);
        }
    }
}
