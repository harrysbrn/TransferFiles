package com.senseonics.events;

public class CalibrationRequestEvent {
    private final EventPoint eventPoint;
    private int notificationId;

    public CalibrationRequestEvent(EventPoint eventPoint, int notificationId) {
        this.eventPoint = eventPoint;
        this.notificationId = notificationId;
    }

    public EventPoint getEventPoint() {
        return eventPoint;
    }

    public int getNotificationId() {
        return notificationId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CalibrationRequestEvent)) return false;

        CalibrationRequestEvent that = (CalibrationRequestEvent) o;

        if (eventPoint.getEventType() != that.eventPoint.getEventType()) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return eventPoint.hashCode();
    }
}
