package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadDoNotDisturbModeSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadDoNotDisturbModeSingleByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.doNotDisturbMode;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setDoNotDisturbMode(false);
                break;
            case 0x55:
                model.setDoNotDisturbMode(true);
                break;
        }
    }
}
