package com.senseonics.util;

import android.util.Log;

import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;

import java.util.Calendar;

import javax.inject.Inject;

public class NotificationEventPersistor {

    private DatabaseManager databaseManager;

    @Inject
    public NotificationEventPersistor(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public void createDisconnectedNotificationEventPoint() {
        EventPoint eventPoint = new EventPoint(Calendar.getInstance(),
                0, Utils.EVENT_TYPE.NOTIFICATION_EVENT_RED);
        eventPoint.setNotes("");
        eventPoint.setNotificationEventType(Utils.TransmitterMessageCode.
                TransmitterDisconnected);
        eventPoint.setRecordNumber(-1);
        eventPoint.setEventHidden(false);
        long eventId = databaseManager.addEvent(eventPoint, true);
        Log.d(NotificationEventPersistor.class.getSimpleName(), "new event " + eventId + " created");

    }


}
