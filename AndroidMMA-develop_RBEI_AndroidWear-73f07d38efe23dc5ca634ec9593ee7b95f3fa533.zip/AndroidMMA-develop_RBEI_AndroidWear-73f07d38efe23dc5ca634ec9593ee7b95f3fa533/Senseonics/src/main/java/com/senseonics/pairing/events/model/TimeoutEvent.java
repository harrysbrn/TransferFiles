package com.senseonics.pairing.events.model;

public class TimeoutEvent {
  public TimeoutEvent() {
  }
}
