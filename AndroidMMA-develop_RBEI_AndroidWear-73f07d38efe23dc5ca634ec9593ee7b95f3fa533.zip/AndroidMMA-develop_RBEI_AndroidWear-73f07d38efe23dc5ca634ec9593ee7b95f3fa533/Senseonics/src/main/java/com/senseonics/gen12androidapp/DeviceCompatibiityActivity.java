package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.util.Utils;

import java.io.File;
import java.util.Locale;

public class DeviceCompatibiityActivity extends BaseActivity {
    private WebView webview;
    private Dialog dialog;
    private String fileName;
 	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.activity_devicecompatibility, null),
                parms_content);

        webview = (WebView) findViewById(R.id.webView);
        WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        //settings.setUseWideViewPort(true);
        //settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);
        String strLanguage = Locale.getDefault().getLanguage();
        fileName = "DeviceWarning_en.html";
        switch (strLanguage) {
            case "de":
                fileName = "DeviceWarning_de.html";
                break;
            case "nb":
                fileName = "DeviceWarning_nb.html";
                break;
            case "nl":
                fileName = "DeviceWarning_nl.html";
                break;
            case "ro":
                fileName = "DeviceWarning_ro.html";
                break;
            case "sv":
                fileName = "DeviceWarning_sv.html";
                break;
            case "fr":
                fileName = "DeviceWarning_fr.html";
                break;
            case "it":
                fileName = "DeviceWarning_it.html";
                break;
            case "da":
                fileName = "DeviceWarning_da.html";
                break;
            case "fi":
                fileName = "DeviceWarning_fi.html";
                break;
            case "es":
                fileName = "DeviceWarning_es.html";
                break;
            case "pl":
                fileName = "DeviceWarning_pl.html";
                break;
        }

        // Configure the navigation bar
        naviBarTitle.setVisibility(View.GONE);
        naviBarTitleImageView.setVisibility(View.VISIBLE);
        naviBarTitleImageView.setImageResource(R.drawable.company_logo_white);
        naviBarLayout.setVisibility(View.VISIBLE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);
        naviBarRightItemTextView.setVisibility(View.GONE);

		TextView cancel = (TextView) findViewById(R.id.cancel);
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
			}
		});

		TextView accept = (TextView) findViewById(R.id.accept);
		accept.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeviceCompatibiityActivity.this, EulaScreenActivity.class);
                intent.putExtra("eula_init", "true");
                startActivityForResult(intent, Utils.WELCOME_UNIT_SELECTION_RESULT);

            }
        });

        Bundle extras = getIntent().getExtras();
        if (extras.containsKey("eula_init")) {
            String eulaInit = extras.getString("eula_init");
            if(eulaInit.equals("true")) {
                cancel.setVisibility(View.VISIBLE);
                accept.setVisibility(View.VISIBLE);
                statusBarDrawerButton.setVisibility(View.GONE);
                File file = new File(getFilesDir() + "//" + fileName);
                if (!file.exists()) {
                    Utils.CopyAssetsFile(fileName,"DeviceWarning", DeviceCompatibiityActivity.this);
                }
            }
        }

        webview.loadUrl("file:///"+getFilesDir() + "//" + fileName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // Result coming back from the unit selection page when the Finish button is pressed
        if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
            finish();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    public void displayCheckingResult(Utils.MLCheckResult error) {
        String title = "", message = "";
        switch (error) {
            case Timeout:
                title = getString(R.string.request_timeout);
                message = getString(R.string.invalid_error_text);
                break;
            case NotConnectedToWifi:
                title = getString(R.string.wi_fi_disconnected);
                message = getString(R.string.wi_fi_disconnected_text);
                break;
            case ServerError:
                title = getString(R.string.server_error);
                message = getString(R.string.invalid_error_text);
                break;
            case None:
                title = getString(R.string.file_corrupted);
                message = getString(R.string.invalid_error_text);
                break;
            case Unknown:
            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.invalid_error_text);
                break;
        }


        if (this.isThisActivityTop()) {
            if (dialog != null && dialog.isShowing())
                dialog.dismiss();
            dialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
                    title, message));
            dialog.show();
        }
    }


    class DownloadFileFromURL extends AsyncTask<String,String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        private String response;
        @Override
        protected String doInBackground(String... f_url) {
            response = Utils.getLatestFile(f_url[0],Utils.URL_EULA, DeviceCompatibiityActivity.this);
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            if (response != null && !response.equals("-1")) {

            } else {
                if (response == null) {
                    displayCheckingResult(Utils.MLCheckResult.NotConnectedToWifi);
                }
                else {
                    displayCheckingResult(Utils.MLCheckResult.ServerError);
                }
            }
            webview.loadUrl("file:///"+getFilesDir() + "//" + fileName);
            super.onPostExecute(result);
        }
    }

}
