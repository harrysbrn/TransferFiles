package com.senseonics.gen12androidapp;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.Locale;

public class MyProductInfoActivity extends BaseActivity {
    private final String PartNumber_en = "FG-5300-01-300";
    private final String PartNumber_nb = "FG-5300-03-200";
    private final String PartNumber_sv = "FG-5300-02-200";

    private final String PartNumber_de = "FG-5300-04-200";
    private final String PartNumber_da = "FG-5300-08-200";
    private final String PartNumber_es = "FG-5300-06-200";
    private final String PartNumber_fr = "FG-5300-09-200";
    private final String PartNumber_it = "FG-5300-05-200";
    private final String PartNumber_nl = "FG-5300-07-200";

    private final String PartNumber_XL_en = "FG-5301-01-300";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();

        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.fragment_productinfo, null),
                parms_content);

        PackageInfo pInfo;
        try {
            pInfo = getPackageManager().getPackageInfo(
                    getPackageName(), 0);
            String appVersionName = String.valueOf(pInfo.versionName);
            WebView copyrightText3 = (WebView)findViewById(R.id.copyrightText3);
            String productinfo = getString(R.string.productinfo);
            productinfo = productinfo.replace("@version",appVersionName);

            String stringReleaseDate = "";
            if (Utils.VERSION_RELEASE_DATE != null && !Utils.VERSION_RELEASE_DATE.equals("")) {
                Calendar releaseDate = Utils.getCalendarForMonthDayYearFromString(Utils.VERSION_RELEASE_DATE);
                stringReleaseDate = Utils.formatDateToYearMonthDayString(releaseDate);
            }
            else {
                stringReleaseDate = getString(R.string.not_available);
            }

            productinfo = productinfo.replace("@releasedate", stringReleaseDate);
            copyrightText3.loadData(productinfo, "text/html; charset=UTF-8", null);
            // #3126 Add part number
            String strPartNo;
            // #4014 Display XL FG number if the connected Transmitter firmware is XL (Android)
            if (transmitterStateModel.isFormattedTransmitterVersionXL()) {
                strPartNo = PartNumber_XL_en;
            }
            else {
                String strLanguage = Locale.getDefault().getLanguage();
                strPartNo = PartNumber_en;
                switch (strLanguage) {
                    case "nb":
                        strPartNo = PartNumber_nb;
                        break;
                    case "sv":
                        strPartNo = PartNumber_sv;
                        break;
                    case "de":
                        strPartNo = PartNumber_de;
                        break;
                    case "da":
                        strPartNo = PartNumber_da;
                        break;
                    case "es":
                        strPartNo = PartNumber_es;
                        break;
                    case "fr":
                        strPartNo = PartNumber_fr;
                        break;
                    case "it":
                        strPartNo = PartNumber_it;
                        break;
                    case "nl":
                        strPartNo = PartNumber_nl;
                        break;
                }
            }
            TextView tvPartNo = (TextView)findViewById(R.id.tvPartNo);
            tvPartNo.setText(strPartNo);

        } catch (PackageManager.NameNotFoundException e1) {
            e1.printStackTrace();
        }

        // Configure the navigation bar
        naviBarTitle.setText(R.string.product_information);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);
    }
    @Override
    protected void onResume() {
        Log.d(MyProductInfoActivity.class.getSimpleName(), "onResume");

        super.onResume();
    }
}
