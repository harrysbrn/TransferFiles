package com.senseonics.events;

public class DMSUploadResultEvent {
    private boolean result;

    public DMSUploadResultEvent (boolean resultIn) {
        this.result = resultIn;
    }

    public boolean getResult() {
        return this.result;
    }
}
