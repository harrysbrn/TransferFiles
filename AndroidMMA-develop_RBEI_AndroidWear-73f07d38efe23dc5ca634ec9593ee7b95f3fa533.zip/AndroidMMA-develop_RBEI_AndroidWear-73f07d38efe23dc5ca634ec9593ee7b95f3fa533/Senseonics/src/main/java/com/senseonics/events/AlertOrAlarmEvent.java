package com.senseonics.events;

import com.senseonics.util.Utils;

import java.util.Objects;

public class AlertOrAlarmEvent {
    private AlertEventPoint aep;
    private int notificationId;

    public AlertOrAlarmEvent(AlertEventPoint aepIn, int notificationId) {
        this.aep = aepIn;
        this.notificationId = notificationId;
    }

    public AlertEventPoint getAlertEventPoint() {
        return aep;
    }

    public int getNotificationId() {
        return notificationId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(aep.getEventType(), aep.getAlertType());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final AlertOrAlarmEvent other = (AlertOrAlarmEvent) obj;
        return Objects.equals(this.aep.getEventType(), other.aep.getEventType())
                && Objects.equals(this.aep.getAlertType(), other.aep.getAlertType());
    }
}
