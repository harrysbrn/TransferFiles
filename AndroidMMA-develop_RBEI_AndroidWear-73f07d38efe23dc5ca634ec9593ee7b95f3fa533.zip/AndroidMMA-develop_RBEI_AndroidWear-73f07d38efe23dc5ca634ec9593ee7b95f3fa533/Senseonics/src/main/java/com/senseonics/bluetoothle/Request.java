package com.senseonics.bluetoothle;

import android.util.Log;

import com.google.common.base.Objects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class Request implements Comparable<Request>{
    public static final int SYNC_PRIORITY = 10;
    private final int expectedResponseId;
    private final int[] data;
    private final int recordNr;
    private final int expectedResponseCount;
    private int priority;
    private int runningResponseCount;
    private long insertionTime;

    public Request(int expectedResponseId, int[] data) {
        this(expectedResponseId, data, 0, 1);
    }

    public Request(int expectedResponseId, int[] data, int recordNumber, int expectedResponseCount) {
        this(expectedResponseId, data, recordNumber, expectedResponseCount, 0);
    }

    public Request(int expectedResponseId, int[] data, int recordNumber, int expectedResponseCount, int priority) {
        this.expectedResponseId = expectedResponseId;
        this.data = data;
        this.recordNr = recordNumber;
        this.expectedResponseCount = expectedResponseCount;
        this.priority = priority;
        this.runningResponseCount = 0;
    }

    public void setInsertionTime(long insertionTime) {
        this.insertionTime = insertionTime;
    }

    public int getExpectedResponseId() {
        return expectedResponseId;
    }

    public int[] getData() {
        return data;
    }

    public byte[] getDataBytes() {
        return convertToByteArray(data);
    }

    private byte[] convertToByteArray(int[] ints) {
        byte[] bytes = new byte[ints.length];
        for (int i = 0; i < ints.length; i++) {
            bytes[i] = (byte) ints[i];
        }
        return bytes;
    }

    public boolean isResponseIdTheLastExpectedResponse(int responseId) {
        if(expectedResponseId == responseId) {
            runningResponseCount++;
        }
        return (runningResponseCount >= expectedResponseCount);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Request)) return false;

        Request request = (Request) o;

        if (expectedResponseId != request.expectedResponseId) return false;
        if (recordNr != request.recordNr) return false;
        if (!Arrays.equals(data, request.data)) return false;
        if (compareTo(request) != 0) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = expectedResponseId;
        result = 31 * result + (data != null ? Arrays.hashCode(data) : 0);
        result = 31 * result + recordNr + priority;
        return result;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("data", HexHelper.intArrayToString(data))
                .add("responseId", "0x" + Integer.toHexString(expectedResponseId).toUpperCase())
                .add("recordNr", recordNr)
                .add("priority", priority)
                .add("insertionTime", insertionTime)
                .toString();
    }

    @Override
    public int compareTo(Request another) {

        int priorityCompare = Integer.compare(priority, another.priority);
        if (priorityCompare == 0) {
            return Long.compare(insertionTime, another.insertionTime);
        }
        return priorityCompare;
    }

    static Request saveBondingInformation() {
        return new Request(CommandAndResponseIDs.SaveBLEBondingInformationResponseID, CommandOperations.operationToSaveBLEBondingInformation());
    }

    static Request readSignalStrengthRequest() {
        return operationToReadTwoByteSerialFlashRegister(MemoryMap.sensorFieldCurrentAddress);
    }

    static Request readBatteryLevelRequest() {
        return operationToReadSingleByteSerialFlashRegister(MemoryMap.batteryPercentageAddress);
    }

    static Request readHysteresisPercentRequest() {
        return operationToReadSingleByteSerialFlashRegister(MemoryMap.hysteresisPercentageAddress);
    }

    static Request readHysteresisValueRequest() {
        return operationToReadSingleByteSerialFlashRegister(MemoryMap.hysteresisValueAddress);
    }

    static Request readPredictiveHysteresisPercentRequest() {
        return operationToReadSingleByteSerialFlashRegister(MemoryMap.hysteresisPredictivePercentageAddress);
    }

    static Request readPredictiveHysteresisValueRequest() {
        return operationToReadSingleByteSerialFlashRegister(MemoryMap.hysteresisPredictiveValueAddress);
    }

    static Request readGlucoseAlertsAndStatus() {
        return new Request(CommandAndResponseIDs.ReadSensorGlucoseAlertsAndStatusResponseID, CommandOperations.operationToReadSensorGlucoseAlertsAndStatus());
    }

    /** #3194 */
    static Request readRawDataValue(MemoryMap.RAW_DATA_INDEX index) {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(index.getMemoryAddress()));
    }

    static Request readGlucoseData() {
        Log.d("#3640", "readGlucoseData");
        return new Request(CommandAndResponseIDs.ReadSensorGlucoseResponseID, CommandOperations
                .operationToReadMostRecentGlucoseData());
    }

    static Request readFirstAndLastSensorGlucoseRecordNumbers() {
        return new Request(CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseRecordNumbersResponseID, CommandOperations.operationToReadFirstAndLastSensorGlucoseRecordNumbers());
    }

    static Request readFirstAndLastSensorGlucoseAlertRecordNumbers() {
        return new Request(CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseID, CommandOperations.operationToReadFirstAndLastSensorGlucoseAlertRecordNumbers());
    }

    static Request readFirstAndLastBloodGlucoseDataRecordNumber() {
        return new Request(CommandAndResponseIDs.ReadFirstAndLastBloodGlucoseDataRecordNumbersResponseID, CommandOperations.operationToReadFirstAndLastBloodGlucoseDataRecordNumbers());
    }

    static Request ping() {
        return new Request(CommandAndResponseIDs.PingResponseID, CommandOperations.operationToPingTransmitter());
    }

    static Request model() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.transmitterModelNumberAddress));
    }

    static Request version() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.transmitterSoftwareVersionAddress));
    }

    static Request versionExtension() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.transmitterSoftwareVersionExtAddress));
    }

    static Request lastCalDate() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.mostRecentCalibrationDateAddress));
    }

    static Request lastCalTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.mostRecentCalibrationTimeAddress));
    }

    static Request phaseStartDate() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.startDateOfCalibrationPhaseAddress));
    }

    static Request phaseStartTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.startTimeOfCalibrationPhaseAddress));
    }

    static Request completedCalibrationsCount() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.calibrationsMadeInThisPhaseAddress));
    }

    static Request currentCalibrationPhase() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.currentCalibrationPhaseAddress));
    }

    static Request readClinicalMode() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.clinicalMode));
    }

    static Request readCurrentTransmitterDateAndTime() {
        return new Request(CommandAndResponseIDs.ReadCurrentTrasmitterDateAndTimeResponseID, CommandOperations.operationToReadCurrentTransmitterDateAndTime());
    }

    static Request readSensorGlucoseSamplingInterval() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.sensorGlucoseSamplingInterval));
    }

    static Request readMorningCalibrationTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.morningCalibrationTime));
    }

    static Request readEveningCalibrationTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.eveningCalibrationTime));
    }

    static Request sendCurrentDateAndTimeToTransmitter() {

        Calendar calendar = Calendar.getInstance();

        TimeZone mTimeZone = calendar.getTimeZone();

        int mUTCOffset = mTimeZone.getOffset((new Date()).getTime());
        int mGMTOffsetInMinutes = (int) TimeUnit.MINUTES.convert(mUTCOffset,
                TimeUnit.MILLISECONDS);

        int UTCHours = mGMTOffsetInMinutes / 60;
        int UTCMinutes = Math.abs(mGMTOffsetInMinutes) % 60;
        int UTCSeconds = 0;

        int TimeZoneOffsetSign;
        if (UTCHours >= 0)
            TimeZoneOffsetSign = 0x00;
        else
            TimeZoneOffsetSign = 0xFF;

        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int[] DateGMT = BinaryOperations.calculateDateBytes(year, month, day);

        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        int s = calendar.get(Calendar.SECOND);
        int[] TimeGMT = BinaryOperations.calculateTimeBytes(h, m, s);

        int[] TimeZone = BinaryOperations.calculateTimeBytes(
                Math.abs(UTCHours), Math.abs(UTCMinutes), Math.abs(UTCSeconds));

        return new Request(CommandAndResponseIDs.SetCurrentTrasmitterDateAndTimeResponseID, CommandOperations.operationToSetTransmitterDateAndTime(DateGMT,
                TimeGMT, TimeZone, TimeZoneOffsetSign));
    }

    static Request linkedSensorId() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.linkedSensorIDAddress));
    }

    static Request detectedSensorId() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.unlinkedSensorIDAddress));
    }


    static Request readSensorInsertionDate() {
        return new Request(
                CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.sensorInsertionDateAddress));
    }

    static Request readSensorInsertionTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.sensorInsertionTimeAddress));
    }

    public static Request readReadyForCalibration() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.readyForCalibrationAddress));
    }

    public static Request readNextCalibrationDate() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.nextCalibrationDate));
    }

    public static Request readSensorLifeDays() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.sensorLifeAddress));
    }

    public static Request readMinCalibrationTreshold() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.minCalibrationTreshold));
    }

    public static Request readMaxCalibrationTreshold() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.maxCalibrationTreshold));
    }

    public static Request readNextCalibrationTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.nextCalibrationTime));
    }

    public static Request readMinutesRemainingUntilCalibrationAllowed() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.minutesRemainingUntilCalibrationAllowed));
    }

    public static Request readAlgorithmParameterFormatVersion() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.algorithmParameterFormatVersion));
    }

    // #2936
    public static Request readMEPSavedValue() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.mepSavedValueAddress));
    }

    public static Request readMEPSavedRefChannelMetric() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.mepSavedRefChannelMetricAddress));
    }

    public static Request readMEPSavedDriftMetric() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.mepSavedDriftMetricAddress));
    }

    public static Request readMEPSavedLowRefMetric() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.mepSavedLowRefMetricAddress));
    }

    public static Request readMEPSavedSpike() {
        return new Request(CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID, CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.mepSavedSpikeAddress));
    }

    public static Request readEEP24MSP() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.eep24MSPAddress));
    }

    // #2379
    public static Request readLowGlucoseAlarmRepeatIntervalDayTime() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmRepeatIntervalDayTimeAddress));
    }

    public static Request writeLowGlucoseAlarmRepeatIntervalDayTime(int value) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmRepeatIntervalDayTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readHighGlucoseAlarmRepeatIntervalDayTime() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.highGlucoseAlarmRepeatIntervalDayTimeAddress));
    }

    public static Request writeHighGlucoseAlarmRepeatIntervalDayTime(int value) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.highGlucoseAlarmRepeatIntervalDayTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readLowGlucoseAlarmRepeatIntervalNightTime() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmRepeatIntervalNightTimeAddress));
    }

    public static Request writeLowGlucoseAlarmRepeatIntervalNightTime(int value) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmRepeatIntervalNightTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readHighGlucoseAlarmRepeatIntervalNightTime() {
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.highGlucoseAlarmRepeatIntervalNightTimeAddress));
    }

    public static Request writeHighGlucoseAlarmRepeatIntervalNightTime(int value) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.highGlucoseAlarmRepeatIntervalNightTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readDayStartTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.dayStartTimeAddress));
    }

    public static Request readNightStartTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.nightStartTimeAddress));
    }

    public static Request writeDayStartTime(int hour, int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int value[] = BinaryOperations.calculateTimeBytes(hour, minutes, 0);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.dayStartTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request writeNightStartTime(int hour, int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int value[] = BinaryOperations.calculateTimeBytes(hour, minutes, 0);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.nightStartTimeAddress, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readMinutesBeforeNextCalibrationTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.minsBeforeNextCalibrationTime));
    }

    public static Request readMinutesAfterNextCalibrationTime() {
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.minsAfterNextCalibrationTime));
    }

    public static Request sendBloodGlucoseData(int[] requestData) {
        return new Request(CommandAndResponseIDs.SendBloodGlucoseDataResponseID, requestData);
    }

    public static Request writeHighGlucoseTarget(int level) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int[] value = BinaryOperations.data16BitsFromIntLSByteFirst(level);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.highGlucoseTarget, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readHighGlucoseTargetRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.highGlucoseTarget);
        return new Request(expectedResponseId, data);
    }

    public static Request writeLowGlucoseTargetRequest(int level) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int[] value = BinaryOperations.data16BitsFromIntLSByteFirst(level);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.lowGlucoseTarget, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readLowGlucoseTargetRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.lowGlucoseTarget);
        return new Request(expectedResponseId, data);
    }

    public static Request writeHighGlucoseAlarmRequest(int glucoseLevel) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int[] value = BinaryOperations.data16BitsFromIntLSByteFirst(glucoseLevel);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.highGlucoseAlarmTreshold, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readHighGlucoseAlarmRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.highGlucoseAlarmTreshold);
        return new Request(expectedResponseId, data);
    }

    public static Request writeLowGlucoseAlarmRequest(int glucoseLevel) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int[] value = BinaryOperations.data16BitsFromIntLSByteFirst(glucoseLevel);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmTreshold, value);
        return new Request(expectedResponseId, data);
    }

    public static Request readLowGlucoseAlarmRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.lowGlucoseAlarmTreshold);
        return new Request(expectedResponseId, data);
    }

    public static Request writePredictiveAlertsRequest(boolean switchState) {
        int switchStateValue;
        if (switchState)
            switchStateValue = 0x55;
        else
            switchStateValue = 0x00;
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.predictiveAlert, switchStateValue);
        return new Request(expectedResponseId, data);
    }

    public static Request readPredictiveAlertsRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations
                .operationToReadSingleByteSerialFlashRegister(MemoryMap.predictiveAlert);
        return new Request(expectedResponseId, data);
    }

    public static Request writePredictiveFallingTimeIntervalRequest(int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.predictiveFallingRateAlertTimeInterval,
                minutes);
        return new Request(expectedResponseId, data);
    }

    public static Request writePredictiveRisingTimeIntervalRequest(int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.predictiveRisingRateAlertTimeInterval, minutes);
        return new Request(expectedResponseId, data);
    }

    public static Request readPredictiveFallingTimeIntervalRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.predictiveFallingRateAlertTimeInterval);
        return new Request(expectedResponseId, data);
    }

    public static Request writeRateAlert(boolean state) {
        int switchStateValue;
        if (state)
            switchStateValue = 0x55;
        else
            switchStateValue = 0x00;

        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.rateAlert, switchStateValue);
        return new Request(expectedResponseId, data);
    }

    public static Request readRateAlert() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.rateAlert);
        return new Request(expectedResponseId, data);
    }

    public static Request writeRateAlertFallingThresholdRequest(int threshold) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.rateAlertFallingTreshold, threshold);
        return new Request(expectedResponseId, data);
    }

    public static Request writeRateAlertRisingThresholdRequest(int threshold) {
        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.rateAlertRisingTreshold, threshold);
        return new Request(expectedResponseId, data);
    }

    public static Request readRateAlertFallingThresholdRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.rateAlertFallingTreshold);
        return new Request(expectedResponseId, data);
    }

    public static Request writeClinicalModeRequest(boolean isClinicalMode) {
        int switchStateValue;
        if (isClinicalMode)
            switchStateValue = 0x55;
        else
            switchStateValue = 0x00;

        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.clinicalMode, switchStateValue);
        return new Request(expectedResponseId, data);
    }

    public static Request readVibrateModeRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.vibrateMode);
        return new Request(expectedResponseId, data);
    }

    public static Request readDoNotDisturbModeRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadSingleByteSerialFlashRegister(MemoryMap.doNotDisturbMode);
        return new Request(expectedResponseId, data);
    }

    public static Request writeVibrateModeRequest(boolean isVibrateMode) {
        int switchStateValue;
        if (isVibrateMode)
            switchStateValue = 0x55;
        else
            switchStateValue = 0x00;

        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.vibrateMode, switchStateValue);
        return new Request(expectedResponseId, data);
    }

    public static Request writeDoNotDisturbModeRequest(boolean shouldNotDisturb) {
        int switchStateValue;
        if (shouldNotDisturb)
            switchStateValue = 0x55;
        else
            switchStateValue = 0x00;

        int expectedResponseId = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteSingleByteSerialFlashRegister(MemoryMap.doNotDisturbMode, switchStateValue);
        return new Request(expectedResponseId, data);
    }

    public static Request readSensorIdRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToReadFourByteSerialFlashRegister(MemoryMap.linkedSensorIDAddress);
        return new Request(expectedResponseId, data);
    }

    public static Request readUnlinkedSensorIdRequest() {
        int expectedResponseId = CommandAndResponseIDs.ReadFourByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations
                .operationToReadFourByteSerialFlashRegister(MemoryMap.unlinkedSensorIDAddress);
        return new Request(expectedResponseId, data);
    }

    public static Request writePatientEvent(long millis, int eventTypeId, int eventSubtype, int quantity) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);

        int[] date = BinaryOperations.calculateDateBytes(year, month, day);
        int[] time = BinaryOperations.calculateTimeBytes(hour, minute, second);

        int[] data = CommandOperations.operationToWritePatientEvent(date, time, eventTypeId, eventSubtype, quantity);

        return new Request(CommandAndResponseIDs.WritePatientEventResponseID, data);
    }

    public static Request writeGlucosePatientEvent(long millis, int glucoseLevel) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);

        int[] date =  BinaryOperations.calculateDateBytes(year, month, day);
        int[] time = BinaryOperations.calculateTimeBytes(hour, minute, second);

        int[] value = BinaryOperations.data16BitsFromIntLSByteFirst(glucoseLevel);

        int[] meter = new int[]{0, 0};
        int[] data = CommandOperations.operationToSendBloodGlucoseValueToTransmitter(date, time, value, 0, meter, false);

        return Request.sendBloodGlucoseData(data);
    }

    public static Request writeLastFourByteTransmitterNameRequest(String transmitterName) {

        int[] nameArray1 = new int[4];
        int[] nameArray2 = new int[4];
        for (int i = 0; i < 4; ++i) {
            if (i < transmitterName.length())
                nameArray1[i] = (int) transmitterName.charAt(i);
            else
                nameArray1[i] = 0;
        }
        for (int i = 0; i < 4; ++i) {
            if (4 + i < transmitterName.length())
                nameArray2[i] = (int) transmitterName.charAt(4 + i);
            else
                nameArray2[i] = 0;
        }
        int expectedResponseId = CommandAndResponseIDs.WriteFourByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteFourByteSerialFlashRegister(MemoryMap.transmitterNameLast4Byte, nameArray2);
        return new Request(expectedResponseId, data);
    }

    public static Request writeFirstFourByteTransmitterNameRequest(String transmitterName) {
        int[] nameArray1 = new int[4];
        int[] nameArray2 = new int[4];
        for (int i = 0; i < 4; ++i) {
            if (i < transmitterName.length())
                nameArray1[i] = (int) transmitterName.charAt(i);
            else
                nameArray1[i] = 0;
        }
        for (int i = 0; i < 4; ++i) {
            if (4 + i < transmitterName.length())
                nameArray2[i] = (int) transmitterName.charAt(4 + i);
            else
                nameArray2[i] = 0;
        }
        int expectedResponseId = CommandAndResponseIDs.WriteFourByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteFourByteSerialFlashRegister(MemoryMap.transmitterNameFirst4Byte, nameArray1);
        return new Request(expectedResponseId, data);
    }

    public static Request writeMorningCalibrationTime(int hour, int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int value[] = BinaryOperations.calculateTimeBytes(hour, minutes, 0);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.morningCalibrationTime, value);
        return new Request(expectedResponseId, data);
    }

    public static Request writeEveningCalibrationTime(int hour, int minutes) {
        int expectedResponseId = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
        int value[] = BinaryOperations.calculateTimeBytes(hour, minutes, 0);
        int[] data = CommandOperations.operationToWriteTwoByteSerialFlashRegister(MemoryMap.eveningCalibrationTime, value);
        return new Request(expectedResponseId, data);
    }


    public static List<Request> writeTransmitterChunk(int[] data, int address, int chunkSize) {
        int numBytes = data.length;
        ArrayList<Request> requests = new ArrayList<Request>();
        int currentAddress = address;
        for (int i = 0; i < numBytes; i += chunkSize) {
            int currentChunkSize = chunkSize;
            if (i + currentChunkSize > numBytes) {
                currentChunkSize = numBytes - i;
            }
            int[] subarray = new int[currentChunkSize];
            System.arraycopy(data, i, subarray, 0, currentChunkSize);

            for (int j = 0; j < subarray.length; ++j)
                Log.d("subarray " + i, subarray[j] + " " + currentAddress);

            int[] addressArray = new int[3];
            addressArray[2] = currentAddress & 0xff;
            addressArray[1] = (currentAddress & 0xff00) >> 8;
            addressArray[0] = (currentAddress & 0xff0000) >> 16;

            currentAddress += currentChunkSize;
            int[] dataToSend = CommandOperations.operationToWriteNByteSerialFlashRegister(addressArray, currentChunkSize, subarray);
            requests.add(new Request(CommandAndResponseIDs.WriteNByteSerialFlashRegisterResponseID, dataToSend));
        }
        return requests;
    }

    public static Request writeSensorID(long sensorId) {
        int expectedResponseId = CommandAndResponseIDs.LinkTransmitterWithSensorResponseID;

        int[] array = new int[4];
        array[0] = (int) (sensorId & 0xffL);
        array[1] = (int) ((sensorId & 0xff00L) >> 8);
        array[2] = (int) ((sensorId & 0xff0000L) >> 16);

        array[3] = (int) ((sensorId & 0xff000000L) >> 24);
        if (array[3] != 0xFF) {
            array[3] = 1; // MSB version number should be 0x01 if it's not 0xFF
        }

        Log.d(BluetoothUtils.class.getSimpleName(), array[0] + " " + array[1] + " " + array[2] + " "
                + array[3]);
        int[] value2 = new int[]{array[3], array[2], array[1], array[0]};
        // int[] value2 = new int[] { array[0], array[1] , array[2], array[3] };
        // int[] value2 = new int[] { 0x00, 0x00, 0x00, 0x00 };
        int[] data = CommandOperations.operationToLinkTransmitterWithSensor(value2);

        return new Request(expectedResponseId, data);
    }

    public static Request enterDiagnosticMode() {
        return new Request(CommandAndResponseIDs.EnterDiagnosticModeResponseID, CommandOperations.operationToEnterDiagnosticMode());
    }

    public static Request exitDiagnosticMode() {
        return new Request(CommandAndResponseIDs.ExitDiagnosticModeResponseID, CommandOperations.operationToExitDiagnosticMode());
    }

    public static Request writeAppVersion(String appVersion) {
        String[] versionSplit = appVersion.split("\\.");
        /** The version checking has been done in StateSyncer */
        int x = Integer.parseInt(versionSplit[0]);
        int y = Integer.parseInt(versionSplit[1]);
        int z = Integer.parseInt(versionSplit[2]);

        int[] appVersionArray = new int[4];
        appVersionArray[0] = (z & 0x00FF);
        appVersionArray[1] = (z & 0xFF00) >> 8;
        appVersionArray[2] = y;
        appVersionArray[3] = x;

        Log.d("AppVersion", "appVersionArray:" + appVersionArray[0] + "|" + appVersionArray[1] + "|" + appVersionArray[2] + "|" + appVersionArray[3]);

        int expectedResponseId = CommandAndResponseIDs.WriteFourByteSerialFlashRegisterResponseID;
        int[] data = CommandOperations.operationToWriteFourByteSerialFlashRegister(MemoryMap.appVersionAddress, appVersionArray);
        return new Request(expectedResponseId, data);
    }

    public static Request markPatientEventRecordAsDeleted(int recordNumber) {
        return new Request(CommandAndResponseIDs.MarkPatientEventRecordAsDeletedResponseID,
                CommandOperations.operationToMarkPatientEventRecordAsDeleted(new int[] {recordNumber}));
    }

    static Request operationToReadTwoByteSerialFlashRegister(
            int[] registerAddress) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = "";
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return new Request(CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID, commandToSend);
    }

    // ---------------------------------------------------

    // 0x2A
    static Request operationToReadSingleByteSerialFlashRegister(
            int[] registerAddress) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return new Request(CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID, commandToSend);
    }

    public static Request forceGlucoseMeasurement() {
        return new Request(CommandAndResponseIDs.TestResponseID, CommandOperations.operationToForceGlucoseMeasurement());
    }

}
