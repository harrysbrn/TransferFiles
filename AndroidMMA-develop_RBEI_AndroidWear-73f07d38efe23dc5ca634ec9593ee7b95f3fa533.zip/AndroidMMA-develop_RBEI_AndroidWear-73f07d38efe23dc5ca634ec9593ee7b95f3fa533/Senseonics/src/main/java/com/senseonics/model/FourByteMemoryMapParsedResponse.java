package com.senseonics.model;

public interface FourByteMemoryMapParsedResponse {

    int[] getMemoryAddress();
    void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model);
}
