package com.senseonics.fragments;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.GLUCOSE_UNIT;

import java.util.Locale;

public class GlucoseUnitFragment extends Fragment {

	public CheckBox radioMgDLType, radioMmolType;
    private TextView unitReadingTextView, unitMeasurementTextView, unitExampleTextView, unitDespTextView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_glucoseunit, null);

        TextView radioTextMgDLView = (TextView) view.findViewById(R.id.textMgDL);
        TextView radioTextMmolView = (TextView) view.findViewById(R.id.textMmol);
		radioMgDLType = (CheckBox) view.findViewById(R.id.radioMgDL);
		radioMmolType = (CheckBox) view.findViewById(R.id.radioMmol);

        unitReadingTextView = (TextView) view.findViewById(R.id.unitReadingText);
        unitMeasurementTextView = (TextView) view.findViewById(R.id.unitMeasurement);
        unitExampleTextView = (TextView) view.findViewById(R.id.unitExampleText);
        unitDespTextView = (TextView) view.findViewById(R.id.unitDespText);

        radioTextMgDLView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioMgDLType.setChecked(true);
            }
        });

        radioTextMmolView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioMmolType.setChecked(true);
            }
        });

        radioMgDLType
				.setOnCheckedChangeListener(new OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                                                 boolean isChecked) {
                        if (isChecked) {
                            radioMmolType.setChecked(false);
                            updateTextForUnit(GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL);
                        }
                    }
                });

		radioMmolType
				.setOnCheckedChangeListener(new OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                                                 boolean isChecked) {
                        if (isChecked) {
                            radioMgDLType.setChecked(false);
                            updateTextForUnit(GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L);
                        }
                    }
                });

        Activity act = getActivity();
        if (act != null) {
            SharedPreferences sharedPreferences = act.getSharedPreferences(
                    Utils.SHARED_PREF, Context.MODE_PRIVATE);
            if (!sharedPreferences.contains(Utils.prefGlucoseUnit)) {
                /** no stored unit */
                /*
                Locale.getDefault().getLanguage()       ---> en
                Locale.getDefault().getISO3Language()   ---> eng
                Locale.getDefault().getCountry()        ---> US
                Locale.getDefault().getISO3Country()    ---> USA
                Locale.getDefault().getDisplayCountry() ---> United States
                Locale.getDefault().getDisplayName()    ---> English (United States)
                Locale.getDefault().toString()          ---> en_US
                Locale.getDefault().getDisplayLanguage()---> English
                */
                String localeString = Locale.getDefault().toString();
                Log.d("Initial", "Locale:" + localeString);

                // #2967 Default unit for Germany and Italy should be mg/dl (Android)
                if (localeString.equals("en_US") ||
                        localeString.equals("de_DE") ||
                        localeString.equals("it_IT")) {
                    radioMgDLType.setChecked(true);
                } else {
                    radioMmolType.setChecked(true);
                }
            }
            else {
                /** has stored unit */
                Utils.GLUCOSE_UNIT storedUnit = Utils.GLUCOSE_UNIT.values()[sharedPreferences
                        .getInt(Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal())];
                if (storedUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
                    radioMgDLType.setChecked(true);
                }
                else {
                    radioMmolType.setChecked(true);
                }
            }
        }

		return view;
	}

    private void updateTextForUnit(GLUCOSE_UNIT unitSelected) {
        Spanned unitGlucoseReadingText = null;
        Spanned unitMeasurement = null;
        Spanned unitExample = null;
        Spanned unitDesp = null;

        if(unitSelected == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {

            unitGlucoseReadingText = Html.fromHtml(getResources().getString(R.string.unit_glucose_reading_text_mgdl_mmol_2)
                    .replace("%value%", "<b>"+getResources().getString(R.string.unit_glucose_reading_set) +"</b>"));

            unitMeasurement =  Html.fromHtml(getResources().getString(R.string.unit_selected_text)
                    .replace("%value%", "<b>"+getResources().getString(R.string.mg_Dl) +"</b>"));

            unitExample = Html.fromHtml(getResources().getString(R.string.unit_example_text_mgdl));

            unitDesp = Html.fromHtml(getResources().getString(R.string.unit_descriptive_text_mgdl_mmol)
                    .replace("%value%", "<b>"+getResources().getString(R.string.mg_Dl) +"</b>"));
        }
        else {
            unitGlucoseReadingText = Html.fromHtml(getResources().getString(R.string.unit_glucose_reading_text_mgdl_mmol_2)
                    .replace("%value%", "<b>"+getResources().getString(R.string.unit_glucose_reading_changed) + "</b>"));

            unitMeasurement =  Html.fromHtml(getResources().getString(R.string.unit_selected_text)
                    .replace("%value%", "<b>"+getResources().getString(R.string.mmol_L) +"</b>"));

            unitExample = Html.fromHtml(getResources().getString(R.string.unit_example_text_mmol));

            unitDesp = Html.fromHtml(getResources().getString(R.string.unit_descriptive_text_mgdl_mmol)
                    .replace("%value%", "<b>"+getResources().getString(R.string.mmol_L) +"</b>"));
        }

        unitReadingTextView.setText(unitGlucoseReadingText);
        unitMeasurementTextView.setText(unitMeasurement);
        unitExampleTextView.setText(unitExample);
        unitDespTextView.setText(unitDesp);

    }

}
