package com.senseonics.bluetoothle;

import android.util.Log;

import java.util.Arrays;

public class ResponseOperations {

	public static int[] RESULT_OK = new int[] { 100 };

	public interface ReaderManager {

		// RESPONSES TO ESTABLISH LINK AND CONTROL TRANSMITTER

		void parsedReadCurrentTrasmitterDateAndTimeResponse(int[] date,
				int[] time, int[] timeZoneOffset, int timeZoneOffsetSign);

		void parsedChangeTimingParametersResponse(int requestSuccessfull);

		// -

		void parsedReadSingleSensorGlucoseDataRecordResponseData(
				int glucoseRecordNumber, int[] date, int[] time, int value,
				int sensorGlucoseAlertFlags);

		void parsedReadSingleSensorGlucoseAlertRecordResponse(
				int sensorGlucoseAlertRecordNr, int[] date, int[] time,
				int sensorGlucoseAlertLogRecordType, int sensorGlucoseValue,
				int sensorGlucoseRateValue, int alertThresholdOrTimInterval);

		void parsedSendBloodGlucoseDataResponse(int calibrationUseFlags);

		void parsedReadSingleBloodGlucoseDataRecordResponse(int recordNr,
				int[] date, int[] time, int bloodGlucoseValue,
				int meterIdentifier, int calUseFlags,
				int closestSensorGlucoseEntryRecordNr);

		// - Patient event

		void parsedReadSinglePatientEventResponse(int recordNr, int[] date,
				int[] time, int eventTypeId, int eventSubtypeId,
				int eventSubtypeQ, int textLength);

		void parsedMarkPatientEventRecordAsDeletedResponse(int deletedRecordNr);

		void parsedReadSingleMiscEventLogResponse(int recordNr, int[] date,
				int[] time, int miscEventType, int[] eventAddtitionalInfo);

		void parsedReadFirstAndLastMiscEventLogRecordNumbersResponse(
				int firstRecordNr, int lastRecordNr);

		// -

		void parsedReadFirstAndLastErrorLogRecordNumbersResponse(
				int firstRecordNr, int lastRecordNr);

		// -

		void parsedReadNByteSerialFlashRegisterResponse(int[] address, int n,
				int[] values);

		void parsedWriteNByteSerialFlashRegisterResponse(int[] address, int n);

		void parsedWriteFourByteSerialFlashRegisterResponse(int[] data,
				int[] address);

		void parsedReadTwoByteSerialFlashRegisterResponse(int[] data,
				int[] address);

		void parsedWriteTwoByteSerialFlashRegisterResponse(int[] data,
				int[] address);

		void parsedReadSingleByteSerialFlashRegisterResponse(int data,
				int[] address);

	}

	public static class Response {
		private int responseId = 0;
		private boolean responseAccepted;
		private int[] data;

		public Response(boolean responseAccepted, int[] data) {
			super();
			this.setResponseAccepted(responseAccepted);
			this.setData(data);
		}

		public Response(int responseId, boolean responseAccepted, int[] data) {
			super();
			this.setResponseId(responseId);
			this.setResponseAccepted(responseAccepted);
			this.setData(data);
		}

		public int getResponseId() {
			return responseId;
		}

		public void setResponseId(int responseId) {
			this.responseId = responseId;
		}

		public int[] getData() {
			return data;
		}

		public void setData(int[] data) {
			this.data = data;
		}

		public boolean isResponseAccepted() {
			return responseAccepted;
		}

		public void setResponseAccepted(boolean responseAccepted) {
			this.responseAccepted = responseAccepted;
		}
	}

	public static Response checkResponse(int[] response,
                                         final ReaderManager manager, int expectedResponseId, BluetoothService service) {

		boolean isResponseIdOK = false;

		if (expectedResponseId == response[0]) {
			Log.d("CHECK CORRECTION", "Response ID good!");
			isResponseIdOK = true;
		}
		
		int responseID = response[0];

		// if it's push notification
		if (responseID >= 0x40 && responseID < 0x60)
		{
			Log.w("Push Response", "responseID:" + responseID);
		}

		switch (responseID) {

		// RESPONSES TO ESTABLISH LINK AND CONTROL TRANSMITTER

		/* 0x82 */
		case CommandAndResponseIDs.LinkTransmitterWithSensorResponseID:
			Log.d("RESPONSE", "Is response to LINK TRM WITH SENSOR ID");
			if (isLinkTransmitterWithSensorResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x83 */
		case CommandAndResponseIDs.ResetTransmitterResponseID:
			Log.d("RESPONSE", "Is response to RESET TRM");
			if (isResetTransmitterResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x84 */
		case CommandAndResponseIDs.ClearErrorFlagsResponseID:
			Log.d("RESPONSE", "Is response to CLEAR ERROR FLAGS");
			if (isClearErrorFlagsResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x85 */
		case CommandAndResponseIDs.StartSelfTestSequenceResponseID:
			Log.d("RESPONSE", "Is response to START SELF TEST SEQ");
			if (isStartSelfTestSequenceResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x86 */
		case CommandAndResponseIDs.ReadAllAvailableSensorsResponseID:
			Log.d("RESPONSE", "Is response to READ ALL AV. SENSORS");
			// FUTURE
			if (isReadAllAvailableSensorsResponseCorrect(response)) {
				parseReadAllAvailableSensorsResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x87 */
		case CommandAndResponseIDs.SetCurrentTrasmitterDateAndTimeResponseID:
			Log.d("RESPONSE", "Is response to SET TRM DATE N TIME");
			if (isSetCurrentTrasmitterDateAndTimeResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xE9 */
		case CommandAndResponseIDs.SaveBLEBondingInformationResponseID:
			break;

		/* 0xF4 */
		case CommandAndResponseIDs.DisconnectBLESavingBondingInformationResponseID:
			Log.d("RESPONSE",
					"Is response to DISCONNECT N SAVE BLE BONDING INFO");
			if (isDisconnectBLESavingBondingInformationResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xF5 */
		case CommandAndResponseIDs.ChangeTimingParametersResponseID:
			Log.d("RESPONSE", "Is response to CHANGE TIMING PARAMS");
			if (isChangeTimingParametersResponseCorrect(response)) {
				parseChangeTimingParametersResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// -----------------------------------------------------------------------------------------------


		/* 0x89 */
		case CommandAndResponseIDs.ReadSingleSensorGlucoseDataRecordResponseID:
			Log.d("RESPONSE",
					"Is response to READ SINGLE SENSOR GLUCOSE RECORD");
			if (isReadSingleSensorGlucoseDataRecordResponseCorrect(response)) {
				parseReadSingleSensorGlucoseDataRecordResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// -----------------------------------------------------------------------------------------------

		/* 0x91 */
		case CommandAndResponseIDs.ReadSingleSensorGlucoseAlertRecordResponseID:
			Log.d("RESPONSE",
					"Is response to READ SINGLE SENSOR GLUCOSE ALERT RECORD");
			if (isReadSingleSensorGlucoseAlertRecordResponseCorrect(response)) {
				parseReadSingleSensorGlucoseAlertRecordResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x94 */
		case CommandAndResponseIDs.AssertSnoozeAgainsAlarmResponseID:
			Log.d("RESPONSE", "Is response to ASSERT SNOOZE AGAINST ALARM");
			Log.d("messagecode", "Is response to ASSERT SNOOZE AGAINST ALARM"
					+ Arrays.toString(response));
			if (isAssertSnoozeAgainsAlarmResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// ------------------------------------------------------------------------------

		/* 0x95 */
		case CommandAndResponseIDs.SendBloodGlucoseDataResponseID:
			Log.d("RESPONSE", "Is response to SEND BLOOD GLUCOSE DATA");
			if (isSendBloodGlucoseDataResponseCorrect(response)) {
				parseSendBloodGlucoseDataResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x96 */
		case CommandAndResponseIDs.ReadSingleBloodGlucoseDataRecordResponseID:
			Log.d("RESPONSE",
					"Is response to READ SINGLE BLOOD GLUCOSE DATA RECORD");
			if (isReadSingleBloodGlucoseDataRecordResponseCorrect(response)) {
				parseReadSingleBloodGlucoseDataRecordResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// ------------------------------------------------------------------------------

		/* 0x9B */
		case CommandAndResponseIDs.ReadSinglePatientEventResponseID:
			Log.d("RESPONSE", "Is response to READ SINGLE PATIENT EVENT");
			if (isReadSinglePatientEventResponseCorrect(response)) {
				parseReadSinglePatientEventResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0x9D */
		case CommandAndResponseIDs.MarkPatientEventRecordAsDeletedResponseID:
			Log.d("RESPONSE",
					"Is response to MARK PATIENT EVENT RECORD AS DELETED");
			if (isMarkPatientEventRecordAsDeletedResponseCorrect(response)) {
				parseMarkPatientEventRecordAsDeletedResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// ---------------------------------------------------------------------------------

		/* 0xA2 */
		case CommandAndResponseIDs.ReadSingleMiscEventLogResponseID:
			Log.d("RESPONSE", "Is response to READ SINGLE MISC EVENT LOG");
			if (isReadSingleMiscEventLogResponseCorrect(response)) {
				parseReadSingleMiscEventLogResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xA3 */
		case CommandAndResponseIDs.ReadFirstAndLastMiscEventLogRecordNumbersResponseID:
			Log.d("RESPONSE", "Is response to READ FIRST N LAST MISC EVENT LOG");
			if (isReadFirstAndLastMiscEventLogRecordNumbersResponseCorrect(response)) {
				parseReadFirstAndLastMiscEventLogRecordNumbersResponseData(
						response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xA4 */
		case CommandAndResponseIDs.WriteSingleMiscEventLogRecordResponseID:
			Log.d("RESPONSE", "Is response to WRITE SINGLE MISC EVENT LOG");
			if (isWriteSingleMiscEventLogRecordResponseCorrect(response)) {
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// ---------------------------------------------------------------------------------

		/* 0xA6 */
		case CommandAndResponseIDs.ReadFirstAndLastErrorLogRecordNumbersResponseID:
			Log.d("RESPONSE",
					"Is response to READ FIRST N LAST ERROR LOG REC. NUMBERS");
			if (isReadFirstAndLastErrorLogRecordNumbersResponseCorrect(response)) {
				parseReadFirstAndLastErrorLogRecordNumbersResponseData(
						response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		// ---------------------------------------------------------------------------------

		/* 0xAA */
		case CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to READ SINGLE BYTE REGISTER");
			if (isReadSingleByteSerialFlashRegisterResponseCorrect(response)) {
				parseReadSingleByteSerialFlashRegisterResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xAC */
		case CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to READ TWO BYTE REGISTER");
			if (isReadTwoByteSerialFlashRegisterResponseCorrect(response)) {
				parseReadTwoByteSerialFlashRegisterResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xAD */
		case CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to WRITE TWO BYTE REGISTER");
			if (isWriteTwoByteSerialFlashRegisterResponseCorrect(response)) {
				parseWriteTwoByteSerialFlashRegisterResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xAF */
		case CommandAndResponseIDs.WriteFourByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to WRITE FOUR BYTE REGISTER");
			if (isWriteFourByteSerialFlashRegisterResponseCorrect(response)) {
				parseWriteFourByteSerialFlashRegisterResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xB0 */
		case CommandAndResponseIDs.ReadNByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to READ N BYTE REGISTER");
			if (isReadNByteSerialFlashRegisterResponseCorrect(response)) {
				parseReadNByteSerialFlashRegisterResponseData(response, manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* 0xB1 */
		case CommandAndResponseIDs.WriteNByteSerialFlashRegisterResponseID:
			Log.d("RESPONSE", "Is response to WRITE N BYTE REGISTER");
			if (isWriteNByteSerialFlashRegisterResponseCorrect(response)) {
				parseWriteNByteSerialFlashRegisterResponseData(response,
						manager);
				return new Response(isResponseIdOK, RESULT_OK);
			}
			break;

		/* If you are planning to handle a response with id in the range of 0x40..0x60 - Add that to the PushNotificationListener class. */

		}

		return null;
	}

	// -------------------------------------------------------------------------------------
	// ----------------RESPONSES TO ESTABLISH LINK AND CONTROL
	// TRANSMITTER------------------
	// -------------------------------------------------------------------------------------

	// ----------------------------PING-RESPONSE-0x81--------------------------------------

	// correction check

	public static boolean isPingResponseCorrect(int[] response) {

		if (response.length != 15) {
			Log.d("CHECK CORRECTION", "PingResponse length not good!");
			return false;
		}

		int[] data = new int[13];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[13] || crcArray[1] != response[14]) {
			Log.d("CHECK CORRECTION", "PingResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ------------------------LINK-TRM-WITH-SENSOR-RESPONSE-0x82-------------------------------

	// correction check
	private static boolean isResetTransmitterResponseCorrect(int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"ResetTransmitterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"ResetTransmitterResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no data to parse on this response

	// ------------------------RESET-TRANSMITTER-RESPONSE-0x83-------------------------------

	// correction check
	private static boolean isLinkTransmitterWithSensorResponseCorrect(
			int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"LinkTransmitterWithSensorResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"LinkTransmitterWithSensorResponsee CRC not matching");
			return false;
		}

		return true;

	}

	// no data to parse on this response

	// ------------------------RESET-TRANSMITTER-RESPONSE-0x84-------------------------------

	// correction check
	private static boolean isClearErrorFlagsResponseCorrect(int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"ClearErrorFlagsResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"ClearErrorFlagsResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no data to parse on this response

	// ---------------------START-SELF-TEST-SEQ-RESPONSE-0x85----------------------------

	// correction check
	private static boolean isStartSelfTestSequenceResponseCorrect(int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"StartSelfTestSequenceResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"StartSelfTestSequenceResponse CRC not matching");
			return false;
		}

		return true;
	}

	// ---------------------READ-ALL-SENSORS-RESPONSE-0x86----------------------------

	// correction check
	private static boolean isReadAllAvailableSensorsResponseCorrect(
			int[] response) {

		if (response.length > 4 || response.length == 0) {
			Log.d("CHECK CORRECTION", "ReadAllSensorsResponse length not good!");
			return false;
		}

		int[] data = new int[response.length - 2];
		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[response.length - 2]
				|| crcArray[1] != response[response.length - 1]) {
			Log.d("CHECK CORRECTION",
					"StartSelfTestSequenceResponse CRC not matching");
			return false;
		}
		return true;
	}

	// parse data
	private static void parseReadAllAvailableSensorsResponseData(
			int[] response, ReaderManager manager) {

		for (int i : response) {
			Log.d("response ------", i + " ");
		}
		// int numberOfSensors = response[1];
	}

	// no data to parse on this response

	// ---------------------------SET-TRM-DATE-N-TIME-RESPONSE-0x87-------------------------
	// correction check
	private static boolean isSetCurrentTrasmitterDateAndTimeResponseCorrect(
			int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"SetCurrentTrasmitterDateAndTimeResponse length not good!");
			return false;
		}

		int[] command = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(command);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			return false;
		}

		return true;

	}

	// no data to parse in this response

	// -------------------------READ-TRM-DATE-N-TIME-RESPONSE-0x99-------------------------------

	// correction check
	public static boolean isReadCurrentTrasmitterDateAndTimeResponseCorrect(
			int[] response) {

		if (response.length != 10) {
			Log.d("CHECK CORRECTION",
					"ReadCurrentTrasmitterDateAndTimeResponse length not good!");
			return false;
		}

		int[] data = new int[8];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[8] || crcArray[1] != response[9]) {
			Log.d("CHECK CORRECTION",
					"ReadCurrentTrasmitterDateAndTimeResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadCurrentTrasmitterDateAndTimeResponseData(
			int[] response, ReaderManager manager) {

		int[] date = BinaryOperations.calculateDateFromBytes(new int[] {
				response[1], response[2] });
		int[] time = BinaryOperations.calculateTimeFromBytes(new int[] {
				response[3], response[4] });

		int[] timeZoneOffset = BinaryOperations.calculateTimeFromBytes(new int[] {
				response[5], response[6]});
		int timeZoneOffsetSign = response[7];
		manager.parsedReadCurrentTrasmitterDateAndTimeResponse(date, time,
				timeZoneOffset, timeZoneOffsetSign);
	}

	// ---------------------SAVE-BONDING-INFO-RESPONSE-0xE9--------------------------

	// correction check
	public static boolean isSaveBLEBondingInformationResponseCorrect(
			int[] response) {

		if (CommandAndResponseIDs.SaveBLEBondingInformationResponseID != response[0]) {
			return false;
		}

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"SaveBLEBondingInformationResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"SaveBLEBondingInformationResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no data to parse on this response

	// -------------------DISC-SAVE-BONDING-INFO-RESPONSE-0xF4------------------------

	// correction check
	private static boolean isDisconnectBLESavingBondingInformationResponseCorrect(
			int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"DisconnectBLESavingBondingInformationResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"DisconnectBLESavingBondingInformationResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no data to parse on this response

	// -----------------------CHANGE-TIMING-PARAMS-RESPONSE-0xF5----------------------------

	// correction check
	private static boolean isChangeTimingParametersResponseCorrect(
			int[] response) {

		if (response.length != 4) {
			Log.d("CHECK CORRECTION",
					"ChangeTimingParametersResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[2] || crcArray[1] != response[3]) {
			Log.d("CHECK CORRECTION",
					"ChangeTimingParametersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseChangeTimingParametersResponseData(int[] response,
			ReaderManager manager) {

		int requestSuccessfull = response[1];
		manager.parsedChangeTimingParametersResponse(requestSuccessfull);
	}

	// --------------------------------------------------------------------------------------

	// ----------------------READ-SENSOR-GLUCOSE-RESPONSE-0x88------------------------------

	// correction check
	public static boolean isReadSensorGlucoseResponseCorrect(int[] response) {

		if (response.length != 20) {
			Log.d("CHECK CORRECTION",
					"ReadSensorGlucoseResponse length not good!");
			return false;
		}

		int[] data = new int[18];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[18] || crcArray[1] != response[19]) {
			Log.d("CHECK CORRECTION",
					"ReadSensorGlucoseResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ------------------READ-SINGLE-SENSOR-GLUCOSE-RECORD-RESPONSE-0x89-----------------------

	// correction check
	private static boolean isReadSingleSensorGlucoseDataRecordResponseCorrect(
			int[] response) {

		if (response.length != 13) {
			Log.d("CHECK CORRECTION",
					"ReadSingleSensorGlucoseDataRecordResponse length not good!");
			return false;
		}

		int[] data = new int[11];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[11] || crcArray[1] != response[12]) {
			Log.d("CHECK CORRECTION",
					"ReadSingleSensorGlucoseDataRecordResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadSingleSensorGlucoseDataRecordResponseData(
			int[] response, ReaderManager manager) {

		int glucoseRecordNumber = response[1] | (response[2] << 8)
				| (response[3] << 16);
		int[] date = BinaryOperations.calculateDateFromBytes(new int[] {
				response[4], response[5] });
		int[] time = BinaryOperations.calculateTimeFromBytes(new int[] {
				response[6], response[7] });
		int value = response[8] | (response[9] << 8);
		int sensorGlucoseAlertFlags = response[10];

		manager.parsedReadSingleSensorGlucoseDataRecordResponseData(
				glucoseRecordNumber, date, time, value, sensorGlucoseAlertFlags);

	}

	// ------------------READ-ALL-SENSOR-GLUCOSE-RECORD-RESPONSE-0xF0-----------------------

	// correction check
	public static boolean isReadAllSensorGlucoseDataRecordResponseCorrect(
			int[] response) {

		if (response.length != 13) {
			Log.d("CHECK CORRECTION",
					"ReadAllSensorGlucoseDataRecordResponse length not good!");
			return false;
		}

		int[] data = new int[11];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[11] || crcArray[1] != response[12]) {
			Log.d("CHECK CORRECTION",
					"ReadAllSensorGlucoseDataRecordResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ------------------READ-FIRST-N-LAST-SENSOR-GLUCOSE-NUMBERS-RESPONSE-0x8E-----------------------

	// correction check
	public static boolean isReadFirstAndLastSensorGlucoseRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 9) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastSensorGlucoseRecordNumbersResponse length not good!");
			return false;
		}

		int[] data = new int[7];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[7] || crcArray[1] != response[8]) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastSensorGlucoseRecordNumbersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// --------------------------------------------------------------------------------------

	// -----------------READ-SENSOR-GLUCOSE-ALERTS-N-STATUS-RESPONSE-0x90--------------------

	// correction check
	public static boolean isReadSensorGlucoseAlertsAndStatusResponseCorrect(
			int[] response) {

		if (response.length != 14) {
			Log.d("CHECK CORRECTION",
					"ReadSensorGlucoseAlertsAndStatusResponse length not good!");
			return false;
		}

		int[] data = new int[12];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[12] || crcArray[1] != response[13]) {
			Log.d("CHECK CORRECTION",
					"ReadSensorGlucoseAlertsAndStatusResponse CRC not matching");
			return false;
		}

		return true;

	}

	// -----------------READ-SENSOR-GLUCOSE-ALERTS-N-STATUS-RESPONSE-0x91--------------------

	// correction check
	private static boolean isReadSingleSensorGlucoseAlertRecordResponseCorrect(
			int[] response) {

		if (response.length != 16) {
			Log.d("CHECK CORRECTION",
					"ReadSingleSensorGlucoseAlertRecordResponse length not good!");
			return false;
		}

		int[] data = new int[14];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[14] || crcArray[1] != response[15]) {
			Log.d("CHECK CORRECTION",
					"ReadSingleSensorGlucoseAlertRecordResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadSingleSensorGlucoseAlertRecordResponseData(
			int[] response, ReaderManager manager) {

		int sensorGlucoseAlertRecordNr = response[1] | (response[2] << 8);
		int[] date = new int[] { response[3], response[4] };
		int[] time = new int[] { response[5], response[6] };
		int sensorGlucoseAlertLogRecordType = response[7];
		int sensorGlucoseValue = response[8] | (response[9] << 8);
		int sensorGlucoseRateValue = response[10] | (response[11] << 8);
		int alertThresholdOrTimInterval = response[12] | (response[13] << 8);

		manager.parsedReadSingleSensorGlucoseAlertRecordResponse(
				sensorGlucoseAlertRecordNr, date, time,
				sensorGlucoseAlertLogRecordType, sensorGlucoseValue,
				sensorGlucoseRateValue, alertThresholdOrTimInterval);
	}

	// ---------------READ-FIRST-N-LAST-GLUCOSE-ALERTS-RECORD-NR-RESPONSE-0x92-----------------

	// correction check
	public static boolean isReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponse length not good!");
			return false;
		}

		int[] data = new int[5];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ---------------READ-GLUCOSE-ALERTS-IN-SPEC-RANGE-RESPONSE-0xF1-----------------

	// correction check
	public static boolean isReadAllSensorGlucoseAlertsInSpecifiedRangeResponseCorrect(
			int[] response) {

		if (response.length != 16) {
//			Log.d("CHECK CORRECTION",
//					"ReadAllSensorGlucoseAlertsInSpecifiedRangeResponse length not good!");
			return false;
		}

		int[] data = new int[14];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[14] || crcArray[1] != response[15]) {
			Log.d("CHECK CORRECTION",
					"ReadAllSensorGlucoseAlertsInSpecifiedRangeResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ---------------ASSERT-SNOOZE-AGAINST-ALARM-0x94-----------------

	// correction check
	private static boolean isAssertSnoozeAgainsAlarmResponseCorrect(
			int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"ReadAllSensorGlucoseAlertsInSpecifiedRangeResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"ReadAllSensorGlucoseAlertsInSpecifiedRangeResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no parse data needed for this response

	// ------------------------------------------------------------------

	// --------------SEND-BLOOD-GLUCOSE-DATA-RESPONSE-0x95---------------

	// correction check
	private static boolean isSendBloodGlucoseDataResponseCorrect(int[] response) {

		if (response.length != 4) {
			Log.d("CHECK CORRECTION",
					"SendBloodGlucoseDataResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[2] || crcArray[1] != response[3]) {
			Log.d("CHECK CORRECTION",
					"SendBloodGlucoseDataResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseSendBloodGlucoseDataResponseData(int[] response,
			ReaderManager manager) {

		int calibrationUseFlags = response[1];

		manager.parsedSendBloodGlucoseDataResponse(calibrationUseFlags);
	}

	// --------------READ-SINGLE-BLOOD-GLUCOSE-RESPONSE-0x96---------------

	// correction check
	private static boolean isReadSingleBloodGlucoseDataRecordResponseCorrect(
			int[] response) {

		if (response.length != 17) {
			Log.d("CHECK CORRECTION",
					"ReadSingleBloodGlucoseDataRecordResponse length not good!");
			return false;
		}

		int[] data = new int[15];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[15] || crcArray[1] != response[16]) {
			Log.d("CHECK CORRECTION",
					"ReadSingleBloodGlucoseDataRecordResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseReadSingleBloodGlucoseDataRecordResponseData(
			int[] response, ReaderManager manager) {

		int recordNr = response[1] | (response[2] << 8);
		int[] date = new int[] { response[3], response[4] };
		int[] time = new int[] { response[5], response[6] };
		int bloodGlucoseValue = response[7] | (response[8] << 8);
		int meterIdentifier = response[9] | (response[10] << 8);
		int calUseFlags = response[11];
		int closestEntryRecordNr = response[12] | (response[13] << 8)
				| (response[14] << 16);

		manager.parsedReadSingleBloodGlucoseDataRecordResponse(recordNr, date,
				time, bloodGlucoseValue, meterIdentifier, calUseFlags,
				closestEntryRecordNr);
	}

	// --------------READ-SINGLE-BLOOD-GLUCOSE-RESPONSE-0x97---------------

	// correction check
	public static boolean isReadFirstAndLastBloodGlucoseDataRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastBloodGlucoseDataRecordNumbersResponse length not good!");
			return false;
		}

		int[] data = new int[5];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastBloodGlucoseDataRecordNumbersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// --------------READ-LOG-OF-BLOOD-GLUCOSE-IN-RANGE-RESPONSE-0xF2---------------

	// correction check
	public static boolean isReadLogOfBloodGlucoseDataInSpecifiedRangeResponseCorrect(
			int[] response) {

		if (response.length != 17) {
//			Log.d("CHECK CORRECTION",
//					"ReadLogOfBloodGlucoseDataInSpecifiedRangeResponse length not good!");
			return false;
		}

		int[] data = new int[15];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[15] || crcArray[1] != response[16]) {
			Log.d("CHECK CORRECTION",
					"ReadLogOfBloodGlucoseDataInSpecifiedRangeResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ---------------WRITE-PATIENT-EVENT-RESPONSE-0x9A-----------------

	// correction check
	public static boolean isWritePatientEventResponseCorrect(int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"WritePatientEventResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"WritePatientEventResponse CRC not matching");
			return false;
		}

		return true;

	}

	// -------------------READ-SINGLE-PATIENT-EVENT-0x9B--------------------

	// correction check
	private static boolean isReadSinglePatientEventResponseCorrect(
			int[] response) {

		if (response.length != 15) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse length not good!");
			return false;
		}

		int[] data = new int[13];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[13] || crcArray[1] != response[14]) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseReadSinglePatientEventResponseData(int[] response,
			ReaderManager manager) {

		int recordNr = response[1] | (response[2] << 8);
		int[] date = new int[] { response[3], response[4] };
		int[] time = new int[] { response[5], response[6] };
		int eventTypeId = response[7];
		int eventSubtypeId = response[8] | (response[9] << 8);
		int eventSubtypeQ = response[10] | (response[11] << 8);
		int textLength = response[12];

		manager.parsedReadSinglePatientEventResponse(recordNr, date, time,
				eventTypeId, eventSubtypeId, eventSubtypeQ, textLength);

	}

	// -------------------READ-FIRST-N-LAST-PATIENT-EVENT-REC-NR-0x9C--------------------

	// correction check
	private static boolean isReadFirstAndLastPatientEventRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse length not good!");
			return false;
		}

		int[] data = new int[5];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse CRC not matching");
			return false;
		}

		return true;

	}
	// -------------------MARK-EVENT-AS-DELETED-RESPONSE-0x9D--------------------

	// correction check
	private static boolean isMarkPatientEventRecordAsDeletedResponseCorrect(
			int[] response) {

		if (response.length != 5) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse length not good!");
			return false;
		}

		int[] data = new int[3];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[3] || crcArray[1] != response[4]) {
			Log.d("CHECK CORRECTION",
					"ReadSinglePatientEventResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseMarkPatientEventRecordAsDeletedResponseData(
			int[] response, ReaderManager manager) {

		int deletedRecordNr = response[1] | (response[2] << 8);

		manager.parsedMarkPatientEventRecordAsDeletedResponse(deletedRecordNr);

	}

	// -------------------READ-PATIENT-EVENTS-IN-RANGE-0xF3--------------------

	// correction check
	public static boolean isReadLogOfPatientEventsInSpecifiedRangeResponseCorrect(
			int[] response) {

		if (response.length != 15) {
//			Log.d("CHECK CORRECTION",
//					"ReadLogOfPatientEventsInSpecifiedRangeResponse length not good!");
			return false;
		}

		int[] data = new int[13];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[13] || crcArray[1] != response[14]) {
			Log.d("CHECK CORRECTION",
					"ReadLogOfPatientEventsInSpecifiedRangeResponse CRC not matching");
			return false;
		}

		return true;

	}

	// -------------------READ-SINGLE-MISC-EVENT-LOG-0xA2--------------------

	// correction check
	private static boolean isReadSingleMiscEventLogResponseCorrect(
			int[] response) {

		if (response.length != 19) {
			Log.d("CHECK CORRECTION",
					"ReadSingleMiscEventLogResponse length not good!");
			return false;
		}

		int[] data = new int[17];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[17] || crcArray[1] != response[18]) {
			Log.d("CHECK CORRECTION",
					"ReadSingleMiscEventLogResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseReadSingleMiscEventLogResponseData(int[] response,
			ReaderManager manager) {

		int recordNr = response[1] | (response[2] << 8);
		int[] date = new int[] { response[3], response[4] };
		int[] time = new int[] { response[5], response[6] };
		int miscEventType = response[7] | (response[8] << 8);
		int[] eventAddtitionalInfo = new int[8];

		for (int i = 0; i <= 8; i++) {
			eventAddtitionalInfo[i] = response[i + 9];
		}

		manager.parsedReadSingleMiscEventLogResponse(recordNr, date, time,
				miscEventType, eventAddtitionalInfo);

	}

	// -------------------READ-FIRST-N-LAST-MISC-EVENT-REC-NR-0xA3--------------------

	// correction check
	private static boolean isReadFirstAndLastMiscEventLogRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastMiscEventLogRecordNumbersResponse length not good!");
			return false;
		}

		int[] data = new int[5];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastMiscEventLogRecordNumbersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseReadFirstAndLastMiscEventLogRecordNumbersResponseData(
			int[] response, ReaderManager manager) {

		int firstRecordNr = response[1] | (response[2] << 8);
		int lastRecordNr = response[3] | (response[4] << 8);

		manager.parsedReadFirstAndLastMiscEventLogRecordNumbersResponse(
				firstRecordNr, lastRecordNr);

	}

	// ---------------WRITE-SINGLE-MISC-EVENT-RESPONSE-0xA4-----------------

	// correction check
	private static boolean isWriteSingleMiscEventLogRecordResponseCorrect(
			int[] response) {

		if (response.length != 3) {
			Log.d("CHECK CORRECTION",
					"WriteSingleMiscEventLogRecordResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[1] || crcArray[1] != response[2]) {
			Log.d("CHECK CORRECTION",
					"WriteSingleMiscEventLogRecordResponse CRC not matching");
			return false;
		}

		return true;

	}

	// no parse data needed for this response

	// --------------------------------------------------------------------------------------

	// -------------------READ-FIRST-N-LAST-ERROR-LOG-REC-NR-0xA3--------------------

	// correction check
	private static boolean isReadFirstAndLastErrorLogRecordNumbersResponseCorrect(
			int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastErrorLogRecordNumbersResponse length not good!");
			return false;
		}

		int[] data = new int[5];

		for (int i = 0; i < response.length - 2; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadFirstAndLastErrorLogRecordNumbersResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data

	private static void parseReadFirstAndLastErrorLogRecordNumbersResponseData(
			int[] response, ReaderManager manager) {

		int firstRecordNr = response[1] | (response[2] << 8);
		int lastRecordNr = response[3] | (response[4] << 8);

		manager.parsedReadFirstAndLastErrorLogRecordNumbersResponse(
				firstRecordNr, lastRecordNr);

	}

	// --------------------------------------------------------------------------------------

	// -------------------READ-1-BYTE-REGISTER-RESPONSE-0xAA-------------------

	public static boolean isReadSingleByteSerialFlashRegisterResponseCorrect(int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"ReadSingleByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"ReadSingleByteSerialFlashRegisterResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadSingleByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int data = response[4];
		int[] address = new int[] { response[3], response[2], response[1] };
		manager.parsedReadSingleByteSerialFlashRegisterResponse(data, address);
	}

	// -------------------WRITE-1-BYTE-REGISTER-RESPONSE-0xAB-------------------

	public static boolean isWriteSingleByteSerialFlashRegisterResponseCorrect(
            int[] response) {

		if (response.length != 7) {
			Log.d("CHECK CORRECTION",
					"WriteSingleByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[5] || crcArray[1] != response[6]) {
			Log.d("CHECK CORRECTION",
					"WriteSingleByteSerialFlashRegisterResponse CRC not matching");
			return false;
		}

		return true;

	}

	// ---------------READ-2-BYTE-REGISTER-RESPONSE-0xAC--------------------

	public static boolean isReadTwoByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		if (response.length != 8) {
			Log.d("CHECK CORRECTION",
					"ReadTwoByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4], response[5] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[6] || crcArray[1] != response[7]) {
			Log.d("CHECK CORRECTION",
					"ReadTwoByteSerialFlashRegisterResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadTwoByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int[] data = new int[] { response[4], response[5] };
		int[] address = new int[] { response[3], response[2], response[1] };
		manager.parsedReadTwoByteSerialFlashRegisterResponse(data, address);
	}

	// ---------------WRITE-2-BYTE-REGISTER-RESPONSE-0xAD--------------------

	private static boolean isWriteTwoByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		if (response.length != 8) {
			Log.d("CHECK CORRECTION",
					"WriteTwoByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4], response[5] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[6] || crcArray[1] != response[7]) {
			Log.d("CHECK CORRECTION",
					"WriteTwoByteSerialFlashRegisterResponse CRC not matching");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseWriteTwoByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int[] data = new int[] { response[4], response[5] };
		int[] address = new int[] { response[3], response[2], response[1] };

		manager.parsedWriteTwoByteSerialFlashRegisterResponse(data, address);

	}

	// ---------------READ-4-BYTE-REGISTER-RESPONSE-0xAE--------------------

	public static boolean isReadFourByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		if (response.length != 10) {
			Log.d("CHECK CORRECTION",
					"ReadFourByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4], response[5], response[6], response[7] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[8] || crcArray[1] != response[9]) {
			return false;
		}

		return true;

	}

	// ---------------WRITE-4-BYTE-REGISTER-RESPONSE-0xAF--------------------

	private static boolean isWriteFourByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		if (response.length != 10) {
			Log.d("CHECK CORRECTION",
					"WriteFourByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[] { response[0], response[1], response[2],
				response[3], response[4], response[5], response[6], response[7] };

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[8] || crcArray[1] != response[9]) {
			Log.d("CHECK CORRECTION",
					"WriteFourByteSerialFlashRegisterResponse CRC not good!");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseWriteFourByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int[] data = new int[] { response[4], response[5], response[6],
				response[7] };
		int[] address = new int[] { response[3], response[2], response[1] };

		manager.parsedWriteFourByteSerialFlashRegisterResponse(data, address);

	}

	// ---------------WRITE-N-BYTE-REGISTER-RESPONSE-0xB1--------------------

	private static boolean isWriteNByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		if (response.length != 8) {
			Log.d("CHECK CORRECTION",
					"WriteNByteSerialFlashRegisterResponse length not good!");
			return false;
		}

		int[] data = new int[6];

		for (int i = 0; i < data.length; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[6] || crcArray[1] != response[7]) {
			Log.d("CHECK CORRECTION",
					"WriteNByteSerialFlashRegisterResponse CRC not good!");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseWriteNByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int[] address = new int[] { response[1], response[2], response[3] };
		int n = response[4] | (response[5] << 8);

		manager.parsedWriteNByteSerialFlashRegisterResponse(address, n);
	}

	// ---------------READ-N-BYTE-REGISTER-RESPONSE-0xB0--------------------

	private static boolean isReadNByteSerialFlashRegisterResponseCorrect(
			int[] response) {

		int n = response[4] | (response[5] << 8);

		int[] data = new int[n + 6];

		for (int i = 0; i < data.length; i++) {
			data[i] = response[i];
		}

		int crc = BinaryOperations.GenerateChecksumCRC16(data);
		int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

		if (crcArray[0] != response[n + 7] || crcArray[1] != response[n + 8]) {
			Log.d("CHECK CORRECTION",
					"ReadNByteSerialFlashRegisterResponse CRC not good!");
			return false;
		}

		return true;

	}

	// parse data
	private static void parseReadNByteSerialFlashRegisterResponseData(
			int[] response, ReaderManager manager) {

		int[] address = new int[] { response[1], response[2], response[3] };
		int n = response[4] | (response[5] << 8);
		int[] values = new int[n];

		for (int i = 0; i <= n; i++) {
			values[i] = response[i + 6];
		}

		manager.parsedReadNByteSerialFlashRegisterResponse(address, n, values);

	}

}
