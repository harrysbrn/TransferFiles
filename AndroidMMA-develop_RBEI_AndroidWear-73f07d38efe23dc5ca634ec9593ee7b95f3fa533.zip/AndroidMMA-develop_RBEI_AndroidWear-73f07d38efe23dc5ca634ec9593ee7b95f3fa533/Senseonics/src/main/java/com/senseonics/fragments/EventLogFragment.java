package com.senseonics.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Notification;
import com.senseonics.util.NotificationsAdapter;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class EventLogFragment extends NotificationsFragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
        super.onCreateView(inflater,container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_event_log, null);

		initView(view);

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();

		/** #3664 */
		if (getActivity() instanceof MainActivity) {
			((MainActivity) getActivity()).refreshAfterFragmentChanged();
		}
	}

	@Override
	public OnItemClickListener getOnItemClickListener(
			final NotificationsAdapter adapter) {

		return new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				Notification notification = (Notification) adapter
						.getItem(position);
				Utils.showEventDetails(EventLogFragment.this,
						notification.getEventPoint());
			}
		};
	}

	protected ArrayList<Notification> addSelection() {
		ArrayList<Notification> selection = new ArrayList<Notification>();
		if (selections.size() == 0)
			selection.addAll(getAll());
		else {
			if (selections.contains(GROUP_1))
				selection.addAll(list1);
			if (selections.contains(GROUP_2))
				selection.addAll(list2);
			if (selections.contains(GROUP_3))
				selection.addAll(list3);
			if (selections.contains(GROUP_4))
				selection.addAll(list4);
			if (selections.contains(GROUP_5))
				selection.addAll(list5);
		}
		Collections.sort(selection, new Comparator<Notification>() {

			@Override
			public int compare(Notification lhs, Notification rhs) {
                long timestampeRHS = rhs.getTimestamp();
                long timestampeLHS = lhs.getTimestamp();

                if (timestampeRHS - timestampeLHS > 0) {
                    return 1;
                }
                else if (timestampeRHS - timestampeLHS < 0) {
                    return -1;
                }
                else {
                    return 0;
                }
			}
		});

		if (selection.size() == 0) {
			noStatisticsLayout.setVisibility(View.VISIBLE);
		} else {
			noStatisticsLayout.setVisibility(View.GONE);
		}

		return selection;
	}

	protected ArrayList<Notification> getAll() {
		ArrayList<Notification> selection = new ArrayList<Notification>();
		selection.addAll(list1);
		selection.addAll(list2);
		selection.addAll(list3);
		selection.addAll(list4);
		selection.addAll(list5);

		Collections.sort(selection, new Comparator<Notification>() {

			@Override
			public int compare(Notification lhs, Notification rhs) {
                long timestampeRHS = rhs.getTimestamp();
                long timestampeLHS = lhs.getTimestamp();

                if (timestampeRHS - timestampeLHS > 0) {
                    return 1;
                }
                else if (timestampeRHS - timestampeLHS < 0) {
                    return -1;
                }
                else {
                    return 0;
                }
			}
		});

		if (selection.size() == 0) {
			noStatisticsLayout.setVisibility(View.VISIBLE);
		} else {
			noStatisticsLayout.setVisibility(View.GONE);
		}
		return selection;
	}

	@Override
	public void initData() {

		boolean onlyNotHiddenNotifications = true;
		list1 = getList(
				Arrays.asList(EVENT_TYPE.GLUCOSE_EVENT, EVENT_TYPE.CALIBRATION),
				GROUP_1, false, onlyNotHiddenNotifications);
		list2 = getList(Arrays.asList(EVENT_TYPE.MEAL_EVENT), GROUP_2, false,
				onlyNotHiddenNotifications);
		list3 = getList(Arrays.asList(EVENT_TYPE.INSULIN_EVENT), GROUP_3,
				false, onlyNotHiddenNotifications);
		list4 = getList(Arrays.asList(EVENT_TYPE.HEALTH_EVENT), GROUP_4, false,
				onlyNotHiddenNotifications);
		list5 = getList(Arrays.asList(EVENT_TYPE.EXERCISE_EVENT), GROUP_5,
				false, onlyNotHiddenNotifications);
		adapter.setNotifications(addSelection());
		adapter.notifyDataSetChanged();
	}
}