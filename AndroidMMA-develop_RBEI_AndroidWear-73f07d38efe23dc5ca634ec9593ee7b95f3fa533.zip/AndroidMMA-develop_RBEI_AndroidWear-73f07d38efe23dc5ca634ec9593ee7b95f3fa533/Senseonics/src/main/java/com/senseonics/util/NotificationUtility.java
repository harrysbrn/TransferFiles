package com.senseonics.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

import static com.senseonics.gen12androidapp.Constants.BLUETOOTH_SERVICE_ID;
import static com.senseonics.gen12androidapp.R.string.connected;

@Singleton public class NotificationUtility {
  private boolean shouldPreventUserClearAll = false;
  private Context context;
  private AccountConstants accountConstants;
  private NotificationManager notificationManager;
  private AlarmRingtoneManager alarmRingtoneManager;
  private EventBus eventBus;
  private final int NOTIFICATION_ID_TEMP_PROFILE_TURNED_OFF =
      Utils.TransmitterMessageCode.NumberOfMessages.notificationId() + 11;
  private Transmitter.CONNECTION_STATE connection_state;
  private Intent previousIntent;

  @Inject public NotificationUtility(Context context, NotificationManager notificationManager,
                                     AlarmRingtoneManager alarmRingtoneManager, AccountConstants accountConstants, EventBus eventBus) {
    this.context = context;
    this.notificationManager = notificationManager;
    this.alarmRingtoneManager = alarmRingtoneManager;
    this.accountConstants = accountConstants;
    this.eventBus = eventBus;
    this.eventBus.register(this);
    this.connection_state = Transmitter.CONNECTION_STATE.DISCONNECTED;
  }

  public void createTempProfileTurnedOffNotification() {
    String title = context.getString(R.string.temp_profile_turned_off_title);
    String text = context.getString(R.string.temp_profile_turned_off_body);
    int iconId = R.drawable.ic_icon_eversense_check_white;

    sendNotification(MainActivity.class, iconId, title, text, PendingIntent.FLAG_UPDATE_CURRENT,
        NOTIFICATION_ID_TEMP_PROFILE_TURNED_OFF);
  }

  public void createNotificationFromEvent(Utils.TransmitterMessageCode notificationEventType,
      Object... messageArguments) {

    int titleId = Utils.getNotificationDialogTypeStringId(notificationEventType);
    String title = "";
    if (titleId > 0) {
      title = context.getString(titleId);
    }
    int textId = Utils.getNotificationDialogMessageTitleStringId(notificationEventType);
    String text = "";
    if (textId > 0) {
      text = context.getString(textId, messageArguments);
    }

    int iconId = Utils.getNotificationWhiteIcon(notificationEventType);

    sendNotification(MainActivity.class, iconId, title, text, PendingIntent.FLAG_UPDATE_CURRENT,
        notificationEventType.notificationId());
  }

  public void cancelNotification(Utils.TransmitterMessageCode notificationEventType) {
    notificationManager.cancel(notificationEventType.notificationId());
  }

  private void sendNotification(Class<? extends Activity> activityClass, int iconResId,
      String title, String message, int flags, int notificationID) {
    NotificationCompat.Builder builder =
        new NotificationCompat.Builder(context).setSmallIcon(iconResId)
            .setAutoCancel(true)
            .setContentTitle(title);

    addDefaultVibrateLight(builder);

    builder.setContentText(message);
    builder.setTicker(message);
    builder.setWhen(System.currentTimeMillis());
    builder.setOngoing(shouldPreventUserClearAll);

    Intent notificationIntent = new Intent(context, activityClass);
    notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

    PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, flags);
    builder.setContentIntent(pendingIntent);

    android.app.Notification notification = builder.build();

    /** Customize the sound */
    Uri notifUri;
    if (notificationID == Utils.TransmitterMessageCode.LowGlucoseAlarm.ordinal()) {
      notifUri = alarmRingtoneManager.getUriforRingtone(alarmRingtoneManager.getDayLowAlarmSound());
    } else if (notificationID == Utils.TransmitterMessageCode.HighGlucoseAlarm.ordinal()) {
      notifUri =
          alarmRingtoneManager.getUriforRingtone(alarmRingtoneManager.getDayHighAlarmSound());
    } else {
      notifUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    }
    notification.sound = notifUri;

    notificationManager.notify(notificationID, notification);
  }

  private void addDefaultVibrateLight(NotificationCompat.Builder mBuilder) {
    mBuilder.setDefaults(
        android.app.Notification.DEFAULT_VIBRATE | android.app.Notification.DEFAULT_LIGHTS);
  }

  private android.app.Notification getForegroundServiceNotification(int stringID) {
    Intent nIntent = new Intent();
    nIntent = getPreviousIntent(nIntent);
    PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, nIntent, 0);

    return new NotificationCompat.Builder(context).setSmallIcon(R.drawable.ic_icon_eversense_check_white)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(stringID))
            .setTicker(context.getString(stringID))
            .setContentIntent(pendingIntent) /** #3796 */
            .build();
  }

  private android.app.Notification getForegroundServiceNotification_Connected() {
    return getForegroundServiceNotification(connected);
  }

  private android.app.Notification getForegroundServiceNotification_Disconnected() {
    return getForegroundServiceNotification(R.string.no_transmitter_connected);
  }

  public android.app.Notification getForegroundServiceNotification() {
    if (connection_state == Transmitter.CONNECTION_STATE.CONNECTED) {
      return getForegroundServiceNotification_Connected();
    }
    else {
      return getForegroundServiceNotification_Disconnected();
    }
  }

  public void onEvent(TransmitterConnectionEvent event) {
    Transmitter.CONNECTION_STATE newState = event.getTransmitter().getConnectionState();
    if (newState != Transmitter.CONNECTION_STATE.CONNECTED) {
      newState = Transmitter.CONNECTION_STATE.DISCONNECTED;
    }

    boolean needNotify = false;
    if (connection_state != newState) {
      needNotify = true;
    }
    connection_state = newState;

    if (needNotify) {
      notificationManager.notify(BLUETOOTH_SERVICE_ID, getForegroundServiceNotification());
    }
  }

  /** http://stackoverflow.com/questions/26904705/android-displaying-multiple-activity-in-saved-state-when-notification-click */
  private Intent getPreviousIntent(Intent newIntent) {
    final ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
    final List<ActivityManager.RecentTaskInfo> recentTaskInfos = am.getRecentTasks(1024,0);
    String myPkgNm = context.getPackageName();
    boolean foundMatching = false;

    if (!recentTaskInfos.isEmpty()) {
      ActivityManager.RecentTaskInfo recentTaskInfo;
      for (int i = 0; i < recentTaskInfos.size(); i++) {
        recentTaskInfo = recentTaskInfos.get(i);
        if (recentTaskInfo.baseIntent.getComponent().getPackageName().equals(myPkgNm)) {
          foundMatching = true;
          newIntent = recentTaskInfo.baseIntent;
          newIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
      }
    }

    if (foundMatching) {
      previousIntent = newIntent;
    }

    return previousIntent;
  }
}
