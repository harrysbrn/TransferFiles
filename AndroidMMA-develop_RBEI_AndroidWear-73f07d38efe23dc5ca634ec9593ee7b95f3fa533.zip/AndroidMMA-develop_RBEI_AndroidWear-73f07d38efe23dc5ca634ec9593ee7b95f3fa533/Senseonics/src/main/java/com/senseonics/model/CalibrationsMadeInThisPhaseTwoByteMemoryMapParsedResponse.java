package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class CalibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public CalibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.calibrationsMadeInThisPhaseAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        model.setCalibrationsMadeInThisPhase(dataOne | (dataTwo << 8));
    }
}
