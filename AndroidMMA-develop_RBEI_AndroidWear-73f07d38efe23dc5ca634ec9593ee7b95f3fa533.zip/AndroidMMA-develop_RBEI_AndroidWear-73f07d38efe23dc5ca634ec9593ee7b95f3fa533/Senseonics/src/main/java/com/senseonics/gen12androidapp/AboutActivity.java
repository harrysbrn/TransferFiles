package com.senseonics.gen12androidapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.senseonics.fragments.AboutFragment;

public class AboutActivity extends BaseActivity {

	private AboutFragment aboutFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_simple_fragment, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.about);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);
		
		aboutFragment = new AboutFragment();

		getFragmentManager().beginTransaction()
				.replace(R.id.fragment, aboutFragment)
				.commitAllowingStateLoss();
	}

	@Override
	public void highPriorityRequestFinished() {
		super.highPriorityRequestFinished();
		if (aboutFragment != null)
			aboutFragment.hideProgressDialog();
	}

	@Override
	public void connectionStateChanged() {
		super.connectionStateChanged();
		if (aboutFragment != null){
			aboutFragment.initViews();
		}
	}
}
