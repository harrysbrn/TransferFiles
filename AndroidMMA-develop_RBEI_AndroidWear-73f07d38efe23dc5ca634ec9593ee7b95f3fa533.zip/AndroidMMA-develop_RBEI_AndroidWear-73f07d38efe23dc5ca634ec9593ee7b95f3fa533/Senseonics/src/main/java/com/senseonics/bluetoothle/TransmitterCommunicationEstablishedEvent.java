package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;

public class TransmitterCommunicationEstablishedEvent {
    private final BluetoothGattCharacteristic commandCharacteristic;
    private BluetoothGatt bluetoothGatt;
    private Transmitter transmitter;

    public TransmitterCommunicationEstablishedEvent(BluetoothGattCharacteristic commandCharacteristic, BluetoothGatt bluetoothGatt, Transmitter transmitter) {
        this.commandCharacteristic = commandCharacteristic;
        this.bluetoothGatt = bluetoothGatt;
        this.transmitter = transmitter;
    }

    public BluetoothGattCharacteristic getCommandCharacteristic() {
        return commandCharacteristic;
    }

    public BluetoothGatt getBluetoothGatt() {
        return bluetoothGatt;
    }

    public Transmitter getTransmitter() {
        return transmitter;
    }
}
