package com.senseonics.model.StateModelUpload;

public class DMSStateModelTransmitterInfo {
    private String TxID; // *
    private String TxName;
    private String TxAddress; // ""
    private DMSStateModelUserInfo UserInfo;
    private String TxModel;
    private String TxSoftwareVersion;
    private String TxSoftwareVersionExt; // always ""
    private int AlgoFormatVersion;
    private String DateOfCurrentCalibrationPhase;
    private String LastCriticalFault;
    private String CurrentCalibrationPhase;
    private int SamplingInterval;
    private boolean TxActive;

    public DMSStateModelTransmitterInfo(
            String txID,
            String txName,
            String txAddress,
            DMSStateModelUserInfo userInfo,
            String txModel,
            String txSoftwareVersion,
            String txSoftwareVersionExt,
            int algoFormatVersion,
            String dateOfCurrentCalibrationPhase,
            String lastCriticalFault,
            String currentCalibrationPhase,
            int samplingInterval,
            boolean txActive
    ) {
        AlgoFormatVersion = algoFormatVersion;
        CurrentCalibrationPhase = currentCalibrationPhase;
        DateOfCurrentCalibrationPhase = dateOfCurrentCalibrationPhase;
        LastCriticalFault = lastCriticalFault;
        SamplingInterval = samplingInterval;
        TxActive = txActive;
        TxAddress = txAddress;
        TxID = txID;
        TxModel = txModel;
        TxName = txName;
        TxSoftwareVersion = txSoftwareVersion;
        TxSoftwareVersionExt = txSoftwareVersionExt;
        UserInfo = userInfo;
    }

    public int getAlgoFormatVersion() {
        return AlgoFormatVersion;
    }

    public String getCurrentCalibrationPhase() {
        return CurrentCalibrationPhase;
    }

    public String getDateOfCurrentCalibrationPhase() {
        return DateOfCurrentCalibrationPhase;
    }

    public String getLastCriticalFault() {
        return LastCriticalFault;
    }

    public int getSamplingInterval() {
        return SamplingInterval;
    }

    public boolean isTxActive() {
        return TxActive;
    }

    public String getTxAddress() {
        return TxAddress;
    }

    public String getTxID() {
        return TxID;
    }

    public String getTxModel() {
        return TxModel;
    }

    public String getTxName() {
        return TxName;
    }

    public String getTxSoftwareVersion() {
        return TxSoftwareVersion;
    }

    public String getTxSoftwareVersionExt() {
        return TxSoftwareVersionExt;
    }

    public DMSStateModelUserInfo getUserInfo() {
        return UserInfo;
    }
}
