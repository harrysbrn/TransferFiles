package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.db.DatabaseManager;
import com.senseonics.graph.util.Glucose;
import com.senseonics.util.StaleDataChecker;
import com.senseonics.util.Utils;

import java.util.Calendar;

import javax.inject.Inject;

public class GlucoseLevelParsedResponse implements ParsedResponse {


    private DatabaseManager databaseManager;

    @Inject
    public GlucoseLevelParsedResponse(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadSensorGlucoseResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadSensorGlucoseResponseCorrect(data);
    }

    @Override
    public void apply(int[] response, TransmitterStateModel model) {

        int glucoseRecordNr = response[1] | (response[2] << 8) | (response[3] << 16);
        int[] date = BinaryOperations
                .calculateDateFromBytes(new int[]{response[4], response[5]});
        int[] time = BinaryOperations
                .calculateTimeFromBytes(new int[]{response[6], response[7]});
        int sensorGlucoseUnits = response[8];
        int sensorGlucoseValue = response[9] | (response[10] << 8);
        int sensorGlucoseTrend = response[11] | (response[12] << 8);
        int sensorGlucoseTrendDirection = response[13];
        int glucoseAlarmFlags = response[14];
        int glucoseAlertFlags = response[15];
        int sensorFieldCurrent = response[16] | (response[17] << 8);

        int year = date[0];
        int month = date[1];
        int day = date[2];
        int hour = time[0];
        int minute = time[1];
        int second = time[2];

        final Calendar calendar = Utils.getGMTCalendarFrom(date, time);
        long calendarTimestamp = calendar.getTimeInMillis();

        if (databaseManager.allowAddingGlucoseReading(calendarTimestamp, glucoseRecordNr)) {
            /** #3194 */
            databaseManager.addReadingInGMT(new Glucose(calendarTimestamp, sensorGlucoseValue, -1, glucoseRecordNr, model.getRawDataValues()));
        }

        // set the glucose timestamp
        model.setGlucoseTimestamp(calendar);

        // set the glucose value in the model
                // set the trend value in the model
        Utils.ARROW_TYPE arrowType = Utils.ARROW_TYPE.STALE;
        switch (sensorGlucoseTrendDirection) {
            case 0:
                arrowType = Utils.ARROW_TYPE.STALE;
                break;
            case 1: // 90 degrees down
                arrowType = Utils.ARROW_TYPE.FALLING_FAST;
                break;
            case 2: // 45 degrees down
                arrowType = Utils.ARROW_TYPE.FALLING;
                break;
            case 4:
                arrowType = Utils.ARROW_TYPE.FLAT;
                break;
            case 8: // 45 degrees up
                arrowType = Utils.ARROW_TYPE.RISING;
                break;
            case 16: // 90 degrees up
                arrowType = Utils.ARROW_TYPE.RISING_FAST;
                break;
        }

        /** #3860 */
        StaleDataChecker checker = new StaleDataChecker(model.getGlucoseTimestamp(), model.getSamplingIntervalInSeconds());
        boolean flagStale = checker.isStaleData();

        if (flagStale) {
            arrowType = Utils.ARROW_TYPE.STALE;
        }

        if ((sensorGlucoseValue >= Utils.GLUCOSE_VALID_MIN
                && sensorGlucoseValue <= Utils.GLUCOSE_VALID_MAX)
                && !flagStale) {
            model.setGlucoseLevel(sensorGlucoseValue);
        } else {
            model.setGlucoseLevel(Utils.GLUCOSE_LEVEL_UNKNOWN);
        }

        model.setGlucoseTrendDirection(arrowType);

        /** Increment the max synced record if needed */
        if (glucoseRecordNr == (model.getMaxSyncedSensorRecord() + 1)) {
            model.setMaxSyncedSensorRecord(glucoseRecordNr);
        }
    }
}
