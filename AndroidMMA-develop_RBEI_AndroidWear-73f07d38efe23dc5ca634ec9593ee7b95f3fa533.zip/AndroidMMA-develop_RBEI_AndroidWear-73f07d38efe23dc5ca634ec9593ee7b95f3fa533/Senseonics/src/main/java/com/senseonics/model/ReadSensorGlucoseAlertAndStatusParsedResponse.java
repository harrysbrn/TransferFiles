package com.senseonics.model;

import android.util.Log;

import com.senseonics.gen12androidapp.MessageCoder;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.util.BlindedGlucoseCauseIdentifier;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class ReadSensorGlucoseAlertAndStatusParsedResponse implements ParsedResponse {

    private MessageCoder messageCoder;
    private BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier;

    @Inject
    public ReadSensorGlucoseAlertAndStatusParsedResponse(MessageCoder messageCoder, BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier) {
        this.messageCoder = messageCoder;
        this.blindedGlucoseCauseIdentifier = blindedGlucoseCauseIdentifier;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadSensorGlucoseAlertsAndStatusResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadSensorGlucoseAlertsAndStatusResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        int glucoseLevelAlarmFlags = data[1];
        int glucoseLevelAlertFlags = data[2];
        int rateAlertFlags = data[3];
        int predictiveAlertFlags = data[4];
        int sensorHWStatusAlarmAndAlertFlags = data[5];
        int sensorReadAlertFlags = data[6];
        int sensorReplacementStatusAlarmAndAlertFlags = data[7];
        int sensorCalibrationStatusAlarmAndAlertFlags = data[8];
        int transmitterStatusAlertFlags = data[9];
        int transmitterBatteryAlertFlags = data[10];

        if (glucoseLevelAlarmFlags == 0
                && glucoseLevelAlertFlags == 0
                && rateAlertFlags == 0
                && predictiveAlertFlags == 0
                && sensorHWStatusAlarmAndAlertFlags == 0
                && sensorReadAlertFlags == 0
                && sensorReplacementStatusAlarmAndAlertFlags == 0
                && sensorCalibrationStatusAlarmAndAlertFlags == 0
                && transmitterStatusAlertFlags == 0
                && transmitterBatteryAlertFlags == 0) {
            Log.w(ReadSensorGlucoseAlertAndStatusParsedResponse.class.getSimpleName(), "read alert: NO alarm active");
            model.setCurrentMessageCode(Utils.TransmitterMessageCode.NoAlarmActive);
            return;
        }

        // Same implementation as MLAlertCodeForAlertStatus() in MLTransmitterState.m in iOS App
        // Find which alert/alarm is active and only show the most severe one
        Utils.TransmitterMessageCode response = Utils.TransmitterMessageCode.NoAlarmActive;

        Log.w(ReadSensorGlucoseAlertAndStatusParsedResponse.class.getSimpleName(), "BEFORE read alert: " + model.getCurrentMessageCode());

        if (transmitterStatusAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 = messageCoder.messageCodeForTransmitterStatusAlertFlags(transmitterStatusAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (predictiveAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForPredictiveAlertFlags(predictiveAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (rateAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForRateAlertFlags(rateAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (transmitterBatteryAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForTransmitterBatteryAlertFlags(transmitterBatteryAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (sensorReadAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForSensorReadAlertFlags(sensorReadAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (sensorReplacementStatusAlarmAndAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForSensorReplacementFlags(sensorReplacementStatusAlarmAndAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (sensorCalibrationStatusAlarmAndAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForSensorCalibrationFlags(sensorCalibrationStatusAlarmAndAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (sensorHWStatusAlarmAndAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForSensorHardwareAndAlertFlags(sensorHWStatusAlarmAndAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (glucoseLevelAlarmFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForGlucoseLevelAlarmFlags(glucoseLevelAlarmFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }

        if (glucoseLevelAlertFlags != 0) {
            Utils.TransmitterMessageCode response2 =
                    messageCoder.messageCodeForGlucoseLevelAlertFlags(glucoseLevelAlertFlags);
            if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(response2)) {
                response = Utils.TransmitterMessageCode.values()[Math.min(response2.ordinal(), response.ordinal())];
            }
        }


        //128 is SensorRetiringSoon7Alarm - Premature
        if(sensorReplacementStatusAlarmAndAlertFlags == 128) {
            int actualOrdinalAlert =  Utils.TransmitterMessageCode.SensorRetiredAlarm.ordinal()+1;
            if(response.ordinal() >= actualOrdinalAlert) {
                response = Utils.TransmitterMessageCode.SensorRetiringSoon7Alarm;
            }
        }

        model.setCurrentMessageCode(Utils.TransmitterMessageCode.values()[response.ordinal()]);
    }
}
