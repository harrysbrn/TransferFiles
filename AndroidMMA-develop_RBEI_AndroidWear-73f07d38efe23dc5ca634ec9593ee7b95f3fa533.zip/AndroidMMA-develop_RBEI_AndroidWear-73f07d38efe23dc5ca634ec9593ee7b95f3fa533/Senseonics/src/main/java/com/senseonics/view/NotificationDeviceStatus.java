package com.senseonics.view;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.events.StatusHeaderTapEvent;
import com.senseonics.model.ModelChangedEvent;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.Utils;

import de.greenrobot.event.EventBus;

public class NotificationDeviceStatus extends LinearLayout {

    private TextView textView;

    public NotificationDeviceStatus(Context context) {
        super(context);
        init(context);
    }

    public NotificationDeviceStatus(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public NotificationDeviceStatus(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        inflate(context, R.layout.notification_device_status, this);
        textView = (TextView) findViewById(R.id.textView);
        setBackgroundColor(getResources().getColor(R.color.black));
        textView.setTextColor(getResources().getColor(R.color.graph_white));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        EventBus.getDefault().registerSticky(this);

        this.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // won't post if firstRun or isNotLoggedIn
                if (!Utils.checkIfFirstRun(getContext()) && Utils.checkIfLoggedIn(getContext())) {
                    EventBus.getDefault().post(new StatusHeaderTapEvent());
                }
            }
        });
    }

    @Override
    protected void onDetachedFromWindow() {
        EventBus.getDefault().unregister(this);

        this.setOnClickListener(null);

        super.onDetachedFromWindow();
    }

    public boolean isDisplayingConnectionState() {
        if (textView.getText().equals(getContext().getString(R.string.bluetooth_is_off)) ||
                        textView.getText().equals(getContext().getString(R.string.no_transmitter_connected)) ||
                        textView.getText().equals(getContext().getString(R.string.connecting_wait))) {
            return true;
        } else {
            return false;
        }
    }

    private void displayNoSignal() {
        textView.setText(getContext().getString(R.string.no_sensor_detected_alarm_title));
        setBackgroundColor(getResources().getColor(R.color.black));
        textView.setTextColor(getResources().getColor(R.color.graph_white));
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Log.i(NotificationDeviceStatus.class.getSimpleName(), "onSaveInstanceState");
        return super.onSaveInstanceState();
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        super.onRestoreInstanceState(state);
        Log.i(NotificationDeviceStatus.class.getSimpleName(), "onRestoreInstanceState");
    }

    private void displayTransmitterConnectionStateInStatus(Transmitter.CONNECTION_STATE state) {
        switch (state) {
            case CONNECTING:
            case TRANSPORT_CONNECTED:
            case NEGOTIATING:
                textView.setText(getContext().getString(R.string.connecting_wait));
                setBackgroundColor(getResources().getColor(R.color.black));
                textView.setTextColor(getResources().getColor(R.color.graph_white));
                break;

            default: // for Disconnected and Searching
                textView.setText(getContext().getString(R.string.no_transmitter_connected));
                setBackgroundColor(getResources().getColor(R.color.black));
                textView.setTextColor(getResources().getColor(R.color.graph_white));
                break;
        }
    }

    private void clearStatusDisplay() {
        textView.setText("");
        setBackgroundColor(getResources().getColor(R.color.black));
        textView.setTextColor(getResources().getColor(R.color.graph_white));
    }

    private void updateCalibrationCountdown(long timeLeft) {
        if (timeLeft > 0) {
            long allseconds = timeLeft / 1000;
            int minutes = (int) (allseconds / 60);
            int seconds = (int) (allseconds % 60);
            String text = getResources().getString(R.string.cal_in_progress, minutes, seconds);
            textView.setText(text);
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        } else {
            clearStatusDisplay();
        }
    }

    public String getHoursLeftForWarmupPhaseFormattedStr(TransmitterStateModel modelIn){
        int hours = modelIn.getHoursLeftForWarmupPhase();
        if(hours == 0 )
            return " (< " + getResources().getString(R.string.less_than_one_hour)+")";
        return " (< "+ (hours+1) + " " + getResources().getString(R.string.hours_remaining) + ")";
    }

    public void onEventMainThread(ModelChangedEvent event) {
        Utils.TransmitterMessageCode currentMessageCode = event.getModel().getCurrentMessageCode();
//        Log.d("statusBar", "-----------------------------------------------------------------------");
//        Log.d("statusBar", "Placement Mode:" + event.getModel().isPlacementModeInProgress());
//        Log.d("statusBar", "Clinical Mode:" + event.getModel().isClinicalMode());
//        Log.d("statusBar", "Blinded:" + event.getModel().canCurrentMessageCodeBeReasonForBlinded());
//        Log.d("statusBar", "Current message code:" + currentMessageCode);
//        Log.d("statusBar", "Current countdown:" + event.getModel().getCurrentCountdown());
//        Log.d("statusBar", "Current Phase:" + event.getModel().getCurrentCalibrationPhase());
//        Log.d("statusBar", "Current Completed Calibrations:" + event.getModel().getCalibrationsMadeInThisPhase());
//        Log.d("statusBar", "-----------------------------------------------------------------------");

        // Bluetooth is OFF
        if (!event.getModel().isBluetoothEnabled()) {
            textView.setText(getContext().getString(R.string.bluetooth_is_off));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        // Bluetooth is ON: Tx not connected
        else if (event.getModel().getTransmitterConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED){
            displayTransmitterConnectionStateInStatus(event.getModel().getTransmitterConnectionState());
        }
        //Transmitter Error Alarm: Tx Error
        else if(currentMessageCode == Utils.TransmitterMessageCode.CriticalFaultAlarm){
            textView.setText(getContext().getString(R.string.transmitter_error));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }// Tx Connected: Check Sensor Signal Strength
        else if (
//                (event.getModel().getSignalStrength() == SIGNAL_STRENGTH.NO_SIGNAL) ||
                (currentMessageCode == Utils.TransmitterMessageCode.SensorAwolAlarm)) {
            displayNoSignal();
        }
        else if (event.getModel().isPlacementModeInProgress()) {
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
            textView.setText(getResources().getString(R.string.placement_in_progress));
        }
        else if (event.getModel().isClinicalMode()) {
            textView.setText(getResources().getString(R.string.clinical_mode_enabled));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else if (currentMessageCode != Utils.TransmitterMessageCode.NoAlarmActive
                && event.getModel().canCurrentMessageCodeBeReasonForBlinded()) {
            textView.setText(getResources().getString(Utils.getNotificationDialogMessageTitleStringId(currentMessageCode))
                    + " " + getResources().getString(Utils.getNotificationDialogTypeStringId(currentMessageCode)));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else if (event.getModel().getCurrentCountdown() > 0) {
            updateCalibrationCountdown(event.getModel().getCurrentCountdown());
        }

        //TODO: Add a TX Busy error code 0x80

        else if ((event.getModel().getCurrentCalibrationPhase() == Utils.CAL_PHASE.WARM_UP)
        && (event.getModel().getSensorInsertionDateAndTime() != null)) {
            textView.setText(event.getModel().getCurrentPhase() + " " + getResources().getString(R.string.phase_text)
                    + getHoursLeftForWarmupPhaseFormattedStr(event.getModel()));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else if ((event.getModel().getCurrentCalibrationPhase() == Utils.CAL_PHASE.INITIALIZATION)
                && (event.getModel().getCalibrationsMadeInThisPhase() != -1)
                && (event.getModel().getCalibrationsRemaining() > TransmitterStateModel.CALIBRATIONS_REQUIRED_BEFORE_GLUCOSE_IN_INITIALIZATION_PHASE)) {

            String text = getResources().getString(R.string.init_phase_notif, event.getModel().getCalibrationsRemaining());
            textView.setText(text);
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else if (event.getModel().isGlucoseLevelWithinRange()) {
            int glucoseLevel = event.getModel().getGlucoseLevel();
//            Log.d("statusBar", "glucoseLevel: " + glucoseLevel);
//            Log.d("statusBar", "target high:" + Utils.GLUCOSE_TARGET_HIGH +
//                    " target low:" + Utils.GLUCOSE_TARGET_LOW);
            setBackgroundColor(getResources().getColor(Utils.getBackgroundColorForGlucose(glucoseLevel)));
            textView.setText(Utils.getGlucoseLevelAlertText(glucoseLevel));
            textView.setTextColor(getResources().getColor(Utils.getTextColorForGlucose(glucoseLevel)));
        }
        else if((event.getModel().getCurrentCalibrationPhase() == Utils.CAL_PHASE.INITIALIZATION)
                && (event.getModel().getCalibrationsMadeInThisPhase() != -1)){

            String text = getResources().getString(R.string.init_phase_notif, event.getModel().getCalibrationsRemaining());
            textView.setText(text);
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else if (event.getModel().getCurrentCalibrationPhase() == Utils.CAL_PHASE.DAILY_CALIBRATION) {
            textView.setText(event.getModel().getCurrentPhase() + " " + getResources().getString(R.string.phase_text));
            setBackgroundColor(getResources().getColor(R.color.black));
            textView.setTextColor(getResources().getColor(R.color.graph_white));
        }
        else {
            clearStatusDisplay();
        }

    }

}
