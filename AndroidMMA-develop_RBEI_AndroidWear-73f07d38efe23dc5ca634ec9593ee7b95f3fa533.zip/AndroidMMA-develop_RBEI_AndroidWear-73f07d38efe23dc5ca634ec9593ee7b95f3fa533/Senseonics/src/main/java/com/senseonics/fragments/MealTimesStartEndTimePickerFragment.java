package com.senseonics.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.DialogUtils.TimeDialogManager;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.TimeZone;

public class MealTimesStartEndTimePickerFragment extends BaseFragment {

	private TextView mealTimeTextTextView, startTimeText, startTimeTextView, endTimeText,
			endTimeTextView;
	private MealTimeDataHandler.MealType mealType = MealTimeDataHandler.MealType.BREAKFAST;
	private int startHour = 6, startMinute = 0,
			endtHour = 10, endMinute = 0;
	private boolean settingsOk = true;

	private MealTimesStartEndTimePickerManager mealTimesStartEndTimePickerManager;
	public MealTimeDataHandler mealTimeDataHandler;
	private RelativeLayout startTimePicker, endTimePicker;
	private Dialog dialog;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater,container, savedInstanceState);

		View view = inflater.inflate(R.layout.mealtime_start_end_time, container, false);
		mealTimeDataHandler = new MealTimeDataHandler(getActivity());
		mealTimeTextTextView = (TextView) view.findViewById(R.id.mealTimeText);
		startTimeText = (TextView) view.findViewById(R.id.startTimeText);
		startTimeTextView = (TextView) view.findViewById(R.id.startTime);
		endTimeText = (TextView) view.findViewById(R.id.endTimeText);
		endTimeTextView = (TextView) view.findViewById(R.id.endTime);
		startTimePicker = (RelativeLayout) view.findViewById(R.id.startTimetPicker);
		endTimePicker = (RelativeLayout) view.findViewById(R.id.endTimePicker);

		Bundle args = getArguments();

		mealType = MealTimeDataHandler.MealType.values()[args.getInt(MealTimeDataHandler.PASS_VALUE)];

		return view;
	}

    @Override
    public void onResume() {
        super.onResume();
        updateViews();
    }

    public void updateViews() {

		if (getActivity() != null) {

			setBothTimesDataHandlerValue();


				startTimePicker.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (dialog != null && dialog.isShowing())
							dialog.dismiss();
						dialog = dialogUtils.createTimePickerDialog(getActivity(),
								startHour, startMinute,
								getResources().getString(R.string.start).toUpperCase(),
								startTimeManager);
						dialog.show();
					}
				});
				endTimePicker.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (dialog != null && dialog.isShowing())
							dialog.dismiss();
						dialog = dialogUtils.createTimePickerDialog(getActivity(),
								endtHour, endMinute,
								getResources().getString(R.string.end).toUpperCase(),
								endTimeManager);
						dialog.show();
					}
				});

				startTimePicker.setBackgroundColor(getResources().getColor(
						android.R.color.white));
				startTimeText
						.setTextColor(getResources().getColor(R.color.black));
				startTimeText.setText(startTimeText.getText().toString().toUpperCase());
				startTimeTextView.setTextColor(getResources().getColor(
						R.color.black));
				endTimePicker.setBackgroundColor(getResources().getColor(
						android.R.color.white));
				endTimeText.setTextColor(getResources().getColor(R.color.black));
			endTimeText.setText(endTimeText.getText().toString().toUpperCase());
				endTimeTextView.setTextColor(getResources().getColor(
						R.color.black));
			}
	}

	public void setBothTimesDataHandlerValue() {

		switch(mealType) {
			case BREAKFAST:
				setStartTime(mealTimeDataHandler.getBreakfastStartHour(), mealTimeDataHandler.getBreakfastStartMinute());
				setEndTime(mealTimeDataHandler.getBreakfastEndHour(), mealTimeDataHandler.getBreakfastEndMinute());
				break;
			case LUNCH:
				setStartTime(mealTimeDataHandler.getLunchStartHour(), mealTimeDataHandler.getLunchStartMinute());
				setEndTime(mealTimeDataHandler.getLunchEndHour(), mealTimeDataHandler.getLunchEndMinute());
				break;
			case SNACK:
				setStartTime(mealTimeDataHandler.getSnackStartHour(), mealTimeDataHandler.getSnackStartMinute());
				setEndTime(mealTimeDataHandler.getSnackEndHour(), mealTimeDataHandler.getSnackEndMinute());
				break;
			case DINNER:
				setStartTime(mealTimeDataHandler.getDinnerStartHour(), mealTimeDataHandler.getDinnerStartMinute());
				setEndTime(mealTimeDataHandler.getDinnerEndHour(), mealTimeDataHandler.getDinnerEndMinute());
				break;
			case SLEEP:
				setStartTime(mealTimeDataHandler.getSleepStartHour(), mealTimeDataHandler.getSleepStartMinute());
				setEndTime(mealTimeDataHandler.getSleepEndHour(), mealTimeDataHandler.getSleepEndtMinute());
				break;
		}

	}


	public void saveStartTimesDataHandlerValue(int hour,int minute) {

		switch(mealType) {
			case BREAKFAST:
				mealTimeDataHandler.setBreakfastStartTime(hour, minute);
				break;
			case LUNCH:
				mealTimeDataHandler.setLunchStartTime(hour, minute);
				break;
			case SNACK:
				mealTimeDataHandler.setSnackStartTime(hour, minute);
				break;
			case DINNER:
				mealTimeDataHandler.setDinnerStartTime(hour, minute);
				break;
			case SLEEP:
				mealTimeDataHandler.setSleepStartTime(hour, minute);
				break;
		}

	}

	public void saveEndTimesDataHandlerValue(int hour,int minute) {

		switch(mealType) {
			case BREAKFAST:
				mealTimeDataHandler.setBreakfastEndTime(hour, minute);
				break;
			case LUNCH:
				mealTimeDataHandler.setLunchEndTime(hour, minute);
				break;
			case SNACK:
				mealTimeDataHandler.setSnackEndTime(hour, minute);
				break;
			case DINNER:
				mealTimeDataHandler.setDinnerEndTime(hour, minute);
				break;
			case SLEEP:
				mealTimeDataHandler.setSleepEndTime(hour, minute);
				break;
		}

	}

	private void setStartTimeTextView(int hour, int minute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		if (startTimeTextView != null)
		{
			startTimeTextView.setText(Utils.getTime24HrFormat(calendar, TimeZone.getDefault(),getActivity()));
		}
	}

	private void setEndTimeTextView(int hour, int minute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		if (endTimeTextView != null)
		{
			endTimeTextView.setText(Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getActivity()));
		}
	}


	private void setStartTime(int hour, int minute) {
		if (hour >= 0 && minute >= 0) {
			// Convert hour from GMT back to local
			startHour = hour;
			startMinute = minute;
			setStartTimeTextView(hour, minute);
		}
		else if (startTimeTextView != null)
		{
			startTimeTextView.setText(Utils.unknownTime);
		}
	}


	private void setEndTime(int hour, int minute) {
		if (hour >= 0 && minute >= 0) {
			// Convert hour from GMT back to local
			endtHour = hour;
			endMinute = minute;

			setEndTimeTextView(hour, minute);
		}
		else if (endTimeTextView != null)
		{
			endTimeTextView.setText(Utils.unknownTime);
		}
	}

	TimeDialogManager startTimeManager = new TimeDialogManager() {

		@Override
		public void onTimeSelected(Integer hour, Integer minute) {

			// #979
			startHour = hour;
			startMinute = minute;
			setStartTimeTextView(hour, minute);
			saveStartTimesDataHandlerValue(hour, minute);
		}
	};

	TimeDialogManager endTimeManager = new TimeDialogManager() {

		@Override
		public void onTimeSelected(Integer hour, Integer minute) {

			// #979
			endtHour = hour;
			endMinute = minute;
			setEndTimeTextView(hour, minute);
			saveEndTimesDataHandlerValue(hour,minute);
		}
	};

	public interface MealTimesStartEndTimePickerManager {

	}

	public void setMealTimesManager(MealTimesStartEndTimePickerManager manager) {
		this.mealTimesStartEndTimePickerManager = manager;
	}

}
