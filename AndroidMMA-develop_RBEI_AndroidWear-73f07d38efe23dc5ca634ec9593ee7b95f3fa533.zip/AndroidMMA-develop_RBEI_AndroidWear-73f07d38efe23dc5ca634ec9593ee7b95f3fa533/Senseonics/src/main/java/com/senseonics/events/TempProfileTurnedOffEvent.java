package com.senseonics.events;

public class TempProfileTurnedOffEvent { /** #3160 */
    public TempProfileTurnedOffEvent() { }
}
