package com.senseonics.gen12androidapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.pairing.BluetoothPairingFragment;
import com.senseonics.util.Utils;

public class InitialBluetoothPairingActivity extends BaseActivity {

  private BluetoothPairingFragment bluetoothPairingFragment;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Add the content view
    LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
    LayoutInflater layoutInflater = getLayoutInflater();
    LinearLayout.LayoutParams parms_content =
        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT);
    rl.addView(layoutInflater.inflate(R.layout.activity_simple_fragment, null), parms_content);

    // Configure the status header
    statusBarDrawerButton.setVisibility(View.GONE);

    // Configure the navigation bar
    naviBarTitle.setVisibility(View.GONE);
    naviBarTitleImageView.setVisibility(View.VISIBLE);
    naviBarTitleImageView.setImageResource(R.drawable.setup_01);
    naviBarLayout.setVisibility(View.VISIBLE);

    //naviBarRightItemTextView.setVisibility(View.GONE);
    showNextButton(transmitterStateModel.getTransmitterConnectionState()
        == Transmitter.CONNECTION_STATE.CONNECTED);

    naviBarRightItemAddEventImageview.setVisibility(View.GONE);

    naviBarRightItemTextView.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        startActivityForResult(
            new Intent(InitialBluetoothPairingActivity.this, InitialDailyCalibrationActivity.class),
            Utils.WELCOME_UNIT_SELECTION_RESULT);
      }
    });

    bluetoothPairingFragment = new BluetoothPairingFragment();

    getFragmentManager().beginTransaction()
                .replace(R.id.fragment, bluetoothPairingFragment)
                .commitAllowingStateLoss();
	}

  private void showNextButton(boolean enable) {
    if (enable) {
      naviBarRightItemTextView.setVisibility(View.VISIBLE);
      naviBarRightItemTextView.setText(getResources().getString(R.string.next));
    } else {
      naviBarRightItemTextView.setVisibility(View.GONE);
    }
  }

  public void onEventMainThread(TransmitterConnectionEvent event) {
    showNextButton(
        event.getTransmitter().getConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED);
    super.onEventMainThread(event);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {

    // Result coming back from the unit selection page when the Finish button is pressed
    if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
      setResult(resultCode);
      finish();
    }

    super.onActivityResult(requestCode, resultCode, data);
  }
}
