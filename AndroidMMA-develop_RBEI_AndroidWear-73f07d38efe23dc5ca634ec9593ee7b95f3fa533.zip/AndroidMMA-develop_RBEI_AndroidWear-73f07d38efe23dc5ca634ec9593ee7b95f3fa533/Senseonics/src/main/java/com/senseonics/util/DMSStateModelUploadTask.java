package com.senseonics.util;

import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.senseonics.model.StateModelUpload.DMSStateModelAppInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelSensorInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelThresholdInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelTransmitterInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelUserInfo;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.KeyStore;

public class DMSStateModelUploadTask extends AsyncTask<Void, Void, Void> {
    private final String Tag = "DMS(StateModelUpLTk)";
    private String response;

    private AccountConstants accountConstants;
    private StateModelUploadUtility stateModelUploadUtility;
    private StateModelUploadUtility.StateModelType stateModelType;

    public DMSStateModelUploadTask(AccountConstants accountConstants, StateModelUploadUtility stateModelUploadUtility, StateModelUploadUtility.StateModelType stateModelType) {
        this.accountConstants = accountConstants;
        this.stateModelUploadUtility = stateModelUploadUtility;
        this.stateModelType = stateModelType;
    }

    @Override
    protected Void doInBackground(Void... params) {
        if (accountConstants.HasValidAccountInfo() == false) {
            Log.d(Tag, "PANIC: No Valid Account Info");
            response = "-1";
            return null;
        }

        String requestString = null;
        String webMethod = null;
        switch (this.stateModelType) {
            case StateModelType_CheckAndUpdatePassword: /** #3707 */
                DMSStateModelUserInfo userInfo = stateModelUploadUtility.fetchStateModelUserInfo();
                requestString = accountConstants.generateCheckAndUpdatePassword(userInfo.getUsername(), userInfo.getPWHash(), userInfo.getPWBinary());
                webMethod = accountConstants.checkAndUpdatePasswordWebserviceFunctionCall;
                break;
            case StateModelType_TxInfo:
                DMSStateModelTransmitterInfo txInfo = stateModelUploadUtility.fetchStateModelTransmitterInfo();
                if (txInfo.getTxID().equals("") == false) {
                    requestString = stateModelUploadUtility.generateStateModelTransmitterInfoRequest(txInfo);
                    webMethod = stateModelUploadUtility.kStateModelUploadTransmitterInfoWebserviceFunctionCall;
                }
                break;
            case StateModelType_SxInfo:
                DMSStateModelSensorInfo sensorInfo = stateModelUploadUtility.fetchStateModelSensorInfo();
                if (sensorInfo.getSensorID().equals("0") == false) {
                    requestString = stateModelUploadUtility.generateStateModelSensorInfoRequest(sensorInfo);
                    webMethod = stateModelUploadUtility.kStateModelUploadSensorInfoWebserviceFunctionCall;
                }
                break;
            case StateModelType_ThresholdInfo:
                DMSStateModelThresholdInfo thresholdInfo = stateModelUploadUtility.fetchStateModelThresholdInfo();
                requestString = stateModelUploadUtility.generateStateModelThresholdInfoRequest(thresholdInfo);
                webMethod = stateModelUploadUtility.kStateModelUploadThresholdInfoWebserviceFunctionCall;
                break;
            case StateModelType_AppInfo:
                DMSStateModelAppInfo appInfo = stateModelUploadUtility.fetchStateModelAppInfo();
                requestString = stateModelUploadUtility.generateStateModelAppInfoRequest(appInfo);
                webMethod = stateModelUploadUtility.kStateModelUploadAppInfoWebserviceFunctionCall;
                break;
            default:
                break;
        }

        if ((requestString!=null) && (webMethod!=null)) {
            response = uploadStateModelData(requestString, webMethod);
        }
        else {
            response = "-1";
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        if (response != null && !response.equals("-1")) {
            Utils.printLongLog(Tag, "UploadData TYPE:" + this.stateModelType + "| RESPONSE:" + response);

            /** #3707 */
            if (this.stateModelType == StateModelUploadUtility.StateModelType.StateModelType_CheckAndUpdatePassword) {
                try {
                    String checkAndUpdatePasswordResult = null;
                    // Parse the result
                    XmlPullParser parser = Xml.newPullParser();
                    InputStream stream = new ByteArrayInputStream(response.getBytes());
                    parser.setInput(stream, null);

                    int event = parser.getEventType();
                    while (event != XmlPullParser.END_DOCUMENT) {
                        if (event == XmlPullParser.START_TAG) {
                            String name = parser.getName();
                            if (name != null && name.equals(accountConstants.TAG_CHECK_AND_UPDATE_PASSWORD_RESULT)) {
                                if (parser.next() == XmlPullParser.TEXT) {
                                    checkAndUpdatePasswordResult = parser.getText();
                                    break;
                                }
                            }
                        }
                        event = parser.next();
                    }

                    Log.d(Tag, "2. checkAndUpdatePasswordResult:" + checkAndUpdatePasswordResult);
                    if ((checkAndUpdatePasswordResult != null) && !checkAndUpdatePasswordResult.equals("")) {
                        String[] results = checkAndUpdatePasswordResult.split(",");

                        if (results.length == 2) {
                            int pResultInt = Integer.parseInt(results[0]); // may have NumberFormatException
                            int uid = Integer.parseInt(results[1]); // may have NumberFormatException

                            AccountConstants.CheckAndUpdatePasswordResult pResult = AccountConstants.CheckAndUpdatePasswordResult.fromValue(pResultInt);

                            if (pResult == AccountConstants.CheckAndUpdatePasswordResult.PwdUpdatedAndAuthenticated) {
                                Log.d(Tag, "2. Set MigrationPasswordUpdated to YES");
                                // set up the flag to true
                                accountConstants.setMigrationPasswordUpdated(true);
                            }
                        }
                    }
                }
                catch (XmlPullParserException|IOException|NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected String uploadStateModelData(String requestStringForUploadData, String webMethod) {
        try {
            StringEntity entity = new StringEntity(requestStringForUploadData, HTTP.UTF_8);
            HttpPost httpPost = accountConstants.formHttpPost(
                    accountConstants.getDMSServerURL(),
                    webMethod,
                    entity
            );

            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);
            SSLSocketFactory sf = new DMSSSLSocketFactory(trustStore);
            HttpClient client = accountConstants.createHttpClient(sf);

            HttpResponse response;

            try {
                response = client.execute(httpPost);
                return EntityUtils.toString(response.getEntity());
            } catch (ClientProtocolException e) {
                Log.d(Tag, "Client Protocol Exception");
            } catch (SocketTimeoutException e) {
                Log.d(Tag, "Socket timeout");
            } catch (ConnectTimeoutException e) {
                Log.d(Tag, "Connect timeout");
            } catch (IOException e) {
                Log.d(Tag, "IO Exception");
                e.printStackTrace();
            }

            return "-1";
        } catch (UnsupportedEncodingException e) {
            Log.d(Tag, "Unsupported Encoding Exception");
            return "-1";
        } catch (Exception e) {
            Log.d(Tag, "Might be keystore exception");
            e.printStackTrace();
            return "-1";
        }
    }

}
