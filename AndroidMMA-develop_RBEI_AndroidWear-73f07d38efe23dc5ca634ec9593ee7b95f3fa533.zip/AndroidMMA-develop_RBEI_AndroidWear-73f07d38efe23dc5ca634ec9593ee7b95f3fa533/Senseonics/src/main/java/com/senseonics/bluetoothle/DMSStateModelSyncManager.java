package com.senseonics.bluetoothle;

import android.content.Context;
import android.util.Log;

import com.senseonics.model.SyncModel;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.DMSStateModelUploadTask;
import com.senseonics.util.StateModelUploadUtility;
import com.senseonics.util.Utils;

import java.util.Calendar;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DMSStateModelSyncManager {
    private final String Tag = "DMS(StateModelSyncMgr)";
//    private final int STATE_MODEL_SYNC_DELAY = 120 * 1000; // 2mins
    private final int STATE_MODEL__UPLOADING_INTERVAL = 116; // sync every 116 mins

    private AccountConstants accountConstants;
    private Context context;
    private StateModelUploadUtility stateModelUploadUtility;
    private SyncModel syncModel;

    @Inject
    public DMSStateModelSyncManager( AccountConstants accountConstants, Context context, StateModelUploadUtility stateModelUploadUtility, SyncModel syncModelIn) {
        this.accountConstants = accountConstants;
        this.context = context;
        this.stateModelUploadUtility = stateModelUploadUtility;
        this.syncModel = syncModelIn;
    }

    public void startModelSync() {
        long lastDiagnosticSyncTimeInMills = accountConstants.getDiagnosticDataLastSyncedOnDateTimeFromPreference();

        if (lastDiagnosticSyncTimeInMills == 0L) {
            // Never synced before
            Log.d(Tag, "no last upload Diagnostic time -> SYNC MODEL NOW");
            modelSyncNow();
        }
        else {
            long currentTimeInMills = Calendar.getInstance().getTimeInMillis();
            long diffTimeInMills = currentTimeInMills - lastDiagnosticSyncTimeInMills;
            Log.d(Tag, "currentTimeInMills:" + currentTimeInMills + "|lastSyncTimeInMills:" + lastDiagnosticSyncTimeInMills + "|diff:"+diffTimeInMills);

            if (diffTimeInMills < 0) {
                Log.d(Tag, "Diagnostic Auto: invalid time");
                accountConstants.resetDiagnosticDataLastSyncedOnInPreference();
                return;
            }

            if (diffTimeInMills < (STATE_MODEL__UPLOADING_INTERVAL * 60L * 1000L)) {
                Log.d(Tag, "Diagnostic: Less than (" + STATE_MODEL__UPLOADING_INTERVAL + " minutes)");
                return;
            }

            modelSyncNow();
        }
    }

    private void modelSyncNow() {
        // Need to have condition check if it's good to execute the upload task

        if (Utils.haveNetworkConnection(context) == false) {
            Log.d(Tag, "PANIC: No Internet");
            return;
        }

        if (Utils.checkIfFirstRun(context) || !Utils.checkIfLoggedIn(context)) {
            Log.d(Tag, "PANIC: Initial Launch | not loggin in");
            return;
        }

        if (syncModel.isSyncing()) {
            Log.d(Tag, "PANIC: Sync Tx is in progress");
            return;
        }

        /**
         * #2963 Save diagnostic data even when Sync is disabled:
         * do not check accountConstants.getAccountEnableAutoSync()
         * - unlike the one in DMSSyncManager.java
         * */

        Log.d(Tag, ">>> Sync Model Now <<<");
        DMSStateModelSyncManager.uploadAllStateModelInfo(accountConstants, stateModelUploadUtility);
    }

    public static void uploadAllStateModelInfo(AccountConstants accountConstants, StateModelUploadUtility stateModelUploadUtility) {
        /** #3707 */
        new DMSStateModelUploadTask(
                accountConstants,
                stateModelUploadUtility,
                StateModelUploadUtility.StateModelType.StateModelType_CheckAndUpdatePassword
        ).execute();

        new DMSStateModelUploadTask(
                accountConstants,
                stateModelUploadUtility,
                StateModelUploadUtility.StateModelType.StateModelType_TxInfo
        ).execute();

        new DMSStateModelUploadTask(
                accountConstants,
                stateModelUploadUtility,
                StateModelUploadUtility.StateModelType.StateModelType_SxInfo
        ).execute();

        /** #3282 Upload the threshold info when first time sync (Android) */
        if (accountConstants.getDiagnosticDataLastSyncedOnDateTimeFromPreference() == 0L) {
            DMSStateModelSyncManager.uploadThresholdInfo(accountConstants, stateModelUploadUtility);
        }

        new DMSStateModelUploadTask(
                accountConstants,
                stateModelUploadUtility,
                StateModelUploadUtility.StateModelType.StateModelType_AppInfo
        ).execute();

        /** set the diagnostic last sync timestamp here instead after the last task finishes executing */
        accountConstants.setCurrentDateTimeToDiagnosticDataLastSyncedOnInPreference();
    }

    public static void uploadThresholdInfo(AccountConstants accountConstants, StateModelUploadUtility stateModelUploadUtility) {
        new DMSStateModelUploadTask(
                accountConstants,
                stateModelUploadUtility,
                StateModelUploadUtility.StateModelType.StateModelType_ThresholdInfo
        ).execute();
    }
}
