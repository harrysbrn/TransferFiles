package com.senseonics.gen12androidapp;

import android.app.ActivityManager;
import android.app.Dialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.senseonics.bluetoothle.BluetoothAdapterWrapper;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.bluetoothle.DialogUtils.NotificationDialogManager;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.CalibrationRequestEvent;
import com.senseonics.events.DismissPlacementGuide;
import com.senseonics.events.EventPoint;
import com.senseonics.events.StatusHeaderTapEvent;
import com.senseonics.events.TempProfileTurnedOffEvent;
import com.senseonics.fragments.AboutFragment;
import com.senseonics.fragments.CalibrateFragment;
import com.senseonics.fragments.CalibrateFragment.CalibrationManager;
import com.senseonics.fragments.ComingSoonFragment;
import com.senseonics.fragments.EventLogFragment;
import com.senseonics.fragments.GraphFragment;
import com.senseonics.fragments.NotificationsFragment;
import com.senseonics.fragments.PlacementGuideFragment;
import com.senseonics.fragments.SettingsFragment;
import com.senseonics.fragments.SettingsFragment.SettingsManager;
import com.senseonics.fragments.StatisticsFragment;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.graph.util.GraphUtils.COLOR;
import com.senseonics.model.ModelChangedEvent;
import com.senseonics.pairing.BluetoothEnabler;
import com.senseonics.pairing.BluetoothPairingFragment;
import com.senseonics.util.AddEventMenuCreator;
import com.senseonics.util.Menu;
import com.senseonics.util.MenuAdapter;
import com.senseonics.util.Utils;
import com.senseonics.view.NotificationDeviceStatus;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

import javax.inject.Inject;

public class MainActivity extends BluetoothPairBaseActivity implements ActivityWithNavigationBar {
    @Inject protected BluetoothAdapterWrapper bluetoothAdapterWrapper;
    @Inject BluetoothEnabler bluetoothEnabler;
    public static final int REQUEST_CODE = 301, RESULT_DELETED = 303;
    // Status bar items
    public static LinearLayout statusBarLayout;
    private Dialog dialog;
    public static ImageView statusBarDrawerButton;
    public static ImageView statusBarImageView;
    public static TextView statusBarTextView;
    // Navigation bar items
    public static RelativeLayout naviBarLayout;
    public static TextView naviBarTitle;
    public static TextView naviBarRightItemTextView;
    private ImageButton refreshButton;
    public static ImageView naviBarRightItemAddEventImageview;
    public static int currentMenu = 0;
    public static int previousMenu = 0;
    private CalibrationManager calibrationManager = new CalibrationManager() {

        @Override
        public void submit(CalibrationEventPoint eventPoint) {
            sendCalibrationEvent(eventPoint);
            selectItem(0);
        }
    };

    private SettingsManager settingsManager = new SettingsManager() {

        @Override
        public void redirectToMainActivity() {

            selectItem(0);
        }
    };

    public static int glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN;
    public static boolean needToRefreshGraph = false;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;
    private ArrayList<Menu> menuItems;
    private FragmentManager fragmentManager;
    private GraphFragment graphFragment;
    private CalibrateFragment calibrateFragment;
    private EventLogFragment eventLogFragment;
    private NotificationsFragment notificationFragment;
    private BluetoothPairingFragment connectionStatusFragment;
    private PlacementGuideFragment placementGuideFragment;
    private StatisticsFragment statisticsFragment;
    private AboutFragment aboutFragment;
    private SettingsFragment settingsFragment;
    private ComingSoonFragment comingSoonFragment;
    private MenuAdapter menuAdapter;
    private Menu menuHome, menuCalibrate, menuEventLog, menuNotifications,
            menuConnStatus, menuPlacementGuide, menuSettings, menuStatistics,
            menuAbout, menuShareMyData;
    private boolean doubleBackToExitPressedOnce = false;
    private Timer timer;

    public static void saveFirstRun(Context context) {
        Utils.saveSettings(context, Utils.prefFirstRun, false);
    }

    public StatisticsFragment getStatisticsFragment() {
        return statisticsFragment;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar on startup
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getActionBar().hide();

        setContentView(R.layout.main_drawer_layout);

        // Get the device screen size
        Utils.setScreenWidthandHeight(MainActivity.this);

        saveFirstRun(this);

        fragmentManager = getFragmentManager();

        calculateGraphSize();

        initGlucoseLevels();
        menuHome = new Menu(MENU_TYPE.HOME, getString(R.string.home),
                R.drawable.home_menu_icon);
        menuCalibrate = new Menu(MENU_TYPE.CALIBRATE,
                getString(R.string.calibrate), R.drawable.calibrate_menu_icon);
        menuEventLog = new Menu(MENU_TYPE.EVENT_LOG,
                getString(R.string.event_log),
                R.drawable.add_event_log_menu_icon);
        menuNotifications = new Menu(MENU_TYPE.NOTIFICATIONS,
                getString(R.string.notifications_2), /** #3214 */
                R.drawable.notification_menu_icon);
        menuConnStatus = new Menu(MENU_TYPE.CONNECTION_STATUS,
                getString(R.string.connection_status),
                R.drawable.connection_status_menu_icon);
        menuPlacementGuide = new Menu(MENU_TYPE.PLACEMENT_GUIDE,
                getString(R.string.placement_guide),
                R.drawable.placement_guide_menu_icon);
        menuSettings = new Menu(MENU_TYPE.SETTINGS,
                getString(R.string.settings), R.drawable.settings_menu_icon);
        menuStatistics = new Menu(MENU_TYPE.STATISTICS,
                getString(R.string.statistics), R.drawable.statistics_menu_icon);
        menuAbout = new Menu(MENU_TYPE.ABOUT, getString(R.string.about),
                R.drawable.about_menu_icon);
        menuShareMyData = new Menu(MENU_TYPE.SHARE_MY_DATA, getString(R.string.share_my_data),
                R.drawable.icon_menu_sharedata);
        initSlidingDrawer();

		/* Setup the status bar*/
        statusBarLayout = (LinearLayout) findViewById(R.id.alertView);
        statusBarLayout.setBackgroundColor(Color.CYAN);

        statusBarDrawerButton = (ImageView) findViewById(R.id.drawerImageButton);
        statusBarDrawerButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(mDrawerList);
            }
        });

        statusBarImageView = (ImageView) statusBarLayout
                .findViewById(R.id.imageView);
        statusBarTextView = (TextView) statusBarLayout
                .findViewById(R.id.textView);
        statusBarLayout.setBackgroundColor(getResources().getColor(
                R.color.black));//notification_gray));
        statusBarTextView.setTextColor(getResources().getColor(R.color.graph_white));

        final TypedArray styledAttributes = getTheme()
                .obtainStyledAttributes(
                        new int[]{android.R.attr.actionBarSize});
        int mActionBarSize = (int) styledAttributes.getDimension(0, 0);
        styledAttributes.recycle();
        Log.d("Actionbar", "height: " + mActionBarSize);

        LinearLayout.LayoutParams parms_statusBar = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, mActionBarSize);
        statusBarLayout.setLayoutParams(parms_statusBar);

		/* Setup the navigation bar*/
        naviBarLayout = (RelativeLayout) findViewById(R.id.navigationBar);
        naviBarTitle = (TextView) findViewById(R.id.navBarTitle);
        naviBarRightItemTextView = (TextView) findViewById(R.id.navBarRightItemTextView);
        refreshButton = (ImageButton) findViewById(R.id.refreshButton);
        naviBarRightItemAddEventImageview = (ImageView) findViewById(R.id.navBarRightItemImageView);
        int naviBarHeight = Utils.screenHeight * 27 / 100 / 4;

        LinearLayout.LayoutParams parms_naviBar = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, naviBarHeight);
        naviBarLayout.setLayoutParams(parms_naviBar);

        bluetoothEnabler.requestToEnableIfDisabled();

        if (savedInstanceState == null) {
            selectItem(0);
        }
    }

    public void calculateGraphSize() {
        Utils.daySubviewWidth = Utils.screenWidth / 3;
        GraphUtils.viewportSize = Utils.daySubviewWidth / 8;
    }

    public void initSlidingDrawer() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);

        menuItems = new ArrayList<Menu>();
        menuAdapter = new MenuAdapter(this, menuItems);
        mDrawerList.setAdapter(menuAdapter);
        addMenuItems();
        enableDisableMenu(BluetoothUtils.mConnected);

        mDrawerToggle = new ActionBarDrawerToggle(this, /* host Activity */
                mDrawerLayout, /* DrawerLayout object */
                R.string.drawer_open, R.string.drawer_close) {
            // #2111 When the side menu is opened, it should scroll to the top
            // #2178 main menu drawer UI: should not snap when opened
            public void onDrawerClosed(View view) {
                mDrawerList.post(new Runnable() {
                    @Override
                    public void run() {
                        mDrawerList.setSelection(0);

                        /** #3664 */
                        transitFragment(currentMenu);
                    }
                });

            }

            public void onDrawerOpened(View drawerView) {
                // update the side menu depending on the connection status
                if(transmitterStateModel.getTransmitterConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED) {
                    enableDisableMenu(false);
                }
                else {
                    enableDisableMenu(true);
                }
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerList.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long arg3) {

                if (!BluetoothUtils.mConnected) {

                    MENU_TYPE menuType = (MENU_TYPE) menuItems.get(position)
                            .getMenuType();
                    if (menuType != MENU_TYPE.PLACEMENT_GUIDE)
                        if (currentMenu != position) {
                            selectItem(position);
                        } else if (currentMenu == position)
                            closeDrawer();

                } else if (currentMenu != position) {
                    selectItem(position);
                } else if (currentMenu == position)
                    closeDrawer();
            }
        });
    }

    public MENU_TYPE getMenuType(int currentMenu) {
        return (MENU_TYPE) menuItems.get(currentMenu).getMenuType();
    }

    @Override
    public void transmitterNameChanged(String name) {
        super.transmitterNameChanged(name);
    }

    public IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Utils.WRITE_N_BYTE_FINISHED);
        return intentFilter;
    }

    @Override
    public void disconnected() {
        super.disconnected();
        MENU_TYPE menuType = (MENU_TYPE) menuItems.get(currentMenu).getMenuType();
        if (menuType == MENU_TYPE.CONNECTION_STATUS
                && connectionStatusFragment != null) {
        } else if (menuType == MENU_TYPE.ABOUT && aboutFragment != null) {
            aboutFragment.initViews();
        }
        transmitterNameChanged(null);
        enableDisableMenu(BluetoothUtils.mConnected);
    }

    @Override
    public void timeZoneChanged() {
        if (isThisActivityTop()) {
            dialogUtils.createTimeZoneChangedDialogInfo(MainActivity.this);
        } else {
            // Send broadcast to BaseActivity
            Intent brodIntent = new Intent(Utils.TIME_ZONE_CHANGED);
            sendBroadcast(brodIntent);
        }
        super.timeZoneChanged();
    }

    @Override
    public void refresh() {
        // Refresh graph fragment
        if (getMenuType(currentMenu) == MENU_TYPE.HOME && graphFragment != null) {
            graphFragment.refreshGraph();
        } else
            // Refresh event log fragment
            if (getMenuType(currentMenu) == MENU_TYPE.EVENT_LOG
                    && eventLogFragment != null) {
                eventLogFragment.initData();
            } else
                // Refresh notifications fragment
                if (getMenuType(currentMenu) == MENU_TYPE.NOTIFICATIONS
                        && notificationFragment != null) {
                    notificationFragment.initData();
                }
    }


    public void onEventMainThread(CalibrationRequestEvent event) {
        EventPoint ep = event.getEventPoint();

        if (isThisActivityTop()) {
            if (getMenuType(currentMenu) != MENU_TYPE.CALIBRATE) {
                dialogUtils.createCalibrateDialogInfo(MainActivity.this, ep, event.getNotificationId());
            }
            else if (calibrateFragment != null) {
                calibrateFragment.nextRequest();
            }
            refreshNotifications();
        }
    }

    @Override
    public void createWarningDialog(String title, String text) {
        if (isThisActivityTop()) {
            dialogUtils.createWarningDialogInfo(this, -1, title, text);
            refreshNotifications();
        } else {
            // Send broadcast to BaseActivity
            Intent brodIntent = new Intent(Utils.WARNING_DIALOG_INTENT_FILTER);
            brodIntent.putExtra("title", title);
            brodIntent.putExtra("text", text);
            sendBroadcast(brodIntent);
        }
    }

    public void refreshNotifications() {
        // Refresh notifications fragment
        if (getMenuType(currentMenu) == MENU_TYPE.NOTIFICATIONS
                && notificationFragment != null) {
            notificationFragment.initData();
        }
    }

    @Override
    protected boolean isThisActivityTop() {
        super.isThisActivityTop();

        ActivityManager am = (ActivityManager) MainActivity.this
                .getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> alltasks = am.getRunningTasks(1);

        for (ActivityManager.RunningTaskInfo task : alltasks) {
            Log.d("main - activity top", task.numRunning + " "
                    + task.topActivity.getClassName());

            // If activity is paused
            if (task.numRunning == 1
                    && !task.topActivity.getPackageName().equals(
                    this.getPackageName()))
                return true;
            else
                // If is not paused
                if (task.topActivity.getClassName().equals(
                        "com.senseonics.gen12androidapp.MainActivity"))
                    return true;
        }
        return false;
    }

    public void initGlucoseLevels() {
        // Define glucose levels
        GraphUtils.glucoseLevels = new TreeMap<Integer, COLOR>();
        GraphUtils.glucoseMinimumLevel = Utils.GRAPH_GLUCOSE_MIN;
        GraphUtils.glucoseMaximumLevel = Utils.GRAPH_GLUCOSE_MAX;

        GraphUtils.glucoseLevels.put(Utils.GRAPH_GLUCOSE_MIN, COLOR.RED_MIN);

        GraphUtils.glucoseLevels.put(Utils.GLUCOSE_ALARM_LEVEL_LOW,
                COLOR.YELLOW_MIN);

        GraphUtils.glucoseLevels.put(Utils.GLUCOSE_TARGET_LOW, COLOR.GREEN_MIN);

        GraphUtils.glucoseLevels
                .put(Utils.GLUCOSE_TARGET_HIGH, COLOR.GREEN_MAX);

        GraphUtils.glucoseLevels.put(Utils.GLUCOSE_ALARM_LEVEL_HIGH,
                COLOR.YELLOW_MAX);

        GraphUtils.glucoseLevels.put(Utils.GRAPH_GLUCOSE_MAX, COLOR.RED_MAX);

    }

    public void enableDisableMenu(boolean shouldEnable) {
        if (shouldEnable) {
            menuCalibrate.setActive(true);
            menuPlacementGuide.setActive(true);
        } else {
            menuCalibrate.setActive(false);
            menuPlacementGuide.setActive(false);
        }

        menuAdapter.notifyDataSetChanged();
    }

    public void addMenuItems() {
        /*if (shouldEnable) {
            menuCalibrate.setActive(true);
            menuPlacementGuide.setActive(true);
        } else {
            menuCalibrate.setActive(false);
            menuPlacementGuide.setActive(false);
        }*/

        menuItems.clear();
        menuItems.add(menuHome);
        menuItems.add(menuCalibrate);
        menuItems.add(menuNotifications);
        menuItems.add(menuEventLog);
        menuItems.add(menuStatistics);
        menuItems.add(menuShareMyData);
        menuItems.add(menuPlacementGuide);
        menuItems.add(menuConnStatus);
        menuItems.add(menuSettings);
        menuItems.add(menuAbout);
        menuAdapter.notifyDataSetChanged();
    }

    private void hideNaviBarRightTextAndImage() {
        naviBarLayout.setVisibility(View.VISIBLE);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);
    }

    private void updateNavigationBar() {
        //Log.d("#3664", "--- updateNavigationBar:" + currentMenu);

        Menu menuItem = menuItems.get(currentMenu);
        MENU_TYPE type = (MENU_TYPE) menuItem.getMenuType();

        refreshButton.setVisibility(View.GONE);
        if(type != MENU_TYPE.CONNECTION_STATUS) {
            refreshButton.clearAnimation();
        }

        if ((type == MENU_TYPE.STATISTICS) && (statisticsFragment == null)) {
            Log.d("#3640", "!!destroy me 2!!");
            type = MENU_TYPE.HOME;
        }

        switch (type) {
            case ABOUT:
                naviBarTitle.setText(getString(R.string.about));
                hideNaviBarRightTextAndImage();
                break;
            case CALIBRATE:
                naviBarTitle.setText(getString(R.string.calibrate));
                naviBarLayout.setVisibility(View.VISIBLE);
                naviBarRightItemAddEventImageview.setVisibility(View.GONE);
                naviBarRightItemTextView.setVisibility(View.VISIBLE);
                naviBarRightItemTextView.setText(getResources().getString(R.string.submit));

                break;
            case CONNECTION_STATUS:
                naviBarTitle.setText(getString(R.string.connection_status));
                naviBarLayout.setVisibility(View.VISIBLE);
                naviBarRightItemAddEventImageview.setVisibility(View.GONE);
                naviBarRightItemTextView.setVisibility(View.GONE);
                refreshButton.setVisibility(View.VISIBLE);
                break;
            case EVENT_LOG:
                naviBarTitle.setText(getString(R.string.event_log));
                naviBarLayout.setVisibility(View.VISIBLE);
                // Only show the "Add Event" Button
                naviBarRightItemTextView.setVisibility(View.GONE);
                naviBarRightItemAddEventImageview.setVisibility(View.VISIBLE);
                naviBarRightItemAddEventImageview.setImageResource(R.drawable.add_event_icon_actionbar);
                naviBarRightItemAddEventImageview.setEnabled(true);
                naviBarRightItemAddEventImageview.setAlpha(1.0f);
                naviBarRightItemAddEventImageview.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDrawerLayout.closeDrawer(mDrawerList);
                        AddEventMenuCreator.createLogEventMenuDialog(MainActivity.this, Calendar.getInstance());
                    }
                });
                break;
            case HOME:
                naviBarLayout.setVisibility(View.GONE);
                break;
            case NOTIFICATIONS:
                naviBarTitle.setText(getString(R.string.notifications_2)); /** #3214 */
                hideNaviBarRightTextAndImage();
                break;
            case PLACEMENT_GUIDE:
                naviBarTitle.setText(getString(R.string.placement_guide));
                hideNaviBarRightTextAndImage();
                break;
            case SETTINGS:
                naviBarTitle.setText(getString(R.string.settings));
                hideNaviBarRightTextAndImage();
                break;
            case STATISTICS:
                naviBarTitle.setText(getString(R.string.statistics));
                naviBarLayout.setVisibility(View.VISIBLE);
                // Only show the "Share" Button
                naviBarRightItemTextView.setVisibility(View.GONE);
                naviBarRightItemAddEventImageview.setVisibility(View.VISIBLE);
                naviBarRightItemAddEventImageview.setImageResource(android.R.drawable.ic_menu_share);
                statisticsFragment.setShareButton(naviBarRightItemAddEventImageview);
                naviBarRightItemAddEventImageview.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDrawerLayout.closeDrawer(mDrawerList);
                        statisticsFragment.createShareDialog();
                    }
                });
                break;
            case SHARE_MY_DATA:
                naviBarTitle.setText(getString(R.string.share_my_data));
                hideNaviBarRightTextAndImage();
                break;
            default:
                break;
        }
    }

    public void selectItem(final int position) {
//        Log.d("#3664", "transitFragment from:" + currentMenu + " to:" + position);
//        Log.d("#3664", "1:" + graphFragment + ",2:" + calibrateFragment + ",3:" + eventLogFragment + ",4:" + notificationFragment + ",5:" + connectionStatusFragment + ",6:" + placementGuideFragment + ",7:" + statisticsFragment + ",8:" + aboutFragment + ",9:" + settingsFragment + ",10:" + comingSoonFragment);

        /** Important */
        previousMenu = currentMenu;
        currentMenu = position;

        mDrawerList.setItemChecked(position, true);
        menuAdapter.notifyDataSetChanged();

        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
//            Log.d("#3664", "Should close drawer");
            closeDrawer(); /** transitFragment() would be invoked in onDrawerClosed() callback */
        }
        else {
            transitFragment(position);
//            Log.d("#3664", "Should NOT close drawer");
        }
    }

    private void nullifyPreviousFragment(int oldPosition, int newPosition) {
        if (oldPosition != newPosition) {
//            Log.d("#3664", "nullifyPreviousFragment: old->" + oldPosition + " new->" + newPosition);

            Menu menuItem = menuItems.get(oldPosition);
            MENU_TYPE menuType = (MENU_TYPE) menuItem.getMenuType();

            switch (menuType) {
                case HOME:
                    graphFragment = null;
                    break;
                case CALIBRATE:
                    calibrateFragment = null;
                    break;
                case EVENT_LOG:
                    eventLogFragment = null;
                    break;
                case NOTIFICATIONS:
                    notificationFragment = null;
                    break;
                case CONNECTION_STATUS:
                    connectionStatusFragment = null;
                    break;
                case PLACEMENT_GUIDE:
                    placementGuideFragment = null;
                    break;
                case STATISTICS:
                    statisticsFragment = null;
                    break;
                case ABOUT:
                    aboutFragment = null;
                    break;
                case SETTINGS:
                    settingsFragment = null;
                    break;
                case SHARE_MY_DATA:
                    comingSoonFragment = null;
                    break;
            }
        }
    }

    private void transitFragment(int position) {

        Menu menuItem = menuItems.get(position);
        MENU_TYPE menuType = (MENU_TYPE) menuItem.getMenuType();

        switch (menuType) {
            case HOME:
                if (graphFragment == null) {
                    initGlucoseLevels();
                    graphFragment = new GraphFragment();
                }
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, graphFragment)
                        .commitAllowingStateLoss();
                Utils.initDates(databaseManager.getEarliestEventDate());
                graphFragment.validateGraph();
                break;
            case CALIBRATE:
                if (calibrateFragment == null) {
                    calibrateFragment = new CalibrateFragment();
                    calibrateFragment.setManager(calibrationManager);
                }

                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, calibrateFragment)
                        .commitAllowingStateLoss();
                break;
            case EVENT_LOG:
                if (eventLogFragment == null)
                    eventLogFragment = new EventLogFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, eventLogFragment)
                        .commitAllowingStateLoss();
                break;
            case NOTIFICATIONS:
                if (notificationFragment == null)
                    notificationFragment = new NotificationsFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, notificationFragment)
                        .commitAllowingStateLoss();
                break;
            case CONNECTION_STATUS:
                if (connectionStatusFragment == null)
                    connectionStatusFragment = new BluetoothPairingFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, connectionStatusFragment)
                        .commitAllowingStateLoss();
                break;
            case PLACEMENT_GUIDE:
                if (placementGuideFragment == null)
                    placementGuideFragment = new PlacementGuideFragment();

                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, placementGuideFragment)
                        .commitAllowingStateLoss();
                break;
            case STATISTICS:
                // if (statisticsFragment == null)
                statisticsFragment = new StatisticsFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, statisticsFragment)
                        .commitAllowingStateLoss();
                break;
            case ABOUT:
                if (aboutFragment == null)
                    aboutFragment = new AboutFragment();

                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, aboutFragment)
                        .commitAllowingStateLoss();
                break;

            case SETTINGS:
                if (settingsFragment == null) {
                    settingsFragment = new SettingsFragment();
                    settingsFragment.setManager(settingsManager);
                }

                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, settingsFragment)
                        .commitAllowingStateLoss();
                break;

            case SHARE_MY_DATA:
                if (comingSoonFragment == null)
                    comingSoonFragment = new ComingSoonFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.content_frame, comingSoonFragment)
                        .commitAllowingStateLoss();

                break;
        }
    }

    public void refreshAfterFragmentChanged() {
        updateNavigationBar();
        nullifyPreviousFragment(previousMenu, currentMenu);
    }

    public void closeDrawer() {
        mDrawerLayout.closeDrawer(mDrawerList);
    }

    @Override
    public void setTitle(CharSequence title) {
        // mTitle = title;
        getActionBar().setTitle(title);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggles
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item))
            return true;
        return super.onOptionsItemSelected(item);
    }

    private void updateGraphThresholds() {
        BluetoothUtils.loadSettings(MainActivity.this);
        initGlucoseLevels();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sharedPreferences.contains("current_x")) {
            GraphUtils.viewportStart = sharedPreferences.getFloat("current_x",
                    0);
        }
        dialogUtils.cancelNotification(this, 0);
        // if (GraphUtils.visibleCalendar != null) {
        // GraphUtils.viewportStart = GraphUtils.getPositionX(
        // GraphUtils.getGraphWidth(), Utils.startDate,
        // Utils.endDateFinished, GraphUtils.visibleCalendar);
        // }

        mDrawerList.setItemChecked(currentMenu, true);
        menuAdapter.notifyDataSetChanged();

        updateGraphThresholds();
        // refresh();

        if (currentMenu == MENU_TYPE.HOME.ordinal() && graphFragment != null) {
            Utils.initDates(databaseManager.getEarliestEventDate());
            graphFragment.validateGraph();
        } else if (currentMenu == MENU_TYPE.CALIBRATE.ordinal()
                && calibrateFragment != null) {
            calibrateFragment.nextRequest();
        }

        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        timer = new Timer();
        timer.schedule(new MainTask(), 120000, 120000);

        Log.d("DMS(MainActivity)", "onResume");
        goToLoginPageForeground();
    }

    @Override
    protected void onPause() {
        super.onPause();

        sharedPreferences.edit().putFloat("current_x",
                (float) GraphUtils.viewportStart);

        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Override
    public void onBackPressed() {

        if (currentMenu != 0) {
            selectItem(0);
        } else {
            // functions to avoid exit the application accidently
            // double click the back button to exit the application
            if (doubleBackToExitPressedOnce) {
                setResult(Utils.WELCOME_UNIT_SELECTION_RESULT);

                super.onBackPressed();

                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, R.string.click_twice_back,
                    Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);

        }
    }

    @Override
    public DialogUtils.NotificationDialogManager provideCalibrationDialogManager() {
        NotificationDialogManager manager = new NotificationDialogManager() {

            @Override
            public void rightButtonPressed() {
                selectItem(MENU_TYPE.CALIBRATE.ordinal());
            }

            @Override
            public void leftButtonPressed() {
            }
        };

        return manager;
    }

    public void displayCheckingResult(Utils.MLCheckResult error) {
        String title = "", message = "";
        switch (error) {
            case Timeout:
                title = getString(R.string.request_timeout);
                message = getString(R.string.invalid_error_text);
                break;
            case NotConnectedToWifi:
                title = getString(R.string.wi_fi_disconnected);
                message = getString(R.string.wi_fi_disconnected_text);
                break;
            case ServerError:
                title = getString(R.string.server_error);
                message = getString(R.string.invalid_error_text);
                break;
            case None:
                title = getString(R.string.file_corrupted);
                message = getString(R.string.invalid_error_text);
                break;
            case Unknown:
            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.invalid_error_text);
                break;
        }


        if (this.isThisActivityTop()) {
            if (dialog != null && dialog.isShowing())
                dialog.dismiss();
            dialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
                    title, message));
            dialog.show();
        }
    }

    @Override
    protected void onDestroy() {
        sharedPreferences.edit().remove("current_x");
        GraphUtils.viewportStart = -1;
        super.onDestroy();
    }

    @Deprecated
    //TODO when the static glucoseLevel field is not longer used, remove this reference.
    public void onEventMainThread(ModelChangedEvent event) {
        glucoseLevel = event.getModel().getGlucoseLevel();
        updateGraphThresholds();
    }

    public void onEventMainThread(DismissPlacementGuide event) {
        switchToHomeLocal();
    }

    private boolean ShouldSwitchToConnectionStatus() {
        NotificationDeviceStatus notificationDeviceStatus = (NotificationDeviceStatus)statusBarLayout.findViewById(R.id.device_status);

        if (notificationDeviceStatus.isDisplayingConnectionState()) {
            return true;
        }
        else {
            return false;
        }
    }

    private void SwtichToAppropriatePageByTappingHeader() {
        if (this.ShouldSwitchToConnectionStatus()) {
            this.switchToConnectionStatusLocal();
        }
        else {
            this.switchToNotificationLocal();
        }
    }

    public void onEventMainThread(StatusHeaderTapEvent event) {
        this.SwtichToAppropriatePageByTappingHeader();
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        Transmitter.CONNECTION_STATE currentState = event.getTransmitter().getConnectionState();

        if (currentState != Transmitter.CONNECTION_STATE.CONNECTED) {
            // #2029 Update the side menu depending on connection status
            enableDisableMenu(false);
        } else {
            enableDisableMenu(true);
        }
        super.onEventMainThread(event);
    }

    /** #3628
    public void onEventMainThread(InvalidUserCredentialEvent event) {
        Log.d("DMS(MainActivity)", "InvalidUserCredentialEvent received");
        goToLoginPageForeground();
    }*/

    /** #3160 */
    public void onEventMainThread(TempProfileTurnedOffEvent event) {
        dialogUtils.fireTempProfileTurnedOffPopup(MainActivity.this, true);
    }

    private void goToLoginPageForeground() {
        if (!Utils.checkIfLoggedIn(this) && !Utils.checkIfFirstRun(this)) {
            Intent intent = new Intent(this, UserAccountLoginActivity.class);
            intent.putExtra(accountConstants.FORCE_LOGOUT_BUNDLE_KEY, "true");
            startActivity(intent);
            finish();
        }
    }

    private void switchToHomeLocal() {
        selectItem(MENU_TYPE.HOME.ordinal());
    }

    private void switchToConnectionStatusLocal() {
        selectItem(MENU_TYPE.CONNECTION_STATUS.ordinal());
    }

    private void switchToNotificationLocal() {
        selectItem(MENU_TYPE.NOTIFICATIONS.ordinal());
    }

    @Override
    public void startActivity(Intent intent) {
        startActivityForResult(intent, Utils.TAP_HEADER_BACK_RESULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("Tap switch","MainActivity onActivityResult:"+requestCode+"|"+resultCode);
        if (requestCode == Utils.TAP_HEADER_BACK_RESULT) {
            if(resultCode == RESULT_OK) {
                this.SwtichToAppropriatePageByTappingHeader();
            }
            else if(resultCode == Utils.DAILY_CALIBRATION_SAVE_RESULT) {
                this.switchToHomeLocal();
            }
            else if(resultCode == Utils.LOG_OUT_BACK_RESULT) {
                Log.d("DMS(MainActivity)", "onActivityResult LOG_OUT_BACK_RESULT");
                goToLoginPageForeground();
            }
        }
    }

    @Override
    public ImageButton getRefreshButton() {
        return refreshButton;
    }

    public enum MENU_TYPE {
        HOME,
        CALIBRATE,
        NOTIFICATIONS,
        EVENT_LOG,
        STATISTICS,
        SHARE_MY_DATA,
        PLACEMENT_GUIDE,
        CONNECTION_STATUS,
        SETTINGS,
        ABOUT
    }

    class MainTask extends TimerTask {
        public void run() {
            Utils.initDates(databaseManager.getEarliestEventDate());

            runOnUiThread(new Runnable() {

                @Override
                public void run() {

                    if (graphFragment != null) {
                        graphFragment.validateGraph();

                        /** #3860 */
                        checkStaleData();
                    }

                }
            });
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
//        Log.d("#3640", "MainActivity: onSaveInstanceState");
        super.onSaveInstanceState(outState);
    }

}
