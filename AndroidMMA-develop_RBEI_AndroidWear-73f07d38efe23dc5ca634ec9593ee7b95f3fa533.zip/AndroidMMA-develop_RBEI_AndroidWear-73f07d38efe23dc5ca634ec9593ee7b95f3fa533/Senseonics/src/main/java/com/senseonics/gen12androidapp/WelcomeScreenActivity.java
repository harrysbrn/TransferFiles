package com.senseonics.gen12androidapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;

import com.senseonics.bluetoothle.BluetoothAdapterWrapper;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class WelcomeScreenActivity extends BaseActivity {
	@Inject
	protected BluetoothAdapterWrapper bluetoothAdapterWrapper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.activity_welcome, null),
                parms_content);

        // Configure the status header
        statusBarDrawerButton.setVisibility(View.GONE);

        // Configure the navigation bar
        naviBarTitle.setVisibility(View.VISIBLE);
        naviBarTitle.setText(getResources().getString(R.string.welcome));
        naviBarTitleImageView.setVisibility(View.GONE);
        naviBarLayout.setVisibility(View.VISIBLE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);
        naviBarRightItemTextView.setVisibility(View.GONE);

		Button doHaveSensor = (Button) findViewById(R.id.doHaveSensor);
		if (bluetoothAdapterWrapper.isBluetoothAdapterAvailable()) {
			doHaveSensor.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					startActivityForResult(new Intent(WelcomeScreenActivity.this,
							InitialBluetoothPairingActivity.class), Utils.WELCOME_UNIT_SELECTION_RESULT);
				}
			});
		} else {
			doHaveSensor.setEnabled(false);
			doHaveSensor.setTextColor(getResources().getColor(R.color.gray_light_text));
		}

		Button dontHaveSensor = (Button) findViewById(R.id.dontHaveSensor);
		dontHaveSensor.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
                startActivityForResult(new Intent(WelcomeScreenActivity.this,
                        GlucoseUnitActivity.class), Utils.WELCOME_UNIT_SELECTION_RESULT);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // Result coming back from the unit selection page when the Finish button is pressed
		if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
            setResult(resultCode);
			finish();
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

}
