package com.senseonics.events;

public class ModelChangedTransmitterFirmwareVersionEvent {
    private String transmitterFirmwareVersion;

    public ModelChangedTransmitterFirmwareVersionEvent(String transmitterFirmwareVersionIn){
        this.transmitterFirmwareVersion = transmitterFirmwareVersionIn;
    }

    public String getTransmitterFirmwareVersion() {
        return transmitterFirmwareVersion;
    }
}
