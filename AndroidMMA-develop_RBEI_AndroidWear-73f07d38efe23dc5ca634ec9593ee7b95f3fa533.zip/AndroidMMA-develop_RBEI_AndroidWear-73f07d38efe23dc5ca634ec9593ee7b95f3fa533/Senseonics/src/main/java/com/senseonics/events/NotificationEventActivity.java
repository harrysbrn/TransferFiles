package com.senseonics.events;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BaseActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;
import com.senseonics.util.Utils.TransmitterMessageCode;

import java.util.Calendar;
import java.util.TimeZone;

public class NotificationEventActivity extends BaseActivity {

	protected Calendar currentDate;
	protected EventPoint eventPoint;
	private TextView eventTypeTextView, dateTextView,
			notificationDetailsTextView, notificationECNoTextView;
	private ImageView notificationImageView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.layout_notification_details, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.details);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);	
				
		RelativeLayout topItemLayout = (RelativeLayout) findViewById(R.id.topItemLayout);
		eventTypeTextView = (TextView) findViewById(R.id.eventType);
		dateTextView = (TextView) findViewById(R.id.eventDate);
		notificationDetailsTextView = (TextView) findViewById(R.id.notificationDetails);
		notificationImageView = (ImageView) findViewById(R.id.notificationImageView);
		notificationECNoTextView = (TextView)findViewById(R.id.notificationECNo);
		Bundle extras = getIntent().getExtras();
		if (extras != null) {

			if (currentDate == null) {
				if (extras.containsKey("eventPoint")) {
					eventPoint = (EventPoint) extras
							.getSerializable("eventPoint");
					currentDate = eventPoint.getCalendar();
				}
			}
		}

		if (currentDate == null)
			currentDate = Calendar.getInstance();

		// Get the transmitter name from the event

		if (extras.containsKey("eventPoint")) {
			eventPoint = (EventPoint) extras.getSerializable("eventPoint");

			int iconResID = Utils.getEventImageResId(eventPoint);
			notificationImageView.setImageResource(iconResID);
			EVENT_TYPE eventType = eventPoint.getEventType();
			switch (eventType) {

			case RATE_ALERT_EVENT_FALLING:
			case RATE_ALERT_EVENT_RISING:
				TransmitterMessageCode code = null;
				if (eventType == Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING) {
					code = TransmitterMessageCode.RateFallingAlarm;
				}
				else {
					code = TransmitterMessageCode.RateRisingAlarm;
				}

				eventTypeTextView.setText(getString(Utils.getNotificationDialogMessageTitleStringId(code)) + " " + getString(Utils.getNotificationDialogTypeStringId(code)));
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(code));
				notificationDetailsTextView.setText(Utils.getRateAlertText(this, eventType,transmitterStateModel.getRateAlertFallingThreshold(),transmitterStateModel.getTransmitterName()));

				break;

			case CALIBRATE_NOW_EVENT:
				eventTypeTextView.setText(getString(R.string.calibrate_now_notification_title) + " " + getString(Utils.getNotificationDialogTypeStringId(TransmitterMessageCode.CalibrationRequiredAlarm)));
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(TransmitterMessageCode.CalibrationRequiredAlarm));
				notificationDetailsTextView
						.setText(Utils.replaceCalibrateButtonStringFromString(
								Utils.replaceTransmitterNameFromString(
										getString(R.string.calibrate_now_notification_message), transmitterStateModel.getTransmitterName()), NotificationEventActivity.this));
				break;
			case CALIBRATE_GRACE_EVENT:
				eventTypeTextView.setText(getString(R.string.calibration_grace_alert_title) + " " + getString(Utils.getNotificationDialogTypeStringId(TransmitterMessageCode.CalibrationGracePeriodAlarm)));
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(TransmitterMessageCode.CalibrationGracePeriodAlarm));
				notificationDetailsTextView
						.setText(Utils.replaceCalibrateButtonStringFromString(
								Utils.replaceTransmitterNameFromString(
								getString(R.string.calibration_grace_alert_message), transmitterStateModel.getTransmitterName()), NotificationEventActivity.this));
				break;
				
			case CALIBRATE_EXPIRED_EVENT:
				eventTypeTextView.setText(getString(R.string.calibration_expired_alarm_title) + " " + getString(Utils.getNotificationDialogTypeStringId(TransmitterMessageCode.CalibrationExpiredAlarm)));
				notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(TransmitterMessageCode.CalibrationExpiredAlarm));
				notificationDetailsTextView
						.setText(Utils.replaceCalibrateButtonStringFromString(
								Utils.replaceTransmitterNameFromString(
								getString(R.string.calibration_expired_alarm_message), transmitterStateModel.getTransmitterName()), NotificationEventActivity.this));
				break;
				
			case NOTIFICATION_EVENT_RED:
			case NOTIFICATION_EVENT_YELLOW:		
			case NOTIFICATION_EVENT_BLUE:
				TransmitterMessageCode notificationEventType = eventPoint
						.getNotificationEventType();

				if (notificationEventType != null) {
					int titleId = Utils
							.getNotificationDialogMessageTitleStringId(notificationEventType);
					String title = "";
					if (titleId > 0){
						title = getString(titleId);

						if (titleId == R.string.unknown_error_alert_title)
						{
							int unknowErrorCode = eventPoint.getUnknownErrorCode();
							if(unknowErrorCode != -1)
							{
								title = Utils.replaceUnknownErrorCodeString(NotificationEventActivity.this, title, unknowErrorCode);
							}
						}
					}
					int textId = Utils
							.getNotificationDialogTextStringId(notificationEventType);
					String text = "";
					if (textId > 0)
					{
						text = Utils.replaceTransmitterNameFromString(getString(textId), transmitterStateModel.getTransmitterName());

						// Check if it's out of range glucose alarm
						if(textId == R.string.out_of_range_low_glucose_alarm_message ||
								textId == R.string.out_of_range_high_glucose_alarm_message)
						{
							text = Utils.replaceOutOfRangeThresholdString(NotificationEventActivity.this, text, textId);
						}
					}

					eventTypeTextView.setText(title + " " + getString(Utils.getNotificationDialogTypeStringId(notificationEventType)));
					notificationECNoTextView.setText(Utils.getEnumIndexTransmitterMessageCode(notificationEventType));
					notificationDetailsTextView.setText(text);
				}
				break;
			default:
				break;
			}

			if (dateTextView != null)
				dateTextView.setText(Utils.formatWeekDateTimeForTimeZone(currentDate, TimeZone.getDefault(),NotificationEventActivity.this));
		}

	}

	public void createDialog(String text) {
		final Dialog dialog = new Dialog(NotificationEventActivity.this,
				R.style.PickerDialog);

		LayoutInflater inflater = LayoutInflater
				.from(NotificationEventActivity.this);
		View view = inflater.inflate(R.layout.dialog, null);

		TextView textView = (TextView) view.findViewById(R.id.textView);
		textView.setText(text);

		TextView cancelText = (TextView) view.findViewById(R.id.cancel);
		cancelText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		TextView okText = (TextView) view.findViewById(R.id.ok);
		okText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
				databaseManager.deleteEvent(eventPoint);
				Intent intent = new Intent();
				setResult(MainActivity.RESULT_DELETED, intent);
				NotificationEventActivity.this.finish();
			}
		});

		dialog.setContentView(view);
		dialog.show();
	}

}
