package com.senseonics.graph.events;

import com.senseonics.events.EventPoint;
import com.senseonics.graph.util.Glucose;
import java.util.List;

public class GraphCacheEvent {
  public final List<List<Glucose>> glucoseValues;
  public final List<EventPoint> events;
  public final boolean newStartEndDates;

  public GraphCacheEvent(List<List<Glucose>> glucoseValues, List<EventPoint> events,
      boolean newStartEndDates) {
    this.glucoseValues = glucoseValues;
    this.events = events;
    this.newStartEndDates = newStartEndDates;
  }
}
