package com.senseonics.bluetoothle.event;

import android.bluetooth.BluetoothDevice;

public class BluetoothGattErrorEvent {
    private final BluetoothDevice bluetoothDevice;

    public BluetoothGattErrorEvent(BluetoothDevice bluetoothDevice) {
        this.bluetoothDevice = bluetoothDevice;
    }

    public BluetoothDevice getBluetoothDevice() {
        return this.bluetoothDevice;
    }
}
