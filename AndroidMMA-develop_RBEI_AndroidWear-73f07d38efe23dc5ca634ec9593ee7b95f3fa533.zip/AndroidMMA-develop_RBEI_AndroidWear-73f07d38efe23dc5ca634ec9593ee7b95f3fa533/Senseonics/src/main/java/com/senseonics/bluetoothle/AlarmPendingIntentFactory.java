package com.senseonics.bluetoothle;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.senseonics.util.AlarmReceiver;

import javax.inject.Inject;
import javax.inject.Singleton;

import static android.app.PendingIntent.FLAG_ONE_SHOT;

@Singleton
public class AlarmPendingIntentFactory {
    @Inject
    public AlarmPendingIntentFactory() {
    }

    public PendingIntent createAlarmPendingIntent(Context context) {
        return PendingIntent.getBroadcast(context, 54127, new Intent(context, AlarmReceiver.class), FLAG_ONE_SHOT);
    }
}
