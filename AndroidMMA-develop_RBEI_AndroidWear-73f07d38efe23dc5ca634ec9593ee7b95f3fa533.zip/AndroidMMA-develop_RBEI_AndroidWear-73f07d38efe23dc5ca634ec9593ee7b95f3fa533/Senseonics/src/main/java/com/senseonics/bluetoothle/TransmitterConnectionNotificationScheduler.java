package com.senseonics.bluetoothle;

import android.util.Log;

import com.senseonics.events.ActivityOnResumeEvent;
import com.senseonics.util.NotificationEventPersistor;
import com.senseonics.util.NotificationUtility;

import java.util.Timer;
import java.util.TimerTask;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

import static com.senseonics.bluetoothle.Transmitter.CONNECTION_STATE.CONNECTED;
import static com.senseonics.bluetoothle.Transmitter.CONNECTION_STATE.DISCONNECTED;
import static com.senseonics.util.Utils.TransmitterMessageCode.TransmitterDisconnected;

@Singleton public class TransmitterConnectionNotificationScheduler {
    private final String TAG = getClass().toString();
    private Timer timer;
    public Transmitter.CONNECTION_STATE lastState;
    private final NotificationUtility notificationUtility;
    private NotificationEventPersistor notificationEventPersistor;
    private ApplicationForegroundState applicationForegroundState;
    private Provider<Timer> timerProvider;
    private final long initialInterval;
    private long followupInterval;
    private long disconnectExpiryPeriod;

    @Inject public TransmitterConnectionNotificationScheduler(EventBus eventBus,
                                                              NotificationUtility notificationUtility,
                                                              NotificationEventPersistor notificationEventPersistor, Provider<Timer> timerProvider,
                                                              ApplicationForegroundState applicationForegroundState,
                                                              @Named("DISCONNECT_INTERVAL_INITIAL") long initialInterval,
                                                              @Named("DISCONNECT_INTERVAL_FOLLOWUP") long followupDisconnectInterval,
                                                              @Named("DISCONNECT_EXPIRY_PERIOD") long disconnectExpiryPeriod) {
        this.lastState = DISCONNECTED;
        this.notificationUtility = notificationUtility;
        this.notificationEventPersistor = notificationEventPersistor;
        this.timerProvider = timerProvider;
        this.applicationForegroundState = applicationForegroundState;
        this.initialInterval = initialInterval;
        this.followupInterval = followupDisconnectInterval;
        this.disconnectExpiryPeriod = disconnectExpiryPeriod;
        this.timer = timerProvider.get();
        eventBus.register(this);
        Log.i(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "ctor " + toString());
    }

    public void onEvent(TransmitterConnectionEvent event) {
        Transmitter.CONNECTION_STATE newState = event.getTransmitter().getConnectionState();
//    Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "onEvent:" + newState);
        if (newState != CONNECTED) {
            transmitterGotDisconnected();
        }
        else {
            transmitterGotConnected();
        }
    }

    public void onEvent(ActivityOnResumeEvent event) {
        cancelTimer();
    }

    private void transmitterGotDisconnected() {
//    Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "GotDisconnected -> last state :" + lastState);
        if (lastState == CONNECTED) {
//      Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "isForeground? -> " + applicationForegroundState.isForeground());
            if (!applicationForegroundState.isForeground()) {
                Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(),
                        "registering upon disconnect " + toString());
                if (timer != null) {
                    cancelTimer();
                }
                timer = null;
                timer = timerProvider.get();
//        Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), ">>>> schedule <<<< " + timer);
                timer.schedule(new FireDisconnectNotificationTimerTask(), initialInterval);
                timer.schedule(new FireDisconnectNotificationTimerTask(), followupInterval, followupInterval);
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        cancelTimer();
                    }
                }, disconnectExpiryPeriod);
            }
        }
        lastState = DISCONNECTED;
    }

    private void transmitterGotConnected() {
//    Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "GotConnected");
        cancelTimer();
        notificationUtility.cancelNotification(TransmitterDisconnected);
        lastState = CONNECTED;
    }

    private void fireDisconnectionNotification() {
        if (!applicationForegroundState.isForeground()) {
//      Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "---- real fire ----");
            notificationUtility.createNotificationFromEvent(TransmitterDisconnected);
            notificationEventPersistor.createDisconnectedNotificationEventPoint();
        }
        else {
//      Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "---- cancel fire ----");
            cancelTimer();
        }
    }

    private void cancelTimer() {
        try {
//      Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "##### cancel timer #####");
            timer.cancel();
        } catch (Exception e) {
            Log.e(TAG, "Canceling non-existent timer", e);
        }
    }

    private class FireDisconnectNotificationTimerTask extends TimerTask {
        public void run() {
//      Log.d(TransmitterConnectionNotificationScheduler.class.getSimpleName(), "---- fire ----");
            fireDisconnectionNotification();
        }
    }
}