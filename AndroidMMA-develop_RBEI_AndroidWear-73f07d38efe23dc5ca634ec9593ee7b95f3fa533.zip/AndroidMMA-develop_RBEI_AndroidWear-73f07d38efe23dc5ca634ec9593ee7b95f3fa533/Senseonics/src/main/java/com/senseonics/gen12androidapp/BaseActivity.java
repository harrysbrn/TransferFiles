package com.senseonics.gen12androidapp;

import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.events.AlertOrAlarmEvent;
import com.senseonics.events.CalibrationRequestEvent;
import com.senseonics.events.NotificationDialogEvent;
import com.senseonics.events.PredictiveRateAlertEvent;
import com.senseonics.events.RateAlertEvent;
import com.senseonics.events.StatusHeaderTapEvent;
import com.senseonics.events.TempProfileTurnedOffEvent;
import com.senseonics.util.Utils;

import java.util.List;

public class BaseActivity extends BluetoothPairBaseActivity implements ServiceActivity, ActivityWithNavigationBar  {

	protected static boolean activityPaused = false;
	private boolean isOnCreate = false;
	// Status bar items
	public static LinearLayout statusBarLayout;
	public static ImageView statusBarDrawerButton;
	public static ImageView statusBarImageView;
	public static TextView statusBarTextView;

	// Navigation bar items
	public static RelativeLayout naviBarLayout;
    public static TextView naviBarTitle;
    public static ImageView naviBarTitleImageView;
    public static TextView naviBarLeftItemTextView;
    public static TextView naviBarRightItemTextView;
	private ImageButton refreshButton;
	public static ImageView naviBarRightItemAddEventImageview;

    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.base_activity_layout);

        // Get the device screen size
        Utils.setScreenWidthandHeight(BaseActivity.this);

		ActionBar actionBar = getActionBar();
		if (actionBar != null) {
			actionBar.setDisplayHomeAsUpEnabled(true);
			actionBar.setHomeButtonEnabled(true);
			actionBar.hide();
		}

		// Disable the transition
		overridePendingTransition(0, 0);

		//registerReceiver(broadcastReceiver, makeIntentFilter());
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                highPriorityRequestFinished();
            }
        };
        registerReceiver(broadcastReceiver, makeIntentFilter());// new IntentFilter(Utils.HIGH_PRIOR_REQUEST_DONE));

		/* Setup the status bar*/
		statusBarLayout = (LinearLayout)findViewById(R.id.alertView_base);
		statusBarLayout.setBackgroundColor(Color.CYAN);

		statusBarDrawerButton = (ImageView)findViewById(R.id.drawerImageButton);
		statusBarDrawerButton.setImageResource(R.drawable.ic_back);
		statusBarDrawerButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		statusBarImageView = (ImageView) statusBarLayout
				.findViewById(R.id.imageView);
		statusBarTextView = (TextView) statusBarLayout
				.findViewById(R.id.textView);
		statusBarLayout.setBackgroundColor(getResources().getColor(
				R.color.black));//notification_gray));
		statusBarTextView.setTextColor(getResources().getColor(R.color.graph_white));

		final TypedArray styledAttributes = getTheme()
				.obtainStyledAttributes(
                        new int[]{android.R.attr.actionBarSize});
		int mActionBarSize = (int) styledAttributes.getDimension(0, 0);
		styledAttributes.recycle();
		Log.d("Actionbar", "height: " + mActionBarSize);

		LinearLayout.LayoutParams parms_statusBar = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,mActionBarSize);
		statusBarLayout.setLayoutParams(parms_statusBar);
		
		/* Setup the navigation bar*/
		naviBarLayout = (RelativeLayout)findViewById(R.id.navigationBar_base);
		naviBarTitle = (TextView)findViewById(R.id.navBarTitle);
        naviBarTitleImageView = (ImageView)findViewById(R.id.navBarTitleImageView);
		naviBarLeftItemTextView = (TextView)findViewById(R.id.navBarLeftItemTextView);
		naviBarRightItemTextView = (TextView)findViewById(R.id.navBarRightItemTextView);
		refreshButton = (ImageButton) findViewById(R.id.refreshButton);
		naviBarRightItemAddEventImageview = (ImageView)findViewById(R.id.navBarRightItemImageView);
		int naviBarHeight = Utils.screenHeight * 27 / 100 / 4;

		LinearLayout.LayoutParams parms_naviBar = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,naviBarHeight);
		naviBarLayout.setLayoutParams(parms_naviBar);

		Log.d("BaseActOnCreate","1");

		isOnCreate = true;
	}

	public IntentFilter makeIntentFilter() {
		final IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Utils.CONNECTED_INTENT_FILTER);
		intentFilter.addAction(Utils.DISCONNECTED_INTENT_FILTER);
		intentFilter.addAction(Utils.WARNING_DIALOG_INTENT_FILTER);
		intentFilter.addAction(Utils.TIME_ZONE_CHANGED);
		intentFilter.addAction(Utils.SENSOR_REPLACEMENT_INTENT_FILTER);
		intentFilter.addAction(Utils.BATTERY_LOW_INTENT_FILTER);
        intentFilter.addAction(Utils.MY_TRANSMITTER_INFO_ARRIVED);
        intentFilter.addAction(Utils.UNLINKED_SENSOR_SERIAL_NUMBER_ARRIVED);

		return intentFilter;
	}

	@Override
	public ImageButton getRefreshButton() {
		return refreshButton;
	}

	public void highPriorityRequestFinished() {
        dialogUtils.showDialogs(BaseActivity.this);
	}

	public void connectionStateChanged() {
	}

	public void refreshNotifications(Activity activity) {
        if (activity instanceof NotificationsActivity) {
            ((NotificationsActivity) activity).refresh();
        }
    }

	@Override
	protected boolean isThisActivityTop() {
		super.isThisActivityTop();

		ActivityManager am = (ActivityManager) BaseActivity.this
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<ActivityManager.RunningTaskInfo> alltasks = am.getRunningTasks(1);

		for (ActivityManager.RunningTaskInfo task : alltasks) {

			// if (task.numRunning == 2)
			// return true;

			Log.d("topActivity -----",
					task.numRunning + " " + BaseActivity.this.getTaskId() + " "
							+ task.topActivity.getClassName() + " ");

			if (task.topActivity.getClassName().equals(
					BaseActivity.this.getClass().getName())) {
				Log.d("top", "true");
				return true;
			}
		}
		return false;
	}

    @Override
    public BluetoothService getService() {
        return ((SenseonicsApplication)getApplication()).getBluetoothServiceClient().getService();
    }

    @Override
	protected void onResume() {
		super.onResume();
		activityPaused = false;


		if (BluetoothUtils.mConnected ) {
			// Fire do not disturb
			if (isOnCreate == false) {
				if (isThisActivityTop()) {
//                    dialogUtils.fireDoNotDisturbAlertDialog(this, !transmitterStateModel.isVibrateMode());
				}
			}
			else
			{
				isOnCreate = false;
			}
		}

        dialogUtils.cancelNotification(this, 0);

		if((this instanceof UserAccountLoginActivity) == false) {
			if (!Utils.checkIfLoggedIn(this) && !Utils.checkIfFirstRun(this)) {
				Log.d("DMS(BaseActivity)", "onResume NOT log in");
				setResult(Utils.LOG_OUT_BACK_RESULT);
				finish();
			}
		}
	}

	@Override
	protected void onPause() {
		// Disable the transition
		overridePendingTransition(0, 0);
		activityPaused = true;
		super.onPause();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private ViewGroup setContentViewWithWrapper(int resContent, int progressBarHeight) {
		ViewGroup decorView = (ViewGroup) this.getWindow().getDecorView();
		ViewGroup decorChild = (ViewGroup) decorView.getChildAt(0);

		// Removing decorChild, we'll add it back soon
		decorView.removeAllViews();

		ViewGroup wrapperView = new FrameLayout(this);

		FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.MATCH_PARENT);

		params.topMargin = progressBarHeight;
		params.gravity = Gravity.TOP;
		decorChild.setId(R.id.DECOR_CHILD);
		wrapperView.addView(decorChild, params);
		wrapperView.setId(R.id.ACTIVITY_LAYOUT_WRAPPER);
		decorView.addView(wrapperView, LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);

		return wrapperView;
	}

	@Override
	public void onBackPressed() {
		//TODO this method is an antipattern.  There is no need to "finish" here.
		finish();
	}

    public void onEventMainThread(CalibrationRequestEvent event) {
        dialogUtils.createCalibrateDialogInfo(BaseActivity.this, event.getEventPoint(), event.getNotificationId());
        refreshNotifications(BaseActivity.this);
    }

	public void onEventMainThread(RateAlertEvent event) {
		super.onEventMainThread(event);
		refreshNotifications(this);
	}

	public void onEventMainThread(PredictiveRateAlertEvent event) {
		super.onEventMainThread(event);
		refreshNotifications(this);
	}

	public void onEventMainThread(AlertOrAlarmEvent event) {
		super.onEventMainThread(event);
		refreshNotifications(this);
	}

	@Override
	public void onEventMainThread(NotificationDialogEvent event) {
		super.onEventMainThread(event);
		refreshNotifications(this);
	}

	public void onEventMainThread(StatusHeaderTapEvent event) {
		setResult(RESULT_OK);
		this.finish();
	}

	/** #3628
	public void onEventMainThread(InvalidUserCredentialEvent event) {
		if((this instanceof UserAccountLoginActivity) == false) {
			Log.d("DMS(BaseActivity)", "InvalidUserCredentialEvent received");
			setResult(Utils.LOG_OUT_BACK_RESULT);
			finish();
		}
	}*/

	/** #3160 */
	public void onEventMainThread(TempProfileTurnedOffEvent event) {
		dialogUtils.fireTempProfileTurnedOffPopup(BaseActivity.this, true);
	}

	@Override
	public DialogUtils.NotificationDialogManager provideCalibrationDialogManager() {
		DialogUtils.NotificationDialogManager manager = new DialogUtils.NotificationDialogManager() {

			@Override
			public void rightButtonPressed() {
				startActivity(new Intent(BaseActivity.this,
						CalibrateActivity.class));
			}

			@Override
			public void leftButtonPressed() {
			}
		};

		return manager;
	}

	@Override
	protected void onDestroy() {
        unregisterReceiver(broadcastReceiver);
		super.onDestroy();
	}

	@Override
	public void startActivity(Intent intent) {
		startActivityForResult(intent, Utils.TAP_HEADER_BACK_RESULT);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == Utils.TAP_HEADER_BACK_RESULT) {
			if(resultCode == RESULT_OK) {
				setResult(RESULT_OK);
				finish();
			}
			else if(resultCode == Utils.LOG_OUT_BACK_RESULT) {
				if((this instanceof UserAccountLoginActivity) == false) {
					setResult(Utils.LOG_OUT_BACK_RESULT);
					finish();
				}
			}
		}
	}

    protected BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();

			boolean activityIsTop = isThisActivityTop();
			Log.d(" name ", BaseActivity.this.getClass().getName() + " "
					+ activityIsTop);
			Log.d("BROADCAST EVENT", action);

			if (Utils.CONNECTED_INTENT_FILTER.equals(action)) {
				connectionStateChanged();
			} else if (Utils.DISCONNECTED_INTENT_FILTER.equals(action)) {
				connectionStateChanged();
			} else if (Utils.WARNING_DIALOG_INTENT_FILTER.equals(action)
					&& activityIsTop) {
				Bundle bundle = intent.getExtras();
				if (bundle != null && bundle.containsKey("title")
						&& bundle.containsKey("text")) {
					String title = bundle.getString("title");
					String text = bundle.getString("text");
                    dialogUtils.createWarningDialogInfo(BaseActivity.this, -1, title,
							text);
				}
			}  else if (Utils.TIME_ZONE_CHANGED.equals(action)) {
                dialogUtils.createTimeZoneChangedDialogInfo(BaseActivity.this);
			}
        }
    };

}
