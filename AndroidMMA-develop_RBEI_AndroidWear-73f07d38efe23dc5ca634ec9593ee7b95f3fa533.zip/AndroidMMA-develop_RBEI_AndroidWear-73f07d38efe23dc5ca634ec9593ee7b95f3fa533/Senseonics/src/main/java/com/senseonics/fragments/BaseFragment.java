package com.senseonics.fragments;

import android.app.Fragment;
import android.os.Bundle;

import com.senseonics.gen12androidapp.ObjectGraphActivity;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.AlarmRingtoneManager;
import com.senseonics.util.BlindedGlucoseCauseIdentifier;
import com.senseonics.bluetoothle.TempProfileManager;

import javax.inject.Inject;

public class BaseFragment extends Fragment {
    @Inject
    protected TransmitterStateModel transmitterStateModel;
    @Inject
    protected BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier;
    @Inject
    protected DialogUtils dialogUtils;
    @Inject
    protected AccountConstants accountConstants;
    @Inject
    protected AlarmRingtoneManager alarmRingtoneManager;
    @Inject
    protected TempProfileManager tempProfileManager; /** #3160 */

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((ObjectGraphActivity) getActivity()).inject(this);
    }

}
