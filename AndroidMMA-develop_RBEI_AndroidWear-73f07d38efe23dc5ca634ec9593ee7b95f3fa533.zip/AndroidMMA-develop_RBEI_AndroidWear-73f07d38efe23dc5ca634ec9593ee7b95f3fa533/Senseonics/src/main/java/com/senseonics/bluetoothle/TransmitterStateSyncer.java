package com.senseonics.bluetoothle;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class TransmitterStateSyncer {
    private BluetoothService bluetoothService;
    private SharedPreferences sharedPreferences;
    private TransmitterStateModel transmitterStateModel;
    private Context context;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;
    private boolean waitingForLastResponse = true;

    @Inject
    public TransmitterStateSyncer(BluetoothService bluetoothService, SharedPreferences sharedPreferences, TransmitterStateModel transmitterStateModel, Context contextIn, BluetoothServiceCommandClient bluetoothServiceCommandClient) {
        this.bluetoothService = bluetoothService;
        this.sharedPreferences = sharedPreferences;
        this.transmitterStateModel = transmitterStateModel;
        this.context = contextIn;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
    }

    /**
     * @param commandId of the last command sent
     * @return true only once until #syncTransmitterState() is called again
     */
    public boolean isTransmitterSynced(int commandId, boolean isTimeoutCommand) {
        if(waitingForLastResponse && isGlucoseDataRequest(commandId)) {
            waitingForLastResponse = false;

            /** #3635 Sync Date and Time after State Sync completes */
            if (!isTimeoutCommand) {
                Log.d("TimeChange", "isTransmitterSynced:" + true + "|service:" + bluetoothService);
                if (bluetoothServiceCommandClient != null) {
//                    Log.d("#3734", TransmitterStateSyncer.class.getSimpleName() + ": isTransmitterSynced()");

                    /** Set the transmitter time in state to 0 upon a reconnection */
                    transmitterStateModel.setTransmitterTime(0L);
                    transmitterStateModel.adjustLastReadDateTimeWhenSendingReadCommand();
                    bluetoothServiceCommandClient.postReadCurrentTransmitterDateAndTime();
                }
            }

            return true;
        }

        return false;
    }

    public void syncTransmitterState() {
        waitingForLastResponse = true;
        syncWholeTransmitterState();
    }

    public void syncTransmitterStateUponReconnect() {
        waitingForLastResponse = true;
        // always sync the whole Transmitter state upon auto-reconnection
        syncWholeTransmitterState();
    }

    private void syncWholeTransmitterState() {
        // Daily Calibration times: write values in SharedPreference to Transmitter (iOS)
        /** #4080 */
        int morningLocalHour = transmitterStateModel.getMorningCalibrationLocalTimeHour();
        int morningLocalMinute = transmitterStateModel.getMorningCalibrationLocalTimeMinute();
        if (morningLocalHour != -1 && morningLocalMinute != -1) {
            int[] morningGMT = Utils.convertHourFromLocaltoGMT(morningLocalHour, morningLocalMinute);
            bluetoothService.postWriteMorningCalibrationTime(morningGMT[0], morningGMT[1]);
        }
        else {
            bluetoothService.postWriteMorningCalibrationTime(transmitterStateModel.getMorningCalibrationTimeHour(), transmitterStateModel.getMorningCalibrationTimeMinute());
        }

        int eveningLocalHour = transmitterStateModel.getEveningCalibrationLocalTimeHour();
        int eveningLocalMinute = transmitterStateModel.getEveningCalibrationLocalTimeMinute();
        if (eveningLocalHour != -1 && eveningLocalMinute != -1) {
            int[] eveningGMT = Utils.convertHourFromLocaltoGMT(eveningLocalHour, eveningLocalMinute);
            bluetoothService.postWriteEveningCalibrationTime(eveningGMT[0], eveningGMT[1]);
        }
        else {
            bluetoothService.postWriteEveningCalibrationTime(transmitterStateModel.getEveningCalibrationTimeHour(), transmitterStateModel.getEveningCalibrationTimeMinute());
        }

        // Set locally stored day and night start time
        bluetoothService.postDayStartTime(transmitterStateModel.getDayStartTimeHour(), transmitterStateModel.getDayStartTimeMinute());
        bluetoothService.postNightStartTime(transmitterStateModel.getNightStartTimeHour(), transmitterStateModel.getNightStartTimeMinute());

        // Transmitter Info
        bluetoothService.postPingRequest();
        bluetoothService.postGetModelRequest();
        bluetoothService.postVersionNumberRequest();
        bluetoothService.postLastCalibrationDateTimeRequest();
        bluetoothService.postPhaseStartDateTimeRequest();
        bluetoothService.postCurrentCalibrationPhaseRequest();
        bluetoothService.postCompletedCalibrationsCountRequest();
        bluetoothService.postHysteresisPercentRequest();
        bluetoothService.postHysteresisValueRequest();
        bluetoothService.postPredictiveHysteresisPercentRequest();
        bluetoothService.postPredictiveHysteresisValueRequest();
        // #2605 Read algorithm file version upon connection
        transmitterStateModel.setAlgorithmParameterFormatVersion(0); /** set to 0 here in case the register does not exist */
        bluetoothService.postAlgorithmParameterFormatVersion();

        // #2936
        bluetoothService.postMEPMSPInfo();

        // #2379
        bluetoothService.postGlucoseAlarmRepeatIntervalAndStartTime();

        // Sensor Info
        bluetoothService.postLinkedSensorId();
        bluetoothService.postReadUnlinkedSensorIdRequest();
        bluetoothService.postSensorInsertionDate();
        bluetoothService.postSensorInsertionTime();

        bluetoothService.postReadClinicalModeRequest();

        bluetoothService.postReadVibrateModeRequest();

        /** #3724 Moved to isTransmitterSynced() */
//        // Sync Date and Time
//        bluetoothService.postReadCurrentTransmitterDateAndTime();
//        if (transmitterStateModel != null && transmitterStateModel.couldWriteTransmitterDateTime()) {
//            bluetoothService.postSendCurrentDateAndTimeToTransmitter();
//        }

        /** Write app version to the Transmitter */
        String appVersion = getAppVersion();
        Log.d("AppVersion", "StateSyncer:" + appVersion);
        if (isValidAppVersion(appVersion)) {
            bluetoothService.postWriteAppVersion(appVersion);
        }

        // Sampling Interval
        bluetoothService.postSensorGlucoseSamplingInterval();

        // Calibration Times
        bluetoothService.postReadMorningCalibrationTime();
        bluetoothService.postReadEveningCalibrationTime();

        // Get the current active alerts
        bluetoothService.postReadSensorGlucoseAlertsAndStatus();

        // Get the min and max calibration thresholds
        bluetoothService.postCalibrationTresholds();

        // Read Glucose Settings
        // Target
        bluetoothService.postReadHighGlucoseTargetRequest();
        bluetoothService.postReadLowGlucoseTargetRequest();

        // Alarm
        bluetoothService.postReadHighGlucoseAlarmRequest();
        bluetoothService.postReadLowGlucoseAlarmRequest();

        // Predictive alert: always read value from Transmitter
        bluetoothService.postReadPredictiveAlertsRequest();
        bluetoothService.postReadPredictiveTimeIntervalRequest();
        // Rate alert: always read value from Transmitter
        bluetoothService.postReadRateAlert();
        bluetoothService.postReadRateAlertThresholdRequest();

        bluetoothService.postReadSignalStrengthRequest();
        bluetoothService.postBatteryLifeRequest();

        /** #3194 */
        bluetoothService.postReadRawDataValues();
        bluetoothService.postReadGlucoseData();
    }

    private boolean isGlucoseDataRequest(int commandId) {
        return commandId == CommandAndResponseIDs.ReadSensorGlucoseCommandID;
    }

    private String getAppVersion() {
        String appVersion = "";

        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager != null) {
                appVersion = packageManager.getPackageInfo(context.getPackageName(), 0).versionName;
            }
        }
        catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return appVersion;
    }

    private boolean isValidAppVersion(String version) {
        boolean retVal = true;

        String[] versionSplit = version.split("\\.");

        if (versionSplit.length != 3) { // not in format X.Y.Z
            retVal = false;
            Log.d("AppVersion", "invalid 1: length=" + versionSplit.length);
        }
        else {
            String x_str = versionSplit[0];
            String y_str = versionSplit[1];
            String z_str = versionSplit[2];

            int x = 0;
            int y = 0;
            int z = 0;

            try {
                x = Integer.parseInt(x_str);
                y = Integer.parseInt(y_str);
                z = Integer.parseInt(z_str);
            }
            catch (NumberFormatException ex) {
                Log.d("AppVersion", "NumberFormatException:" + ex.getMessage());
                retVal = false;
                Log.d("AppVersion", "invalid 2");
            }

            if (retVal == true) { // check valid ranges
                if ((x<0) || (x>255)) {
                    retVal = false;
                    Log.d("AppVersion", "invalid 3");
                }

                if ((y<0) || (y>255)) {
                    retVal = false;
                    Log.d("AppVersion", "invalid 4");
                }

                if ((z<0) || (z>65535)) {
                    retVal = false;
                    Log.d("AppVersion", "invalid 5");
                }
            }
        }

        Log.d("AppVersion", "valid check:" + retVal);
        return retVal;
    }
}
