package com.senseonics.bluetoothle;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

import javax.inject.Inject;

public class CommandProcessor {

    public static final String PUSH_NOTIFICATION_MESSAGE_CODE = "PushNotificationMessageCode";
    public static final String MILLIS = "milliseconds";
    public static final String GLUCOSE_LEVEL = "glucose level";
    public static final String EVENT_TYPE_ID = "event type id";
    public static final String EVENT_SUB_TYPE_ID = "event sub type id";
    public static final String EVENT_QUANTITY = "event quantity";
    public static final String IS_CLINICAL_MODE = "is clinical mode";
    public static final String RECORD_NUMBER = "record number";
    public static final String EXPECTED_RESPONSE_ID = "expected response id";
    public static final String DATA = "data";
    public static final String EXPECTED_RESPONSE_COUNT = "expected response count";
    public static final String TARGET_LOW_VALUE = "target low value";
    public static final String TARGET_HIGH_VALUE = "target high value";
    public static final String ALARM_LOW_VALUE = "alarm low value";
    public static final String ALARM_HIGH_VALUE = "alarm high value";
    /** #4080 */
    public static final String CALIBRATION_HOUR = "calibration hour";
    public static final String CALIBRATION_MINUTE = "calibration minute";

    public enum COMMAND {
        READ_CLINCAL_MODE_DURATION {
            @Override
            public Request generate(Bundle extras) {
                int expectedResponseId = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterResponseID;
                int[] data = CommandOperations.operationToReadTwoByteSerialFlashRegister(MemoryMap.clinicalModeDuration);
                return new Request(expectedResponseId, data);
            }
        },
        SNOOZE {
            @Override
            public Request generate(Bundle extras) {
                int messageCode = extras.getInt(PUSH_NOTIFICATION_MESSAGE_CODE);
                int expectResponseId = CommandAndResponseIDs.AssertSnoozeAgainsAlarmResponseID;
                int[] data = CommandOperations.operationToAssertSnoozeAgainstAlarm(messageCode);
                return new Request(expectResponseId, data);
            }
        }, WRITE_GLUCOSE_EVENT_POINT {
            @Override
            public Request generate(Bundle extras) {
                int glucoseLevel = extras.getInt(GLUCOSE_LEVEL);
                long millis = extras.getLong(MILLIS);
                return Request.writeGlucosePatientEvent(millis, glucoseLevel);
            }
        }, WRITE_PATIENT_EVENT_POINT {
            @Override
            public Request generate(Bundle extras) {
                long millis = extras.getLong(MILLIS);
                int eventTypeId = extras.getInt(EVENT_TYPE_ID);
                int eventSubType = extras.getInt(EVENT_SUB_TYPE_ID);
                int quantity = extras.getInt(EVENT_QUANTITY);
                return Request.writePatientEvent(millis, eventTypeId, eventSubType, quantity);
            }
        }, WRITE_CLINICAL_MODE {
            @Override
            public Request generate(Bundle extras) {
                return Request.writeClinicalModeRequest(extras.getBoolean(IS_CLINICAL_MODE));
            }
        }, MARK_PATIENT_EVENT_RECORD_DELETED {
            @Override
            public Request generate(Bundle extras) {
                return Request.markPatientEventRecordAsDeleted(extras.getInt(RECORD_NUMBER));
            }
        }, SYNC {
            @Override
            public Request generate(Bundle extras) {
                int responseId = extras.getInt(EXPECTED_RESPONSE_ID);
                int[] data = extras.getIntArray(DATA);
                int recordNumber = extras.getInt(RECORD_NUMBER);
                int responseCount = extras.getInt(EXPECTED_RESPONSE_COUNT);

                return new Request(responseId, data, recordNumber, responseCount, Request.SYNC_PRIORITY);
            }
        }, READ_GLUCOSE_DATA {
            @Override
            public Request generate(Bundle extras) {
                return Request.readGlucoseData();
            }
        }, READ_CURRENT_TRANSMITTER_DATE_TIME {
            @Override
            public Request generate(Bundle extras) {
                return Request.readCurrentTransmitterDateAndTime();
            }
        },SEND_CURRENT_DATE_TIME_TO_TRANSMITTER {
            @Override
            public Request generate(Bundle extras) {
                return Request.sendCurrentDateAndTimeToTransmitter();
            }
        },  READ_MEP_SAVED_VALUE {
            @Override
            public Request generate(Bundle extras) {
                return Request.readMEPSavedValue();
            }
        },  READ_MEP_SAVED_REF_CHANNEL_METRIC {
            @Override
            public Request generate(Bundle extras) {
                return Request.readMEPSavedRefChannelMetric();
            }
        },  READ_MEP_SAVED_DRIFT_METRIC {
            @Override
            public Request generate(Bundle extras) {
                return Request.readMEPSavedDriftMetric();
            }
        },  READ_MEP_SAVED_LOW_REF_METRIC {
            @Override
            public Request generate(Bundle extras) {
                return Request.readMEPSavedLowRefMetric();
            }
        },  READ_MEP_SAVED_SPIKE {
            @Override
            public Request generate(Bundle extras) {
                return Request.readMEPSavedSpike();
            }
        },  READ_EEP24_MSP {
            @Override
            public Request generate(Bundle extras) {
                return Request.readEEP24MSP();
            }
        },  READ_SENSOR_GLUCOSE_RANGE {
            @Override
            public Request generate(Bundle extras) {
                return Request.readFirstAndLastSensorGlucoseRecordNumbers();
            }
        },  READ_GLUCOSE_ALERT_RANGE {
            @Override
            public Request generate(Bundle extras) {
                return Request.readFirstAndLastSensorGlucoseAlertRecordNumbers();
            }
        },  READ_BLOOD_GLUCOSE_RANGE {
            @Override
            public Request generate(Bundle extras) {
                return Request.readFirstAndLastBloodGlucoseDataRecordNumber();
            }
		},  WRITE_LOW_TARGET { /** #3160 */
            @Override
            public Request generate(Bundle extras) {
                return Request.writeLowGlucoseTargetRequest(extras.getInt(TARGET_LOW_VALUE));
            }
        }, WRITE_HIGH_TARGET {
            @Override
            public Request generate(Bundle extras) {
                return Request.writeHighGlucoseTarget(extras.getInt(TARGET_HIGH_VALUE));
            }
        }, WRITE_LOW_ALARM {
            @Override
            public Request generate(Bundle extras) {
                return Request.writeLowGlucoseAlarmRequest(extras.getInt(ALARM_LOW_VALUE));
            }
        }, WRITE_HIGH_ALARM {
            @Override
            public Request generate(Bundle extras) {
                return Request.writeHighGlucoseAlarmRequest(extras.getInt(ALARM_HIGH_VALUE));
            }
        }, READ_RAW_VALUE_1 { /** #3194 */
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1);
            }
        }
        , READ_RAW_VALUE_2 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2);
            }
        }
        , READ_RAW_VALUE_3 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3);
            }
        }
        , READ_RAW_VALUE_4 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4);
            }
        }
        , READ_RAW_VALUE_5 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5);
            }
        }
        , READ_RAW_VALUE_6 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6);
            }
        }
        , READ_RAW_VALUE_7 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7);
            }
        }
        , READ_RAW_VALUE_8 {
            @Override
            public Request generate(Bundle extras) {
                return Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8);
            }
        }
        /** #4080 */
        , WRITE_MORNING_CALIBRATION_TIME {
            @Override
            public Request generate(Bundle extras) {
                int hour = extras.getInt(CALIBRATION_HOUR);
                int minute = extras.getInt(CALIBRATION_MINUTE);
                return Request.writeMorningCalibrationTime(hour, minute);
            }
        }
        , WRITE_EVENING_CALIBRATION_TIME {
            @Override
            public Request generate(Bundle extras) {
                int hour = extras.getInt(CALIBRATION_HOUR);
                int minute = extras.getInt(CALIBRATION_MINUTE);
                return Request.writeEveningCalibrationTime(hour, minute);
            }
        };

        public abstract Request generate(Bundle extras);

    }

    @Inject
    public CommandProcessor() {
    }

    @Nullable
    public Request process(Intent intent) {
        try {
            if (intent != null) {
                COMMAND command = COMMAND.valueOf(intent.getAction());
                return command.generate(intent.getExtras());
            }
        } catch (IllegalArgumentException e) {
            Log.w(CommandProcessor.class.getSimpleName(), "unknown command " + intent.getAction());
        } catch (NullPointerException e) {
            Log.d(CommandProcessor.class.getSimpleName(), "no command action given");
        }

        return null;
    }
}
