package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class ReadWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.predictiveAlert;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setPredictiveAlertsActivated(false);
                break;
            case 0x55:
                model.setPredictiveAlertsActivated(true);
                break;
        }
    }
}
