package com.senseonics.gen12androidapp;

import android.app.Activity;
import android.os.Bundle;

import java.util.Arrays;
import java.util.List;

import dagger.ObjectGraph;

public class ObjectGraphActivity extends Activity {

    private ObjectGraph activityGraph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ObjectGraphApplication application = (ObjectGraphApplication) getApplication();
        activityGraph = application.plus(getModules().toArray());
        activityGraph.inject(this);

        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onDestroy() {
        activityGraph = null;
        super.onDestroy();
    }

    protected List<Object> getModules() {
        return Arrays.<Object>asList(new ActivityModule(this));
    }

    public void inject(Object object) {
        activityGraph.inject(object);
    }


}
