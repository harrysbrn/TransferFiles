package com.senseonics.model;

import android.content.SharedPreferences;
import android.util.Log;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class WriteClinicalModeSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {
    private SharedPreferences sharedPreferences;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;

    @Inject
    public WriteClinicalModeSingleByteMemoryMapParsedResponse(SharedPreferences sharedPreferences, BluetoothServiceCommandClient bluetoothServiceCommandClient){
        this.sharedPreferences = sharedPreferences;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
    }

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.clinicalMode;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setClinicalMode(false);
                break;
            case 0x55:
                model.setClinicalMode(true);
                break;
        }

        if(model.isClinicalMode()) {
            long savedTimeMillis = Utils.getLocalTimeInMillisAdjustedToGMT();

            sharedPreferences.edit().putLong(Utils.prefClinicalModeStartTime, savedTimeMillis).apply();

            bluetoothServiceCommandClient.postReadClinicalModeDuration();
            Log.d(WriteClinicalModeSingleByteMemoryMapParsedResponse.class.getSimpleName(),  "Save time in milli: " + savedTimeMillis);
        } else {
            sharedPreferences.edit().remove(Utils.prefClinicalModeStartTime).apply();
        }
    }
}
