package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Handler;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

@Singleton
public class TransmitterScanner {
    static String SENSEONICS_SERVICE_HANDLE = "c3230001-9308-47ae-ac12-3d030892a211";
    final static UUID SENSONICS_SERVICE_HANDLE_UUID = UUID.fromString(SENSEONICS_SERVICE_HANDLE);
    protected BluetoothAdapterWrapper bluetoothAdapterWrapper;
    protected Handler handler;
    protected long scanPeriod;
    private ConnectedTransmitterAsyncQueryHandler queryHandler;
    private BluetoothAdapter.LeScanCallback leScanCallback;
    private boolean shouldStillScan;

    @Inject
    public TransmitterScanner(BluetoothAdapterWrapper bluetoothAdapterWrapper, Handler handler, @Named("SCAN_PERIOD_MILLISECONDS") long scanPeriod, ConnectedTransmitterAsyncQueryHandler queryHandler) {
        this.bluetoothAdapterWrapper = bluetoothAdapterWrapper;
        this.handler = handler;
        this.scanPeriod = scanPeriod;
        this.queryHandler = queryHandler;
    }

    void scan(final DiscoverCallback discoverCallback) {
        stopLeScanIfCurrentlyScanning();
        shouldStillScan = true;
        final Set<Transmitter> transmitters = new HashSet<>();

        queryHandler.startQuery(new ConnectedTransmitterAsyncQueryHandler.Callback() {
            @Override
            public void lastConnectedTransmitter(Transmitter transmitter) {
                if (transmitters.add(transmitter)) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            discoverCallback.onDevice(new ArrayList<>(transmitters));
                        }
                    });
                }
                startScanning();
                stopScanOnTimeout();
            }

            private void startScanning() {
                if (shouldStillScan) {
                    bluetoothAdapterWrapper.startLeScan(leScanCallback);
                }
            }

            @Override
            public void noLastConnectedTransmitter() {
                startScanning();
                stopScanOnTimeout();
            }

            private void stopScanOnTimeout() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (leScanCallback != null) {
                            bluetoothAdapterWrapper.stopLeScan(leScanCallback);
                            leScanCallback = null;
                            discoverCallback.onDiscoveryTimeout();
                        }
                    }
                }, scanPeriod);
            }
        });

        leScanCallback = new BluetoothAdapter.LeScanCallback() {
            @Override
            public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
                if (parseUUIDs(scanRecord).contains(SENSONICS_SERVICE_HANDLE_UUID)) {
                    Transmitter.CONNECTION_STATE initialConnectionState = Transmitter.CONNECTION_STATE.DISCONNECTED;// Transmitter.CONNECTION_STATE.fromBluetoothState(bluetoothManager.getConnectionState(device, BluetoothProfile.GATT));
                    final Transmitter transmitter = new Transmitter(device.getAddress(), device.getName(), initialConnectionState);
                    if (transmitters.add(transmitter)) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Log.i(TransmitterScanner.class.getSimpleName(), "scan found transmitter: " + transmitter);
                                discoverCallback.onDevice(new ArrayList<>(transmitters));
                            }
                        });
                    }
                }
            }
        };

    }

    void stopLeScanIfCurrentlyScanning() {
        shouldStillScan = false;
        if (leScanCallback != null) {
            bluetoothAdapterWrapper.stopLeScan(leScanCallback);
            leScanCallback = null;
        }
    }

    private List<UUID> parseUUIDs(byte[] advertisedData) {
        List<UUID> uuids = new ArrayList<UUID>();

        int offset = 0;
        while (offset < (advertisedData.length - 2)) {
            int len = advertisedData[offset++];
            if (len == 0)
                break;

            int type = advertisedData[offset++];
            switch (type) {
                case 0x02: // Partial list of 16-bit UUIDs
                case 0x03: // Complete list of 16-bit UUIDs
                    while (len > 1) {
                        int uuid16 = advertisedData[offset++];
                        uuid16 += (advertisedData[offset++] << 8);
                        len -= 2;
                        uuids.add(UUID.fromString(String.format(
                                "%08x-0000-1000-8000-00805f9b34fb", uuid16)));
                    }
                    break;
                case 0x06:// Partial list of 128-bit UUIDs
                case 0x07:// Complete list of 128-bit UUIDs
                    // Loop through the advertised 128-bit UUID's.
                    while (len >= 16) {
                        try {
                            // Wrap the advertised bits and order them.
                            ByteBuffer buffer = ByteBuffer.wrap(advertisedData,
                                    offset++, 16).order(ByteOrder.LITTLE_ENDIAN);
                            long mostSignificantBit = buffer.getLong();
                            long leastSignificantBit = buffer.getLong();
                            uuids.add(new UUID(leastSignificantBit,
                                    mostSignificantBit));
                        } catch (IndexOutOfBoundsException e) {
                            // Defensive programming.
                            // Log.e(LOG_TAG, e.toString());
                            continue;
                        } finally {
                            // Move the offset to read the next uuid.
                            offset += 15;
                            len -= 16;
                        }
                    }
                    break;
                default:
                    offset += (len - 1);
                    break;
            }
        }

        return uuids;
    }
}
