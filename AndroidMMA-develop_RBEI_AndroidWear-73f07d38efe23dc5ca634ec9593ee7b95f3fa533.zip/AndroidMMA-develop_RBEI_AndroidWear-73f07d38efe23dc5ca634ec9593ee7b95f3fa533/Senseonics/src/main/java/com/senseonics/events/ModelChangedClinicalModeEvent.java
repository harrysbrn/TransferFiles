package com.senseonics.events;

public class ModelChangedClinicalModeEvent {
    private boolean newValue;

    public ModelChangedClinicalModeEvent(boolean newValue){
        this.newValue = newValue;
    }

    public boolean isNewValue() {
        return newValue;
    }
}
