package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.senseonics.bluetoothle.DMSStateModelSyncManager;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.AccountConstants.MLDMSResult;
import com.senseonics.util.DMSUploadTask;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Arrays;

public class UserAccountActivity extends UserAccountBaseActivity {
	ArrayList<Item> syncDaysValues = new ArrayList<Item>();
	private String Tag = "DMS(UserAccountActivity)";
	private Switch switchAutoSync;
	private TextView
			tvLastSyncedOn,
			tvDefaultSyncDaysValue;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		contentLayout.addView(
				layoutInflater.inflate(R.layout.activity_useraccount, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(getString(R.string.my_account_sync));
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);

		// Find the views
		findViewForBtnSync();
		switchAutoSync = (Switch) findViewById(R.id.auto_sync_switcher);
		tvLastSyncedOn = (TextView) findViewById(R.id.tvLastSyncedOn);
		tvDefaultSyncDaysValue = (TextView) findViewById(R.id.tvDefaultSyncDaysValue);

		// Fetch the preferences
		tvLastSyncedOn.setText(accountConstants.getLastSyncedOnDateTimeStringFromPreference());
		tvDefaultSyncDaysValue.setText(accountConstants.getSyncDaysFromPreference() + "");
		switchAutoSync.setSwitchTextAppearance(this, R.style.SwitchTextAppearanceWhite);

		switchAutoSync.setChecked(accountConstants.getAccountEnableAutoSync());
		if (!accountConstants.HasValidAccountInfo()) {
			switchAutoSync.setChecked(false);
			Utils.saveSettings(this, Utils.prefAccountEnableAutoSync, false);
		}

		switchAutoSync.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked == true) {
					if (!accountConstants.HasValidAccountInfo()) {
						switchAutoSync.setChecked(false);
						displayDialogWithTitleAndMessage(getString(R.string.warning),
								getString(R.string.sync_could_not_start_2));
					} else {
						displayDialogWithTitleAndMessage(null,
								getString(R.string.auto_sync_enabled_text));
					}
				}

				Utils.saveSettings(UserAccountActivity.this, Utils.prefAccountEnableAutoSync, switchAutoSync.isChecked());
			}
		});

		setupBtnSyncOnClickEvent();

		final PickerManager pickerManager = new PickerManager() {

			@Override
			public void selected(int id) {
				String[] strings = syncDaysValues.get(id).getValue().split(" ");
				if (strings.length > 0) {
					tvDefaultSyncDaysValue
							.setText(strings[0]);
					sharedPreferences
							.edit()
							.putInt(Utils.prefAccountSyncDays,
									Integer.valueOf(strings[0])).apply();
				}
			}
		};

		RelativeLayout layoutDefaultSyncDays = (RelativeLayout) findViewById(R.id.layoutDefaultSyncDays);
		layoutDefaultSyncDays.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String dialogTitle = getResources().getString(
						R.string.sync_days);
				syncDaysValues.addAll(Arrays.asList(new Item(0, "1"),
						new Item(1, "3"), new Item(2, "7"), new Item(
								3, "14"), new Item(4, "30")));

				int position = getMinuteItemPosition(syncDaysValues,
						sharedPreferences.getInt(Utils.prefAccountSyncDays,
								Utils.DEFAULT_SYNC_DAYS));

				showDialog(dialogTitle, syncDaysValues, pickerManager, position);
			}
		});
	}

	@Override
	protected void setupBtnSyncOnClickEvent() {
		btnSync.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				if (Utils.haveNetworkConnection(UserAccountActivity.this)) {
					progressDialog.show();
					btnSync.setText(getString(R.string.syncing));

					// 1. upload diagnostic info
					DMSStateModelSyncManager.uploadAllStateModelInfo(accountConstants, stateModelUploadUtility);

					// 2. upload normal data
					new DMSUploadTask(
							false,
							accountConstants, 
							applicationForegroundState,
							notificationUtility,
							24 * accountConstants.getSyncDaysFromPreference(),
							UserAccountActivity.this
					).execute();
				} else {
					dmsError = AccountConstants.MLDMSResult.NotConnectedToWifi;
					displayDMSResult(dmsError);
					btnSync.setText(getString(R.string.sync_now));
					if (progressDialog.isShowing()) {
						progressDialog.dismiss();
					}
				}
			}
		});
	}

	public int getMinuteItemPosition(ArrayList<Item> items, int value) {
		for (int i = 0; i < items.size(); ++i) {
			String[] strings = items.get(i).getValue().split(" ");
			if (strings.length > 0) {
				int minute = Integer.valueOf(strings[0]);
				if (minute == value)
					return i;
			}
		}
		return -1;
	}

	protected void createDialog(String title, String text) {
		final Dialog dialog = new Dialog(this,
				R.style.PickerDialog);

		LayoutInflater inflater = LayoutInflater.from(this);
		View view = inflater.inflate(R.layout.dialog_warning, null);

		TextView textView = (TextView) view.findViewById(R.id.textView);
		textView.setText(text);

		TextView titleView = (TextView) view.findViewById(R.id.titleTextView);
		titleView.setVisibility(View.VISIBLE);
		titleView.setText(title);

		TextView okText = (TextView) view.findViewById(R.id.ok);
		okText.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();

				/** #3628
				// go to login page
				Intent intent = new Intent(UserAccountActivity.this, UserAccountLoginActivity.class);
				startActivity(intent);
				setResult(Utils.LOG_OUT_BACK_RESULT);
				finish(); */
			}
		});

		dialog.setContentView(view);
		dialog.show();
	}

	@Override
	protected void displayDMSResult(AccountConstants.MLDMSResult error, Integer result2, Integer result3) {
		super.displayDMSResult(error, result2, result3);

		if (error == MLDMSResult.DataSaved) {
			tvLastSyncedOn.setText(accountConstants.getLastSyncedOnDateTimeStringFromPreference());
		}
	}

	@Override
	public void TaskDone(AccountConstants.MLDMSResult dmsResult, Integer secondResult, Integer thirdResult) {
		if (dmsResult == MLDMSResult.InvalidUserCredentials) {
			/** #3628 */
			createDialog(getString(R.string.invalid_user_credentials_w_email), getString(R.string.sync_could_not_start_2));
		}
		else {
			displayDMSResult(dmsResult, secondResult, thirdResult);
		}

		resetBtnTextDismissProgressDialog();
	}
}
