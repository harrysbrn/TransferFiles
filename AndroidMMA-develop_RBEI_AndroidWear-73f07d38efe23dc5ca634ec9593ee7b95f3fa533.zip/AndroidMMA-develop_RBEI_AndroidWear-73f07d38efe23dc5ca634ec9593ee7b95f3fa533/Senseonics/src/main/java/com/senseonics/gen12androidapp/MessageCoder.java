package com.senseonics.gen12androidapp;

import com.senseonics.util.Utils;

import javax.inject.Inject;

public class MessageCoder {

    @Inject
    public MessageCoder() {
    }

    public Utils.TransmitterMessageCode messageCodeForPredictiveAlertFlags(int flags) {
        Utils.TransmitterMessageCode msg = null;

        switch (flags) {
            case 1:
                msg = Utils.TransmitterMessageCode.PredictiveLowAlarm;
                break;

            case 4:
                msg = Utils.TransmitterMessageCode.PredictiveHighAlarm;
                break;

            default:
                break;

        }

        return msg;
    }

    // parse the TX status alert flag
    public Utils.TransmitterMessageCode messageCodeForTransmitterStatusAlertFlags(int flags) {
        Utils.TransmitterMessageCode transmitterStatus = null;

        switch (flags) {
            case 1:
                transmitterStatus = Utils.TransmitterMessageCode.CriticalFaultAlarm;
                break;

        /*
         * case 2: // Reserved break;
         */
            case 4:// new sensor detected
                transmitterStatus = Utils.TransmitterMessageCode.InvalidSensorAlarm;
                break;

            case 8:
                transmitterStatus = Utils.TransmitterMessageCode.InvalidClockAlarm;
                break;

            case 16:
                // BLE Disconnected Notification
                break;
            case 32:
                transmitterStatus = Utils.TransmitterMessageCode.VibrationCurrentAlarm;
                break;
            case 64:
                transmitterStatus = Utils.TransmitterMessageCode.SensorAgedOutAlarm;
                break;
            case 128:
                transmitterStatus = Utils.TransmitterMessageCode.SensorOnHoldAlarm;
                break;
            default:
                break;

        }

        return transmitterStatus;
    }

    public Utils.TransmitterMessageCode messageCodeForRateAlertFlags(int flags) {
        Utils.TransmitterMessageCode msg = null;

        switch (flags) {
            case 1:
                msg = Utils.TransmitterMessageCode.RateFallingAlarm;
                break;

            case 2:
                msg = Utils.TransmitterMessageCode.RateRisingAlarm;
                break;

            default:
                break;

        }

        return msg;
    }


    public Utils.TransmitterMessageCode messageCodeForTransmitterBatteryAlertFlags(int flags) {
        Utils.TransmitterMessageCode batteryAlert = null;
        switch (flags) {
            case 1:
                batteryAlert = Utils.TransmitterMessageCode.EmptyBatteryAlarm;
                break;

            case 2:
                batteryAlert = Utils.TransmitterMessageCode.VeryLowBatteryAlarm;
                break;

            case 4:
                // Battery Low Alert
                batteryAlert = Utils.TransmitterMessageCode.LowBatteryAlarm;
                break;

            default:
                break;

        }

        return batteryAlert;
    }

    public Utils.TransmitterMessageCode messageCodeForSensorReadAlertFlags(int flags) {
        Utils.TransmitterMessageCode sensorReadAlert = null;

        switch (flags) {
            case 1:
                sensorReadAlert = Utils.TransmitterMessageCode.SeriouslyHighAlarm;
                break;

            case 2:
                sensorReadAlert = Utils.TransmitterMessageCode.SeriouslyLowAlarm;
                break;

            case 4:
                sensorReadAlert = Utils.TransmitterMessageCode.HighAmbientLightAlarm;
                break;

			case 8:
			    sensorReadAlert = Utils.TransmitterMessageCode.MEPAlarm;
                break;

            case 16:
                sensorReadAlert = Utils.TransmitterMessageCode.SensorTemperatureAlarm;
                break;

            case 32:
                sensorReadAlert = Utils.TransmitterMessageCode.SensorLowTemperatureAlarm;
                break;

            case 64:
                sensorReadAlert = Utils.TransmitterMessageCode.ReaderTemperatureAlarm;
                break;

            default:
                break;

        }

        return sensorReadAlert;
    }

    public Utils.TransmitterMessageCode messageCodeForSensorReplacementFlags(int flags) {
        Utils.TransmitterMessageCode sensorReplacementStatus = null;

        switch (flags) {
            case 1:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiredAlarm;
                break;

            case 2:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon1Alarm;
                break;

            case 4:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon2Alarm;
                break;

            case 8:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon3Alarm;
                break;

            case 16:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon4Alarm;
                break;

            case 32:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon5Alarm;
                break;

            case 64:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon6Alarm;
                break;

            case 128:
                sensorReplacementStatus = Utils.TransmitterMessageCode.SensorRetiringSoon7Alarm;
                break;

            default:
                break;
        }

        return sensorReplacementStatus;
    }

    public Utils.TransmitterMessageCode messageCodeForSensorCalibrationFlags(int flags) {
        Utils.TransmitterMessageCode msgCode = null;

        switch (flags) {
            case 1:// calibration grace alert
                msgCode = Utils.TransmitterMessageCode.CalibrationGracePeriodAlarm;
                break;

            case 2:// calibration expiration alarm
                msgCode = Utils.TransmitterMessageCode.CalibrationExpiredAlarm;
                break;

            case 4:// calibration notification
                msgCode = Utils.TransmitterMessageCode.CalibrationRequiredAlarm;
                break;

            default:
                break;

        }

        return msgCode;
    }

    public Utils.TransmitterMessageCode messageCodeForSensorHardwareAndAlertFlags(int flags) {
        Utils.TransmitterMessageCode sensorHWStatus = null;

        switch (flags) {
            case 1:// sensor HW error
                sensorHWStatus = Utils.TransmitterMessageCode.SensorErrorAlarm;
                break;

            case 2:// no sensor detected
                sensorHWStatus = Utils.TransmitterMessageCode.SensorAwolAlarm;
                //countdownSleep1Sec = true;
                break;

            case 4:// Sensor Instability Alarm
                sensorHWStatus = Utils.TransmitterMessageCode.SensorStablity;
                break;

            case 8:/** #3224 */
                sensorHWStatus = Utils.TransmitterMessageCode.EDRAlarm0;
                break;

            case 16:
                sensorHWStatus = Utils.TransmitterMessageCode.EDRAlarm1;
                break;

            case 32:
                sensorHWStatus = Utils.TransmitterMessageCode.EDRAlarm2;
                break;

            case 64:
                sensorHWStatus = Utils.TransmitterMessageCode.EDRAlarm3;
                break;

            case 128:/** #3920 */
                sensorHWStatus = Utils.TransmitterMessageCode.EDRAlarm4;
                break;

            default:
                break;
        }

        return sensorHWStatus;
    }

    public Utils.TransmitterMessageCode messageCodeForGlucoseLevelAlarmFlags(int flags) {
        Utils.TransmitterMessageCode msgCode = null;
        switch (flags) {
            case 1:
                msgCode = Utils.TransmitterMessageCode.LowGlucoseAlarm;
                break;
            case 2:
                msgCode = Utils.TransmitterMessageCode.HighGlucoseAlarm;
                break;
            default:
                break;
        }
        return msgCode;
    }

    public Utils.TransmitterMessageCode messageCodeForGlucoseLevelAlertFlags(int flags) {
        Utils.TransmitterMessageCode msgCode = null;
        switch (flags) {
            case 1:
                msgCode = Utils.TransmitterMessageCode.LowGlucoseAlert;
                break;

            case 2:
                msgCode = Utils.TransmitterMessageCode.HighGlucoseAlert;
                break;

            default:
                break;
        }

        return msgCode;
    }
}
