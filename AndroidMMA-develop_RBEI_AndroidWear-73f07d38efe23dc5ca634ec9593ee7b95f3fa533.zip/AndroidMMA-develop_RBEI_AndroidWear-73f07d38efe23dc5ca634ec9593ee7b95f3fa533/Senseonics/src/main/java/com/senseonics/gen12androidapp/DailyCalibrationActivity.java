package com.senseonics.gen12androidapp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.fragments.DailyCalibrationFragment;
import com.senseonics.fragments.DailyCalibrationFragment.CalibrationManager;
import com.senseonics.model.ModelChangedEvent;

public class DailyCalibrationActivity extends BaseActivity {

	protected DailyCalibrationFragment dailyCalibrationFragment;
    protected ProgressDialog progressDialog;

    protected CalibrationManager calibrationManager = new CalibrationManager() {

		@Override
		public void settingsOk(boolean value) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onMorningCalibrationSelected(int hour, int minute, boolean isInitial) {
			if (BluetoothUtils.mConnected) {
				BluetoothService bluetoothService = getService();
				if (bluetoothService != null) {
					bluetoothService.postWriteMorningCalibrationTime(hour, minute);
				}
				if (!isInitial) {
					progressDialog.show();
				}
			}
		}

		@Override
		public void onEveningCalibrationSelected(int hour, int minute, boolean isInitial) {
			if (BluetoothUtils.mConnected) {
				BluetoothService bluetoothService = getService();
				if (bluetoothService != null) {
					bluetoothService.postWriteEveningCalibrationTime(hour, minute);
				}
				if (!isInitial) {
					progressDialog.show();
				}
			}
		}
	};

	@Override
	public void connectionStateChanged() {
		if(dailyCalibrationFragment!=null)
		{
			dailyCalibrationFragment.updateViews();
		}
		
		super.connectionStateChanged();
	}

	@Override
	public void highPriorityRequestFinished() {
		if (progressDialog.isShowing())
		{
			progressDialog.dismiss();
		}
		
		super.highPriorityRequestFinished();
	}

	public void onEventMainThread(ModelChangedEvent event) {
		if (progressDialog.isShowing())
			progressDialog.dismiss();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_simple_fragment, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.daily_calibration);
		naviBarRightItemTextView.setVisibility(View.VISIBLE);
		naviBarRightItemTextView.setText(R.string.save);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);

		progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
		progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
		progressDialog.setCancelable(true);
		progressDialog.setOnCancelListener(new OnCancelListener() {

			@Override
			public void onCancel(DialogInterface dialog) {
				if (dailyCalibrationFragment != null) {
					dailyCalibrationFragment.setBothCalibrationTimeToCurrentModelValue();
				}
			}
		});

		dailyCalibrationFragment = new DailyCalibrationFragment();
		dailyCalibrationFragment.setCalibrationManager(calibrationManager);
		getFragmentManager().beginTransaction()
				.replace(R.id.fragment, dailyCalibrationFragment)
				.commitAllowingStateLoss();
		
	}
	
	public void setNaviBarRightItemTextViewOnClick(OnClickListener listener) {
		naviBarRightItemTextView.setOnClickListener(listener);
	}
	
	public  void enableSaveButton() {
		if (naviBarRightItemTextView != null) {
			naviBarRightItemTextView.setClickable(true);
			naviBarRightItemTextView.setTextColor(getResources().getColor(
					android.R.color.white));
		}
	}
	
	public void disableSaveButton() {
		// Disable the save button
		if (naviBarRightItemTextView != null) {
			naviBarRightItemTextView.setClickable(false);
			naviBarRightItemTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
		}
	}

	@Override
	protected void onResume() {
		BluetoothService bluetoothService = getService();
		if (bluetoothService != null) {
			bluetoothService.postReadMorningCalibrationTime();
			bluetoothService.postReadEveningCalibrationTime();
		}
		super.onResume();
	}

	@Override
	protected void onPause() {
		if (progressDialog.isShowing()) {
			progressDialog.dismiss();
		}

		super.onPause();
	}
}
