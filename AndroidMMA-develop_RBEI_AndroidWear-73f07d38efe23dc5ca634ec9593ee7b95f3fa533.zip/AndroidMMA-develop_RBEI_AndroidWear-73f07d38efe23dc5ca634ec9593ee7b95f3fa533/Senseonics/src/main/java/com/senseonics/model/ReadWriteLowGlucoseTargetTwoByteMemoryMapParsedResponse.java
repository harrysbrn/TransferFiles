package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.lowGlucoseTarget;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int lowGlucoseTarget = BinaryOperations.dataIntFrom16BitsLSByteFirst(dataOne, dataTwo);
        Log.i("Glucose thresholds", "low target: " + lowGlucoseTarget);
        model.setLowGlucoseTarget(lowGlucoseTarget);

    }
}
