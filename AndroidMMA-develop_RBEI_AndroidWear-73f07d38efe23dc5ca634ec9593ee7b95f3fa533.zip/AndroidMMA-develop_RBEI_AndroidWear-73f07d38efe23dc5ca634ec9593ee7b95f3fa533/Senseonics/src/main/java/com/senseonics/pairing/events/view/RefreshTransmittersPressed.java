package com.senseonics.pairing.events.view;

public class RefreshTransmittersPressed {
}
