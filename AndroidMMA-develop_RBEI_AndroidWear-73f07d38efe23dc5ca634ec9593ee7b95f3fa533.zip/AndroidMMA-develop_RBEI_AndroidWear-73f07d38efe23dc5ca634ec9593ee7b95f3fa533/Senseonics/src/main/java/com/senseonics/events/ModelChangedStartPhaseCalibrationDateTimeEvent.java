package com.senseonics.events;

import java.util.Calendar;

public class ModelChangedStartPhaseCalibrationDateTimeEvent {
    private Calendar startCalibrationPhaseDateAndTime;

    public ModelChangedStartPhaseCalibrationDateTimeEvent(Calendar startCalibrationPhaseDateAndTime){
        this.startCalibrationPhaseDateAndTime = startCalibrationPhaseDateAndTime;
    }

    public Calendar getStartCalibrationPhaseDateAndTime() {
        return startCalibrationPhaseDateAndTime;
    }
}
