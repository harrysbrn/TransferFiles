package com.senseonics.gen12androidapp;

public class Constants {
  public static final String REFRESH_BUTTON = "REFRESH_BUTTON";
  public static final String IS_FIRST_RUN = "IS_FIRST_RUN";
  public static final String NEW_START_END_DATES = "NEW_START_END_DATES";
  public static final String START_DATE = "START_DATE";
  public static final String END_DATE = "END_DATE";
  public static final String IS_FOREGROUND = "IS_FOREGROUND";
  public static final int BLUETOOTH_SERVICE_ID = 1337;
}
