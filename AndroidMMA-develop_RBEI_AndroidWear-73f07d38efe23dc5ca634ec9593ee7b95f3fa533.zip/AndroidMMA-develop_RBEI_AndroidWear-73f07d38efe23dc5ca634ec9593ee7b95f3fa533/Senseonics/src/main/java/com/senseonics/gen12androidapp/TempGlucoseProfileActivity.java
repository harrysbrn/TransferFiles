package com.senseonics.gen12androidapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.senseonics.fragments.TempGlucoseProfileFragment;

public class TempGlucoseProfileActivity extends BaseActivity{ /** #3160 */
    private TempGlucoseProfileFragment tempGlucoseProfileFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.activity_simple_fragment, null),
                parms_content);

        // Configure the navigation bar
        naviBarTitle.setText(R.string.temp_profile_title);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        tempGlucoseProfileFragment = new TempGlucoseProfileFragment();
        getFragmentManager().beginTransaction()
                .replace(R.id.fragment, tempGlucoseProfileFragment)
                .commitAllowingStateLoss();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

}
