package com.senseonics.bluetoothle;

public class CommandAndResponseIDs {

	//Commands to establish Link and Control Transmitter
	
	public static final int PingCommandID = 0x01;
	public static final int PingResponseID = 0x81;
	
	public static final int LinkTransmitterWithSensorCommandID  = 0x02;
	public static final int LinkTransmitterWithSensorResponseID = 0x82;
	
	public static final int ResetTransmitterCommandID  = 0x03;
	public static final int ResetTransmitterResponseID = 0x83;
	
	public static final int ClearErrorFlagsCommandID  = 0x04;
	public static final int ClearErrorFlagsResponseID = 0x84;
	
	public static final int StartSelfTestSequenceCommandID  = 0x05;
	public static final int StartSelfTestSequenceResponseID = 0x85;
	
	public static final int ReadAllAvailableSensorsCommandID  = 0x06; //Future use only
	public static final int ReadAllAvailableSensorsResponseID = 0x86; //Future use only

	
	public static final int SetCurrentTrasmitterDateAndTimeCommandID  = 0x07;
	public static final int SetCurrentTrasmitterDateAndTimeResponseID = 0x87;

	
	public static final int ReadCurrentTrasmitterDateAndTimeCommandID  = 0x19;
	public static final int ReadCurrentTrasmitterDateAndTimeResponseID = 0x99;

	
	public static final int SaveBLEBondingInformationCommandID  = 0x69;
	public static final int SaveBLEBondingInformationResponseID = 0xE9;

	
	public static final int DisconnectBLESavingBondingInformationCommandID  = 0x74;
	public static final int DisconnectBLESavingBondingInformationResponseID = 0xF4;

	
	public static final int ChangeTimingParametersCommandID  = 0x75;
	public static final int ChangeTimingParametersResponseID = 0xF5;
	

	public static final int EnterDiagnosticModeCommandID = 0x76;
	public static final int EnterDiagnosticModeResponseID = 0xF6;
	
	
	public static final int ExitDiagnosticModeCommandID = 0x77;
	public static final int ExitDiagnosticModeResponseID = 0xF7;

	//Commands to Read Sensor Glucose values
	
	public static final int ReadSensorGlucoseCommandID  = 0x08;
	public static final int ReadSensorGlucoseResponseID = 0x88;
	
	public static final int ReadSingleSensorGlucoseDataRecordCommandID  = 0x09;
	public static final int ReadSingleSensorGlucoseDataRecordResponseID = 0x89;
	
	public static final int ReadAllSensorGlucoseDataInSpecifiedRangeCommandID  = 0x70;
	public static final int ReadAllSensorGlucoseDataInSpecifiedRangeResponseID = 0xF0;
	
	public static final int ReadFirstAndLastSensorGlucoseRecordNumbersCommandID  = 0x0E;
	public static final int ReadFirstAndLastSensorGlucoseRecordNumbersResponseID = 0x8E;
	
	//Commands to Read Sensor Glucose Alerts and Alarms
	
	public static final int ReadSensorGlucoseAlertsAndStatusCommandID  = 0x10;
	public static final int ReadSensorGlucoseAlertsAndStatusResponseID = 0x90;
	
	public static final int ReadSingleSensorGlucoseAlertRecordCommandID  = 0x11;
	public static final int ReadSingleSensorGlucoseAlertRecordResponseID = 0x91;
	
	public static final int ReadFirstAndLastSensorGlucoseAlertRecordNumbersCommandID  = 0x12;
	public static final int ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseID = 0x92;
	
	public static final int ReadAllSensorGlucoseAlertsInSpecifiedRangeCommandID  = 0x71;
	public static final int ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID = 0xF1;
	
	public static final int AssertSnoozeAgainsAlarmCommandID  = 0x14;
	public static final int AssertSnoozeAgainsAlarmResponseID = 0x94;
	
	//Commands to Read and Write Blood Glucose Data Log
	
	public static final int SendBloodGlucoseDataCommandID  = 0x15;
	public static final int SendBloodGlucoseDataResponseID = 0x95;
	
	public static final int ReadSingleBloodGlucoseDataRecordCommandID  = 0x16;
	public static final int ReadSingleBloodGlucoseDataRecordResponseID = 0x96;
	
	public static final int ReadFirstAndLastBloodGlucoseDataRecordNumbersCommandID  = 0x17;
	public static final int ReadFirstAndLastBloodGlucoseDataRecordNumbersResponseID = 0x97;
	
	public static final int ReadLogOfBloodGlucoseDataInSpecifiedRangeCommandID  = 0x72;
	public static final int ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID = 0xF2;
	
	//Commands to Read and Write Patient Events
	
	public static final int WritePatientEventCommandID  = 0x1A;
	public static final int WritePatientEventResponseID = 0x9A;
	
	public static final int ReadSinglePatientEventCommandID  = 0x1B;
	public static final int ReadSinglePatientEventResponseID = 0x9B;
	
	public static final int ReadFirstAndLastPatientEventRecordNumbersCommandID  = 0x1C;
	public static final int ReadFirstAndLastPatientEventRecordNumbersResponseID = 0x9C;
	
	public static final int MarkPatientEventRecordAsDeletedCommandID  = 0x1D;
	public static final int MarkPatientEventRecordAsDeletedResponseID = 0x9D;
	
	public static final int ReadLogOfPatientEventsInSpecifiedRangeCommandID  = 0x73;
	public static final int ReadLogOfPatientEventsInSpecifiedRangeResponseID = 0xF3;

	//Commands to Read and Write Miscellaneous Event Log
	
	public static final int ReadSingleMiscEventLogCommandID  = 0x22;
	public static final int ReadSingleMiscEventLogResponseID = 0xA2;
	
	public static final int ReadFirstAndLastMiscEventLogRecordNumbersCommandID  = 0x23;
	public static final int ReadFirstAndLastMiscEventLogRecordNumbersResponseID = 0xA3;
	
	public static final int WriteSingleMiscEventLogRecordCommandID  = 0x24;
	public static final int WriteSingleMiscEventLogRecordResponseID = 0xA4;
	
	//Commands to Read Error Log
	
	public static final int ReadFirstAndLastErrorLogRecordNumbersCommandID  = 0x27;
	public static final int ReadFirstAndLastErrorLogRecordNumbersResponseID = 0xA7;
	
	//Commands to Read and Write Data Memory directly
	
	public static final int ReadSingleByteSerialFlashRegisterCommandID  = 0x2A;
	public static final int ReadSingleByteSerialFlashRegisterResponseID = 0xAA;
	
	public static final int WriteSingleByteSerialFlashRegisterCommandID  = 0x2B;
	public static final int WriteSingleByteSerialFlashRegisterResponseID = 0xAB;
	
	public static final int ReadTwoByteSerialFlashRegisterCommandID  = 0x2C;
	public static final int ReadTwoByteSerialFlashRegisterResponseID = 0xAC;
	
	public static final int WriteTwoByteSerialFlashRegisterCommandID  = 0x2D;
	public static final int WriteTwoByteSerialFlashRegisterResponseID = 0xAD;
	
	public static final int ReadFourByteSerialFlashRegisterCommandID  = 0x2E;
	public static final int ReadFourByteSerialFlashRegisterResponseID = 0xAE;
	
	public static final int WriteFourByteSerialFlashRegisterCommandID  = 0x2F;
	public static final int WriteFourByteSerialFlashRegisterResponseID = 0xAF;
	
	public static final int ReadNByteSerialFlashRegisterCommandID  = 0x30;
	public static final int ReadNByteSerialFlashRegisterResponseID = 0xB0;
	
	public static final int WriteNByteSerialFlashRegisterCommandID   = 0x31;
	public static final int WriteNByteSerialFlashRegisterResponseID  = 0xB1;
	
	//Commands initiated by Transmitter and sent to DDD
	
	public static final int GlucoseLevelAlarmPushNotificationCommandID  = 0x40;
	public static final int GlucoseLevelAlarmPushNotificationResponseID = 0xC0;
	
	public static final int GlucoseLevelAlertPushNotificationCommandID  = 0x41;
	public static final int GlucoseLevelAlertPushNotificationResponseID = 0xC1;
	
	public static final int GlucoseRateAlertOrPredictiveAlertPushNotificationCommandID  = 0x42;
	public static final int GlucoseRateAlertOrPredictiveAlertPushNotificationResponseID = 0xC2;
	
	public static final int CalibrationAlarmOrAlertPushNotificationCommandID  = 0x43;
	public static final int CalibrationAlarmOrAlertPushNotificationResponseID = 0xC3;
	
	public static final int SensorReplacementAlarmOrAlertPushNotificationCommandID  = 0x44;
	public static final int SensorReplacementAlarmOrAlertPushNotificationResponseID = 0xC4;
	
	public static final int SensorHWStatusAlarmOrAlertPushNotificationCommandID  = 0x45;
	public static final int SensorHWStatusAlarmOrAlertPushNotificationResponseID = 0xC5;
	
	public static final int TransmitterStatusAlarmOrAlertPushNotificationCommandID  = 0x46;
	public static final int TransmitterStatusAlarmOrAlertPushNotificationResponseID = 0xC6;
	
	public static final int TransmitterBatteryAlertPushNotificationCommandID  = 0x47;
	public static final int TransmitterBatteryAlertPushNotificationResponseID = 0xC7;
	
	public static final int SensorReadAlertPushNotificationCommandID  = 0x49;
	public static final int SensorReadAlertPushNotificationResponseID = 0xC9;
	
	public static final int KeepAliveCommandID  = 0x50;
	public static final int KeepAliveResponseID = 0xD0;

	public static final int TestCommandID = 0x60;
	public static final int TestResponseID = 0xE0;

	public static final int TestCommandForceGlucoseMeasurement = 0x18;

    public static final int ErrorResponseID = 0x80;
	
}
