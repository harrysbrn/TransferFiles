package com.senseonics.events;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventUtils.HEALTH_CONDITION;
import com.senseonics.events.EventUtils.HEALTH_SEVERITY;
import com.senseonics.events.EventUtils.PickerManager;

public class HealthEventActivity extends EventActivity {

	private PickerManager conditionManager, severityManager;
	private String conditionName, severityName;
	private HEALTH_CONDITION condition = HEALTH_CONDITION.NORMAL;
	private HEALTH_SEVERITY severity = HEALTH_SEVERITY.MEDIUM;
	private TextView conditionTextView, severityTextView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.health_event);
		
		LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.dialog_health_event, contentLayout);

		RelativeLayout conditionLayout = (RelativeLayout) findViewById(R.id.conditionLayout);
		conditionTextView = (TextView) findViewById(R.id.condition);

		if (eventPoint != null)
			setCondition(((HealthEventPoint) eventPoint).getHealthCondition()
					.ordinal());
		else
			setCondition(condition.ordinal());
		conditionManager = new PickerManager() {

			@Override
			public void selected(int id) {
				setCondition(id);
			}
		};

		conditionLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventUtils.createHealthConditionPicker(
						HealthEventActivity.this,
						getResources().getString(R.string.condition),
						conditionManager, condition.ordinal());
			}
		});

		RelativeLayout severityLayout = (RelativeLayout) findViewById(R.id.severityLayout);
		severityTextView = (TextView) findViewById(R.id.severity);

		if (eventPoint != null)
			setSeverity(((HealthEventPoint) eventPoint).getHealthSeverity()
					.ordinal());
		else
			setSeverity(severity.ordinal());

		severityManager = new PickerManager() {

			@Override
			public void selected(int id) {
				setSeverity(id);
			}
		};
		severityLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventUtils.createHealthSeverityPicker(HealthEventActivity.this,
						getResources().getString(R.string.severity),
						severityManager, severity.ordinal());
			}
		});
	}

	public void setCondition(int id) {
		condition = EventUtils.HEALTH_CONDITION.values()[id];
		conditionName = EventUtils.getHealthConditionName(
				HealthEventActivity.this, condition);
		conditionTextView.setText(conditionName);
	}

	public void setSeverity(int id) {
		severity = EventUtils.HEALTH_SEVERITY.values()[id];
		severityName = EventUtils.getHealthSeverityName(
				HealthEventActivity.this, severity);
		severityTextView.setText(severityName);
	}

	@Override
	public void onSavePressed() {
		super.onSavePressed();

		HealthEventPoint healthEventPoint = null;
		if (isEditing) {
			healthEventPoint = new HealthEventPoint(eventPoint.getDatabaseId(),
					currentDate, glucoseLevel, condition, severity,
					notesEditText.getText().toString());
			databaseManager.updateEvent(healthEventPoint);
		} else {
			healthEventPoint = new HealthEventPoint(currentDate, glucoseLevel,
					condition, severity, notesEditText.getText().toString());
			int rowId = (int) databaseManager.addEvent(healthEventPoint, false);
			healthEventPoint.setDatabaseId(rowId);
		}
		// Write event to transmitter
		BluetoothPairBaseActivity.patientEventPoints.add(healthEventPoint);
		getService().postWritePatientEventPoint(healthEventPoint);

		finish();
	}
}
