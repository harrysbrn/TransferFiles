package com.senseonics.model;

import com.senseonics.db.DatabaseManager;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.util.Utils;

import java.util.Calendar;

public enum ALERT_LOG_RECORD_TYPE {
    LOW_GLUCOSE_ALARM_ASSERTED(0x00){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.ALARM_EVENT, Utils.ALERT_TYPE.LOW_GLUCOSE,
                    calendar, sensorGlucoseValue, 0, 0, recordNumber, false);
        }
    },
    HIGH_GLUCOSE_ALARM_ASSERTED(0x01){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.ALARM_EVENT, Utils.ALERT_TYPE.HIGH_GLUCOSE,
                    calendar, sensorGlucoseValue, 0, 0, recordNumber, false);
        }
    },
    LOW_GLUCOSE_ALERT_ASSERTED(0x02){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.ALERT_EVENT, Utils.ALERT_TYPE.LOW_GLUCOSE,
                    calendar, sensorGlucoseValue, 0, 0, recordNumber, false);
        }
    },
    HIGH_GLUCOSE_ALERT_ASSERTED(0x03){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.ALERT_EVENT, Utils.ALERT_TYPE.HIGH_GLUCOSE,
                    calendar, sensorGlucoseValue, 0, 0, recordNumber, false);
        }
    },
    FALLING_RATE_ALERT_ASSERTED(0x04){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING, null, calendar,
                    sensorGlucoseValue, sensorGlucoseRateValue, 0,
                    recordNumber, false);
        }
    },

    RISING_RATE_ALERT_ASSERTED(0x05){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING, null, calendar,
                    sensorGlucoseValue, sensorGlucoseRateValue, 0,
                    recordNumber, false);
        }
    },
    PREDICTIVE_LOW_GLUCOSE_ALERT_ASSERTED(0x06){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING, null,
                    calendar, sensorGlucoseValue, 0,
                    alertThresholdOrTimeInterval, recordNumber, false);
        }
    },
    PREDICTIVE_HIGH_GLUCOSE_ALERT_ASSERTED(0x07){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            saveAlert(databaseManager, Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING, null,
                    calendar, sensorGlucoseValue, 0,
                    alertThresholdOrTimeInterval, recordNumber, false);
        }
    },
    SENSOR_CALIBRATION_NOTIFICATION_ASSERTED(0x09){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            // sensorGlucoseValue is 0 according to the transmitter firmware, save glucose level to be unknown - consistent with saveCalibrationAlert in PushNotificationListener
            saveNotification(databaseManager, Utils.TransmitterMessageCode.CalibrationRequiredAlarm, "", Utils.GLUCOSE_LEVEL_UNKNOWN, calendar, true);
        }
    },
    SENSOR_CALIBRATION_GRACE_PERIOD_ALERT_ASSERTED(0x0A){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            // sensorGlucoseValue is 0 according to the transmitter firmware, save glucose level to be unknown - consistent with saveCalibrationAlert in PushNotificationListener
            saveNotification(databaseManager, Utils.TransmitterMessageCode.CalibrationGracePeriodAlarm, "", Utils.GLUCOSE_LEVEL_UNKNOWN, calendar, true);
        }
    },
    SENSOR_CALIBRATION_EXPIRED_ALARM_ASSERTED(0x0B){
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            // sensorGlucoseValue is 0 according to the transmitter firmware, save glucose level to be unknown - consistent with saveCalibrationAlert in PushNotificationListener
            saveNotification(databaseManager, Utils.TransmitterMessageCode.CalibrationExpiredAlarm, "", Utils.GLUCOSE_LEVEL_UNKNOWN, calendar, true);
        }
    },
    OUT_OF_RANGE_LOW_GLUCOSE_ASSERTED(0x0C) {
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            // set glucose level to unknown to be consistent with PushNotificationListener
            saveNotification(databaseManager, Utils.TransmitterMessageCode.SeriouslyLowAlarm, "",
                    Utils.GLUCOSE_LEVEL_UNKNOWN, calendar, false);
        }
    },
    OUT_OF_RANGE_HIGH_GLUCOSE_ASSERTED(0x0D) {
        @Override
        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
            // set glucose level to unknown to be consistent with PushNotificationListener
            saveNotification(databaseManager, Utils.TransmitterMessageCode.SeriouslyHighAlarm, "",
                    Utils.GLUCOSE_LEVEL_UNKNOWN, calendar, false);
        }
    },

    /* For the Cleared events, ignore them for now: do not save to database - same as iOS */
    LOW_GLUCOSE_ALARM_CLEARED(0xF0)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.ALARM_EVENT, Utils.ALERT_TYPE.LOW_GLUCOSE,
//                    calendar, sensorGlucoseValue, 0, 0, recordNumber, true);
//        }
//    }
    ,
    HIGH_GLUCOSE_ALARM_CLEARED(0xF1)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.ALARM_EVENT, Utils.ALERT_TYPE.HIGH_GLUCOSE,
//                    calendar, sensorGlucoseValue, 0, 0, recordNumber, true);
//        }
//    }
    ,
    LOW_GLUCOSE_ALERT_CLEARED(0xF2)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.ALERT_EVENT, Utils.ALERT_TYPE.LOW_GLUCOSE,
//                    calendar, sensorGlucoseValue, 0, 0, recordNumber, true);
//        }
//    }
    ,
    HIGH_GLUCOSE_ALERT_CLEARED(0xF3)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.ALERT_EVENT, Utils.ALERT_TYPE.HIGH_GLUCOSE,
//                    calendar, sensorGlucoseValue, 0, 0, recordNumber, true);
//        }
//    }
    ,
    FALLING_RATE_ALERT_CLEARED(0xF4)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING, null, calendar,
//                    sensorGlucoseValue, sensorGlucoseRateeValue, 0,
//                    recordNumber, true);
//        }
//    }
    ,
    RISING_RATE_ALERT_CLEARED(0xF5)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING, null, calendar, sensorGlucoseValue, sensorGlucoseRateValue, 0, recordNumber, true);
//        }
//    }
    ,
    PREDICTIVE_LOW_GLUCOSE_ALERT_CLEARED(0xF6)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING, null, calendar, sensorGlucoseValue, 0, alertThresholdOrTimeInterval, recordNumber, true);
//
//        }
//    }
    ,
    PREDICTIVE_HIGH_GLUCOSE_ALERT_CLEARED(0xF7)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveAlert(databaseManager, Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING, null, calendar, sensorGlucoseValue, 0, alertThresholdOrTimeInterval, recordNumber, true);
//
//        }
//    }
    ,
    // 0xF8 Unused
    SENSOR_CALIBRATION_NOTIFICATION_CLEARED(0xF9),
    SENSOR_CALIBRATION_GRACE_PERIOD_ALERT_CLEARED(0xFA),
    SENSOR_CALIBRATION_EXPIRED_ALARM_CLEARED(0xFB),
    OUT_OF_RANGE_LOW_GLUCOSE_ALARM_CLEARED(0xFC)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveNotification(databaseManager, Utils.TransmitterMessageCode.SeriouslyLowAlarm, "", sensorGlucoseValue, calendar, true);
//        }
//    }
    ,
    OUT_OF_RANGE_HIGH_GLUCOSE_ALARM_CLEARED(0xFD)
//            {
//        @Override
//        public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {
//            saveNotification(databaseManager, Utils.TransmitterMessageCode.SeriouslyHighAlarm, "", sensorGlucoseValue, calendar, true);
//        }
//    }
    ;

    private int typeCode;

    ALERT_LOG_RECORD_TYPE(int typeCode) {
        this.typeCode = typeCode;
    }

    private static void saveAlert(DatabaseManager databaseManager, Utils.EVENT_TYPE eventType, Utils.ALERT_TYPE type,
                                  Calendar calendar, int glucoseValue, float rateValue,
                                  int predictiveMinutes, int recordNumber, boolean hidden) {
        glucoseValue = getGlucoseValue(glucoseValue);
        AlertEventPoint alertEvent = new AlertEventPoint(eventType, calendar,
                glucoseValue, type, Utils.GLUCOSE_TYPE.SENSOR_GLUCOSE);
        alertEvent.setRecordNumber(recordNumber);
        // save rate and predictive all to 0 to be in consistent with PushNotificationListener
        alertEvent.setRateValue(0.0f);
        alertEvent.setPredictiveMinutes(0);
        alertEvent.setEventHidden(hidden);
        databaseManager.addEvent(alertEvent, true);
    }

    private static void saveNotification(DatabaseManager databaseManager, Utils.TransmitterMessageCode notificationEventType,
                                         String notes, int glucoseLevel,
                                         Calendar calendar, boolean hidden) {
        glucoseLevel = getGlucoseValue(glucoseLevel);
        EventPoint eventPoint = new EventPoint(calendar,
                glucoseLevel, notificationEventType.getEventType());
        eventPoint.setNotes(notes);
        eventPoint.setNotificationEventType(notificationEventType);
        eventPoint.setRecordNumber(-1);
        eventPoint.setEventHidden(hidden);

        if (notificationEventType == Utils.TransmitterMessageCode.NumberOfMessages) {
            eventPoint.setUnknownErrorCode(Utils.currentUnknownErrorCode);
        }

        databaseManager.addEvent(eventPoint, true);
    }


    public static ALERT_LOG_RECORD_TYPE findBy(int sensorGlucoseAlertLogRecordType) {
        for (ALERT_LOG_RECORD_TYPE type : ALERT_LOG_RECORD_TYPE.values()) {
            if (type.typeCode == sensorGlucoseAlertLogRecordType) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown Sensor Glucose Alert Log Record Type (" + sensorGlucoseAlertLogRecordType + ")");
    }

    public void save(DatabaseManager databaseManager, int sensorGlucoseValue, Calendar calendar, int alertThresholdOrTimeInterval, int recordNumber, int sensorGlucoseRateValue) {

    }

    private static int getGlucoseValue(int sensorGlucoseValue) {
        if ((sensorGlucoseValue >= Utils.GLUCOSE_VALID_MIN) && (sensorGlucoseValue <= Utils.GLUCOSE_VALID_MAX)) {
            return sensorGlucoseValue;
        } else {
            return Utils.GLUCOSE_LEVEL_UNKNOWN;
        }
    }
}
