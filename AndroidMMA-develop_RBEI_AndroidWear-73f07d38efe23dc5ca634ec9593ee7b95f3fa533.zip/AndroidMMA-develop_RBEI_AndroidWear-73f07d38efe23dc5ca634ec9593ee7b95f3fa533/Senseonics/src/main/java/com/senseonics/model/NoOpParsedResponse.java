package com.senseonics.model;

public class NoOpParsedResponse implements ParsedResponse {
    @Override
    public int getExpectedResponseId() {
        return 0;
    }

    @Override
    public boolean check(int[] data) {
        return false;
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        //
    }
}
