package com.senseonics.events;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.DialogUtils.DoublePickerManager;
import com.senseonics.events.EventUtils.EXERCISE_INTENSITY;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.util.ArrayList;

public class ExerciseEventActivity extends EventActivity {

	private PickerManager intensityManager;
	private String intensityName;
	private EXERCISE_INTENSITY intensity = EXERCISE_INTENSITY.MEDIUM;
	private TextView intensityTextView, durationTextView;
	private ArrayList<Item> list1, list2;
	private Dialog dialog;

	private int durationMinute = 0;
	private int minHours = 0, maxHours = 5;
	private int minMinutes = 0, maxMinutes = 59;
	private int selectedHours, selectedMinute;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.exercise_event);
		
		LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.dialog_exercise_event, contentLayout);

		list1 = dialogUtils.getNumbersBetweenWithSuffix(minHours, maxHours, 1, getString(R.string.hr));
		list2 = dialogUtils.getNumbersBetweenWithSuffix(minMinutes, maxMinutes, 1, getString(R.string.min));

		RelativeLayout intensityLayout = (RelativeLayout) findViewById(R.id.intensityLayout);
		RelativeLayout durationLayout = (RelativeLayout) findViewById(R.id.durationLayout);
		intensityTextView = (TextView) findViewById(R.id.intensity);
		durationTextView = (TextView) findViewById(R.id.duration);

		intensityManager = new PickerManager() {

			@Override
			public void selected(int id) {
				setIntensity(id);
			}
		};

		intensityLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventUtils.createExerciseIntensityPicker(
						ExerciseEventActivity.this,
						getResources().getString(R.string.intensity),
						intensityManager, intensity.ordinal());
			}
		});

		final DoublePickerManager pickerManager = new DoublePickerManager() {

			@Override
			public void selected(int id1, int id2) {
				selectedHours = Integer.valueOf(list1.get(id1).getValue().replace(getString(R.string.hr), ""));
				selectedMinute = Integer.valueOf(list2.get(id2).getValue().replace(getString(R.string.min), ""));

				durationMinute = selectedHours * 60 + selectedMinute;
				durationTextView.setText(String.valueOf(selectedHours)
						+ getString(R.string.hr) + " "
						+ String.valueOf(selectedMinute)
						+ getString(R.string.min));
			}
		};
		durationLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (dialog != null && dialog.isShowing())
					dialog.dismiss();

				int position1 = Utils.getItemPosition(list1, selectedHours + getString(R.string.hr));
				int position2 = Utils.getItemPosition(list2, selectedMinute + getString(R.string.min));

				dialog = dialogUtils.createPickerDialog(ExerciseEventActivity.this,
						getString(R.string.duration), list1, list2, null,
						pickerManager, position1, position2, false, false);
				dialog.show();

			}
		});

		// durationLayout.setOnTouchListener(new OnT);

		if (eventPoint != null) {
			setIntensity(((ExerciseEventPoint) eventPoint).getIntensity()
					.ordinal());
			durationMinute = ((ExerciseEventPoint) eventPoint).getDuration();
		} else
			setIntensity(intensity.ordinal());

		selectedHours = durationMinute / 60;
		selectedMinute = durationMinute % 60;

		int position1 = Utils.getItemPosition(list1, selectedHours + getString(R.string.hr));
		int position2 = Utils.getItemPosition(list2, selectedMinute + getString(R.string.min));
		if (position1 != -1 && position2 != -1)
			pickerManager.selected(position1, position2);
	}

	public void setIntensity(int id) {
		intensity = EXERCISE_INTENSITY.values()[id];
		intensityName = EventUtils.getExerciseIntensityName(
				ExerciseEventActivity.this, intensity);
		intensityTextView.setText(intensityName);
	}

	@Override
	public void onSavePressed() {
		super.onSavePressed();

		ExerciseEventPoint exerciseEventPoint = null;
		if (isEditing) {
			exerciseEventPoint = new ExerciseEventPoint(
					eventPoint.getDatabaseId(), currentDate, glucoseLevel,
					durationMinute, intensity, notesEditText.getText()
							.toString());
			databaseManager.updateEvent(exerciseEventPoint);
		} else {
			exerciseEventPoint = new ExerciseEventPoint(currentDate,
					glucoseLevel, durationMinute, intensity, notesEditText
							.getText().toString());
			int rowId = (int) databaseManager.addEvent(exerciseEventPoint,
					false);
			exerciseEventPoint.setDatabaseId(rowId);
		}

		BluetoothPairBaseActivity.patientEventPoints.add(exerciseEventPoint);
		getService().postWritePatientEventPoint(exerciseEventPoint);

		finish();
	}
}
