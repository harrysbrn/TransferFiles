package com.senseonics.pairing.events.model;

public class BeginDiscoveryEvent {
  public BeginDiscoveryEvent() {
  }
}
