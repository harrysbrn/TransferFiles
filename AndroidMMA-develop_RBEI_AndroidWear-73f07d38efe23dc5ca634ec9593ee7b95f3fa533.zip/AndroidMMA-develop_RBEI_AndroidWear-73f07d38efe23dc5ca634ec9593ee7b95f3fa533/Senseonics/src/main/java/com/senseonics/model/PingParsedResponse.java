package com.senseonics.model;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;

import javax.inject.Inject;

public class PingParsedResponse implements ParsedResponse {

    @Inject
    public PingParsedResponse() {
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.PingResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isPingResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        int serialnumber = (data[4] << 24)
                + (data[3] << 16 )
                + (data[2] << 8 )
                + data[1];
        String transmitterID = "" + serialnumber;

        String transmitterName = "";
        if (data[5] != 0)
            transmitterName += Character.toString((char) data[5]);
        if (data[6] != 0)
            transmitterName += Character.toString((char) data[6]);
        if (data[7] != 0)
            transmitterName += Character.toString((char) data[7]);
        if (data[8] != 0)
            transmitterName += Character.toString((char) data[8]);
        if (data[9] != 0)
            transmitterName += Character.toString((char) data[9]);
        if (data[10] != 0)
            transmitterName += Character.toString((char) data[10]);
        if (data[11] != 0)
            transmitterName += Character.toString((char) data[11]);
        if (data[12] != 0)
            transmitterName += Character.toString((char) data[12]);

        model.setTransmitterName(transmitterName);

        model.setTransmitterSerialNumber(transmitterID);
    }
}
