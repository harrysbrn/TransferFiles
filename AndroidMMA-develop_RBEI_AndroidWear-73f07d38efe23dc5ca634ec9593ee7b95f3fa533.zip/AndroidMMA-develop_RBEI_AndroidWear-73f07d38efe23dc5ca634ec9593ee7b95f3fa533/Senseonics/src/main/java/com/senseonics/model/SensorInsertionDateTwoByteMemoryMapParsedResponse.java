package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class SensorInsertionDateTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public SensorInsertionDateTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.sensorInsertionDateAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{dataOne, dataTwo});
        model.setSensorInsertionDateOnly(date);
    }
}
