package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.events.EventUtils;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.DMSSSLSocketFactory;
import com.senseonics.util.DMSTaskCallback;
import com.senseonics.util.Item;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.KeyStore;
import java.util.ArrayList;

import static com.senseonics.util.AccountConstants.CheckAndUpdatePasswordResult.PwdUpdatedAndAuthenticated;

public class UserAccountBaseActivity extends BaseActivity implements DMSTaskCallback {
    protected Dialog dialog;
    protected String userID;
    protected AccountConstants.MLDMSResult dmsError = AccountConstants.MLDMSResult.None;
    private String Tag = "DMS(UABaseActivity)";
    protected ProgressDialog progressDialog;
    protected TextView btnSync;
    protected LinearLayout contentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize the preferences if needed
        accountConstants.initAccountSecurePreference();
        accountConstants.initAccountPreferences();

        // Add the content view
        contentLayout = (LinearLayout) findViewById(R.id.base_activity_linear_layout);

        progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        dismissDialog();
        dismissProgressDialog();
        super.onDestroy();
    }

    protected void setupBtnSyncOnClickEvent() {
    }

    protected void findViewForBtnSync() {
        btnSync = (TextView) findViewById(R.id.btnSync);
    }

    private void setTextForBtnSync(String textToSet) {
        // only update the text when the activity is UserAccountActivity
        if (this instanceof UserAccountActivity) {
            btnSync.setText(textToSet);
        }
    }

    protected void showDialog(String title, ArrayList<Item> items,
                              final EventUtils.PickerManager pickerManager, int currentSelected) {
        if (items.size() > 1) {
            if (dialog != null && dialog.isShowing())
                dialog.hide();
            dialog = dialogUtils.createPickerDialog(UserAccountBaseActivity.this,
                    title, items, pickerManager, currentSelected);
            dialog.show();
        }
    }

    /**
     * #3707
     */
    private String checkAndUpdatePassword(String userName, String password) {
        if (userName != null && !userName.equals("") && password != null && !password.equals("")) {
            try {
                String pwdHash = accountConstants.generateBase64RFC2898(password);
                String pwdBinary = accountConstants.stringToBase64Data(password);

                String requestString = accountConstants.generateCheckAndUpdatePassword(userName, pwdHash, pwdBinary);

                StringEntity entity = new StringEntity(requestString, HTTP.UTF_8);
                HttpPost httpPost = accountConstants.formHttpPost(
                        accountConstants.getDMSServerURL(),
                        accountConstants.checkAndUpdatePasswordWebserviceFunctionCall,
                        entity
                );

                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                SSLSocketFactory sf = new DMSSSLSocketFactory(trustStore);
                HttpClient client = accountConstants.createHttpClient(sf);

                HttpResponse response;

                try {
                    response = client.execute(httpPost);
                    return EntityUtils.toString(response.getEntity());
                } catch (ClientProtocolException e) {
                    Log.d(Tag, "Client Protocol Exception");
                } catch (SocketTimeoutException e) {
                    dmsError = AccountConstants.MLDMSResult.Timeout;
                    Log.d(Tag, "Socket timeout");
                } catch (ConnectTimeoutException e) {
                    dmsError = AccountConstants.MLDMSResult.Timeout;
                    Log.d(Tag, "Connect timeout");
                } catch (IOException e) {
                    dmsError = AccountConstants.MLDMSResult.ServerError;
                    Log.d(Tag, "IO Exception");
                    e.printStackTrace();
                }

                return "-1";
            } catch (UnsupportedEncodingException e) {
                Log.d(Tag, "Unsupported Encoding Exception");
                return "-1";
            } catch (Exception e) {
                Log.d(Tag, "Might be keystore exception");
                return "-1";
            }
        }
        return null;
    }

    /**
     * #3707
     */
    protected class checkAndUpdatePasswordAsynctask extends AsyncTask<Void, Void, Void> {
        private String userName;
        private String passWord;
        private String response;

        protected checkAndUpdatePasswordAsynctask(String userNameIn, String passWordIn) {
            this.userName = userNameIn;
            this.passWord = passWordIn;
        }

        @Override
        protected Void doInBackground(Void... params) {
            response = checkAndUpdatePassword(userName, passWord);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            if (response != null && !response.equals("-1")) {
                Boolean hasError = true;

                try {
                    String checkAndUpdatePasswordResult = null;
                    // Parse the result
                    XmlPullParser parser = Xml.newPullParser();
                    InputStream stream = new ByteArrayInputStream(response.getBytes());
                    parser.setInput(stream, null);

                    int event = parser.getEventType();
                    while (event != XmlPullParser.END_DOCUMENT) {
                        if (event == XmlPullParser.START_TAG) {
                            String name = parser.getName();
                            if (name != null && name.equals(accountConstants.TAG_CHECK_AND_UPDATE_PASSWORD_RESULT)) {
                                if (parser.next() == XmlPullParser.TEXT) {
                                    checkAndUpdatePasswordResult = parser.getText();
                                    break;
                                }
                            }
                        }
                        event = parser.next();
                    }

//                    Log.d(Tag, "checkAndUpdatePasswordResult:" + checkAndUpdatePasswordResult);
                    if ((checkAndUpdatePasswordResult != null) && !checkAndUpdatePasswordResult.equals("")) {
                        String[] results = checkAndUpdatePasswordResult.split(",");

                        if (results.length == 2) {
                            int pResultInt = Integer.parseInt(results[0]); // may have NumberFormatException
                            int uid = Integer.parseInt(results[1]); // may have NumberFormatException

                            // No error
                            hasError = false;

                            /** Get result ID */
                            AccountConstants.CheckAndUpdatePasswordResult pResult = AccountConstants.CheckAndUpdatePasswordResult.fromValue(pResultInt);

                            /** Save user ID if needed */
                            userID = Integer.toString(uid);

                            switch (pResult) {
                                case InvalidCredentials:
                                case EmailNotExist:
                                    dmsError = AccountConstants.MLDMSResult.IDNotFound;
                                    displayDMSResult(dmsError);
                                    break;

                                case PwdUpdatedAndAuthenticated:
                                case NoPwdUpdateNeededAndAuthenticated:
                                    /** Important since DMS does the data migration every midnight, there would be gap since midnight */
                                    if (pResult == PwdUpdatedAndAuthenticated) {
//                                        Log.d(Tag, "1. Set MigrationPasswordUpdated to YES");
                                        // set up the flag to true
                                        accountConstants.setMigrationPasswordUpdated(true);
                                    }
                                    // considered as login successfully
                                    dmsError = AccountConstants.MLDMSResult.DataSaved;
                                    TaskDone(dmsError, 0, 0);
                                    break;

                                case ServerError:
                                default:
                                    // unknown error
                                    dmsError = AccountConstants.MLDMSResult.ServerError;
                                    displayDMSResult(dmsError);
                                    break;
                            }
                        }
                    }
                } catch (XmlPullParserException | IOException | NumberFormatException e) {
                    e.printStackTrace();
                }

                if (hasError) {
                    dmsError = AccountConstants.MLDMSResult.ServerError;
                    displayDMSResult(dmsError);
                }
            } else {
                if (response == null) {
                    dmsError = AccountConstants.MLDMSResult.NotConnectedToWifi;
                    displayDMSResult(dmsError);
                } else {
                    dmsError = AccountConstants.MLDMSResult.ServerError;
                    displayDMSResult(dmsError);
                }
            }

            dismissProgressDialog();
        }
    }

    protected void displayDMSResult(AccountConstants.MLDMSResult error, Integer result2, Integer result3) {
        String title = "", message = "";
        switch (error) {

            case DataSaved:
                title = getString(R.string.data_saved);
                message = getString(R.string.data_saved_text);
                message = message.replaceFirst("%@", result2.toString());
                message = message.replaceFirst("%@", result3.toString());

                break;

            case GeneralErrorSavingData:
                title = getString(R.string.general_error_saving_data);
                message = getString(R.string.general_error_saving_data_text);
                break;

            case InvalidUserCredentials:
                title = getString(R.string.invalid_user_credentials_w_email);
                message = getString(R.string.invalid_user_credentials_text_w_email);
                break;

            case InvalidDeviceType:
                title = getString(R.string.invalid_device_type);
                message = getString(R.string.invalid_device_type_text);
                break;

            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.unknown_error_text);
                break;
        }

        displayDialogWithTitleAndMessage(title, message);
    }

    protected void displayDMSResult(AccountConstants.MLDMSResult error) {
        String title = "", message = "";
        switch (error) {
            case Timeout:
                title = getString(R.string.request_timeout);
                message = getString(R.string.request_timeout_text);
                break;
            case NotConnectedToWifi:
                title = getString(R.string.wi_fi_disconnected);
                message = getString(R.string.wi_fi_disconnected_text);
                break;
            case ServerError:
                title = getString(R.string.server_error);
                message = getString(R.string.server_error_text);
                break;
            case IDNotFound:
                title = getString(R.string.invalid_user_credentials_w_email);
                message = getString(R.string.invalid_user_credentials_text_w_email);
                break;
            case None:
                break;
            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.unknown_error_text);
                break;
        }

        displayDialogWithTitleAndMessage(title, message);
    }

    protected void displayDialogWithTitleAndMessage(String title, String message) {
        dismissDialog();
        dialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
                title, message));
        dialog.show();
    }

    protected void resetBtnTextDismissProgressDialog() {
        setTextForBtnSync(getString(R.string.sync_now));
        dismissProgressDialog();
    }

    private void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    private void dismissDialog() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    @Override
    public void TaskDone(AccountConstants.MLDMSResult dmsResult) {
        displayDMSResult(dmsResult);
        resetBtnTextDismissProgressDialog();
    }

    @Override
    public void TaskDone(AccountConstants.MLDMSResult dmsResult, Integer secondResult, Integer thirdResult) {
    }

}
