package com.senseonics.db;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class ConnectedTransmitterContentProvider extends ContentProvider{

    SenseonicsDBHelper helper;

    @Override
    public boolean onCreate() {
        helper = new SenseonicsDBHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return helper.getReadableDatabase().query(ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, projection, selection, selectionArgs, null, null, sortOrder);
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        SQLiteDatabase database = helper.getWritableDatabase();

        Cursor cursor = database.rawQuery("select count(*) from " + ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, null);
        cursor.moveToFirst();
        if (cursor.getInt(0) > 0) {
            performDelete(database);
        }

        long id = database.insert(ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, null, values);
        return Uri.withAppendedPath(uri, "" + id);
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase database = helper.getWritableDatabase();
        return performDelete(database);
    }

    private int performDelete(SQLiteDatabase database) {
        return database.delete(ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, null, null);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return helper.getWritableDatabase().update(ConnectedTransmitterTableInfo.CONNECTED_TRANSMITTER_TABLE, values, selection, selectionArgs);
    }
}
