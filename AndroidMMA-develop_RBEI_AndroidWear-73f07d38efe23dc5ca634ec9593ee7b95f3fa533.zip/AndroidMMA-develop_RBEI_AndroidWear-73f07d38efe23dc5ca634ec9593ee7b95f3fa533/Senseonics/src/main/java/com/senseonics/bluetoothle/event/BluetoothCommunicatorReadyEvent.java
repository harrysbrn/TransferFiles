package com.senseonics.bluetoothle.event;

public class BluetoothCommunicatorReadyEvent {
}
