package com.senseonics.events;

public class ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent {
    private int newValue;

    public ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
