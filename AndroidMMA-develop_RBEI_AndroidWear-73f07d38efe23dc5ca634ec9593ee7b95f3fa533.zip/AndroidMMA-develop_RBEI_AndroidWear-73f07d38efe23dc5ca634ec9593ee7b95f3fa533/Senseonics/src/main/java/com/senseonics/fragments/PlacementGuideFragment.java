package com.senseonics.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ServiceActivity;
import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.events.DismissPlacementGuide;
import com.senseonics.model.BATTERY_LEVEL;
import com.senseonics.model.ModelChangedEvent;
import com.senseonics.model.SIGNAL_STRENGTH;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class PlacementGuideFragment extends BaseFragment {

    private ImageView imageView;
    private TextView signalText;

    // Create the timer to update the signal strength
    private Timer placementGuideProcessTimer;
    private boolean initialSetup = false;
    private BluetoothService bluetoothService;

    @Inject
    protected EventBus eventBus;
    @Inject
    protected Handler handler;

    private boolean onCreateViewCalled;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      super.onCreateView(inflater, container, savedInstanceState);

        onCreateViewCalled = true;

      View view = inflater.inflate(R.layout.fragment_placementguide, container, false);
        imageView = (ImageView) view.findViewById(R.id.imageView);
        signalText = (TextView) view.findViewById(R.id.signalStrength);
//        getFragmentManager().

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("initial_setup"))
            initialSetup = true;

        return view;
    }


    public void onEventMainThread(ModelChangedEvent event) {
        setSignalStrength(event.getModel().getSignalStrength());
    }

    @Override
    public void onResume() {
        super.onResume();

        if (onCreateViewCalled) {
            eventBus.register(this);
            setSignalStrength(transmitterStateModel.getSignalStrength());
            startTimer();

            /** #3664 */
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).refreshAfterFragmentChanged();
            }
        }
        else {
            eventBus.post(new DismissPlacementGuide()); /** #3413 */
        }
    }

    @Override
    public void onPause() {
        onCreateViewCalled = false;
        stopSignalStrengthTimer();
        eventBus.unregister(this);
        super.onPause();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        bluetoothService = ((ServiceActivity) activity).getService();
    }

    private void startTimer() {
        // Check the battery
        if (transmitterStateModel.isTransmitterConnected()) {
            // Log.d("SignalStrength battery", "Battery: " +
            // Utils.batteryStrength);

            BATTERY_LEVEL battery_level = transmitterStateModel.getBatteryLevel();
            if ((battery_level == BATTERY_LEVEL.BL_0)
                    || (battery_level == BATTERY_LEVEL.BL_5)
                    || (battery_level == BATTERY_LEVEL.BL_10)
                    || (battery_level == BATTERY_LEVEL.UNKNOWN_NEG_1)) {
                // Log.d("SignalStrength battery", "Low Battery");

                // If is not the initial screen show notification
                if (!initialSetup) {
                    dialogUtils.createWarningDialogInfo((BluetoothPairBaseActivity)getActivity(),
                            -1,// no image needed
                            getString(R.string.placement_low_battery_title),
                            getString(R.string.placement_low_battery_body)
                                    .replace("%value%", transmitterStateModel.getSamplingIntervalInMinutes()+""));
                    return;
                }
            }
        }

        setupPlacementGuideProcess();
    }

    private void stopSignalStrengthTimer() {
        if (placementGuideProcessTimer != null) {
            placementGuideProcessTimer.cancel();
            placementGuideProcessTimer = null;

            // Quit the diagnostic mode
            if (bluetoothService != null) {
                bluetoothService.postExitDiagnosticMode();
            }
            transmitterStateModel.setPlacementModeInProgress(false);

        }
    }

    private void setupPlacementGuideProcess() {
        placementGuideProcessTimer = new Timer();
        transmitterStateModel.setPlacementModeInProgress(true);

        placementGuideProcessTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (bluetoothService != null) {
                    bluetoothService.postEnterDiagnosticMode();
                }
            }
        }, 0, TimeUnit.SECONDS.toMillis(30));

        placementGuideProcessTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                // Get the signal strength from the transmitter
                if (bluetoothService != null) {
                    bluetoothService.postReadSignalStrengthRequest();
                }
            }
        }, 0, TimeUnit.SECONDS.toMillis(3));


        placementGuideProcessTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (placementGuideProcessTimer != null) {
                    placementGuideProcessTimer.cancel();
                }
                final DialogUtils.NotificationDialogManager manager = new DialogUtils.NotificationDialogManager() {
                    @Override
                    public void rightButtonPressed() {
                        eventBus.post(new DismissPlacementGuide());
                    }

                    @Override
                    public void leftButtonPressed() {
                        startTimer();
                    }
                };
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (getActivity() != null) {
                            Dialog dialog = dialogUtils.createPlacementDialog(getActivity(), new DialogUtils.PlacementDialogInfo(manager));
                            dialog.show();
                        }
                    }
                });

            }
        }, TimeUnit.SECONDS.toMillis(90));
    }

    private void setSignalStrength(SIGNAL_STRENGTH signalStrength) {
        if (imageView != null && signalText != null) {
            switch (signalStrength) {

                case EXCELLENT:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_excellent_placement_guide);
                    signalText.setText(getString(R.string.excellent));
                    break;

                case GOOD:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_good_placement_guide);
                    signalText.setText(getString(R.string.good));
                    break;

                case LOW:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_low_placement_guide);
                    signalText.setText(getString(R.string.low));
                    break;

                case VERY_LOW:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_very_low_placement_guide);
                    signalText.setText(getString(R.string.very_low));
                    break;

                case POOR:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_poor_placement_guide);
                    signalText.setText(getString(R.string.poor));
                    break;

                case NO_SIGNAL:
                    imageView
                            .setImageResource(R.drawable.signal_indicator_no_signal_placement_guide);
                    signalText.setText(getString(R.string.no_signal));
                    break;

                default:
                    break;

            }
        }
    }
}
