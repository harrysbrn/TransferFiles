package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DMSStateModelSyncManager;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.bluetoothle.TempProfileManager;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.model.ModelChangedEvent;
import com.senseonics.util.Convert;
import com.senseonics.util.Item;
import com.senseonics.util.ThresholdsController;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.GLUCOSE_UNIT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

import javax.inject.Inject;

public class GlucoseSettingsActivity extends BaseActivity {
	private final TempProfileManager.GLUCOSE_PROFILE_TYPE NonTemp = TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP;

	private Dialog dialog;
	private ProgressDialog progressDialog;
	private ArrayList<Item> values;
	private SharedPreferences sharedPreferences;

	@Inject
	protected ThresholdsController thresholdsController;
	@Inject
	protected TempProfileManager tempProfileManager;

	// predictive alerts : 10 - 60
	private float incValueRate = 0.5f;
	// rate alerts : 1.5 - 5.0
	private float rateAlertMin = 1.5f, rateAlertMax = 5.0f;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_glucose, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.glucose_event);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);

		progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
		progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
		progressDialog.setCancelable(true);

		sharedPreferences = getSharedPreferences(Utils.SHARED_PREF,
				Context.MODE_PRIVATE);
	}

	public void onEventMainThread(ModelChangedEvent event) {
		if (progressDialog.isShowing())
			progressDialog.dismiss();
		loadSettingsViews();
	}

	@Override
	protected void onResume() {
		super.onResume();
		loadSettingsViews();
	}

	public void loadSettingsViews() {
		initGlucoseTargetLevels();
		initGlucoseAlarmLevels();
		initPredictiveAlerts();
		initRateAlerts();
	}

	public void showDialog(String title, ArrayList<Item> items,
			final PickerManager pickerManager, int currentSelected) {
		if (items.size() > 1) {
			if (dialog != null && dialog.isShowing())
				dialog.hide();
			dialog = dialogUtils.createPickerDialog(GlucoseSettingsActivity.this,
                    title, items, pickerManager, currentSelected);
			dialog.show();
		}
	}

	// GLUCOSE TARGET LEVELS
	public void initGlucoseTargetLevels() {
		LinearLayout contentLayout = (LinearLayout) findViewById(R.id.contentLayoutTargets);
		TextView glucoseTargetHighTextView = (TextView) findViewById(R.id.glucoseTargetHighTextView);
		TextView glucoseTargetLowTextView = (TextView) findViewById(R.id.glucoseTargetLowTextView);
		final TextView targetHighTextView = (TextView) findViewById(R.id.targetHigh);
		final TextView targetLowTextView = (TextView) findViewById(R.id.targetLow);
		RelativeLayout targetHighLayout = (RelativeLayout) findViewById(R.id.targetHighLayout);
		RelativeLayout targetLowLayout = (RelativeLayout) findViewById(R.id.targetLowLayout);

		if (BluetoothUtils.mConnected) {
			final PickerManager managerTargetHigh = new PickerManager() {

				@Override
				public void selected(int id) {
					int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
					/** #3789 */
					selectedVal = thresholdsController.getTargetHighWithRangeChecked(selectedVal);

					targetHighTextView.setText(Utils.getGlucoseLevelString(
							GlucoseSettingsActivity.this,
							selectedVal));

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) { // do not write to tx
						tempProfileManager.setThresholdForAttributeForProfileType(
								selectedVal,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH,
								NonTemp);

						displayTempProfileEnabledWarning();
					}
					else {
						Utils.GLUCOSE_TARGET_HIGH = selectedVal;
						sharedPreferences
								.edit()
								.putInt(Utils.prefTargetHigh, selectedVal).commit();
						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							getService().postWriteHighGlucoseTarget(selectedVal);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}
					}
				}
			};

			targetHighLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String dialogTitleHigh = getResources().getString(
							R.string.high_target);

					int valueToDisplay = Utils.GLUCOSE_TARGET_HIGH;
					values = thresholdsController.getTargetHighValues(Utils.GLUCOSE_TARGET_LOW, Utils.GLUCOSE_ALARM_LEVEL_HIGH);

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) {
						valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH);

						values = thresholdsController.getTargetHighValues(
								tempProfileManager.getThresholdForProfileTypeForAttribute(
										NonTemp,
										TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW),
								tempProfileManager.getThresholdForProfileTypeForAttribute(
										NonTemp,
										TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH));
					}

					int position = thresholdsController.getPosition(valueToDisplay, values);
					showDialog(dialogTitleHigh, values, managerTargetHigh,
							position);
				}
			});


			final PickerManager managerTargetLow = new PickerManager() {

				@Override
				public void selected(int id) {
					int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
					/** #3789 */
					selectedVal = thresholdsController.getTargetLowWithRangeChecked(selectedVal);

					targetLowTextView.setText(Utils.getGlucoseLevelString(
							GlucoseSettingsActivity.this,
							selectedVal));

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) { // do not write to tx
						tempProfileManager.setThresholdForAttributeForProfileType(
								selectedVal,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW,
								NonTemp);

						displayTempProfileEnabledWarning();
					}
					else {
						Utils.GLUCOSE_TARGET_LOW = selectedVal;
						sharedPreferences
								.edit()
								.putInt(Utils.prefTargetLow, selectedVal).commit();
						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							getService().postWriteLowGlucoseTargetRequest(selectedVal);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}
					}
				}
			};

			targetLowLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String dialogTitleLow = getResources().getString(
							R.string.low_target);

					int valueToDisplay = Utils.GLUCOSE_TARGET_LOW;
					values = thresholdsController.getTargetLowValues(Utils.GLUCOSE_TARGET_HIGH, Utils.GLUCOSE_ALARM_LEVEL_LOW);

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) {
						valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW);

						values = thresholdsController.getTargetLowValues(
								tempProfileManager.getThresholdForProfileTypeForAttribute(
										NonTemp,
										TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH),
								tempProfileManager.getThresholdForProfileTypeForAttribute(
										NonTemp,
										TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW));
					}

					int position = thresholdsController.getPosition(valueToDisplay, values);
					showDialog(dialogTitleLow, values, managerTargetLow,
							position);
				}
			});

			contentLayout.setBackgroundColor(getResources().getColor(
					android.R.color.white));
			glucoseTargetHighTextView.setTextColor(getResources().getColor(
					R.color.black));
			glucoseTargetLowTextView.setTextColor(getResources().getColor(
					R.color.black));
			targetHighTextView.setTextColor(getResources().getColor(
					R.color.black));
			targetLowTextView.setTextColor(getResources().getColor(
					R.color.black));
			targetHighLayout.setClickable(true);
			targetLowLayout.setClickable(true);
			
		} else {
			
			contentLayout.setBackgroundColor(getResources().getColor(
					R.color.inactive_gray));
			glucoseTargetHighTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			glucoseTargetLowTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			targetHighTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			targetLowTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			targetHighLayout.setClickable(false);
			targetLowLayout.setClickable(false);
		}

		if (tempProfileManager.getTempProfileEnabled()) {
			targetHighTextView.setText(Utils.getGlucoseLevelString(this,
					tempProfileManager.getThresholdForProfileTypeForAttribute(
							NonTemp,
							TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH)));
			targetLowTextView.setText(Utils.getGlucoseLevelString(this,
					tempProfileManager.getThresholdForProfileTypeForAttribute(
							NonTemp,
							TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW)));
		}
		else {
			targetHighTextView.setText(Utils.getGlucoseLevelString(this,
					Utils.GLUCOSE_TARGET_HIGH));
			targetLowTextView.setText(Utils.getGlucoseLevelString(this,
					Utils.GLUCOSE_TARGET_LOW));
		}
	}

	// GLUCOSE ALARM LEVELS
	public void initGlucoseAlarmLevels() {

		final TextView alarmHighTextView = (TextView) findViewById(R.id.alarmHigh);
		final TextView alarmLowTextView = (TextView) findViewById(R.id.alarmLow);
		RelativeLayout alarmHighLayout = (RelativeLayout) findViewById(R.id.alarmHighLayout);
		RelativeLayout alarmLowLayout = (RelativeLayout) findViewById(R.id.alarmLowLayout);
		LinearLayout contentLayout = (LinearLayout) findViewById(R.id.contentLayoutAlarm);
		TextView glucoseAlarmHighTextView = (TextView) findViewById(R.id.glucoseAlarmHighTextView);
		TextView glucoseAlarmLowTextView = (TextView) findViewById(R.id.glucoseAlarmLowTextView);

		if (BluetoothUtils.mConnected) {

			final PickerManager managerAlarmHigh = new PickerManager() {

				@Override
				public void selected(int id) {
					int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
					/** #3789 */
					selectedVal = thresholdsController.getAlarmHighWithRangeChecked(selectedVal);

					alarmHighTextView.setText(Utils.getGlucoseLevelString(
							GlucoseSettingsActivity.this,
							selectedVal));

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) { // do not write to tx
						tempProfileManager.setThresholdForAttributeForProfileType(
								selectedVal,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH,
								NonTemp);

						displayTempProfileEnabledWarning();
					}
					else {
						Utils.GLUCOSE_ALARM_LEVEL_HIGH = selectedVal;
						sharedPreferences
								.edit()
								.putInt(Utils.prefAlarmHigh, selectedVal).commit();
						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							getService().postWriteHighGlucoseAlarmRequest(selectedVal);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}

					}
				}
			};
			alarmHighLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String dialogTitleHigh = getString(R.string.high_alert); /** #3214 */

					int valueToDisplay = Utils.GLUCOSE_ALARM_LEVEL_HIGH;
					values = thresholdsController.getAlarmHighValues(Utils.GLUCOSE_TARGET_HIGH);

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) {
						valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH);

						values = thresholdsController.getAlarmHighValues(tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH));
					}

					int position = thresholdsController.getPosition(valueToDisplay, values);
					showDialog(dialogTitleHigh, values, managerAlarmHigh,
							position);
				}
			});


			final PickerManager managerAlarmLow = new PickerManager() {

				@Override
				public void selected(int id) {
					int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
					/** #3789 */
					selectedVal = thresholdsController.getAlarmLowWithRangeChecked(selectedVal);

					alarmLowTextView.setText(Utils.getGlucoseLevelString(
							GlucoseSettingsActivity.this,
							selectedVal));

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) { // do not write to tx
						tempProfileManager.setThresholdForAttributeForProfileType(
								selectedVal,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW,
								NonTemp);

						displayTempProfileEnabledWarning();
					}
					else {
						Utils.GLUCOSE_ALARM_LEVEL_LOW = selectedVal;
						sharedPreferences
								.edit()
								.putInt(Utils.prefAlarmLow, selectedVal).commit();
						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							getService().postWriteLowGlucoseAlarmRequest(selectedVal);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}
					}
				}
			};
			alarmLowLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String dialogTitleLow = getString(R.string.low_alert); /** #3214 */

					int valueToDisplay = Utils.GLUCOSE_ALARM_LEVEL_LOW;
					values = thresholdsController.getAlarmLowValues(Utils.GLUCOSE_TARGET_LOW);

					/** #3160 */
					if (tempProfileManager.getTempProfileEnabled()) {
						valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW);

						values = thresholdsController.getAlarmLowValues(tempProfileManager.getThresholdForProfileTypeForAttribute(
								NonTemp,
								TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW));
					}

					int position = thresholdsController.getPosition(valueToDisplay, values);
					showDialog(dialogTitleLow, values, managerAlarmLow,
							position);
				}
			});
			contentLayout.setBackgroundColor(getResources().getColor(
					android.R.color.white));
			glucoseAlarmHighTextView.setTextColor(getResources().getColor(
					R.color.black));
			glucoseAlarmLowTextView.setTextColor(getResources().getColor(
					R.color.black));
			alarmHighTextView.setTextColor(getResources().getColor(
					R.color.black));
			alarmLowTextView.setTextColor(getResources()
					.getColor(R.color.black));
			alarmLowLayout.setClickable(true);
			alarmHighLayout.setClickable(true);
			
		} else {
			
			contentLayout.setBackgroundColor(getResources().getColor(
					R.color.inactive_gray));
			glucoseAlarmHighTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			glucoseAlarmLowTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			alarmHighTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			alarmLowTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			alarmLowLayout.setClickable(false);
			alarmHighLayout.setClickable(false);
		}

		if (tempProfileManager.getTempProfileEnabled()) {
			alarmHighTextView.setText(Utils.getGlucoseLevelString(
					GlucoseSettingsActivity.this, tempProfileManager.getThresholdForProfileTypeForAttribute(
							NonTemp,
							TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH)));
			alarmLowTextView.setText(Utils.getGlucoseLevelString(
					GlucoseSettingsActivity.this, tempProfileManager.getThresholdForProfileTypeForAttribute(
							NonTemp,
							TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW)));
		}
		else {
			alarmHighTextView.setText(Utils.getGlucoseLevelString(
					GlucoseSettingsActivity.this, Utils.GLUCOSE_ALARM_LEVEL_HIGH));
			alarmLowTextView.setText(Utils.getGlucoseLevelString(
					GlucoseSettingsActivity.this, Utils.GLUCOSE_ALARM_LEVEL_LOW));
		}
	}

	// PREDICTIVE ALERTS
	public void initPredictiveAlerts() {

		RelativeLayout predictiveMinutesLayout = (RelativeLayout) findViewById(R.id.minutesFromAlertLayout);
		RelativeLayout predictiveMinutesOnOffLayout = (RelativeLayout) findViewById(R.id.predictiveAlertOnOff);

		final TextView minutesFromAlertTextView = (TextView) findViewById(R.id.minutesFromAlert);

		Switch predictiveAlertSwitch = (Switch) findViewById(R.id.predictiveAlertSwitch);
		predictiveAlertSwitch.setSwitchTextAppearance(this,
				R.style.SwitchTextAppearanceWhite);

		LinearLayout contentLayout = (LinearLayout) findViewById(R.id.contentLayoutPredictive);
		TextView predictiveAlertsTextView = (TextView) findViewById(R.id.predictiveAlertsTextView);
		TextView minutsFromAlertTextView = (TextView) findViewById(R.id.minutesFromAlertTextView);

		if (BluetoothUtils.mConnected) {

			predictiveAlertSwitch
					.setOnCheckedChangeListener(new OnCheckedChangeListener() {

						@Override
						public void onCheckedChanged(CompoundButton buttonView,
													 boolean isChecked) {
							if (isChecked) {
								Utils.predictiveAlertsActivated = true;
								minutesFromAlertTextView
										.setText(Utils.PREDICTIVE_MINUTES
												+ " ");
							} else {
								Utils.predictiveAlertsActivated = false;
								minutesFromAlertTextView
										.setText(Utils.unknownString);
							}
							sharedPreferences
									.edit()
									.putBoolean(
											Utils.prefPredictiveAlertsActivated,
											Utils.predictiveAlertsActivated)
									.commit();
							if (BluetoothUtils.mConnected) {
								progressDialog.show();
								getService().postWritePredictiveAlertsRequest(Utils.predictiveAlertsActivated);

								/** #3282 Upload the threshold info when user changes the settings */
								uploadThresholdInfoToDMSServer();
							}
						}
					});

			final PickerManager pickerManager = new PickerManager() {

				@Override
				public void selected(int id) {
					String[] strings = values.get(id).getValue().split(" ");
					if (strings.length > 0) {
						Utils.PREDICTIVE_MINUTES = Integer.valueOf(strings[0]);
						minutesFromAlertTextView
								.setText(Utils.PREDICTIVE_MINUTES + " ");
						sharedPreferences
								.edit()
								.putInt(Utils.prefPredictiveMinutes,
										Utils.PREDICTIVE_MINUTES).commit();
						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							getService().postWritePredictiveTimeIntervalRequest(Utils.PREDICTIVE_MINUTES);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}
					}
				}
			};
			predictiveMinutesLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					if (Utils.predictiveAlertsActivated) {

						String dialogTitle = getResources().getString(
								R.string.minutes_from_alert_level);
						values = new ArrayList<Item>();

						values.addAll(Arrays.asList(
								new Item(0, "10"),
								new Item(1, "20"),
								new Item(2, "30"))); //#2645 Remove the option of 45 minutes/60 minutes from predictive alert (Android)
						int position = getMinuteItemPosition(values,
								Utils.PREDICTIVE_MINUTES);
						showDialog(dialogTitle, values, pickerManager, position);
					}
				}
			});
			contentLayout.setBackgroundColor(getResources().getColor(
					android.R.color.white));
			predictiveAlertsTextView.setTextColor(getResources().getColor(
					R.color.black));
			minutsFromAlertTextView.setTextColor(getResources().getColor(
					R.color.black));
			minutesFromAlertTextView.setTextColor(getResources().getColor(
					R.color.black));
			predictiveAlertSwitch.setEnabled(true);
			predictiveMinutesLayout.setClickable(true);
			
		} else {
			
			contentLayout.setBackgroundColor(getResources().getColor(
					R.color.inactive_gray));
			predictiveAlertsTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			minutsFromAlertTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			minutesFromAlertTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			predictiveAlertSwitch.setEnabled(false);
			predictiveMinutesLayout.setClickable(false);
		}

		predictiveMinutesOnOffLayout.setClickable(false);

		if (Utils.predictiveAlertsActivated)
			minutesFromAlertTextView.setText(Utils.PREDICTIVE_MINUTES + " ");
		else
			minutesFromAlertTextView.setText(Utils.unknownString);
		predictiveAlertSwitch.setChecked(Utils.predictiveAlertsActivated);
	}

	// RATE ALERTS
	public void initRateAlerts() {

		RelativeLayout rateAlertLayout = (RelativeLayout) findViewById(R.id.rateAlertLayout);
		RelativeLayout rateAlertOnOffLayout = (RelativeLayout) findViewById(R.id.rateAlertOnOff);
		final TextView rateAlertTextView = (TextView) findViewById(R.id.rateAlert);
		Switch rateAlertSwitch = (Switch) findViewById(R.id.rateAlertSwitch);
		rateAlertSwitch.setSwitchTextAppearance(this,
				R.style.SwitchTextAppearanceWhite);

		TextView unitTextView = (TextView) findViewById(R.id.unitText);
		unitTextView.setText(R.string.rate_of_change);
		LinearLayout contentLayout = (LinearLayout) findViewById(R.id.contentLayoutRate);
		TextView rateAlertsTextView = (TextView) findViewById(R.id.rateAlertsTextView);

		if (BluetoothUtils.mConnected) {
			final PickerManager pickerManager = new PickerManager() {

				@Override
				public void selected(int id) {
					String[] strings = values.get(id).getValue().split(" ");
					if (strings.length > 0) {
						if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
							Utils.RATE_VALUE = Float.valueOf(strings[0]);
						} else {
							Utils.RATE_VALUE = Convert.MLConvertMmolToMgRate(Float
									.valueOf(strings[0]));
						}
						rateAlertTextView.setText(strings[0] + "");

						sharedPreferences
								.edit()
								.putFloat(Utils.prefRateValue, Utils.RATE_VALUE)
								.commit();

						if (BluetoothUtils.mConnected) {
							progressDialog.show();
							int rate = (int) (Utils.RATE_VALUE * 10);
							Log.d(GlucoseSettingsActivity.class.getSimpleName(), rate + " _-_-_-_-_-_-_-_-_-_-");
							getService().postWriteRateAlertThresholdRequest(rate);

							/** #3282 Upload the threshold info when user changes the settings */
							uploadThresholdInfoToDMSServer();
						}

					}
				}
			};
			rateAlertSwitch
					.setOnCheckedChangeListener(new OnCheckedChangeListener() {

						@Override
						public void onCheckedChanged(CompoundButton buttonView,
								boolean isChecked) {

							if (isChecked) {
								Utils.rateAlertsActivated = true;
								if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
									rateAlertTextView.setText(String
											.valueOf(Utils.RATE_VALUE));
								} else {
									rateAlertTextView.setText(String.valueOf(Convert
											.MLConvertMmolToMg(Utils.RATE_VALUE)));
								}
							} else {
								Utils.rateAlertsActivated = false;
								rateAlertTextView.setText(Utils.unknownString);
							}
							sharedPreferences
									.edit()
									.putBoolean(Utils.prefRateAlertsActivated,
											Utils.rateAlertsActivated).commit();
							if (BluetoothUtils.mConnected) {
								progressDialog.show();
								getService().postWriteRateAlert(Utils.rateAlertsActivated);

								/** #3282 Upload the threshold info when user changes the settings */
								uploadThresholdInfoToDMSServer();
							}
						}
					});

			rateAlertLayout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (Utils.rateAlertsActivated) {

						String dialogTitle = getResources().getString(
								R.string.rate_of_change);

						values = dialogUtils.getRateLevels(rateAlertMin,
								rateAlertMax, incValueRate);
						int position = 0;
						if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
							position = Utils.getItemPosition(values,
									Utils.RATE_VALUE);
						} else {
							position = Utils.getItemPosition(values,String.format(Locale.US, "%.2f", Convert.MLConvertMgToMmol(Utils.RATE_VALUE)));

						}
						showDialog(dialogTitle, values, pickerManager, position);
					}
				}
			});

			contentLayout.setBackgroundColor(getResources().getColor(
					android.R.color.white));
			rateAlertsTextView.setTextColor(getResources().getColor(
					R.color.black));
			unitTextView.setTextColor(getResources().getColor(R.color.black));
			rateAlertTextView.setTextColor(getResources().getColor(
					R.color.black));
			rateAlertSwitch.setEnabled(true);
			rateAlertLayout.setClickable(true);
			
		} else {
			
			contentLayout.setBackgroundColor(getResources().getColor(
					R.color.inactive_gray));
			rateAlertsTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			unitTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			rateAlertTextView.setTextColor(getResources().getColor(
					R.color.light_gray));
			rateAlertSwitch.setEnabled(false);
			rateAlertLayout.setClickable(false);
		}

		rateAlertOnOffLayout.setClickable(false);

		if (Utils.rateAlertsActivated) {
			if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
				rateAlertTextView.setText(String.format(Locale.US, "%.1f %s",
						Utils.RATE_VALUE, "mg/dL/min"));
			} else {
				float glucoseMMol = Convert.MLConvertMgToMmol(Utils.RATE_VALUE);
				rateAlertTextView.setText(String.format(Locale.US, "%.2f %s", glucoseMMol,
						"mmol/L/min"));
			}
		} else {
			rateAlertTextView.setText(Utils.unknownString);
		}

		rateAlertSwitch.setChecked(Utils.rateAlertsActivated);
	}

	public int getMinuteItemPosition(ArrayList<Item> items, int value) {
		for (int i = 0; i < items.size(); ++i) {
			String[] strings = items.get(i).getValue().split(" ");
			if (strings.length > 0) {
				int minute = Integer.valueOf(strings[0]);
				if (minute == value)
					return i;
			}
		}
		return -1;
	}

	@Override
	public void onBackPressed() {
		MainActivity.needToRefreshGraph = true;
		super.onBackPressed();
	}

	private void displayTempProfileEnabledWarning() {
		displayDialogWithTitleAndMessage(null, getResources().getString(R.string.temp_profile_glucose_settings_warning));
	}

	private void displayDialogWithTitleAndMessage(String title, String message) {
		if (this.isThisActivityTop()) {
			if (dialog != null && dialog.isShowing()) {
				dialog.dismiss();
			}
			dialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
					title, message));
			dialog.show();
		}
	}

	/** #3282 */
	private void uploadThresholdInfoToDMSServer() {
		// upload the info after a delay since it's fetching from transmitter state model
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				DMSStateModelSyncManager.uploadThresholdInfo(accountConstants, stateModelUploadUtility);
			}
		}, GraphUtils.SECOND);
	}
}
