package com.senseonics.events;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.jjoe64.graphview.Graph;
import com.jjoe64.graphview.LineGraphView;
import com.senseonics.gen12androidapp.BaseActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.DialogUtils.DateDialogManager;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class EventActivity extends BaseActivity {

	protected Calendar startDate, endDate, currentDate;
	protected EditText notesEditText;

	protected EventPoint eventPoint;

	private Graph graphView;
	private int screenWidth;
	protected LinearLayout contentLayout;
	protected int glucoseLevel;
	protected boolean isEditing;
	protected LayoutInflater inflater;
	protected boolean hasSaveButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		hasSaveButton = true;
		inflater = LayoutInflater.from(this);

		if (getIntent().getExtras() != null
				&& getIntent().getExtras().containsKey("edit")) {
			isEditing = true;
			initLayoutWithGraph();
		} else {
			isEditing = false;
			initEventLayout();
		}

		contentLayout = (LinearLayout) findViewById(R.id.content);

		// overridePendingTransition(R.anim.animation_up_in,
		// R.anim.anim_nothing);

		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			startDate = (Calendar) extras.getSerializable("startdate");
			endDate = (Calendar) extras.getSerializable("enddate");
			if (currentDate == null) {
				currentDate = (Calendar) extras.getSerializable("currentdate");
				currentDate.set(Calendar.SECOND, 0);
				currentDate.set(Calendar.MILLISECOND, 0);
			}
		}

		if (startDate == null || endDate == null) {
			startDate = Calendar.getInstance();
			endDate = Calendar.getInstance();
		}
		if (currentDate == null)
			currentDate = Calendar.getInstance();

		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

	}

	public void hideKeyboard(View view) {
		InputMethodManager imm = (InputMethodManager) EventActivity.this
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(view.getApplicationWindowToken(),
				InputMethodManager.HIDE_NOT_ALWAYS);
	}

	@Override
	protected void onResume() {
		super.onResume();

		// Select date
		final TextView date = (TextView) findViewById(R.id.date);
		final View dateView = (View) findViewById(R.id.dateView);
		notesEditText = (EditText) findViewById(R.id.notes);

		if (eventPoint != null && notesEditText != null) {
			notesEditText.setImeOptions(EditorInfo.IME_ACTION_DONE);
			notesEditText.setRawInputType(InputType.TYPE_CLASS_TEXT);
			notesEditText.setText(eventPoint.getNotes());
			notesEditText.setSelection(notesEditText.getText().length());
		}
		
		if(isEditing == false)
		{
			if(currentDate == null) {
				// Get the NOW date time
				currentDate = Calendar.getInstance();
			}
		}
		
		if (date != null)
		{
			date.setText(Utils.formatDate(currentDate, TimeZone.getDefault(),EventActivity.this));
		}
		
		final DateDialogManager dialogManager = new DateDialogManager() {

			@Override
			public void onDateSelected(Calendar calendar) {
				currentDate = calendar;
				date.setText(Utils.formatDate(currentDate,
						TimeZone.getDefault(),EventActivity.this));
			}
		};

		if (dateView != null)
			dateView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					hideKeyboard(v);
                    dialogUtils.createDateTimePickerDialog(EventActivity.this,
                            currentDate, startDate, endDate, dialogManager, false);
				}
			});

		if (isEditing) {

			if (hasSaveButton) {
				naviBarLeftItemTextView.setVisibility(View.GONE);
				// Create the "Save" button on the right on the navigation bar
				naviBarRightItemTextView.setVisibility(View.VISIBLE);
				naviBarRightItemTextView.setText(R.string.save);
				naviBarRightItemTextView.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						hideKeyboard(v);
						onSavePressed();
					}
				});

				LinearLayout bottomLayout = (LinearLayout) findViewById(R.id.event_hide_button_layout);
				/** only add the bottom Hide button layout if it does not exist */
				if (bottomLayout == null) {
					LinearLayout act_graph_linear_layout = (LinearLayout) findViewById
							(R.id.activity_event_log_graphview_linearlayout);
					RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
							LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

					View view = inflater.inflate(R.layout.event_hide_button, null);
					view.setLayoutParams(params);
					act_graph_linear_layout.addView(view);

					LinearLayout buttonsParent = (LinearLayout) view
							.findViewById(R.id.event_hide_button_layout);
					buttonsParent.setBackgroundColor(getResources().getColor(
							R.color.transparent));
					TextView cancelButton = (TextView) view
							.findViewById(R.id.hidebutton);
					cancelButton
							.setTextColor(getResources().getColor(R.color.graph_white));
					cancelButton
							.setBackgroundColor(getResources().getColor(R.color.graph_red));
					cancelButton.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							createDialog(getString(R.string.hide_event_question));
						}
					});

					// Stretch the Hide button
					LayoutParams params_hide = new LinearLayout.LayoutParams(
							LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT,
							1f);
					cancelButton.setLayoutParams(params_hide);
				}
			}
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private void addContentView(int resource)
	{
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(resource, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.event_log);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);
	}
	
	public void initLayoutWithGraph() {
		this.addContentView(R.layout.activity_event_log_graphview);
		
		Bundle extras = getIntent().getExtras();

		Calendar startDate, endDate;
		startDate = Calendar.getInstance();
		endDate = Calendar.getInstance();

		ArrayList<EventPoint> events = new ArrayList<EventPoint>();

		if (extras.containsKey("eventPoint")) {

			eventPoint = (EventPoint) extras.getSerializable("eventPoint");
			currentDate = eventPoint.getCalendar();
			startDate.setTimeZone(TimeZone.getTimeZone("GMT"));
			endDate.setTimeZone(TimeZone.getTimeZone("GMT"));
            // static graph start date to be 90 mins before the event;
            // end date to be 90 mins after the event
			startDate.setTimeInMillis(currentDate.getTimeInMillis()
					- GraphUtils.MINUTE * 90);
			endDate.setTimeInMillis(currentDate.getTimeInMillis()
					+ GraphUtils.MINUTE * 90);
		}

		List<List<Glucose>> glucosePoints = databaseManager
				.getGlucoseBetween(startDate, endDate, GraphUtils.MINUTE);
		events = databaseManager.getEventsBetween(startDate, endDate,
				Utils.GLUCOSE_LEVEL_UNKNOWN, Utils.GLUCOSE_MAX);

		// ---------------------------------
		RelativeLayout graphLayout = (RelativeLayout) findViewById(R.id.graphView);

		DisplayMetrics metrics = new DisplayMetrics();
		this.getWindowManager().getDefaultDisplay().getMetrics(metrics);

		screenWidth = metrics.widthPixels;

		int margin = (int) getResources().getDimension(R.dimen.box_margin);
		int graphWidth = screenWidth - (2 * margin);
		int graphHeight = (screenWidth * 2) / 3;

		graphView = new LineGraphView(this, "", startDate, endDate, graphWidth,
				graphHeight, graphWidth, 0, false, true); // the last false means it's a static graph
		graphView.addSeries(glucosePoints);
		graphView.setEventPoints(events, startDate, endDate);
		graphView.setScalable(false);
		graphView.setScrollable(false);

        ((LineGraphView) graphView).setDrawBackground(true);

		RelativeLayout.LayoutParams graphParams = new RelativeLayout.LayoutParams(
				graphWidth, graphHeight);
		graphView.setLayoutParams(graphParams);

		graphLayout.addView(graphView);

	}

	public void initEventLayout() {
		this.addContentView(R.layout.activity_event_log);

		// Configure the navigation bar to have Cancel and Save buttons
		naviBarLeftItemTextView.setVisibility(View.VISIBLE);
		naviBarLeftItemTextView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				onBackPressed();
			}
		});

		naviBarRightItemTextView.setVisibility(View.VISIBLE);
		naviBarRightItemTextView.setText(R.string.save);
        naviBarRightItemTextView.setTypeface(Typeface.DEFAULT_BOLD);
		naviBarRightItemTextView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				hideKeyboard(v);
				onSavePressed();
			}
		});
	}

	public void onSavePressed() {

		currentDate.set(Calendar.SECOND, 0);
		currentDate.set(Calendar.MILLISECOND, 0);
		glucoseLevel = databaseManager.getGlucoseLevelAt(currentDate, true);
		if (glucoseLevel == -1) {
			glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN;
		}
	}

	public void createDialog(String text) {
		final Dialog dialog = new Dialog(EventActivity.this,
				R.style.PickerDialog);

		LayoutInflater inflater = LayoutInflater.from(EventActivity.this);
		View view = inflater.inflate(R.layout.dialog, null);

		TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(text);

        TextView titleView = (TextView) view.findViewById(R.id.title);
        titleView.setVisibility(View.VISIBLE);
        titleView.setText(getString(R.string.hide));


        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setText(getString(R.string.no));
        cancelText.setTypeface(Typeface.DEFAULT_BOLD);
		cancelText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(getString(R.string.yes));
        okText.setTypeface(Typeface.DEFAULT);
		okText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
				eventPoint.setEventHidden(true);

				eventPoint.setCalendarEventHidden(Calendar.getInstance());
				databaseManager.updateEvent(eventPoint);
				// databaseManager.deleteEvent(eventPoint);
				if (eventPoint.getRecordNumber() > 0) {
					bluetoothServiceCommandClient.postMarkPatientEventDeleted(eventPoint.getRecordNumber());
				}
				Intent intent = new Intent();
				setResult(MainActivity.RESULT_DELETED, intent);
				EventActivity.this.finish();
			}
		});

		dialog.setContentView(view);
		dialog.show();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
}
