package com.senseonics.bluetoothle.event;

public class TransmitterRSSIEvent {
    private int RSSIValue;

    public TransmitterRSSIEvent(int RSSIValueIn){
        this.RSSIValue = RSSIValueIn;
    }

    public int getRSSIValue() {
        return this.RSSIValue;
    }

    @Override
    public String toString() {
        return "TransmitterRSSIEvent: rssi value " + this.RSSIValue;
    }
}
