package com.senseonics.graph.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.ArrayList;
import java.util.TimeZone;

public class EventsListAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<EventPoint> eventPoints;
	private LayoutInflater layoutInflater;

	public EventsListAdapter(Context context, ArrayList<EventPoint> eventPoints) {
		super();
		this.context = context;
		this.eventPoints = eventPoints;
		layoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return eventPoints.size();
	}

	@Override
	public Object getItem(int arg0) {
		return eventPoints.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	public void setEvents(ArrayList<EventPoint> eventPoints) {
		this.eventPoints = eventPoints;
	}

	public void setEvent(EventPoint eventPoint) {
		eventPoints = new ArrayList<EventPoint>();
		eventPoints.add(eventPoint);
	}

	@Override
	public View getView(int arg0, View view, ViewGroup arg2) {

		ViewHolder holder = null;
		if (arg0 < eventPoints.size()) {

			if (view == null) {
				view = layoutInflater.inflate(R.layout.event_listitem, null);
				holder = new ViewHolder();
				holder.imageView = (ImageView) view
						.findViewById(R.id.imageView);
				holder.timeTextView = (TextView) view
						.findViewById(R.id.timeView);
				holder.eventTypeTextView = (TextView) view
						.findViewById(R.id.eventType);
				view.setTag(holder);
			} else {
				holder = (ViewHolder) view.getTag();
			}

			EventPoint eventPoint = eventPoints.get(arg0);

			// update view
			EVENT_TYPE eventType = eventPoint.getEventType();
			if (eventType != null) {
				Bitmap bitmap = GraphUtils.getBitmapForEvent(eventPoint);
				if (bitmap != null)
					holder.imageView.setImageBitmap(bitmap);
			}
			holder.timeTextView.setText(Utils.getTime24HrFormat(eventPoint
					.getCalendar(), TimeZone.getDefault(),context));

			switch (eventPoint.getEventType()) {
			case ALERT_EVENT:
			case ALARM_EVENT:
				holder.eventTypeTextView
						.setText(Utils.getAlertEventTitle(context,
								((AlertEventPoint) eventPoint).getAlertType()));
				break;
			case NOTIFICATION_EVENT_RED:
				Utils.TransmitterMessageCode notificationEventType = eventPoint.getNotificationEventType();
				if ((notificationEventType == Utils.TransmitterMessageCode.SeriouslyLowAlarm) ||
						(notificationEventType == Utils.TransmitterMessageCode.SeriouslyHighAlarm))
				{
					holder.eventTypeTextView.setText(Utils.getNotificationDialogMessageTitleStringId(notificationEventType));
				}
				break;
			case NOTIFICATION_EVENT_YELLOW:
				Utils.TransmitterMessageCode notificationEventTypeYellow = eventPoint.getNotificationEventType();
				if (notificationEventTypeYellow == Utils.TransmitterMessageCode.EDRAlarm4) /** #3920 */
				{
					holder.eventTypeTextView.setText(Utils.getNotificationDialogMessageTitleStringId(notificationEventTypeYellow));
				}
				break;

			default:
				holder.eventTypeTextView.setText(Utils.getEventName(context,
						eventPoint.getEventType()));
				break;
			}
		}else
			notifyDataSetChanged();
		return view;
	}

	private class ViewHolder {
		ImageView imageView;
		TextView timeTextView;
		TextView eventTypeTextView;
	}

}
