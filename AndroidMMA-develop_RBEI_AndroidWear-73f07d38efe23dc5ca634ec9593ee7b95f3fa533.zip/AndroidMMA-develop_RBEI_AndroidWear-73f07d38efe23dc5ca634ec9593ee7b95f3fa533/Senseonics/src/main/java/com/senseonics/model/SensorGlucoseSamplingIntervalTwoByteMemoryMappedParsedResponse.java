package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class SensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse implements TwoByteMemoryMapParsedResponse {

    @Inject
    public SensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.sensorGlucoseSamplingInterval;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {

        model.setSamplingIntervalInSeconds(dataOne | (dataTwo << 8));

    }
}
