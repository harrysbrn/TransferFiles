package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class LinkedSensorIdAddressFourByteMemoryMapParsedResponse implements FourByteMemoryMapParsedResponse {

    @Inject
    public LinkedSensorIdAddressFourByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.linkedSensorIDAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        long fullSensorID = dataOne | (dataTwo << 8) | (dataThree << 16) | ((long)dataFour << 24);
        int sensorID = dataOne | (dataTwo << 8) | (dataThree << 16);

        if (!Utils.isValidSensorID(fullSensorID) || (sensorID == 0)) {
            model.setLinkedSensorId(null);
        } else {
            model.setLinkedSensorId(String.valueOf(sensorID));
        }

    }
}
