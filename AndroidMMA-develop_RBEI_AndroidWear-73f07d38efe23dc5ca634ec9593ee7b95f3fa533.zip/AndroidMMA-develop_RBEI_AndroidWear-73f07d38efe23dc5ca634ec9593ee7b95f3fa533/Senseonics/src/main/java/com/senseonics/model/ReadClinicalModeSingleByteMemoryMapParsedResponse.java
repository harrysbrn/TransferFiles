package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadClinicalModeSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadClinicalModeSingleByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.clinicalMode;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setClinicalMode(false);
                break;
            case 0x55:
                model.setClinicalMode(true);
                break;
        }
    }
}
