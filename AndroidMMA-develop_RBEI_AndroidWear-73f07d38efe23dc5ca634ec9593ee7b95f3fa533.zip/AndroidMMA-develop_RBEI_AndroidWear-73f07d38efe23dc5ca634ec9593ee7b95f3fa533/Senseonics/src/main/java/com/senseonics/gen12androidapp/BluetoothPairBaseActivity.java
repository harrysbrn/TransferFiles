package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;
import com.senseonics.bluetoothle.ApplicationForegroundState;
import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.bluetoothle.DialogUtils.WarningDialogInfo;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.bluetoothle.ResponseOperations.ReaderManager;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.bluetoothle.event.BluetoothCommunicatorReadyEvent;
import com.senseonics.bluetoothle.event.LegacyResponseHandlingEvent;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.ActivityOnResumeEvent;
import com.senseonics.events.AlertOrAlarmEvent;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.DMSUploadResultEvent;
import com.senseonics.events.EventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.InvalidUserCredentialEvent;
import com.senseonics.events.NotificationDialogEvent;
import com.senseonics.events.PredictiveRateAlertEvent;
import com.senseonics.events.RateAlertEvent;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.model.SyncModel;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.pairing.events.view.RefreshTransmittersPressed;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.AlarmRingtoneManager;
import com.senseonics.util.AppUpdateChecker;
import com.senseonics.util.NotificationUtility;
import com.senseonics.util.StaleDataChecker;
import com.senseonics.util.StateModelUploadUtility;
import com.senseonics.util.UserInfoSecureStorer;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.CALIBRATION_STATE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class BluetoothPairBaseActivity extends ObjectGraphActivity implements ServiceActivity,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {
    private static final int LOCATION_REQUEST_CODE = 462;
    protected static boolean activityPaused = false;

    // Declare Google Play Services Client
    GoogleApiClient googleClient;

    @Inject
    protected DatabaseManager databaseManager;

    protected View progressView;
    protected static CalibrationEventPoint calibrationEvent;
    public static ArrayList<EventPoint> patientEventPoints;
    private boolean isOnCreate = false;
    protected static CountDownTimer countDownTimer;
    private SyncProgressManager syncProgressManager;
    private Dialog invalidCredentialDialog;

    @Inject
    protected Handler handler;
    @Inject
    protected TransmitterStateModel transmitterStateModel;
    @Inject
    protected EventBus eventBus;
    @Inject
    protected DialogUtils dialogUtils;
    @Inject
    protected BluetoothServiceCommandClient bluetoothServiceCommandClient;
    @Inject
    protected SyncModel syncModel;
    @Inject
    protected SharedPreferences sharedPreferences;
    @Inject
    protected AccountConstants accountConstants;
    @Inject
    protected UserInfoSecureStorer userInfoSecureStorer;
    @Inject
    protected ApplicationForegroundState applicationForegroundState;
    @Inject
    protected NotificationUtility notificationUtility;
    @Inject
    protected StateModelUploadUtility stateModelUploadUtility;
    @Inject
    protected AlarmRingtoneManager alarmRingtoneManager;
    @Inject
    protected AppUpdateChecker appUpdateChecker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Utils.initDates(databaseManager.getEarliestEventDate());

        progressView = getLayoutInflater().inflate(R.layout.progressbar, null);
        progressView.setVisibility(View.INVISIBLE);

        patientEventPoints = new ArrayList<>();

        initBluetoothLE();

        IntentFilter intent = new IntentFilter();
        intent.addAction(BluetoothDevice.ACTION_FOUND);
        intent.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        intent.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        intent.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);

        isOnCreate = true;

        // Build a new GoogleApiClient for the the Wearable API
        googleClient = new GoogleApiClient.Builder(this)
                .addApi(Wearable.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
    }

    // Connect to the data layer when the Activity starts
    @Override
    protected void onStart() {
        super.onStart();
        googleClient.connect();
    }

    // Disconnect from the data layer when the Activity stops
    @Override
    protected void onStop() {
        if (null != googleClient && googleClient.isConnected()) {
            googleClient.disconnect();
        }
        super.onStop();
    }

    @Override
    public void onConnected(Bundle connectionHint) {

        String WEARABLE_DATA_PATH = "/wearable_data";

        // Create a DataMap object and send it to the data layer
        DataMap dataMap = new DataMap();
        dataMap.putLong("time", new Date().getTime());
        dataMap.putString("hole", "1");
        dataMap.putString("front", "250");
        dataMap.putString("middle", "260");
        dataMap.putString("back", "270");
        //Requires a new thread to avoid blocking the UI
        new SendToDataLayerThread(WEARABLE_DATA_PATH, dataMap).start();
    }

    // Placeholders for required connection callbacks
    @Override
    public void onConnectionSuspended(int cause) {
        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), ": Google Client connection suspended");
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), ": Google Client connection failed");
    }


    public void checkPermissionsIfNeeded() {
        /** For Android M and above to request permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_REQUEST_CODE);
        } else {
            eventBus.post(new RefreshTransmittersPressed());
        }*/
        eventBus.post(new RefreshTransmittersPressed());
    }

    /** For Android M and above to request permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_REQUEST_CODE:
                if (permissionsGranted(grantResults)) {
                    eventBus.post(new RefreshTransmittersPressed());
                }
                break;
        }
    }

    private boolean permissionsGranted(int[] grantResults) {
        if (grantResults.length == 0) {
            return false;
        }
        for (int grantResult : grantResults) {
            if (grantResult != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }*/

    public void initBluetoothLE() {

        // Use this check to determine whether BLE is supported on the device.
        // Then you can
        // selectively disable BLE-related features.
        Dialog dialog = null;
        if (!getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_BLUETOOTH_LE)) {
            dialog = dialogUtils.createWarningDialog(this, new WarningDialogInfo(
                    R.drawable.red_alert_mark,
                    getString(R.string.notification),
                    getString(R.string.ble_not_supported)));
        }
    }

    protected void sendCalibrationEvent(CalibrationEventPoint event) {
        calibrationEvent = event;
        Utils.calibrationState = CALIBRATION_STATE.REASON_UNKNOWN;
        getService().postSendBloodGlucoseDataResponse(event);
        Log.d(BluetoothPairBaseActivity.class.getSimpleName(),
                "glucoseLevel: " + calibrationEvent.getGlucoseLevel());
    }

    public void transmitterNameChanged(String name) {
        Utils.transmitterName = name;
    }


    public void writeNByteToTransmitterFinished() {
        Intent brodIntent = new Intent(Utils.WRITE_N_BYTE_FINISHED);
        sendBroadcast(brodIntent);
    }

    public void disconnected() {
        BluetoothUtils.mConnected = false;

        Intent brodIntent = new Intent(Utils.DISCONNECTED_INTENT_FILTER);
        sendBroadcast(brodIntent);
    }

    public void timeChanged() {
        // Fire time change notification
        createWarningDialog(
                getResources().getString(
                        R.string.time_updated_transmitter_notification_title),
                getResources().getString(
                        R.string.time_updated_transmitter_notification_message));

    }

    public void timeZoneChanged() {
    }

    public void refresh() {
    }

    public void createWarningDialog(String title, String text) {
    }

    // ---------------------------------------------------

    // Response
    private ReaderManager readerManager = new ReaderManager() {


        //TODO: For Senseonics - The following blocks of code can be replaced by creating instances of MemoryMapParsedResponse
        @Override
        public void parsedReadSingleByteSerialFlashRegisterResponse(int data,
                                                                    int[] address) {
            // Calibration state
            if (Utils.areArraysEqual(address,
                    MemoryMap.readyForCalibrationAddress)) {
                switch (data) {
                    case 0:
                        Utils.calibrationState = CALIBRATION_STATE.READY;
                        break;
                    case 1:
                        Utils.calibrationState = CALIBRATION_STATE.NOT_ENOUGH_DATA;
                        break;
                    case 2:
                        Utils.calibrationState = CALIBRATION_STATE.GLUCOSE_RATE_TOO_HIGH;
                        break;
                    case 3:
                        Utils.calibrationState = CALIBRATION_STATE.TOO_SOON;
                        break;
                    case 4:
                        Utils.calibrationState = CALIBRATION_STATE.DROPOUT_PHASE;
                        break;
                    case 5:
                        Utils.calibrationState = CALIBRATION_STATE.SENSOR_EOL;
                        break;
                    case 6:
                        Utils.calibrationState = CALIBRATION_STATE.NO_SENSOR_LINKED;
                        break;
                    case 7:
                        Utils.calibrationState = CALIBRATION_STATE.UNSUPPORTED_MODE;
                        break;
                    case 8:
                        Utils.calibrationState = CALIBRATION_STATE.WAITING_POST_CALIBRATION;
                        break;
                    case 9:
                        Utils.calibrationState = CALIBRATION_STATE.LED_DISCONNECT_DETECTED;
                        break;
                    default:
                        Utils.calibrationState = CALIBRATION_STATE.REASON_UNKNOWN;
                }
                sendBroadcast(new Intent(Utils.CALIBRATION_STATE_ARRIVED));
            }

        }

        @Override
        public void parsedReadTwoByteSerialFlashRegisterResponse(int[] data,
                                                                 int[] address) {
            // Next scheduled calibration date
            if (Utils.areArraysEqual(address, MemoryMap.nextCalibrationDate)) {
                int[] date = BinaryOperations.calculateDateFromBytes(data);

                Utils.nextScheduledCalibration = Calendar.getInstance();
                Utils.nextScheduledCalibration.setTimeZone(TimeZone
                        .getTimeZone("GMT"));

                Utils.nextScheduledCalibration.set(Calendar.HOUR_OF_DAY, 0);
                Utils.nextScheduledCalibration.set(Calendar.MINUTE, 0);
                Utils.nextScheduledCalibration.set(Calendar.SECOND, 0);

                Utils.nextScheduledCalibration.set(Calendar.MILLISECOND, 0);
                Utils.nextScheduledCalibration.set(Calendar.YEAR, date[0]);
                Utils.nextScheduledCalibration.set(Calendar.MONTH, date[1] - 1);
                Utils.nextScheduledCalibration.set(Calendar.DAY_OF_MONTH,
                        date[2]);
            } else
                // Next scheduled calibration time
                if (Utils.areArraysEqual(address, MemoryMap.nextCalibrationTime)) {
                    int[] time = BinaryOperations.calculateTimeFromBytes(data);
                    if (Utils.nextScheduledCalibration != null) {

                        Utils.nextScheduledCalibration.set(Calendar.HOUR_OF_DAY,
                                time[0]);
                        Utils.nextScheduledCalibration
                                .set(Calendar.MINUTE, time[1]);
                        Utils.nextScheduledCalibration
                                .set(Calendar.SECOND, time[2]);
                    }
                } else if (Utils.areArraysEqual(address,
                        MemoryMap.minsBeforeNextCalibrationTime)) {
                    int value = BinaryOperations.dataIntFrom16BitsLSByteFirst(data);
                    Utils.minsBeforeNextCalibrationTime = value;
                } else if (Utils.areArraysEqual(address,
                        MemoryMap.minsAfterNextCalibrationTime)) {
                    int value = BinaryOperations.dataIntFrom16BitsLSByteFirst(data);
                    Utils.minsAfterNextCalibrationTime = value;
                } else
                    // Estimated minutes before calibration is possible
                    if (Utils.areArraysEqual(address,
                            MemoryMap.minutesRemainingUntilCalibrationAllowed)) {
                        int value = BinaryOperations.dataIntFrom16BitsLSByteFirst(data);
                        Utils.minutesRemainingUntilCalibrationAllowed = value;
                    } else
                        // Clinical Mode Duration
                        if (Utils.areArraysEqual(address, MemoryMap.clinicalModeDuration)) {
                            int value = BinaryOperations.dataIntFrom16BitsLSByteFirst(data);
                            Utils.clinicalModeDuration = value * 60 * 60 * 1000;
                            Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "Duration: " + Utils.clinicalModeDuration + " value:" + value);

                            // remove the old value first
                            if (sharedPreferences.contains(Utils.prefClinicalModeDuration)) {
                                sharedPreferences.edit().remove(Utils.prefClinicalModeDuration)
                                        .apply();
                            }

                            Utils.saveSettings(BluetoothPairBaseActivity.this,
                                    Utils.prefClinicalModeDuration, Utils.clinicalModeDuration);
                        } else
                            // Sensor Life remaining in Days
                            if (Utils.areArraysEqual(address,
                                    MemoryMap.sensorLifeAddress)) {
                                int daysLeftInTx = data[0] | (data[1] << 8);

                                // #3181 Current App shows 98 days for 'Sensor remaining days' instead of 91 days (Android)
                                int daysLeft = ((daysLeftInTx - 7) > 0) ? (daysLeftInTx - 7) : 0;
                                Utils.sensorLifeDays = daysLeft;
                                Log.d(BluetoothPairBaseActivity.class.getSimpleName(), " ------------ "
                                        + Utils.sensorLifeDays);
                            } else
                                // Calibrate Max Treshold
                                if (Utils.areArraysEqual(address,
                                        MemoryMap.maxCalibrationTreshold)) {
                                    Utils.maxCalibrationTreshold = data[0] | (data[1] << 8);
                                    Log.d(BluetoothPairBaseActivity.class.getSimpleName(), " ------------ cal max threshod:"
                                            + Utils.maxCalibrationTreshold);
                                }
                                // Calibrate Min Treshold

                                else
                                    // Calibrate Min Treshold
                                    if (Utils.areArraysEqual(address,
                                            MemoryMap.minCalibrationTreshold)) {
                                        Utils.minCalibrationTreshold = data[0] | (data[1] << 8);
                                        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), " ------------ cal min threshod:"
                                                + Utils.minCalibrationTreshold);
                                    }


        }

        // Calibration result
        @Override
        public void parsedSendBloodGlucoseDataResponse(int calibrationUseFlags) {

            if (calibrationEvent != null) {
                // is response to calibration submission
                int textIdTitle = Utils
                        .getTitleIdForCalibrationUseFlag(calibrationUseFlags);
                String textMessage = getTextForCalibrationUseFlag(
                        BluetoothPairBaseActivity.this, calibrationUseFlags);

                createWarningDialog(getResources().getString(textIdTitle),
                        textMessage);

                // Calibration accepted
                Utils.CALIBRATION_USE_FLAG useFlag = Utils.CALIBRATION_USE_FLAG.values()[calibrationUseFlags];
                if (useFlag == Utils.CALIBRATION_USE_FLAG.ACTUALLY_USED_FOR_CALIBRATION ||
                        useFlag == Utils.CALIBRATION_USE_FLAG.THIS_ONE_USED_PREVIOUS_ONE_DELETED) /** #3209 */ {
                    refreshCalibrationInformations();

                    // Start countdown
                    calibrationEvent.setCalibrationUsed(true);

                    // save the accepted calibration time
                    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
                    calendar.setTimeInMillis(calibrationEvent.getTimestamp());
                    long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
                    long DSToffset = calendar.get(Calendar.DST_OFFSET);
                    sharedPreferences.edit().putLong(Utils.prefCalibrationDateTime, calendar.getTimeInMillis() - timeZoneDiff - DSToffset).apply();

                    int duration = transmitterStateModel.getCalibrationDuration();

                    if (countDownTimer == null) {
                        countDownTimer = new CustomCountDownTimer(eventBus, duration * GraphUtils.MINUTE, 1000);
                    } else {
                        countDownTimer.cancel();
                        countDownTimer = null;

                        countDownTimer = new CustomCountDownTimer(eventBus, duration * GraphUtils.MINUTE, 1000);
                    }
                    countDownTimer.start();

                    // Add the calibration event to database
                    databaseManager.addEvent(calibrationEvent, true);
                } else {
                    calibrationEvent.setCalibrationUsed(false);

                    // Create a manual glucose event
                    databaseManager.addEvent(
                            new GlucoseEventPoint(calibrationEvent
                                    .getCalendar(), calibrationEvent
                                    .getGlucoseLevel(), calibrationUseFlags
                                    ,calibrationEvent.getNotes() /** APPDEV-4032 */
                            ),
                            true);
                }
                calibrationEvent = null;
                refresh();
            }

            calibrationEvent = null;

            // Update glucose event in database to be Synced
            if (patientEventPoints != null && patientEventPoints.size() > 0) {
                EventPoint eventPoint = patientEventPoints.get(0);
                eventPoint.setEventSynced(true);
                databaseManager.updateEvent(eventPoint);
                patientEventPoints.remove(0);
            }
        }

        @Override
        public void parsedReadCurrentTrasmitterDateAndTimeResponse(int[] date,
                                                                   int[] time, int[] timeZoneOffset, int timeZoneOffsetSign) {
            Log.d(BluetoothPairBaseActivity.class.getSimpleName(),
                    "<<<<  >>>>");

            Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "timeZoneOffset:" + timeZoneOffset[0] + " "
                    + timeZoneOffset[1] + " " + timeZoneOffset[2]
                    + " ; timeZoneOffsetSign: " + timeZoneOffsetSign);

            // timeZoneOffsetSign if 255(0xFF) then -1 otherwise 1
            int offsetSign = (timeZoneOffsetSign == 255) ? (-1) : 1;
            int offsetMins = offsetSign
                    * (timeZoneOffset[0] * 60 + timeZoneOffset[1]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            int year = date[0];
            int month = date[1];
            int day = date[2];
            int hour = time[0];
            int minute = time[1];
            int second = time[2];

            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month - 1);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, second);

            Calendar localTime = Calendar.getInstance();
            TimeZone localTimeZone = TimeZone.getDefault();
            Date now = new Date();
            long localTimeZoneInMilli = localTimeZone.getOffset(now.getTime());
            int localGMTMins = (int) (localTimeZoneInMilli / 1000 / 60); // in
            // minutes
            if (offsetMins != localGMTMins) {
                // 979 if timezone changed, set default morning and evening time
                // 8AM and 6PM (local)
                if (transmitterStateModel.isTransmitterConnected()) {
                    getService().postWriteMorningCalibrationTime(Utils.morningCalibrationHourDefaultLocal - localGMTMins / 60, Utils.morningCalibrationMinuteDefault);
                    getService().postWriteEveningCalibrationTime(Utils.eveningCalibrationHourDefaultLocal - localGMTMins / 60, Utils.eveningCalibrationMinuteDefault);
                }
            }

        }

        @Override
        public void parsedChangeTimingParametersResponse(int requestSuccessfull) {
            Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "<<<< "
                    + requestSuccessfull + " >>>>");
        }

        @Override
        public void parsedReadSingleSensorGlucoseDataRecordResponseData(
                int glucoseRecordNumber, int[] date, int[] time, int value,
                int sensorGlucoseAlertFlags) {
            Log.d(BluetoothPairBaseActivity.class.getSimpleName(),
                    "<<<<  >>>>");
        }

        @Override
        public void parsedReadSingleSensorGlucoseAlertRecordResponse(
                int sensorGlucoseAlertRecordNr, int[] date, int[] time,
                int sensorGlucoseAlertLogRecordType, int sensorGlucoseValue,
                int sensorGlucoseRateValue, int alertThresholdOrTimInterval) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadSingleBloodGlucoseDataRecordResponse(
                int recordNr, int[] date, int[] time, int bloodGlucoseValue,
                int meterIdentifier, int calUseFlags,
                int closestSensorGlucoseEntryRecordNr) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadSinglePatientEventResponse(int recordNr,
                                                         int[] date, int[] time, int eventTypeId, int eventSubtypeId,
                                                         int eventSubtypeQ, int textLength) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedMarkPatientEventRecordAsDeletedResponse(
                int deletedRecordNr) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadSingleMiscEventLogResponse(int recordNr,
                                                         int[] date, int[] time, int miscEventType,
                                                         int[] eventAddtitionalInfo) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadFirstAndLastMiscEventLogRecordNumbersResponse(
                int firstRecordNr, int lastRecordNr) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadFirstAndLastErrorLogRecordNumbersResponse(
                int firstRecordNr, int lastRecordNr) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedReadNByteSerialFlashRegisterResponse(int[] address,
                                                               int n, int[] values) {
            // TODO Auto-generated method stub
        }

        @Override
        public void parsedWriteNByteSerialFlashRegisterResponse(int[] address,
                                                                int n) {

            if (BluetoothUtils.linkingRequestsInitialized == true) {
                BluetoothUtils.linkingPacketsNumber--;

                Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "linkingPacketsNumber--: " + BluetoothUtils.linkingPacketsNumber);

                if (BluetoothUtils.linkingPacketsNumber <= 0) {
                    writeNByteToTransmitterFinished();
                }
            }
        }

        @Override
        public void parsedWriteFourByteSerialFlashRegisterResponse(int[] data,
                                                                   int[] address) {

            if (Utils.areArraysEqual(address,
                    MemoryMap.transmitterNameFirst4Byte)) {
                String s = "";
                if (data[0] != 0)
                    s += Character.toString((char) data[0]);
                if (data[1] != 0)
                    s += Character.toString((char) data[1]);
                if (data[2] != 0)
                    s += Character.toString((char) data[2]);
                if (data[3] != 0)
                    s += Character.toString((char) data[3]);

                if (!s.equals(""))
                    Utils.transmitterNameContainer = s;
            } else if (Utils.areArraysEqual(address,
                    MemoryMap.transmitterNameLast4Byte)) {
                String s = "";
                if (data[0] != 0)
                    s += Character.toString((char) data[0]);
                if (data[1] != 0)
                    s += Character.toString((char) data[1]);
                if (data[2] != 0)
                    s += Character.toString((char) data[2]);
                if (data[3] != 0)
                    s += Character.toString((char) data[3]);

                if (Utils.transmitterNameContainer != null) {
                    Utils.transmitterNameContainer += s;

                    Log.d(BluetoothPairBaseActivity.class.getSimpleName(),
                            Utils.transmitterNameContainer);
                    transmitterNameChanged(Utils.transmitterNameContainer);
                }
            }
        }

        @Override
        public void parsedWriteTwoByteSerialFlashRegisterResponse(int[] data,
                                                                  int[] address) {
        }
    };

    @Override
    public BluetoothService getService() {
        return ((SenseonicsApplication) getApplication()).getBluetoothServiceClient().getService();
    }

    @Override
    protected void onResume() {
        super.onResume();

        ((SenseonicsApplication) getApplication()).getBluetoothServiceClient().bind(this);
        eventBus.register(this);

        removeSyncProgressManager();
        syncProgressManager = new SyncProgressManager(this, syncModel, eventBus, sharedPreferences);

        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "in BluetoothPairBaseActivity onResume " + dialogUtils.toString());
        dialogUtils.showDialogs(BluetoothPairBaseActivity.this);

        activityPaused = false;

        /** cancel tx disconnection timer upon activity resumes */
        eventBus.post(new ActivityOnResumeEvent());

        /** #3860 */
        checkStaleData();

        /** #3640 */
        if (this instanceof MainActivity) {
            if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                if (bluetoothServiceCommandClient != null) {
                    bluetoothServiceCommandClient.postReadRawDataValues();
                    bluetoothServiceCommandClient.postReadGlucoseData();
                }
            }
        }

        /** Prepare for log syncing */
        if (this instanceof MainActivity) {
            if (transmitterStateModel.isTransmitterConnected() && !syncModel.isSyncing()) {
                if (bluetoothServiceCommandClient != null) {
                    bluetoothServiceCommandClient.postGetRangesForSyncing();
                }
            }
        }

        if (transmitterStateModel.isTransmitterConnected()) {
            if (isOnCreate == false) {
                if (isThisActivityTop() && applicationForegroundState.isSameActivityPausedResumed()) {
                    dialogUtils.fireDoNotDisturbAlertDialog(this, !transmitterStateModel.isVibrateMode());
                }
            } else {
                isOnCreate = false;
            }
        }

        if (isOnCreate == true) {
            isOnCreate = false;
        }

        if (isThisActivityTop()) {
            /** #3160 */
            dialogUtils.fireTempProfileTurnedOffPopup(this, false);
        }

        /** #3261 */
        appUpdateChecker.checkForSoftwareUpdate(this);

        syncProgressManager.update();
    }

    @Override
    protected void onPause() {
        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "in BluetoothPairBaseActivity onPause");
        eventBus.unregister(this);
        ((SenseonicsApplication) getApplication()).getBluetoothServiceClient().unbind(this);
        activityPaused = true;
        removeSyncProgressManager();
        super.onPause();
    }

    private void removeSyncProgressManager() {
        if (syncProgressManager != null) {
            syncProgressManager.remove();
            syncProgressManager = null;
        }
    }

    protected boolean isThisActivityTop() {
        return false;
    }

    public void refreshCalibrationInformations() {
        if (transmitterStateModel.isTransmitterConnected()) {
            getService().postCompletedCalibrationsCountRequest();
            getService().postLastCalibrationDateTimeRequest();
        }
    }

    @Override
    protected void onDestroy() {
        dialogUtils.removeDialogs();
        dialogUtils.removeOtherDialogs();
        super.onDestroy();
    }

    public DialogUtils.NotificationDialogManager provideCalibrationDialogManager() {
        return new DialogUtils.NotificationDialogManager() {
            @Override
            public void leftButtonPressed() {
            }

            @Override
            public void rightButtonPressed() {
            }
        };

    }

    /** #3860 */
    protected void checkStaleData() {
        StaleDataChecker checker = new StaleDataChecker(transmitterStateModel.getGlucoseTimestamp(), transmitterStateModel.getSamplingIntervalInSeconds());
        boolean flagStale = checker.isStaleData();
        if (flagStale) {
            transmitterStateModel.setGlucoseLevel(Utils.GLUCOSE_LEVEL_UNKNOWN);
            transmitterStateModel.setGlucoseTrendDirection(Utils.ARROW_TYPE.STALE);
        }
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        Transmitter.CONNECTION_STATE currentState = event.getTransmitter().getConnectionState();

        Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "transmitter conn changed to: " + currentState.name());

        if (currentState != Transmitter.CONNECTION_STATE.CONNECTED) {
            syncModel.clear();
            removeSyncProgressManager();
            dialogUtils.showDialogs(BluetoothPairBaseActivity.this);
        } else {
            removeSyncProgressManager();
            syncProgressManager = new SyncProgressManager(this, syncModel, eventBus, sharedPreferences);
        }
    }


    public void onEventMainThread(LegacyResponseHandlingEvent event) {
        ResponseOperations.checkResponse(event.getData(), readerManager, event.actualResponseId(), getService());
    }

    public void onEventMainThread(RateAlertEvent event) {
        dialogUtils.createPredictiveRateAlertDialogInfo(this, event.getAlertEventPoint(), event.getNotificationId());
    }

    public void onEventMainThread(PredictiveRateAlertEvent event) {
        dialogUtils.createPredictiveRateAlertDialogInfo(this, event.getAlertEventPoint(), event.getNotificationId());
    }

    public void onEventMainThread(AlertOrAlarmEvent event) {
        dialogUtils.createAlertDialogInfo(this, event.getAlertEventPoint(), event.getNotificationId());
    }

    public void onEventMainThread(BluetoothCommunicatorReadyEvent event) {
        syncModel.clear();

        if (bluetoothServiceCommandClient != null) {
            bluetoothServiceCommandClient.postGetRangesForSyncing();
        }
    }

    public void onEventMainThread(NotificationDialogEvent event) {
        dialogUtils.createNotificationDialogInfo(this, event.getEventPoint(), event.getTransmitterMessageCode());
    }

    public void onEventMainThread(DMSUploadResultEvent event) {
        Log.d("PairBase DMS", "Upload result:" + event.getResult());
        if (event.getResult() == true) {
            Utils.makeAlwaysShownToast(this, getResources().getString(R.string.synced_success));
        }
    }

    public void onEventMainThread(InvalidUserCredentialEvent event) {
        Log.d("DMS(PairBaseActivity)", "InvalidUserCredentialEvent received");

        /** #3628 */
        if ((this instanceof UserAccountLoginActivity) == false) {
            displayInvalidCredentialDialogWithTitleAndMessage(getString(R.string.invalid_user_credentials_w_email), getString(R.string.sync_could_not_start_2));
        }
    }

    private void displayInvalidCredentialDialogWithTitleAndMessage(String title, String message) {
        if (invalidCredentialDialog != null && invalidCredentialDialog.isShowing()) {
            invalidCredentialDialog.dismiss();
        }
        invalidCredentialDialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
                title, message));
        invalidCredentialDialog.show();
    }

    private String getTextForCalibrationUseFlag(Context context, int calUseFlag) {
        String textMessage;
        switch (calUseFlag) {
            case 0:
                textMessage = context.getResources().getString(
                        R.string.cal_not_entered_message);
                break;
            case 1:
                int duration = transmitterStateModel.getCalibrationDuration();

                textMessage = (context.getResources().getString(
                        R.string.cal_accepted_message))
                        .replace("%d", String.valueOf(duration));
                break;
            case 2:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_too_different_message);
                textMessage = textMessage.replace("%value%",
                        Utils.getGlucoseLevelString(context, Utils.LAST_CALIBRATION_VALUE));
                textMessage = textMessage.replace("%d",
                        Utils.RETRY_CAL_TOO_DIFFERENT_WAIT_HOURS);
                break;
            case 3:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_too_low_message);
                textMessage = textMessage.replace("%value%",
                        Utils.getGlucoseLevelString(context, Utils.minCalibrationTreshold)).replace("%d",
                        Utils.RETRY_CAL_TOO_LOW_WAIT_HOURS);
                break;
            case 4:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_too_high_message);
                textMessage = textMessage.replace("%value%",
                        Utils.getGlucoseLevelString(context, Utils.maxCalibrationTreshold)).replace("%d",
                        Utils.RETRY_CAL_TOO_HIGH_WAIT_HOURS);
                break;
            case 5:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_rate_message);
                textMessage = textMessage.replace("%d",
                        Utils.RETRY_CAL_RATE_WAIT_HOURS);
                break;
            case 6:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_not_ready_message);
                textMessage = textMessage.replace("%d",
                        Utils.RETRY_CAL_NOT_READY_WAIT_MINUTES);
                break;
            case 7:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_data_message);
                textMessage = textMessage.replace("%d",
                        Utils.RETRY_CAL_REJECTED_WAIT_MINUTES);
                break;
            case 8:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_replacement_message);
                break;
            case 9:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_blinded_message);
                textMessage = textMessage.replace("%d",
                        Utils.RETRY_CAL_BLINDED_WAIT_HOURS);
                break;
            case 10:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_auto_link_message);
                break;
            case 11:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_led_disconnect_title);
                break;
            case 12:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_other_message);
                break;
            default:
                textMessage = context.getResources().getString(
                        R.string.cal_rejected_unknown_message);
                break;
        }
        return textMessage;
    }

    class SendToDataLayerThread extends Thread {
        String path;
        DataMap dataMap;

        // Constructor for sending data objects to the data layer
        SendToDataLayerThread(String p, DataMap data) {
            path = p;
            dataMap = data;
        }

        public void run() {
            // Construct a DataRequest and send over the data layer
            PutDataMapRequest putDMR = PutDataMapRequest.create(path);
            putDMR.getDataMap().putAll(dataMap);
            PutDataRequest request = putDMR.asPutDataRequest();
            DataApi.DataItemResult result = Wearable.DataApi.putDataItem(googleClient, request).await();
            if (result.getStatus().isSuccess()) {
                Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "DataMap: " + dataMap + " sent successfully to data layer ");
            } else {
                // Log an error
                Log.d(BluetoothPairBaseActivity.class.getSimpleName(), "ERROR: failed to send DataMap to data layer");
            }
        }
    }

}