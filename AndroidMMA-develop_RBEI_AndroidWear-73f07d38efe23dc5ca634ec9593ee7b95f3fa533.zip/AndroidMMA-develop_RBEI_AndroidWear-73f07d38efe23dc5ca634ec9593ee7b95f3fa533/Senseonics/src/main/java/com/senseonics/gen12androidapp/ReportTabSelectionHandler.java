package com.senseonics.gen12androidapp;

import android.content.Context;
import android.content.SharedPreferences;

import com.senseonics.util.Utils;

public class ReportTabSelectionHandler {
    private final String PREF_VALUE = "REPORT_TAB_SELECTION";
    private SharedPreferences sharedPreferences;
    public final static int TAB1 = 0, TAB2 = 1, TAB3 = 2, TAB4 = 3,
            TAB5 = 4;

    public ReportTabSelectionHandler(Context context) {
        sharedPreferences = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
    }

    public int getSelectedTab() {
        return sharedPreferences.getInt(PREF_VALUE, TAB1);
    }

    public void setSelectedTab(int selectedTab) {
        sharedPreferences.edit().putInt(PREF_VALUE, selectedTab).apply();
    }
}


