package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class ReadWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.predictiveFallingRateAlertTimeInterval;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        model.setPredictiveFallingRateAlertMinuteInterval(data);
    }
}
