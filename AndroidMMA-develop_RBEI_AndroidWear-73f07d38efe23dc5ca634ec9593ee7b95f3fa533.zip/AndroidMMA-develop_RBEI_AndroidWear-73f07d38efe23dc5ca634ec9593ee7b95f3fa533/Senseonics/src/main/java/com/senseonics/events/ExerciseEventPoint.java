package com.senseonics.events;

import android.content.Context;

import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventUtils.EXERCISE_INTENSITY;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;

public class ExerciseEventPoint extends EventPoint implements PatientEventPoint {
	private static final long serialVersionUID = 1L;
	private int duration;
	private EXERCISE_INTENSITY intensity;

	public ExerciseEventPoint(Calendar calendar, int glucoseLevel,
			int duration, EXERCISE_INTENSITY intensity, String notes) {
		super(calendar, glucoseLevel);
		setDuration(duration);
		setIntensity(intensity);
		setNotes(notes);
		setEventType(EVENT_TYPE.EXERCISE_EVENT);
	}

	public ExerciseEventPoint(int databaseId, Calendar calendar,
			int glucoseLevel, int duration, EXERCISE_INTENSITY intensity,
			String notes) {
		super(databaseId, calendar, glucoseLevel);
		setDuration(duration);
		setIntensity(intensity);
		setNotes(notes);
		setEventType(EVENT_TYPE.EXERCISE_EVENT);
	}

	public int getDuration() {
		return duration;
	}

	public String getDurationText(Context context) {
		int hours = duration / 60;
		int minutes = duration % 60;

		return hours + context.getResources().getString(R.string.hr) + " "
				+ minutes + context.getResources().getString(R.string.min);
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public EXERCISE_INTENSITY getIntensity() {
		return intensity;
	}

	public void setIntensity(EXERCISE_INTENSITY intensity) {
		this.intensity = intensity;
	}

	@Override
	public int eventTypeId() {
		return EventUtils.eventTypeExercise;
	}

	@Override
	public int eventSubTypeId() {
		return intensity.getSubType();
	}

	@Override
	public int quantity() {
		return duration;
	}

}
