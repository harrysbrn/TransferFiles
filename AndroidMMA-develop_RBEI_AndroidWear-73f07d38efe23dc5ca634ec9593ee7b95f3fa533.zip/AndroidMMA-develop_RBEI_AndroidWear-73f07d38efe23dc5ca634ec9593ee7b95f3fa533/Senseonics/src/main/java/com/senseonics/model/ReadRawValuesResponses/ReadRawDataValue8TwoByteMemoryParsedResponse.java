package com.senseonics.model.ReadRawValuesResponses;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.model.TwoByteMemoryMapParsedResponse;

import javax.inject.Inject;

public class ReadRawDataValue8TwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadRawDataValue8TwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.RawDataValue8Address;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int intVal = (dataTwo << 8) | (dataOne);
        Log.d("RawValue", "raw 8:" + intVal);
        model.setRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8, intVal);
    }
}
