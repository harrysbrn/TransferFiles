package com.senseonics.events;

public class ModelChangedCalibrationTimeEvent {
}
