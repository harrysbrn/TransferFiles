package com.senseonics.events;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.util.Convert;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.GLUCOSE_UNIT;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class GlucoseEventActivity extends EventActivity {

	private ArrayList<Item> glucoseValues, glucoseValuesMg;
	private TextView glucoseLevelTextView, bloodGlucoseNotUsedReasonTextView;
	private Dialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Set navigation bar title
		naviBarTitle.setText(R.string.glucose_event);

		LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.dialog_glucose_event, contentLayout);

		glucoseLevelTextView = (TextView) findViewById(R.id.glucoseValue);
		if (eventPoint != null) {
			if (eventPoint instanceof GlucoseEventPoint) {
				GlucoseEventPoint glucoseEvent = (GlucoseEventPoint) eventPoint;

				LinearLayout bloodGlucoseNotUsedLayout = (LinearLayout) findViewById(R.id.bloodGlucoseNotUsedLayout);
				bloodGlucoseNotUsedLayout.setVisibility(View.VISIBLE);

				bloodGlucoseNotUsedReasonTextView = (TextView) findViewById(R.id.bloodGlucoseNotUsedReason);
				
				int textIdTitle = Utils
						.getTitleIdForCalibrationUseFlagForEventActivity(glucoseEvent.getCalibrationFlag());

				bloodGlucoseNotUsedReasonTextView.setText(getResources().getString(textIdTitle));
			}
			String glucoseLevelString = Utils.getGlucoseLevelString(this,
					eventPoint.getGlucoseLevel());
			glucoseLevelTextView.setText(glucoseLevelString);
			glucoseLevel = eventPoint.getGlucoseLevel();
		} else
		{
			glucoseLevel = Utils.GLUCOSE_DEFAULT_LEVEL;
		}
				
		glucoseValuesMg = dialogUtils.getNumbersBetween(Utils.minBloodGlucose,
				Utils.maxBloodGlucose, 1);
		if(Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
			glucoseValues = dialogUtils.getGlucoseLevels(Utils.minBloodGlucose,
					Utils.maxBloodGlucose, 1);
		} else {
			glucoseValues = dialogUtils.getGlucoseLevels(Convert.MLConvertMgToMmol(Utils.minBloodGlucose),
					Convert.MLConvertMgToMmol(Utils.maxBloodGlucose), 0.1f);
		}

		final PickerManager manager = new PickerManager() {

			@Override
			public void selected(int id) {

				glucoseLevel = dialogUtils.getGlucoseValueMg(glucoseValues.get(id)
						.getValue());
				String glucoseLevelString = Utils.getGlucoseLevelString(
						GlucoseEventActivity.this, glucoseLevel);
				glucoseLevelTextView.setText(glucoseLevelString);
			}
		};

		RelativeLayout glucoseLayout = (RelativeLayout) findViewById(R.id.glucose);
		glucoseLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (dialog != null && dialog.isShowing())
					dialog.dismiss();

				int position = getPosition(glucoseLevel);
				dialog = dialogUtils.createPickerDialog(GlucoseEventActivity.this,
						getResources().getString(R.string.glucose_event),
						glucoseValues, manager, position);

				dialog.show();
			}
		});

		int position = getPosition(glucoseLevel);
		if (position > 0)
			manager.selected(position);

	}

	public int getPosition(int glucoseValue) {
		int position;
		if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
			position = Utils.getItemPosition(glucoseValuesMg, glucoseLevel);
		else
			position = Utils.getItemPosition(glucoseValues,
					String.format(Locale.US, "%.1f", Convert.MLConvertMgToMmol(glucoseValue)));
		return position;
	}

	@Override
	public void onSavePressed() {

		currentDate.set(Calendar.SECOND, 0);
		currentDate.set(Calendar.MILLISECOND, 0);

		if (isEditing) {
			GlucoseEventPoint glucoseEvent = (GlucoseEventPoint) eventPoint;
			databaseManager.updateEvent(new GlucoseEventPoint(eventPoint
					.getDatabaseId(), currentDate, glucoseLevel, glucoseEvent
					.getCalibrationFlag(), glucoseEvent.getNotes()));
			finish();
		} else {
			Context context = GlucoseEventActivity.this;
			Spanned confirm_body = Html.fromHtml("<br><b>"
					+ getString(R.string.time) + ": "
					+ (Utils.getTime24HrFormat(currentDate, TimeZone.getDefault(), GlucoseEventActivity.this))
					+ "<br><br>" + getString(R.string.value) + ": "
					+ Utils.getGlucoseLevelString(context, glucoseLevel)
					+ "</b>" + "<br>");
			OnClickListener submitOnClickListener = new OnClickListener() {

				@Override
				public void onClick(View v) {
					btnSubmitClicked();
				}
			};

			// Show the cabliration confirmation
			Utils.showCalibrationConfirmationPage(context,
					R.string.glucose_event_submit_title, confirm_body,
					submitOnClickListener);
		}
	}

	private void btnSubmitClicked() {
		GlucoseEventPoint glucoseEventPoint = new GlucoseEventPoint(
				currentDate, glucoseLevel, 0, notesEditText.getText().toString());
		int rowId = (int) databaseManager.addEvent(glucoseEventPoint, false);
		glucoseEventPoint.setDatabaseId(rowId);
		BluetoothPairBaseActivity.patientEventPoints.add(glucoseEventPoint);
		getService().postWriteGlucoseEvent(glucoseEventPoint);

		finish();
	}
	
	@Override
	protected void onResume() {
		super.onResume();

		if (isEditing == true)
		{
			// Hide the "Save" button if it's editing glucose event
			naviBarRightItemTextView.setVisibility(View.GONE);

			// Disable the editing of Time and Glucose Cells
			RelativeLayout glucoseLayout = (RelativeLayout) findViewById(R.id.glucose);
			glucoseLayout.setClickable(false);

			// Hide the glucose arrow
			findViewById(R.id.arrow).setVisibility(View.INVISIBLE);
			
			// Disable the editing of Time
			View dateView = (View) findViewById(R.id.dateView);
			dateView.setClickable(false);

			// Hide the time arrow
			dateView.findViewById(R.id.arrowDate).setVisibility(View.INVISIBLE);

			// Hide the notes arrow
			RelativeLayout notesView = (RelativeLayout) findViewById(R.id.notesView);
			notesView.findViewById(R.id.arrowNotes).setVisibility(View.INVISIBLE);

			// Disable the notes
			notesEditText.setFocusable(false);
			notesEditText.setSelection(0);
		}
		
	}
}
