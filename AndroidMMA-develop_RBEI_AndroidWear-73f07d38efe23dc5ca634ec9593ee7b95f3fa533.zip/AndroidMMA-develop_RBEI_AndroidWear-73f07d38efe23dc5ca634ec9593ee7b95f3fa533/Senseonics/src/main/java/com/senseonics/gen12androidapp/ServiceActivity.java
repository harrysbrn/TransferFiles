package com.senseonics.gen12androidapp;

import com.senseonics.bluetoothle.BluetoothService;

public interface ServiceActivity {

    BluetoothService getService();
}
