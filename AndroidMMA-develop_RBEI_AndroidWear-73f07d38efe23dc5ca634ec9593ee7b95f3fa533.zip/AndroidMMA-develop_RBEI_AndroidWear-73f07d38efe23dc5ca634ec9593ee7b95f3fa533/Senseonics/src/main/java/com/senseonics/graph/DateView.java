package com.senseonics.graph;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;
import java.util.Calendar;
import java.util.Date;

public class DateView extends View {

	private float textHeight;
	private String text;
	private Paint textPaint;
	private Rect rect;
	private Bitmap leftArrow, rightArrow;
	private int bitmapWidth, bitmapHeight;
	private Paint myPaint;

	// These constructors aren't used
	public DateView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
	}

	public DateView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public DateView(Context context) {
		super(context);
	}
	// --------------------------------

	public DateView(Context context, int width, int height) {
		super(context);

		text = "";

		textPaint = new Paint();
		textPaint.setAntiAlias(true);
		textPaint.setColor(getResources().getColor(android.R.color.white));
		textPaint.setTypeface(Typeface.DEFAULT_BOLD);
		textPaint.setTextAlign(Align.CENTER);

		int textMaxHeight = (height * 3) / 2;
		rect = new Rect(0, getTop(), width, height);

		textPaint.setTextSize(getResources().getDimension(
				R.dimen.dateview_text_size));
		textHeight = GraphUtils.measureText("12PMg", textPaint).height();
		Log.d(" **** text height", textMaxHeight + " " + textHeight);

		leftArrow = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.left_arrow);
		rightArrow = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.right_arrow);

		bitmapHeight = leftArrow.getHeight();
		bitmapWidth = leftArrow.getWidth();
		int arrowHeight = (rect.height() / 3) * 2;

		if (bitmapHeight > arrowHeight) {
			float v = bitmapHeight / arrowHeight;
			int arrowWidth = (int) (bitmapWidth * v);
			leftArrow = Bitmap.createScaledBitmap(leftArrow, arrowWidth,
					arrowHeight, true);
			rightArrow = Bitmap.createScaledBitmap(rightArrow, arrowWidth,
					arrowHeight, true);

			bitmapHeight = arrowHeight;
			bitmapWidth = arrowWidth;
		}

		myPaint = new Paint();
		myPaint.setColor(Color.BLACK);
		myPaint.setStrokeWidth(1.5f);
		myPaint.setStyle(Style.STROKE);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.drawText(text, rect.width() / 2, rect.bottom
				- (rect.height() - textHeight) / 2, textPaint);

		// Do not show right arrow if the date range text has "TODAY"
		if (!text.contains(getResources().getString(R.string.today))) {
			canvas.drawBitmap(rightArrow, rect.width() - bitmapWidth
					- bitmapWidth / 2, (rect.height() - bitmapHeight) / 2,
					textPaint);
		}
		
		// Do not show left arrow if reaching the earliest date
		String earliestString1 = (String) DateFormat.format("E dd MMMM, yyyy", Utils.startDate);
		String earliestString2 = (String) DateFormat.format("MMM dd, yyyy", Utils.startDate);

		if (!text.contains(earliestString1) && !text.contains(earliestString2))
		{
			canvas.drawBitmap(leftArrow, bitmapWidth / 2,
					(rect.height() - bitmapHeight) / 2, textPaint);
		}
		
		canvas.drawRect(0, 0, getWidth(), getHeight(), myPaint);

		super.onDraw(canvas);
	}

	public void setDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		Date current_date = calendar.getTime();
		text = (String) DateFormat.format("E dd MMMM, yyyy ", current_date);

		if (DateUtils.isToday(current_date.getTime())) {
			text = getResources().getString(R.string.today);
		}
		
		textPaint.setColor(getResources().getColor(android.R.color.black));
		invalidate();
	}

	public void setDate(Date date1, Date date2) {

		textPaint.setColor(getResources().getColor(android.R.color.black));

		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(date1);

		String date1Text = (String) DateFormat.format("MMM dd, yyyy ",
				calendar1.getTime());

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(date2);

		Date calendar2_date = calendar2.getTime();
		String date2Text = (String) DateFormat.format("MMM dd, yyyy ",
				calendar2_date);
		if (DateUtils.isToday(calendar2_date.getTime())
				|| calendar2_date.after(new Date())) {
			date2Text = getResources().getString(R.string.today);
		}

		text = date1Text + " - " + date2Text;

		invalidate();
	}

	public void setListener(OnClickListener listener) {
		setOnClickListener(listener);
	}

}
