package com.senseonics.model.StateModelUpload;

public class DMSStateModelUserInfo {
    private String UserID;
    private String PWHash;
    private String PWBinary;
    private String Username;

    public DMSStateModelUserInfo(
            String userID,
            String PWHash,
            String PWBinary,
            String Username
    ) {
        this.UserID = userID;
        this.PWHash = PWHash;
        this.PWBinary = PWBinary;
        this.Username = Username;
    }

    public String getUserID() {
        return UserID;
    }

    public String getPWHash() {
        return PWHash;
    }

    public String getPWBinary() {
        return PWBinary;
    }

    public String getUsername() {
        return Username;
    }
}
