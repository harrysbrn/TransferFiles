package com.senseonics.gen12androidapp;

public class Event {

	private long timestamp;
	private int eventType;
	private int noteKey = 0;
	private int variableParamShort = 0;
	private int variableParamLong = 0;
	private int syncBit = 0;
	private int recordNumber = 0;
	
	public Event(long timestamp, int eventType, int noteKey,
			int variableParamShort, int variableParamLong, int syncBit,
			int recordNumber) {
		super();
		this.timestamp = timestamp;
		this.eventType = eventType;
		this.noteKey = noteKey;
		this.variableParamShort = variableParamShort;
		this.variableParamLong = variableParamLong;
		this.syncBit = syncBit;
		this.recordNumber = recordNumber;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public int getEventType() {
		return eventType;
	}

	public void setEventType(int eventType) {
		this.eventType = eventType;
	}

	public int getNoteKey() {
		return noteKey;
	}

	public void setNoteKey(int noteKey) {
		this.noteKey = noteKey;
	}

	public int getVariableParamShort() {
		return variableParamShort;
	}

	public void setVariableParamShort(int variableParamShort) {
		this.variableParamShort = variableParamShort;
	}

	public int getVariableParamLong() {
		return variableParamLong;
	}

	public void setVariableParamLong(int variableParamLong) {
		this.variableParamLong = variableParamLong;
	}

	public int getSyncBit() {
		return syncBit;
	}

	public void setSyncBit(int syncBit) {
		this.syncBit = syncBit;
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
}
