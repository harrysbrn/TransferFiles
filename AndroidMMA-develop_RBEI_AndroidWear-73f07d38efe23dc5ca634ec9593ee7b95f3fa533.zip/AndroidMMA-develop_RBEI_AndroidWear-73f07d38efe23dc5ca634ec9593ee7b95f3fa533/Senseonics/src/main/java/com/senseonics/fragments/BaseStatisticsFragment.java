package com.senseonics.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ReportTabSelectionHandler;
import com.senseonics.db.DatabaseManager;
import com.senseonics.util.Emailer;

import javax.inject.Inject;

public abstract class BaseStatisticsFragment extends BaseFragment{

	protected RelativeLayout noStatisticsLayout;
	protected LinearLayout contentLayout, tab1Layout, tab2Layout, tab3Layout, tab4Layout,
			tab5Layout;
	protected TextView tab1Text, tab2Text, tab3Text, tab4Text, tab5Text;
	protected String tab1Name, tab2Name, tab3Name, tab4Name, tab5Name;
	protected int selectedState[];
	protected ReportTabSelectionHandler reportTabSelectionHandler;
	protected ProgressDialog progressDialog;

	@Inject
	protected Emailer emailer;
	@Inject
	protected DatabaseManager databaseManager;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		reportTabSelectionHandler = new ReportTabSelectionHandler(getActivity());

		tab1Name = getString(R.string.day_1);
		tab2Name = getString(R.string.day_7);
		tab3Name = getString(R.string.day_14);
		tab4Name = getString(R.string.day_30);
		tab5Name = getString(R.string.day_90);

		selectedState = new int[5];
		selectedState[ReportTabSelectionHandler.TAB1] = 0;
		selectedState[ReportTabSelectionHandler.TAB2] = 0;
		selectedState[ReportTabSelectionHandler.TAB3] = 0;
		selectedState[ReportTabSelectionHandler.TAB4] = 0;
		selectedState[ReportTabSelectionHandler.TAB5] = 0;
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void onPause() {
		super.onPause();
		dismissProgressDialogIfNeeded();
	}

	protected void createProgressDialogIfNeeded() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
			progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
			progressDialog.setCancelable(false);
		}
	}

	protected void showProgressDialogIfNeeded() {
		if ((progressDialog != null) && (getActivity() != null)) {
			if (!progressDialog.isShowing()) {
				progressDialog.show();
			}
		}
	}

	protected void dismissProgressDialogIfNeeded() {
		if ((progressDialog != null) && (getActivity() != null)) {
			if (progressDialog.isShowing()) {
				progressDialog.dismiss();
			}
		}
	}

	protected String returnTabNameString(int tabId){
		String days = "";
		switch (tabId) {
			case ReportTabSelectionHandler.TAB1:
				days = tab1Name;
				break;
			case ReportTabSelectionHandler.TAB2:
				days = tab2Name;
				break;
			case ReportTabSelectionHandler.TAB3:
				days = tab3Name;
				break;
			case ReportTabSelectionHandler.TAB4:
				days = tab4Name;
				break;
			case ReportTabSelectionHandler.TAB5:
				days = tab5Name;
				break;
		}
		return days;
	}
	protected void updateTabSelection() {
		int selectedTab = reportTabSelectionHandler.getSelectedTab();
		setSelected(selectedTab, getLayoutForTabId(selectedTab));
	}

	protected void initTabs(View view) {

		tab1Layout = (LinearLayout) view.findViewById(R.id.tab1);
		tab1Text = (TextView) view.findViewById(R.id.tab1Text);
		tab1Text.setText(tab1Name);

		tab2Layout = (LinearLayout) view.findViewById(R.id.tab2);
		tab2Text = (TextView) view.findViewById(R.id.tab2Text);
		tab2Text.setText(tab2Name);

		tab3Layout = (LinearLayout) view.findViewById(R.id.tab3);
		tab3Text = (TextView) view.findViewById(R.id.tab3Text);
		tab3Text.setText(tab3Name);

		tab4Layout = (LinearLayout) view.findViewById(R.id.tab4);
		tab4Text = (TextView) view.findViewById(R.id.tab4Text);
		tab4Text.setText(tab4Name);

		tab5Layout = (LinearLayout) view.findViewById(R.id.tab5);
		tab5Text = (TextView) view.findViewById(R.id.tab5Text);
		tab5Text.setText(tab5Name);

		tab1Layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setSelected(ReportTabSelectionHandler.TAB1, tab1Layout);
			}
		});
		tab2Layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setSelected(ReportTabSelectionHandler.TAB2, tab2Layout);
			}
		});
		tab3Layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setSelected(ReportTabSelectionHandler.TAB3, tab3Layout);
			}
		});
		tab4Layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setSelected(ReportTabSelectionHandler.TAB4, tab4Layout);
			}
		});
		tab5Layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setSelected(ReportTabSelectionHandler.TAB5, tab5Layout);
			}
		});
	}

	protected LinearLayout getLayoutForTabId (int tabId) {
		LinearLayout returnLayout = tab1Layout;
		switch (tabId) {
			case ReportTabSelectionHandler.TAB1:
				returnLayout = tab1Layout;
				break;

			case ReportTabSelectionHandler.TAB2:
				returnLayout = tab2Layout;
				break;

			case ReportTabSelectionHandler.TAB3:
				returnLayout = tab3Layout;
				break;

			case ReportTabSelectionHandler.TAB4:
				returnLayout = tab4Layout;
				break;

			case ReportTabSelectionHandler.TAB5:
				returnLayout = tab5Layout;
				break;
		}

		return returnLayout;
	}

	public void setSelected(int tabId, LinearLayout tabLayout) {

		if (selectedState != null && selectedState[tabId] == 0) {
			clearAllButtonStates();
			selectedState[tabId] = 1;
			reportTabSelectionHandler.setSelectedTab(tabId);
			tabLayout.setSelected(true);
			activateDeactivateTabText(tabId);
			((StatisticsFragment)getParentFragment()).setShareButtonEnabled(hasData());
		}
	}

	public boolean hasData() {
		return noStatisticsLayout.getVisibility() != View.VISIBLE;
	}

	public void activateDeactivateTabText(int tabId){
		int selectedColor = getResources().getColor(
				R.color.graph_white);
		int unselectedColor = getResources().getColor(
				R.color.dark_dark_gray);

		switch (tabId) {
		case ReportTabSelectionHandler.TAB1:
			tab1Text.setTextColor(selectedColor);

			tab2Text.setTextColor(unselectedColor);
			tab3Text.setTextColor(unselectedColor);
			tab4Text.setTextColor(unselectedColor);
			tab5Text.setTextColor(unselectedColor);
			break;
		case ReportTabSelectionHandler.TAB2:
			tab2Text.setTextColor(selectedColor);

			tab1Text.setTextColor(unselectedColor);
			tab3Text.setTextColor(unselectedColor);
			tab4Text.setTextColor(unselectedColor);
			tab5Text.setTextColor(unselectedColor);
			break;
		case ReportTabSelectionHandler.TAB3:
			tab3Text.setTextColor(selectedColor);

			tab1Text.setTextColor(unselectedColor);
			tab2Text.setTextColor(unselectedColor);
			tab4Text.setTextColor(unselectedColor);
			tab5Text.setTextColor(unselectedColor);
			break;
		case ReportTabSelectionHandler.TAB4:
			tab4Text.setTextColor(selectedColor);

			tab1Text.setTextColor(unselectedColor);
			tab2Text.setTextColor(unselectedColor);
			tab3Text.setTextColor(unselectedColor);
			tab5Text.setTextColor(unselectedColor);
			break;
		case ReportTabSelectionHandler.TAB5:
			tab5Text.setTextColor(selectedColor);

			tab1Text.setTextColor(unselectedColor);
			tab2Text.setTextColor(unselectedColor);
			tab3Text.setTextColor(unselectedColor);
			tab4Text.setTextColor(unselectedColor);
			break;
		}
	}

	public void clearAllButtonStates() {

		selectedState[ReportTabSelectionHandler.TAB1] = 0;
		tab1Layout.setSelected(false);

		selectedState[ReportTabSelectionHandler.TAB2] = 0;
		tab2Layout.setSelected(false);

		selectedState[ReportTabSelectionHandler.TAB3] = 0;
		tab3Layout.setSelected(false);

		selectedState[ReportTabSelectionHandler.TAB4] = 0;
		tab4Layout.setSelected(false);

		selectedState[ReportTabSelectionHandler.TAB5] = 0;
		tab5Layout.setSelected(false);
	}

	public void formShareEmail() {
		if(!amIEmpty()) {
			emailer.formShareEmail(getEmailTitle(), getEmailBody(), contentLayout);
		} else {
			Log.d(BaseStatisticsFragment.class.getSimpleName(), "not sharing");
		}
	}

	protected abstract String getEmailTitle();
	protected abstract String getEmailBody();
	protected boolean amIEmpty() {
		return noStatisticsLayout != null && noStatisticsLayout.getVisibility() == View.VISIBLE;
	}


}
