package com.senseonics.events;

public class StatusHeaderTapEvent {
}
