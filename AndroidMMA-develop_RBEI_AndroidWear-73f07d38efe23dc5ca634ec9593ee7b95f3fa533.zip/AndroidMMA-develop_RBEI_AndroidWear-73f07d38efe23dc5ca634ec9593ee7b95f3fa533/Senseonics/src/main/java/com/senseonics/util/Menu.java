package com.senseonics.util;

public class Menu {
	private Object menuType;
	private String menuName;
	private int drawableId;
	private boolean active;

	public Menu(Object menuType, String menuName, int drawableId) {
		super();
		this.menuType = menuType;
		this.setMenuName(menuName);
		this.setDrawableId(drawableId);
		this.setActive(true);
	}

	public Object getMenuType() {
		return menuType;
	}

	public void setMenuType(Object menuType) {
		this.menuType = menuType;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public int getDrawableId() {
		return drawableId;
	}

	public void setDrawableId(int drawableId) {
		this.drawableId = drawableId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
}