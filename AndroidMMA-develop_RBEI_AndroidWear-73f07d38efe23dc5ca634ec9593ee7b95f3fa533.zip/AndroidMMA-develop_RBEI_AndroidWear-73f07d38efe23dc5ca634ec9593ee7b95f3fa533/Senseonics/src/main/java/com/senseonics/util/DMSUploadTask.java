package com.senseonics.util;

import android.os.AsyncTask;
import android.util.Log;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.bluetoothle.ApplicationForegroundState;
import com.senseonics.events.DMSUploadResultEvent;
import de.greenrobot.event.EventBus;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.KeyStore;
import java.util.ArrayList;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

public class DMSUploadTask extends AsyncTask<Void, Void, Void> {
    private final String Tag = "DMS(DMSUploadTask)";
    private String response;

    private Boolean isLogin;
    private AccountConstants accountConstants;
    private int hoursBack;
    private String userName;
    private String passWord;
    private String userID;
    private DMSTaskCallback dmsTaskCallback;
    private EventBus eventBus;
    private ApplicationForegroundState applicationForegroundState;
    private NotificationUtility notificationUtility;

    public DMSUploadTask(Boolean isLoginIn, AccountConstants accountConstantsIn, ApplicationForegroundState applicationForegroundState, NotificationUtility notificationUtility) {
        this.isLogin = isLoginIn;
        this.accountConstants = accountConstantsIn;
        this.applicationForegroundState = applicationForegroundState;
        this.notificationUtility = notificationUtility;

        this.hoursBack = 0;
        this.userName = "";
        this.passWord = "";
        this.userID = "";
        this.dmsTaskCallback = null;
        this.eventBus = null;
    }

    public DMSUploadTask(Boolean isLoginIn, AccountConstants accountConstantsIn, ApplicationForegroundState applicationForegroundState, NotificationUtility notificationUtility, int hoursBackIn, EventBus eventBus) {
        this(isLoginIn, accountConstantsIn, applicationForegroundState, notificationUtility);

        this.hoursBack = hoursBackIn;
        this.eventBus = eventBus;
    }

    public DMSUploadTask(Boolean isLoginIn, AccountConstants accountConstantsIn, ApplicationForegroundState applicationForegroundState, NotificationUtility notificationUtility, int hoursBackIn, DMSTaskCallback dmsTaskCallbackIn) {
        this(isLoginIn, accountConstantsIn, applicationForegroundState, notificationUtility);

        this.hoursBack = hoursBackIn;
        this.dmsTaskCallback = dmsTaskCallbackIn;
    }

    public DMSUploadTask(Boolean isLoginIn, AccountConstants accountConstantsIn, ApplicationForegroundState applicationForegroundState, NotificationUtility notificationUtility, DMSTaskCallback dmsTaskCallbackIn, String userNameIn, String passWordIn, String userIDIn) {
        this(isLoginIn, accountConstantsIn, applicationForegroundState, notificationUtility);

        this.dmsTaskCallback = dmsTaskCallbackIn;
        this.userName = userNameIn;
        this.passWord = passWordIn;
        this.userID = userIDIn;
    }

    @Override
    protected Void doInBackground(Void... params) {
        // Get the data from database in the background
        String requestString;
        Log.d(Tag, "accountConstants:" + accountConstants);
        if (isLogin) {
            requestString = accountConstants.prepareRequestStringForUploadingLoginData(passWord, userID);
        } else {
            // check if account info is valid if it's not login
            if (accountConstants.HasValidAccountInfo() == false) {
                Log.d(Tag, "PANIC: No Valid Account Info");
                response = "-1";
                return null;
            }
            else {
                requestString = accountConstants.prepareRequestStringForUploadingData(hoursBack);

                /** #3628 Record the sync START time - either manual or automatic */
                accountConstants.setCurrentDateTimeToLastSyncedStartInPreference();
            }
        }

        // Upload data in the background
        response = uploadDeviceData(requestString);
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        AccountConstants.MLDMSResult dmsError = AccountConstants.MLDMSResult.None;

        if (response != null && !response.equals("-1")) {
            Utils.printLongLog(Tag, "UploadData Response:" + response);

            ArrayList<String> uploadResults = accountConstants.getUploadResultFromResponse(response);

            if((uploadResults != null) && (uploadResults.size() == accountConstants.kUploadResultCount)) {
                Integer savedResult = Integer.valueOf(uploadResults.get(0));
                Integer secondResult = Integer.valueOf(uploadResults.get(1));
                Integer thirdResult = Integer.valueOf(uploadResults.get(2));

                Log.d(Tag, savedResult + "|" + secondResult + "|" + thirdResult + "|");

                dmsError = AccountConstants.MLDMSResult.fromValue(savedResult);
                Log.d(Tag, "dmsError: " + dmsError);

                // Save the last sync date and time
                if ((dmsError == AccountConstants.MLDMSResult.DataSaved) && (this.isLogin == false)) {
                    // no need to set the last sync date time if it's login
                    accountConstants.setCurrentDateTimeToLastSyncedOnInPreference();

                    if (eventBus != null) {
                        eventBus.post(new DMSUploadResultEvent(true));
                    }
                }

                // no need to force logout (show notification) if it's login
                if ((dmsError == AccountConstants.MLDMSResult.InvalidUserCredentials) && (this.isLogin == false)) {
                    /** #3628
                    accountConstants.setDefaultLoggedIn(); */

                    /** #3628 remove the "Invalid username or password" dialog or local notification if it's auto sync and the server returns invalid credential.
                     if (!applicationForegroundState.isForeground()) {
                        // set local notification
                        notificationUtility.createForceLogoutNotification();
                    }
                    else {
                        if (eventBus != null) {
                            eventBus.post(new InvalidUserCredentialEvent());
                        }
                    } */

                    /** #3628 */
                    Answers.getInstance().logCustom(new CustomEvent("Logout")
                            .putCustomAttribute("Reason", "InvalidUserCredentials")
                            .putCustomAttribute("Info", savedResult + "|" + secondResult + "|" + thirdResult));

                    Answers.getInstance().logCustom(new CustomEvent("Sync Invalid Credentials")
                            .putCustomAttribute("Info", savedResult + "|" + secondResult + "|" + thirdResult));
                }

                if(dmsTaskCallback != null) {
                    dmsTaskCallback.TaskDone(dmsError, secondResult, thirdResult);
                }
            }
            else {
                dmsError = AccountConstants.MLDMSResult.ServerError;
                if(dmsTaskCallback != null) {
                    dmsTaskCallback.TaskDone(dmsError);
                }
            }

        } else {
            if (response == null) {
                dmsError = AccountConstants.MLDMSResult.NotConnectedToWifi;
                if(dmsTaskCallback != null) {
                    dmsTaskCallback.TaskDone(dmsError);
                }
            }
            else {
                dmsError = AccountConstants.MLDMSResult.ServerError;
                if(dmsTaskCallback != null) {
                    dmsTaskCallback.TaskDone(dmsError);
                }
            }
        }
    }

    protected String uploadDeviceData(String requestStringForUploadData) {
        try {
            //Code used for debug and generate the soap request.
				/* File file = new File(Environment.getExternalStorageDirectory(), "file.txt");
				BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				writer.write(requestStringForUploadData);
				writer.newLine();
				writer.flush();
				writer.close();*/

            StringEntity entity = new StringEntity(requestStringForUploadData, HTTP.UTF_8);
            HttpPost httpPost = accountConstants.formHttpPost(
                    accountConstants.getDMSServerURL(),
                    accountConstants.uploadDeviceEventsWebserviceFunctionCall,
                    entity
            );

            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);
            SSLSocketFactory sf = new DMSSSLSocketFactory(trustStore);
            HttpClient client = accountConstants.createHttpClient(sf);

            HttpResponse response;

            try {
                response = client.execute(httpPost);
                return EntityUtils.toString(response.getEntity());
            } catch (ClientProtocolException e) {
                Log.d(Tag, "Client Protocol Exception");
            } catch (SocketTimeoutException e) {
                Log.d(Tag, "Socket timeout");
            } catch (ConnectTimeoutException e) {
                Log.d(Tag, "Connect timeout");
            } catch (IOException e) {
                Log.d(Tag, "IO Exception");
                e.printStackTrace();
            }

            return "-1";
        } catch (UnsupportedEncodingException e) {
            Log.d(Tag, "Unsupported Encoding Exception");
            return "-1";
        } catch (Exception e) {
            Log.d(Tag, "Might be keystore exception");
            e.printStackTrace();
            return "-1";
        }
    }
}
