package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse implements SingleByteMemoryMapParsedResponse{
    @Inject
    public ReadWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.lowGlucoseAlarmRepeatIntervalDayTimeAddress;
    }

    @Override
    public void apply(int dataOne, TransmitterStateModel model) {
        model.setLowGlucoseAlarmRepeatIntervalDayTime(dataOne);
    }
}
