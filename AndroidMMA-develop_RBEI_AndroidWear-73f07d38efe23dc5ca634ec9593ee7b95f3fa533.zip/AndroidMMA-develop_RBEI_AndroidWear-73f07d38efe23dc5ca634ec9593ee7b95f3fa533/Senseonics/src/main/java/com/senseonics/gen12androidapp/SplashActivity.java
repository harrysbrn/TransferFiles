package com.senseonics.gen12androidapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.crashlytics.android.Crashlytics;
import com.senseonics.bluetoothle.TempProfileManager;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.AlarmRingtoneManager;
import com.senseonics.util.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;

import javax.inject.Inject;

import io.fabric.sdk.android.Fabric;

public class SplashActivity extends ObjectGraphActivity {
    boolean flag = false;
    private Handler handler = new Handler();

    @Inject
    protected AccountConstants accountConstants;

    @Inject
    protected AlarmRingtoneManager alarmRingtoneManager;

    @Inject
    protected TempProfileManager tempProfileManager; /** #3160 */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Since the relase version is not yet signed, we enable Crashlytics also in debug.
//        if (false == BuildConfig.DEBUG) {
            //this is the MAIN activity in the AndroidManifest. We put this here instead of in
            //the Application.onCreate to avoid issues during testRelease phase of Gradle build.
            Fabric.with(this, new Crashlytics());
//        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        /** Set LoggedIn to false and Set EnableAutoSync to true if needed */
        accountConstants.presetLoggedInAndEnableAutoSync();

        /** Set the Default ringtones if it does not exist */
        alarmRingtoneManager.setAlarmSoundsToDefaults();

        /** #3160 */
        tempProfileManager.restoreAllGlucoseProfilesToStateValueIfNeeded();

        /** APPDEV-3639 */
        boolean isLoggedIn = Utils.checkIfLoggedIn(this);
        boolean isFirstRun = Utils.checkIfFirstRun(this);
        if (isLoggedIn || !isFirstRun) {
            Utils.saveFirstRunForEULA(this);
        }

        boolean firstRunforEULA = Utils.checkIfFirstRunForEULA(this);
        if (firstRunforEULA) {
            JSONArray obj = null;

            try {
                obj = new JSONArray(loadJSONFromAsset());

                String manufacturer = Build.MANUFACTURER.toLowerCase();
                String model = Build.MODEL.toLowerCase();
                String product = Build.PRODUCT.toLowerCase();
                int SDK_int = Build.VERSION.SDK_INT;

                Log.i("Json Object", "Current Device:"+ manufacturer +" brand:"+ Build.BRAND + " product:"+  product + " model:" + model + " Version:" + Build.VERSION.RELEASE + " SDK_int:" + Build.VERSION.SDK_INT);
                for(int i=0;i<obj.length();i++) {

                    String thisManufacturer = obj.getJSONObject(i).get("Manufacturer").toString().toLowerCase();
                    String thisModel = obj.getJSONObject(i).get("Model").toString().toLowerCase();
                    String thisProduct = obj.getJSONObject(i).get("Model").toString().toLowerCase(); /** Same as thisModel */

                    /** #3680 Decouple Android devices with Android version: the App should only check if Android version is 4.4 (and above) and if the device is compatible */
                    if (manufacturer.contains(thisManufacturer) && (model.contains(thisModel) || product.contains(thisProduct)) && (SDK_int >= Build.VERSION_CODES.KITKAT)) {
                        flag = true;
                        break;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    if(flag == false) {
                        Intent intent = new Intent(SplashActivity.this, DeviceCompatibiityActivity.class);
                        intent.putExtra("eula_init", "true");
                        startActivity(intent);
                    }
                    else {
                        Intent intent = new Intent(SplashActivity.this, EulaScreenActivity.class);
                        intent.putExtra("eula_init", "true");
                        startActivity(intent);
                    }
                    finish();
                }

            }, 3000);
        } else {
            if (!isLoggedIn) {
                startActivity(new Intent(SplashActivity.this, UserAccountLoginActivity.class));
            }
            else if(isFirstRun){
                startActivity(new Intent(SplashActivity.this, WelcomeScreenActivity.class));
            }
            else{
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            }

            finish();
        }
    }

    public String loadJSONFromAsset() {

        try {
            InputStream is = getAssets().open("Device_List.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String bufferString = new String(buffer);
            return bufferString;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        handler.removeMessages(0);
        super.onBackPressed();
    }

}
