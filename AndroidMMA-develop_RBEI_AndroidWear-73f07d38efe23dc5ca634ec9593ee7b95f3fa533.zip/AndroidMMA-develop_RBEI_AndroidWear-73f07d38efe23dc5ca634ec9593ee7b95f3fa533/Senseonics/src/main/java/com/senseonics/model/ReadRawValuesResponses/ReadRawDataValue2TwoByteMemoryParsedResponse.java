package com.senseonics.model.ReadRawValuesResponses;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.model.TwoByteMemoryMapParsedResponse;

import javax.inject.Inject;

public class ReadRawDataValue2TwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadRawDataValue2TwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.RawDataValue2Address;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int intVal = (dataTwo << 8) | (dataOne);
        Log.d("RawValue", "raw 2:" + intVal);
        model.setRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2, intVal);
    }
}
