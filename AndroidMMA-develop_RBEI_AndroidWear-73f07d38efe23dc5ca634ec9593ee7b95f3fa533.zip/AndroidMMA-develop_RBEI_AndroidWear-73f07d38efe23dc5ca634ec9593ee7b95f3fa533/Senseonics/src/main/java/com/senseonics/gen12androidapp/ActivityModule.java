package com.senseonics.gen12androidapp;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.widget.ImageButton;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.fragments.StatisticsFragment;
import com.senseonics.fragments.StatisticsListFragment;
import com.senseonics.fragments.StatisticsPieChartFragment;
import com.senseonics.fragments.StatisticsWeeklyGraphFragment;
import com.senseonics.pairing.BluetoothPairingFragment;
import com.senseonics.util.Utils;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;

@Module(addsTo = ApplicationModule.class, library = true,
        injects = {
                StatisticsWeeklyGraphFragment.class, StatisticsFragment.class,
                LandscapeGraphViewActivity.class, StatisticsPieChartFragment.class,
                StatisticsListFragment.class, BluetoothPairingFragment.class, MainActivity.class,
                LandscapeGraphViewActivity.class
        })
public class ActivityModule {
    private Activity activity;

    ActivityModule(Activity activity) {
        this.activity = activity;
    }

    @Provides
    Activity providesActivity() {
        return activity;
    }

    @Provides
    @Named(Constants.IS_FIRST_RUN)
    boolean provideIsFirstRun(Context context) {
        return Utils.checkIfFirstRun(context);
    }

    @Provides
    @Named(Constants.REFRESH_BUTTON)
    ImageButton provideRefreshButton(Activity activity) {
        return (ImageButton) activity.findViewById(R.id.refreshButton);
    }

    @Provides
    BluetoothService providesBluetoothService(Activity activity) {
        return ((ServiceActivity) activity).getService();
    }

    @Provides
    BluetoothAdapter provideBluetoothAdapter() {
        return BluetoothAdapter.getDefaultAdapter();
    }
}
