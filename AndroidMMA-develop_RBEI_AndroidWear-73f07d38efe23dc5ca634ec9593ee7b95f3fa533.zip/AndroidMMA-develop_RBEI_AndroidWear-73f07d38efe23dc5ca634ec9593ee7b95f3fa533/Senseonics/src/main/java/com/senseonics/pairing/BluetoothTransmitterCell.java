package com.senseonics.pairing;

import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.common.base.Strings;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.model.TransmitterStateModel;

import javax.inject.Inject;

import butterknife.BindColor;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BluetoothTransmitterCell extends RelativeLayout {
  private final TransmitterStateModel transmitterStateModel;
  private final Handler handler;
  @BindView(R.id.state) TextView stateText;
  @BindView(R.id.bluetoothImage) ImageView bluetoothImage;
  @BindView(R.id.progressBar) ProgressBar progressBar;
  @BindView(R.id.name) TextView deviceName;
  @BindColor(R.color.black) int blackColor;

  @Inject public BluetoothTransmitterCell(Context context, TransmitterStateModel transmitterStateModel, Handler handler) {
    super(context);
    inflate(context, R.layout.transmitter_list_item, this);
    ButterKnife.bind(this);

    this.transmitterStateModel = transmitterStateModel;
    this.handler = handler;

    stateText.setTextColor(blackColor);
    deviceName.setTextColor(blackColor);
  }

  public void refresh(Transmitter transmitter) {
    if (Strings.isNullOrEmpty(transmitter.getName())) {
      deviceName.setText(R.string.unknown);
    } else {
      deviceName.setText(transmitter.getName());
    }

    if (transmitterStateModel != null
        && transmitterStateModel.getTransmitter() != null
        && transmitterStateModel.getTransmitterName() != null
        && !transmitterStateModel.getTransmitterName().equals("")
        && transmitter.equals(transmitterStateModel.getTransmitter())) {
      deviceName.setText(transmitterStateModel.getTransmitterName());
    }

    int progressBarVis = View.VISIBLE;
    Transmitter.CONNECTION_STATE state = transmitter.getConnectionState();
    switch (state) {
      case CONNECTED:
        stateText.setText(getResources().getString(R.string.connected));
        progressBarVis = View.GONE;
        bluetoothImage.setVisibility(View.VISIBLE);
        stateText.setTextColor(getResources().getColor(R.color.blue));
        break;
      case CONNECTING:
        stateText.setText(getResources().getString(R.string.connecting) + ".");
        bluetoothImage.setVisibility(View.GONE);
        stateText.setTextColor(getResources().getColor(R.color.black));
        break;
      case NEGOTIATING:
        stateText.setText(getResources().getString(R.string.connecting) + "..");
        bluetoothImage.setVisibility(View.GONE);
        stateText.setTextColor(getResources().getColor(R.color.black));
        break;
      case TRANSPORT_CONNECTED:
        stateText.setText(getResources().getString(R.string.connecting) + "..");
        bluetoothImage.setVisibility(View.GONE);
        stateText.setTextColor(getResources().getColor(R.color.black));
        break;
      case DISCONNECTED:
        stateText.setText(getResources().getString(R.string.not_connected));
        progressBarVis = View.GONE;
        bluetoothImage.setVisibility(View.GONE);
        stateText.setTextColor(getResources().getColor(R.color.black));
        break;
      case SEARCHING:
        stateText.setText(getResources().getString(R.string.searching));
        bluetoothImage.setVisibility(View.GONE);
        stateText.setTextColor(getResources().getColor(R.color.black));
        break;
    }

    int oldVis = progressBar.getVisibility();
    if (oldVis != progressBarVis) {
      final int visToSet = progressBarVis;
      handler.post(new Runnable() {
        @Override
        public void run() {
          progressBar.setVisibility(visToSet);
        }
      });
    }
  }
}
