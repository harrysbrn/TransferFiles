package com.senseonics.gen12androidapp;

import dagger.ObjectGraph;

public interface ObjectGraphApplication {

    void inject(Object object);

    ObjectGraph plus(Object... objects);
}
