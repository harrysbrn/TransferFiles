package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.rateAlertFallingTreshold;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {

        model.setRateAlertFallingThreshold((float)data/10);
    }
}
