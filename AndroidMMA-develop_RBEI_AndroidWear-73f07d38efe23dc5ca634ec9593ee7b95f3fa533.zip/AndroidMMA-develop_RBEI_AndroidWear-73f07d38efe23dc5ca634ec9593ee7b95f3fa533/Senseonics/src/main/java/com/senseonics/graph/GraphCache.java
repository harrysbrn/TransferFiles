package com.senseonics.graph;

import android.util.Log;
import android.util.LruCache;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;
import com.senseonics.graph.events.GraphCacheEvent;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;
import de.greenrobot.event.EventBus;
import java.util.Calendar;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton public class GraphCache {
  private class Query {
    Calendar startDate;
    Calendar endDate;

    @Override public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;
      Query query = (Query) o;
      if (startDate != null ? !startDate.equals(query.startDate) : query.startDate != null) {
        return false;
      }
      return endDate != null ? endDate.equals(query.endDate) : query.endDate == null;
    }

    @Override public int hashCode() {
      int result = startDate != null ? startDate.hashCode() : 0;
      result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
      return result;
    }
  }

  private class Result {
    List<List<Glucose>> glucoseValues;
    List<EventPoint> eventPoints;
  }

  private String TAG = getClass().toString();
  private EventBus eventBus;
  private DatabaseManager databaseManager;
  private LruCache<Query, Result> lruCache = new LruCache<>(20);

  @Inject public GraphCache(EventBus eventBus, DatabaseManager databaseManager) {
    Log.i(TAG, "Creating new GraphCache");
    this.eventBus = eventBus;
    this.databaseManager = databaseManager;
  }

  public void refresh(Calendar startDate, Calendar endDate, boolean validateGraph) {
    GraphUtils.glucoseDataInterval = GraphUtils.getDiffTime();
    Result result = getResult(startDate, endDate);
    eventBus.post(new GraphCacheEvent(result.glucoseValues, result.eventPoints, validateGraph));
  }

  private Result getResult(Calendar startDate, Calendar endDate) {
    Query query = new Query();
    query.startDate = startDate;
    query.endDate = endDate;
    Result result = lruCache.get(query);
    if (result == null) {
      result = new Result();
      result.glucoseValues =
          databaseManager.getGlucoseBetween(startDate, endDate, GraphUtils.glucoseDataInterval);
      result.eventPoints =
          databaseManager.getEventsBetween(startDate, endDate, Utils.GLUCOSE_LEVEL_UNKNOWN,
              Utils.GLUCOSE_MAX);
      lruCache.put(query, result);
    }
    return result;
  }
}
