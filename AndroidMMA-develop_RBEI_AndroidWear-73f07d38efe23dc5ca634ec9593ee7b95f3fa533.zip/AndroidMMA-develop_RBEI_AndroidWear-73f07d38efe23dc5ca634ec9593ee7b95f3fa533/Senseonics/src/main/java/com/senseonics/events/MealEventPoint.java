package com.senseonics.events;

import com.senseonics.events.EventUtils.MEAL_TYPE;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;

public class MealEventPoint extends EventPoint implements PatientEventPoint {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MEAL_TYPE mealType;
	private int carbs;

	public MealEventPoint(Calendar calendar, int glucoseLevel,
			MEAL_TYPE mealType, int carbs, String notes) {
		super(calendar, glucoseLevel);
		setMealType(mealType);
		setCarbs(carbs);
		setNotes(notes);
		setEventType(EVENT_TYPE.MEAL_EVENT);
	}

	public MealEventPoint(int databaseId, Calendar calendar, int glucoseLevel,
			MEAL_TYPE mealType, int carbs, String notes) {
		super(databaseId, calendar, glucoseLevel);
		setMealType(mealType);
		setCarbs(carbs);
		setNotes(notes);
		setEventType(EVENT_TYPE.MEAL_EVENT);
	}

	public MEAL_TYPE getMealType() {
		return mealType;
	}

	public void setMealType(MEAL_TYPE mealType) {
		this.mealType = mealType;
	}

	public int getCarbs() {
		return carbs;
	}

	public void setCarbs(int carbs) {
		this.carbs = carbs;
	}

	@Override
	public int eventTypeId() {
		return EventUtils.eventTypeMeal;
	}

	@Override
	public int eventSubTypeId() {
		return mealType.ordinal();
	}

	@Override
	public int quantity() {
		return carbs;
	}

}
