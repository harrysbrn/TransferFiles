package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse implements SingleByteMemoryMapParsedResponse{
    @Inject
    public ReadWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.highGlucoseAlarmRepeatIntervalNightTimeAddress;
    }

    @Override
    public void apply(int dataOne, TransmitterStateModel model) {
        model.setHighGlucoseAlarmRepeatIntervalNightTime(dataOne);
    }
}
