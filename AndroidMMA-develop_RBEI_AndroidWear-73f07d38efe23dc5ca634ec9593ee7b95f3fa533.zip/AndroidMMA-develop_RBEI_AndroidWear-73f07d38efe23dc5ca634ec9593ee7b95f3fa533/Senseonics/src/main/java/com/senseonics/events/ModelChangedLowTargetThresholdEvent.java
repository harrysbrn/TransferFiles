package com.senseonics.events;

public class ModelChangedLowTargetThresholdEvent { /** #3160 */
    private int newValue;

    public ModelChangedLowTargetThresholdEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
