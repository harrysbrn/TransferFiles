package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadMEPSavedLowRefMetricFourByteMemoryParsedResponse implements FourByteMemoryMapParsedResponse{
    @Inject
    public ReadMEPSavedLowRefMetricFourByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.mepSavedLowRefMetricAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        int intVal = (dataFour << 24) | (dataThree << 16) | (dataTwo << 8) | (dataOne);
        float floatVal = Float.intBitsToFloat(intVal);
        model.setMEPSavedLowRefMetric(floatVal);
    }
}
