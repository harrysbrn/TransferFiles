package com.senseonics.gen12androidapp;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.util.Utils;

import java.io.File;
import java.util.Locale;

@SuppressLint("SetJavaScriptEnabled")
public class WebviewActivity extends BaseActivity {

	private WebView webview;
	private ProgressDialog progressDialog;
	private ProgressBar progressBar;
	private Dialog dialog;
	private String fileName;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_webview, null),
				parms_content);

		// Configure the navigation bar
		naviBarTitle.setText(R.string.faq);
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);

		webview = (WebView) findViewById(R.id.webView);
		progressBar = (ProgressBar) findViewById(R.id.progressBar);

		webview.getSettings().setJavaScriptEnabled(true);

		Bundle extras = getIntent().getExtras();
		if (extras.containsKey("screen_type")) {
			String screenType = extras.getString("screen_type");

			// Faq
			if (screenType.equals("faq")) {
				WebSettings settings = webview.getSettings();
				settings.setUseWideViewPort(true);
				settings.setLoadWithOverviewMode(true);
				String strLanguage = Locale.getDefault().getLanguage();
				fileName = "FAQ_en.html";
				switch (strLanguage) {
					case "nl":
						fileName = "FAQ_nl.html";
						break;
					case "de":
						fileName = "FAQ_de.html";
						break;
					case "nb":
						fileName = "FAQ_nb.html";
						break;
					case "sv":
						fileName = "FAQ_sv.html";
						break;
					case "ro":
						fileName = "FAQ_ro.html";
						break;

				}
				String URL = Utils.URL_FAQ;
				new DownloadFileFromURL().execute(fileName,URL);

				File file = new File(getFilesDir() + "//icon_tips_arrow@2x.png");
				if (!file.exists()) {
					Utils.CopyAssetsFile("icon_tips_arrow@2x.png","", WebviewActivity.this);
					Utils.CopyAssetsFile("icon_tips_arrow_down@2x.png","", WebviewActivity.this);
					Utils.CopyAssetsFile("jquery-git2.js","", WebviewActivity.this);
				}

				file = new File(getFilesDir() + "//" + fileName);
				if (!file.exists()) {
					Utils.CopyAssetsFile(fileName, "", WebviewActivity.this);
				}
				webview.loadUrl("file:///"+getFilesDir() + "//" + fileName);


			}
		else if (screenType.equals("privacy")) {
				naviBarTitle.setText(R.string.privacy_statement);
				WebSettings settings = webview.getSettings();
				settings.setUseWideViewPort(true);
				settings.setLoadWithOverviewMode(true);
				String strLanguage = Locale.getDefault().getLanguage();
				fileName = "Privacy_en.html";
				switch (strLanguage) {
					case "nl":
						fileName = "Privacy_nl.html";
						break;
					case "de":
						fileName = "Privacy_de.html";
						break;
					case "nb":
						fileName = "Privacy_nb.html";
						break;
					case "ro":
						fileName = "Privacy_ro.html";
						break;
					case "sv":
						fileName = "Privacy_sv.html";
						break;
					case "fr":
						fileName = "Privacy_fr.html";
						break;
					case "it":
						fileName = "Privacy_it.html";
						break;
					case "da":
						fileName = "Privacy_da.html";
						break;
					case "fi":
						fileName = "Privacy_fi.html";
						break;
					case "es":
						fileName = "Privacy_es.html";
						break;
					case "pl":
						fileName = "Privacy_pl.html";
						break;
				}
				String URL = Utils.URL_PRIVACY;
				new DownloadFileFromURL().execute(fileName,URL);
				File file = new File(getFilesDir() + "//" + fileName);
				if (!file.exists()) {
					Utils.CopyAssetsFile(fileName,"Privacy", WebviewActivity.this);
				}

			}

        }

		webview.setWebViewClient(new WebViewClient() {

			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				return false;
			}

			@Override
			public void onPageFinished(WebView view, String url) {

				super.onPageFinished(view, url);
				progressBar.setVisibility(View.GONE);
			}

		});
	}

	public void displayCheckingResult(Utils.MLCheckResult error) {
		String title = "", message = "";
		switch (error) {
			case Timeout:
				title = getString(R.string.request_timeout);
				message = getString(R.string.invalid_error_text);
				break;
			case NotConnectedToWifi:
				title = getString(R.string.wi_fi_disconnected);
				message = getString(R.string.wi_fi_disconnected_text);
				break;
			case ServerError:
				title = getString(R.string.server_error);
				message = getString(R.string.invalid_error_text);
				break;
			case None:
				title = getString(R.string.file_corrupted);
				message = getString(R.string.invalid_error_text);
				break;
			case Unknown:
			default:
				title = getString(R.string.unknown_error);
				message = getString(R.string.invalid_error_text);
				break;
		}


		if (this.isThisActivityTop()) {
			if (dialog != null && dialog.isShowing())
				dialog.dismiss();
			dialog = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1,
					title, message));
			dialog.show();
		}
	}


	class DownloadFileFromURL extends AsyncTask<String,String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		private String response;
		@Override
		protected String doInBackground(String... f_url) {
			response = Utils.getLatestFile(f_url[0],f_url[1], WebviewActivity.this);
			return response;
		}

		@Override
		protected void onPostExecute(String result) {
			if (response != null && !response.equals("-1")) {
			} else {
				if (response == null) {
					displayCheckingResult(Utils.MLCheckResult.NotConnectedToWifi);
				}
				else {
					displayCheckingResult(Utils.MLCheckResult.ServerError);
				}
			}

			webview.loadUrl("file:///"+getFilesDir() + "//" + fileName);
			super.onPostExecute(result);
		}
		}
}
