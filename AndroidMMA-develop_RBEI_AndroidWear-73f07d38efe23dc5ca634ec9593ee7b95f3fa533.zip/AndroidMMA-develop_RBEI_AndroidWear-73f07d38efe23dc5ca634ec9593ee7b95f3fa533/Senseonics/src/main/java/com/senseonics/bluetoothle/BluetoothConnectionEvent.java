package com.senseonics.bluetoothle;

public class BluetoothConnectionEvent {
    private boolean isBluetoothEnabled;

    public BluetoothConnectionEvent(boolean isBluetoothEnabled) {
        this.isBluetoothEnabled = isBluetoothEnabled;
    }

    public boolean isBluetoothEnabled() {
        return isBluetoothEnabled;
    }
}
