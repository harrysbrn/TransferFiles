package com.senseonics.fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.InputType;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.CalibrateActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ServiceActivity;
import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils.DateDialogManager;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Convert;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.CALIBRATION_STATE;
import com.senseonics.util.Utils.CAL_PHASE;
import com.senseonics.util.Utils.GLUCOSE_UNIT;
import com.senseonics.util.Utils.TransmitterMessageCode;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

public class CalibrateFragment extends BaseFragment {

    private String startingText = "-----";
    private Boolean glucoseValueSelected, timeValueSelected;
    private ArrayList<Item> glucoseValues, glucoseValuesMg;
    private int glucoseLevel;
    private Calendar startDate, currentDate;
    private TextView timeTextView, glucoseTextView, nextScheduleTextView, sensorDaysSinceInsertionTextView;
    private boolean tipsIsShowing;

    private View view;
    private TextView textView;
    private ImageView arrowTips;
    private TextView time_label;
    private TextView glucose_label;
    private TextView time_selection_label;
    private TextView glucose_selection_label;

    private RelativeLayout timePicker;
    private RelativeLayout glucosePicker;

    private Dialog dialog;
    private Timer timer;

    private CalibrationManager manager;

    private ProgressDialog progressDialog;
    private BroadcastReceiver broadcastReceiver;
    private static int  CALIBRATION_VIEW_REFRESH_INTERVAL = 120000; //REFRESH THE PAGE FOR EVERY 2 MINS.

    private Dialog confirmationDialog;

    /** APPDEV-4032 */
    private TextView notesLabel;
    private EditText notesEditText;

    public interface CalibrationManager {
        void submit(CalibrationEventPoint event);
    }

    public void setManager(CalibrationManager manager) {
        this.manager = manager;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        view = inflater.inflate(R.layout.fragment_calibrate, null);

        progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(true);

        currentDate = Calendar.getInstance();
        startDate = Calendar.getInstance();

        glucoseValueSelected = false;
        timeValueSelected = false;

        initTimePicker(view);
        initGlucosePicker(view);
        initNextScheduleCalibrationTime(view);
        initSensorLifeRemainingDays(view);
        initBottomLayout(view);

        time_label = (TextView) view.findViewById(R.id.time_label);
        glucose_label = (TextView) view.findViewById(R.id.glucose_label);
        time_selection_label = (TextView) view.findViewById(R.id.time);
        glucose_selection_label = (TextView) view.findViewById(R.id.glucose);

        /** APPDEV-4032 */
        notesLabel = (TextView) view.findViewById(R.id.notesLabel);
        notesEditText = (EditText) view.findViewById(R.id.notes);
        notesEditText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        notesEditText.setRawInputType(InputType.TYPE_CLASS_TEXT);

        setupSubmitEvent();

        tipsIsShowing = false;

        textView = (TextView) view.findViewById(R.id.text);

        // Set the default value
        Utils.calibrationState = CALIBRATION_STATE.REASON_UNKNOWN;
        refreshCalibrationState();

        timer = new Timer();
        timer.schedule(new UpdateTimeTask(), 0, CALIBRATION_VIEW_REFRESH_INTERVAL); // refresh the status
        return view;
    }

    /** #4022 */
    private void dismissConfirmationDialog() {
        if (confirmationDialog != null && confirmationDialog.isShowing()) {
            confirmationDialog.dismiss();
        }
    }

    // Submit
    private void setupSubmitEvent() {
        /** APPDEV-4142 Reduce number of taps needed to complete a cal entry (Android) */
        OnClickListener eventClickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                // Set the date and time
                CalibrationEventPoint event = new CalibrationEventPoint(
                        currentDate, glucoseLevel, false,
                        notesEditText.getText().toString() /** APPDEV-4032 */
                );

                hideProgressDialog();

                Utils.calibrationState = Utils.CALIBRATION_STATE.REASON_UNKNOWN;
                Utils.nextScheduledCalibration = null;

                if (timer != null) {
                    timer.cancel();
                    timer = null;
                }

                // Store the submitted calibration value
                Utils.LAST_CALIBRATION_VALUE = glucoseLevel;

                // Submit the event
                manager.submit(event);
            }
        };

        if(getActivity().getClass() == MainActivity.class) {
            MainActivity.naviBarRightItemTextView.setOnClickListener(eventClickListener);
        }
        else if(getActivity().getClass() == CalibrateActivity.class) {
            CalibrateActivity.naviBarRightItemTextView.setOnClickListener(eventClickListener);
        }
    }

    private void setTextViewToGrayText(TextView textView) {
        textView.setTextColor(getResources().getColor(R.color.light_gray));
    }

    private void setTextViewToBlackText(TextView textView) {
        textView.setTextColor(getResources().getColor(R.color.black));
    }

    private void enableSubmitButton() {
        /*
		 * #1225 the submit button is only enabled when the time and glucose are
		 * selected
		 */

        // Enable the submit button
        if(getActivity().getClass() == MainActivity.class) {
            if (MainActivity.naviBarRightItemTextView != null) {
                MainActivity.naviBarRightItemTextView.setClickable(true);
                MainActivity.naviBarRightItemTextView.setTextColor(getResources()
                        .getColor(android.R.color.white));
            }
        }
        else if(getActivity().getClass() == CalibrateActivity.class) {
            if (CalibrateActivity.naviBarRightItemTextView != null) {
                CalibrateActivity.naviBarRightItemTextView.setClickable(true);
                CalibrateActivity.naviBarRightItemTextView.setTextColor(getResources()
                        .getColor(android.R.color.white));
            }
        }
    }

    private void disableSubmitButton() {
        // Disable the submit button
        if(getActivity().getClass() == MainActivity.class) {
            if (MainActivity.naviBarRightItemTextView != null) {
                MainActivity.naviBarRightItemTextView.setClickable(false);
                MainActivity.naviBarRightItemTextView.setTextColor(getResources()
                        .getColor(R.color.light_gray));
            }
        }
        else if(getActivity().getClass() == CalibrateActivity.class) {
            if (CalibrateActivity.naviBarRightItemTextView != null) {
                CalibrateActivity.naviBarRightItemTextView.setClickable(false);
                CalibrateActivity.naviBarRightItemTextView.setTextColor(getResources()
                        .getColor(R.color.light_gray));
            }
        }
    }

    private void enablePickersAndBottomLayout() {

        // Enable the pickers
        timePicker.setClickable(true);
        setTextViewToBlackText(time_label);
        setTextViewToBlackText(time_selection_label);

        glucosePicker.setClickable(true);
        setTextViewToBlackText(glucose_label);
        setTextViewToBlackText(glucose_selection_label);

        /** APPDEV-4032 */
        setTextViewToBlackText(notesLabel);
        notesEditText.setFocusableInTouchMode(true);

        // #965 Start the blinking
        startBlinkTextView(timeTextView);
        startBlinkTextView(glucoseTextView);

        // Check to see if submit button needs to be enabled
        checkIfSubmitButtonNeedEnable();
    }

    private void disablePickersAndBottomLayout() {
        disableSubmitButton();

        // Disable the picker selection
        timePicker.setClickable(false);
        setTextViewToGrayText(time_label);
        setTextViewToGrayText(time_selection_label);

        glucosePicker.setClickable(false);
        setTextViewToGrayText(glucose_label);
        setTextViewToGrayText(glucose_selection_label);

        /** APPDEV-4032 */
        setTextViewToGrayText(notesLabel);
        notesEditText.setFocusable(false);

        // #965 Stop the blinking
        stopBlinkTextView(timeTextView);
        stopBlinkTextView(glucoseTextView);
    }

    private void printCalendar(String tag, Calendar cal) {
        Log.d(tag,
                "Calendar:" + cal.get(Calendar.YEAR) + "/"
                        + (cal.get(Calendar.MONTH) + 1) + "/"
                        + cal.get(Calendar.DAY_OF_MONTH) + " "
                        + cal.get(Calendar.HOUR_OF_DAY) + ":"
                        + cal.get(Calendar.MINUTE) + ":"
                        + cal.get(Calendar.SECOND)
        );
    }

    public void updateSensorDaysSinceInsertion() {
        Calendar insertionDate = transmitterStateModel.getSensorInsertionDateAndTime();

        String daysString;

        if (insertionDate != null) {
            long insertionMillis = insertionDate.getTimeInMillis();
            long nowMills = Calendar.getInstance().getTimeInMillis();

            int days = (int)(((double)(nowMills - insertionMillis)) / 1000 / 60 / 60 / 24);

            if (days < 0) {
                days = 0;
            }

            daysString = String.valueOf(days);

            /** #3266 Days since insertion after 180days should show >180 and not a number (Android) */
            final int MAX_DAYS = 180;
            if (days > MAX_DAYS) {
                daysString = ">" + MAX_DAYS;
            }
        }
        else {
            daysString = Utils.unknownString;
        }

        Spanned confirm_body = Html.fromHtml("<b>"+getActivity().getResources().getString(R.string.sensor_days_since_insertion)+ ": " + daysString+"</b>");

        sensorDaysSinceInsertionTextView.setText(confirm_body);
    }

    public void updateNextScheduledCalibration() {

        String tag = "next_calibrate";
        if ((Utils.nextScheduledCalibration != null)
                && (Utils.minsBeforeNextCalibrationTime != -1)
                && (Utils.minsAfterNextCalibrationTime != -1)) {
            // nextScheduledCalibration is in GMT time
            Log.d(tag,
                    "Utils.nextScheduledCalibration1:"
                            + Utils.formatDate_TimeZone(Utils.nextScheduledCalibration,
                            TimeZone.getDefault()));

            Calendar nextCalibration = Utils
                    .copyCalendar(Utils.nextScheduledCalibration);
            nextCalibration.setTimeZone(TimeZone.getDefault());
            // nextCalibration.setTimeInMillis(nextCalibration.getTimeInMillis()
            // - timeZoneDiff);
            Log.d(tag,
                    "nextCalibration local:"
                            + Utils.formatDate_TimeZone(nextCalibration,
                            TimeZone.getDefault()));

            Calendar minRange = Utils.copyCalendar(nextCalibration);
            minRange.setTimeInMillis(minRange.getTimeInMillis()
                    - Utils.minsBeforeNextCalibrationTime * GraphUtils.MINUTE);
            Calendar maxRange = Utils.copyCalendar(nextCalibration);
            maxRange.setTimeInMillis(maxRange.getTimeInMillis()
                    + Utils.minsAfterNextCalibrationTime * GraphUtils.MINUTE);

            Log.d(tag, "minsBeforeNextCalibrationTime:"
                    + Utils.minsBeforeNextCalibrationTime);
            Log.d(tag, "minsAfterNextCalibrationTime:"
                    + Utils.minsAfterNextCalibrationTime);

            Log.d(tag,
                    "minRange:"
                            + Utils.formatDate_TimeZone(minRange, TimeZone.getDefault()));
            Log.d(tag,
                    "maxRange:"
                            + Utils.formatDate_TimeZone(maxRange, TimeZone.getDefault()));

            Log.d(tag,
                    "Utils.nextScheduledCalibration2:"
                            + Utils.formatDate_TimeZone(Utils.nextScheduledCalibration,
                            TimeZone.getDefault()));

            Calendar todayCalendar = Calendar.getInstance();

            this.printCalendar(tag, nextCalibration);
            this.printCalendar(tag, minRange);
            this.printCalendar(tag, maxRange);
            this.printCalendar(tag, todayCalendar);

            String dayString = getString(R.string.tomorrowLow);

            // minrange date is dateOfInterest
            if ((todayCalendar.get(Calendar.YEAR) == minRange.get(Calendar.YEAR))
                    && (todayCalendar.get(Calendar.MONTH) == minRange.get(Calendar.MONTH))
                    && (todayCalendar.get(Calendar.DAY_OF_MONTH) == minRange.get(Calendar.DAY_OF_MONTH))) {
                Log.d(tag, "TODAY");
                dayString = getString(R.string.todayLow);
            }

            if (maxRange.after(todayCalendar)) {
                String displayText = "";

                if ((Utils.minsBeforeNextCalibrationTime == 0) && (Utils.minsAfterNextCalibrationTime == 0)) {
                    displayText = dayString + " " + Utils.getTime(nextCalibration, TimeZone.getDefault());
                } else {
                    displayText = dayString + " " + getString(R.string.between)
                            + " " + Utils.getTime24HrFormat(minRange, TimeZone.getDefault(), getActivity())
                            + " " + getString(R.string.and)
                            + " " + Utils.getTime24HrFormat(maxRange, TimeZone.getDefault(), getActivity());
                }

                nextScheduleTextView.setText(displayText);
            } else {
                if (Utils.calibrationState == CALIBRATION_STATE.TOO_SOON) {
                    nextScheduleTextView
                            .setText(getString(R.string.next_schedule_cal_unknown));
                } else {
                    nextScheduleTextView.setText(getString(R.string.now));
                }
            }

        } else {
            nextScheduleTextView
                    .setText(getString(R.string.next_schedule_cal_unknown));
        }
    }

    private String suggestedUserAction() {
        // if no sensor detected, then inform the user to place the transmitter
        // over the sensor
        // otherwise, inform them to wait 10 minutes, they just haven't
        // collected enough data yet
        String userAction = null;
        int minutesRemainingUntilCalibration = Utils.minutesRemainingUntilCalibrationAllowed;
        if ((minutesRemainingUntilCalibration <= 0)
                || (minutesRemainingUntilCalibration == 0xFFFF)
                || (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.SensorAwolAlarm)) {
            minutesRemainingUntilCalibration = 5; // default wait period should
            // be 5 minutes if the
            // value is
            // not read from the
            // Transmitter
        }

        if (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.SensorAwolAlarm) {
            userAction = getString(R.string.place_sensor).replace("%d",
                    String.valueOf(minutesRemainingUntilCalibration));
        } else {
            userAction = getString(R.string.wait_for_x_minutes).replace("%d",
                    String.valueOf(minutesRemainingUntilCalibration));
        }

        return userAction;
    }

    public void refreshCalibrationState() {
        Log.d(CalibrateFragment.class.getSimpleName(), "refreshCalibrationState: " + Utils.calibrationState);
        hideProgressDialog();
        if (getActivity() != null) {
            // disable first
            disablePickersAndBottomLayout();

            if (BluetoothUtils.mConnected == false) {
                textView.setText(getString(R.string.disconnected_from_transmitter));
                textView.setTextColor(getResources().getColor(R.color.graph_red));
                return;
            }

            switch (Utils.calibrationState) {
                case READY:
                    textView.setText(getString(R.string.calibrate_text));
                    textView.setTextColor(getResources().getColor(R.color.black));

                    /** APPDEV-4142 Reduce number of taps needed to complete a cal entry (Android) */
                    updateTimeWithCalendar(Calendar.getInstance());

                    // only enable in this case
                    enablePickersAndBottomLayout();
                    break;

                case NOT_ENOUGH_DATA:
                    String notEnoughDataString = getString(R.string.not_enough_data);
                    notEnoughDataString += " " + suggestedUserAction();
                    textView.setText(notEnoughDataString);
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case GLUCOSE_RATE_TOO_HIGH:
                    textView.setText(getString(R.string.rate_too_high));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case DROPOUT_PHASE:
                    textView.setText(getString(R.string.drop_out));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case TOO_SOON:
                    textView.setText(getString(R.string.too_soon));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case NO_SENSOR_LINKED:
                    textView.setText(getString(R.string.no_sensor_linked));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case UNSUPPORTED_MODE:
                    textView.setText(getString(R.string.unsupported_mode));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case WAITING_POST_CALIBRATION:
                    // #1234: calculate duration based on 3x sampling interval/60.
                    int duration = transmitterStateModel.getCalibrationDuration();

                    String strSet = getString(R.string.waiting_post_calibration)
                            .replace("%d", String.valueOf(duration));

                    textView.setText(strSet);
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case SENSOR_EOL:
                case LED_DISCONNECT_DETECTED:
                    textView.setText(getString(R.string.sensor_eol));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                case REASON_UNKNOWN:
                    // #1146 Need to check for warm up phase
                    if (transmitterStateModel.getCurrentCalibrationPhase() == CAL_PHASE.WARM_UP) {
                        textView.setText(getString(R.string.warmup_unknown));
                    } else {
                        textView.setText(getString(R.string.unknown_reason));
                    }

                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

                default:
                    textView.setText(getString(R.string.unknown_reason));
                    textView.setTextColor(getResources().getColor(R.color.graph_red));
                    break;

            }
        }
    }

    private void checkIfSubmitButtonNeedEnable() {
        if (timeTextView != null && glucoseTextView != null) {
            String timeString = timeTextView.getText().toString();
            String glucoseString = glucoseTextView.getText().toString();

            if ((timeString != startingText) && (glucoseString != startingText)) {
                enableSubmitButton();
            } else {
                disableSubmitButton();
            }
        }
    }

    private void startBlinkTextView(TextView tv) {
        if (tv != null) {
            Animation anim = new AlphaAnimation(0.0f, 1.0f);

            anim.setDuration(300); // You can manage the blinking time with this
            // parameter
            anim.setStartOffset(20);
            anim.setRepeatMode(Animation.REVERSE);
            anim.setRepeatCount(Animation.INFINITE);

            tv.startAnimation(anim);

            if (tv.getText().toString() != startingText) {
                stopBlinkTextView(tv);
            }
        }
    }

    private void stopBlinkTextView(TextView tv) {
        if (tv != null) {
            tv.clearAnimation();
        }
    }

    private void updateTimeTextView() {
        if (timeValueSelected == true) {
            timeTextView.setText(Utils.getTime24HrFormat(currentDate,
                    TimeZone.getDefault(), getActivity()));

            // #965 Stop the blinking
            stopBlinkTextView(timeTextView);
        } else {
            timeTextView.setText(startingText);
        }

        checkIfSubmitButtonNeedEnable();
    }

    private void updateTimeWithCalendar(Calendar calendar) {
        currentDate = calendar;
        timeValueSelected = true;
        updateTimeTextView();
    }

    private void initTimePicker(View view) {

        timePicker = (RelativeLayout) view.findViewById(R.id.timePicker);
        timeTextView = (TextView) view.findViewById(R.id.time);

        final DateDialogManager dialogManager = new DateDialogManager() {

            @Override
            public void onDateSelected(Calendar calendar) {
                updateTimeWithCalendar(calendar);
            }
        };

        updateTimeTextView();

        timePicker.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                currentDate = Calendar.getInstance();
                currentDate.set(Calendar.SECOND, 0);
                currentDate.set(Calendar.MILLISECOND, 0);

                // #1003 restrict to only 10 minutes from the current time
                Date date = new Date();
                startDate.setTime(date);
                startDate.add(Calendar.MINUTE, -10);
                startDate.set(Calendar.SECOND, 0);
                startDate.set(Calendar.MILLISECOND, 0);

                Log.d("timepicker",
                        Utils.formatDate_TimeZone(startDate, TimeZone.getDefault())
                                + " ; "
                                + Utils.formatDate_TimeZone(currentDate,
                                TimeZone.getDefault()));

                dialogUtils.createDateTimePickerDialog(getActivity(), currentDate,
                        startDate, currentDate, dialogManager, true);
            }
        });
    }

    private void updateGlucoseTextWithString(String glucoseLevel) {
        if ((glucoseValueSelected == true) && (glucoseLevel != null)) {
            glucoseTextView.setText(glucoseLevel);

            // #965 Stop the blinking
            stopBlinkTextView(glucoseTextView);
        } else {
            glucoseTextView.setText(startingText);
        }

        checkIfSubmitButtonNeedEnable();
    }

    private void initGlucosePicker(View view) {

        glucosePicker = (RelativeLayout) view.findViewById(R.id.glucosePicker);
        glucoseTextView = (TextView) view.findViewById(R.id.glucose);

        int glucoseLevelInModel = transmitterStateModel.getGlucoseLevel();
        if (glucoseLevelInModel >= Utils.minBloodGlucose
                && glucoseLevelInModel <= Utils.maxBloodGlucose) {
            glucoseLevel = glucoseLevelInModel;
        } else {
            glucoseLevel = Utils.GLUCOSE_DEFAULT_LEVEL;
        }

        glucoseValuesMg = dialogUtils.getNumbersBetween(Utils.minBloodGlucose,
                Utils.maxBloodGlucose, 1);
        if(Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            glucoseValues = dialogUtils.getGlucoseLevels(Utils.minBloodGlucose,
                    Utils.maxBloodGlucose, 1);
        } else {
            glucoseValues = dialogUtils.getGlucoseLevels(Convert.MLConvertMgToMmol(Utils.minBloodGlucose),
                    Convert.MLConvertMgToMmol(Utils.maxBloodGlucose), 0.1f);
        }
        final PickerManager manager = new PickerManager() {

            @Override
            public void selected(int id) {
                glucoseLevel = dialogUtils.getGlucoseValueMg(glucoseValues.get(id)
                        .getValue());
                String glucoseLevelString = Utils.getGlucoseLevelString(
                        getActivity(), glucoseLevel);
                glucoseValueSelected = true;
                updateGlucoseTextWithString(glucoseLevelString);
            }
        };

        updateGlucoseTextWithString(null);

        glucosePicker.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (dialog != null && dialog.isShowing())
                    dialog.dismiss();

                int position = getPosition(glucoseLevel);
                dialog = dialogUtils.createPickerDialog(getActivity(),
                        getString(R.string.glucose_event), glucoseValues,
                        manager, position);

                dialog.show();
            }
        });
    }

    private int getPosition(int glucoseValue) {
        int position;
        if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            position = Utils.getItemPosition(glucoseValuesMg, glucoseValue);
        } else {
            Log.d("GlucosePicker",
                    "glucose level: " + Convert.MLConvertMgToMmol(glucoseValue));

            position = Utils.getItemPosition(glucoseValues,
                    String.format(Locale.US, "%.1f", Convert.MLConvertMgToMmol(glucoseValue)));
        }

        return position;
    }

    private void initNextScheduleCalibrationTime(View view) {
        nextScheduleTextView = (TextView) view.findViewById(R.id.nextSchedule);
        updateNextScheduledCalibration();
    }


    private void initSensorLifeRemainingDays(View view) {
        sensorDaysSinceInsertionTextView = (TextView) view.findViewById(R.id.sensorDaysSinceInsertionText);
        updateSensorDaysSinceInsertion();
    }

    private void initBottomLayout(View view) {

        LinearLayout tipsLayout = (LinearLayout) view.findViewById(R.id.tips);

        arrowTips = (ImageView) view.findViewById(R.id.arrowTips);
        final LinearLayout tipsTextViewLayout = (LinearLayout) view
                .findViewById(R.id.tipsTextLayout);
        TextView tipsTextView = (TextView) view.findViewById(R.id.tipsText);
        tipsTextView.setText(getString(R.string.tips_html_text));

        tipsLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (tipsIsShowing) {
                    tipsIsShowing = false;
                    arrowTips.setImageResource(R.drawable.icon_tips_arrow);
                    tipsTextViewLayout.setVisibility(View.GONE);
                } else {
                    tipsIsShowing = true;
                    arrowTips.setImageResource(R.drawable.icon_tips_arrow_down);
                    tipsTextViewLayout.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    @Override
    public void onStop() {
        hideProgressDialog();
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                refreshCalibrationState();
                updateNextScheduledCalibration();
                updateSensorDaysSinceInsertion();
            }
        };
        getActivity().registerReceiver(broadcastReceiver, new IntentFilter(Utils.CALIBRATION_STATE_ARRIVED));

        /** #3664 */
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).refreshAfterFragmentChanged();
        }

        /** #4022 */
        dismissConfirmationDialog();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // the timer would only be cancelled when the fragment is destroyed so that the timer could work in the background
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Override
    public void onPause() {
        getActivity().unregisterReceiver(broadcastReceiver);
        super.onPause();
    }

    private void hideProgressDialog() {
        progressDialog.dismiss();
    }

    public void nextRequest() {
        progressDialog.show();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                progressDialog.dismiss();
            }
        }, GraphUtils.MINUTE / 5);

        postCalibrationRequests();
    }

    private void postCalibrationRequests() {
        // Set the default value
        Utils.calibrationState = CALIBRATION_STATE.REASON_UNKNOWN;

        BluetoothService bluetoothService = ((ServiceActivity) getActivity()).getService();
        bluetoothService.postNextCalibrationDate();
        bluetoothService.postNextCalibrationTime();
        bluetoothService.postMinutesRemainingUntilCalibrationAllowed();
        bluetoothService.postMinutesBeforeNextCalibrationTime();
        bluetoothService.postMinutesAfterNextCalibrationTime();
        bluetoothService.postReadyForCalibration();
    }

    private class UpdateTimeTask extends TimerTask {
        public void run() {

            if (getActivity() != null) {
                getActivity().runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        Log.i("Calibrate timer", "--- Timer tick ---");

                        /** #4022 */
                        dismissConfirmationDialog();

                        hideProgressDialog();
                        if (BluetoothUtils.mConnected == true) {
                            progressDialog.show();
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {

                                @Override
                                public void run() {
                                    progressDialog.dismiss();
                                }
                            }, GraphUtils.MINUTE / 8);

                            postCalibrationRequests();
                        }

                        currentDate = Calendar.getInstance();

                        updateTimeTextView();
                    }
                });
            }
        }
    }

}
