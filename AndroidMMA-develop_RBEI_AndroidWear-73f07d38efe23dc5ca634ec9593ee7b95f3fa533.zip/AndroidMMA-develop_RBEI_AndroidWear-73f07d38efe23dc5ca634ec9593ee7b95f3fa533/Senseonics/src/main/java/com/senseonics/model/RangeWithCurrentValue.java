package com.senseonics.model;

import android.util.Log;

import com.google.common.base.Objects;
import com.senseonics.util.Range;

import java.util.ArrayList;
import java.util.List;


class RangeWithCurrentValue {
    private int max;
    private int currentRecordNumber;
    private int responseId;
    private List<Range> ranges;
    private int totalRecordsExpected;

    public RangeWithCurrentValue(int responseId) {
        this.responseId = responseId;
        max = 0;
        currentRecordNumber = 0;
        ranges = new ArrayList<>();
    }

    public int getResponseId() {
        return responseId;
    }

    public void setCurrentRecordNumber(int currentValue) {
        this.currentRecordNumber = currentValue;
        Log.d(SyncModel.class.getSimpleName(), this.toString());
    }

    public boolean isSyncing() {
        return max != currentRecordNumber;
    }

    public int getNumberOfRecordsExpected() {
        return totalRecordsExpected;
    }

    public int getFinished() {
        int finished = 0;
        for (Range range : ranges) {
            int result = range.compareTo(currentRecordNumber);
            if (result == 0) {
                finished += (range.getCount() - (range.getTo() - currentRecordNumber));
            } else if (result < 0) {
                finished += range.getCount();
            }
        }

        return finished;
    }

    public int getPercent() {
        if (totalRecordsExpected <= 0) {
            return 0;
        }

        int finished = getFinished();

        return (int) ((((float) (finished)) / totalRecordsExpected) * 100);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("responseId", "0x" + Integer.toHexString(responseId))
                .add("max", max)
                .add("totalRecordsExpected", totalRecordsExpected)
                .add("currentRecordNumber", currentRecordNumber)
                .add("percent", getPercent())
                .add("finished", getFinished())
                .toString();
    }

    public void addRange(int maxRecordNumber, int expectResponseCount) {
        totalRecordsExpected += expectResponseCount;
        ranges.add(new Range(maxRecordNumber - expectResponseCount + 1, maxRecordNumber));
        max = Math.max(max, maxRecordNumber);
    }

    public void setCurrentToMaxOfCurrentRange() {

        for (Range range : ranges) {
            int result = range.compareTo(currentRecordNumber);
            if (result == 0) {
                currentRecordNumber = range.getTo();
                break;
            }
        }
    }
}
