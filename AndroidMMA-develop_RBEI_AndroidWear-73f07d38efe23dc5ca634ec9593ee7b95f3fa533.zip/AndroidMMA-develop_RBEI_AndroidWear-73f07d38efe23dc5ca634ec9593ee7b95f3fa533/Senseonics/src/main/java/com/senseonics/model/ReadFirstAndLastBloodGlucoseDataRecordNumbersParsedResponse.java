package com.senseonics.model;

import android.content.SharedPreferences;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.PrepareSyncingRequestTask;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.db.DatabaseManager;
import com.senseonics.util.Range;

import javax.inject.Inject;

public class ReadFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse implements ParsedResponse {
    private SyncModel syncModel;
    private DatabaseManager databaseManager;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;
    private SharedPreferences sharedPreferences;

    @Inject
    public ReadFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse(SyncModel syncModel, DatabaseManager databaseManager, BluetoothServiceCommandClient bluetoothServiceCommandClient, SharedPreferences sharedPreferences) {
        this.syncModel = syncModel;
        this.databaseManager = databaseManager;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
        this.sharedPreferences = sharedPreferences;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadFirstAndLastBloodGlucoseDataRecordNumbersResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadFirstAndLastBloodGlucoseDataRecordNumbersResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        int firstRecordNr = data[1] | (data[2] << 8);
        int lastRecordNr = data[3] | (data[4] << 8);

        model.setBloodGlucoseRecordRange(new Range(firstRecordNr, lastRecordNr));
        if (!syncModel.isSyncing()) {
            syncModel.clear();
            PrepareSyncingRequestTask prepareSyncingRequestTask = new PrepareSyncingRequestTask(databaseManager, model.getMaxGlucoseRecordsToSync(), bluetoothServiceCommandClient, syncModel, model, sharedPreferences);
            prepareSyncingRequestTask.execute();
        }
    }
}
