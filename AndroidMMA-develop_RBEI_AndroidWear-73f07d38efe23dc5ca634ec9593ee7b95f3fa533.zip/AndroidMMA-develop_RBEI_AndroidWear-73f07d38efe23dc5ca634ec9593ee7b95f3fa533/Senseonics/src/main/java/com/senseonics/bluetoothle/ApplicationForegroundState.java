package com.senseonics.bluetoothle;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton public class ApplicationForegroundState
    implements Application.ActivityLifecycleCallbacks {
  private static int foregroundActivityCount = 0;
  private Activity lastActivityResumed;
  private Activity lastActivityPaused;

  @Inject public ApplicationForegroundState() {
  }

  public boolean isSameActivityPausedResumed() {
    return lastActivityResumed == lastActivityPaused;
  }

  public boolean isForeground() {
    return foregroundActivityCount > 0;
  }

  public void onActivityCreated(Activity activity, Bundle bundle) {
  }

  public void onActivityDestroyed(Activity activity) {
  }

  public void onActivityResumed(Activity activity) {
    foregroundActivityCount++;
    lastActivityResumed = activity;
  }

  public void onActivityPaused(Activity activity) {
    foregroundActivityCount--;
    lastActivityPaused = activity;
  }

  public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
  }

  public void onActivityStarted(Activity activity) {
  }

  public void onActivityStopped(Activity activity) {

  }
}
