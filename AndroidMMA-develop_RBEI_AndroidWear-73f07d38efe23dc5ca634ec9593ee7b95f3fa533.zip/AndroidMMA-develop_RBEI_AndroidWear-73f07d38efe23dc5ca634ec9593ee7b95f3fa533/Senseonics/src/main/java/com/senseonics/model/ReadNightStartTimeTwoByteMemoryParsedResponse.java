package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadNightStartTimeTwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse{
    @Inject
    public ReadNightStartTimeTwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.nightStartTimeAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] data = {dataOne, dataTwo};
        int[] time = BinaryOperations.calculateTimeFromBytes(data);

        model.setNightStartTimeHour(time[0]);
        model.setNightStartTimeMinute(time[1]);
    }
}
