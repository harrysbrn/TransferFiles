package com.senseonics.gen12androidapp;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.content.FileProvider;

import com.senseonics.util.BitmapFileUtil;
import com.senseonics.util.Emailer;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;

import static com.senseonics.util.Emailer.EMAIL_BODY;
import static com.senseonics.util.Emailer.EMAIL_TITLE;

public class BitmapSenderActivity extends ObjectGraphActivity {

    private static final int REQUEST_CODE = 5845;
    private static final String FOLDER_NAME = "/Senseonics";
    private static final String SCREENSHOT_NAME = "/senseonics_statistics.png";

    @Inject
    BitmapFileUtil bitmapFileUtil;
    @Inject
    BitmapSender bitmapSender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_graph_bitmap);

        prepareForExport();
    }

    public void prepareForExport() {
        /** For Android M and above to request permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isStorageAccessNeeded()) {
            requestPermissions(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_CODE);
        } else {
            sendBitmap();
        }*/
        sendBitmap();
    }

    /** For Android M and above to request permission
    @TargetApi(Build.VERSION_CODES.M)
    private boolean isStorageAccessNeeded() {
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    sendBitmap();
                } else {
                    finishAndRemoveTask();
                }
                break;
        }
    }*/

    private void sendBitmap() {
        try {
            String screenshotPath = getScreenshotPath();
            if (bitmapFileUtil.moveFile(getIntent().getStringExtra(Emailer.EMAIL_BITMAP_PATH), screenshotPath)) {
                bitmapSender.sendBitmap(this,
                        getIntent().getStringExtra(EMAIL_TITLE),
                        getIntent().getStringExtra(EMAIL_BODY),
                        FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", new File(screenshotPath)));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                finishAndRemoveTask();
            }
            else {
                finish();
            }
        }
    }

    private String getScreenshotPath() {
        File folder = new File(Environment.getExternalStorageDirectory() + FOLDER_NAME);
        if (!folder.exists()) {
            if (!folder.mkdir()) {
                return "N/A";
            }
        }
        return Environment.getExternalStorageDirectory() + FOLDER_NAME + SCREENSHOT_NAME;
    }
}
