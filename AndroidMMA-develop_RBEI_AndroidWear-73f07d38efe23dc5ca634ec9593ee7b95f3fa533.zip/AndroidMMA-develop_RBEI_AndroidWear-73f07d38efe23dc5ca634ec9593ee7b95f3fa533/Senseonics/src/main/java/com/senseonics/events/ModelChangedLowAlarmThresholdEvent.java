package com.senseonics.events;

public class ModelChangedLowAlarmThresholdEvent { /** #3160 */
    private int newValue;

    public ModelChangedLowAlarmThresholdEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
