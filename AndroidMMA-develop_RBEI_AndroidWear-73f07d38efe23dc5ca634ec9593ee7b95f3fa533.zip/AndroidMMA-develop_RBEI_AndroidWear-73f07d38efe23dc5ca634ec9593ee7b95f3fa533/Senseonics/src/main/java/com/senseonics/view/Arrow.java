package com.senseonics.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import com.senseonics.gen12androidapp.R;

public class Arrow extends View {

    private Paint paint;
    private Path path;
    private int triangleColor;
    private Path strokePath;

    public Arrow(Context context, AttributeSet attrs) {
        super(context, attrs);

        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStrokeWidth(3);
        path = new Path();
        strokePath = new Path();
    }

    public void setTriangleColor(int color){
        triangleColor = color;

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        paint.setColor(triangleColor);
        paint.setStyle(Paint.Style.FILL);
        path.moveTo(0, 0);
        path.lineTo((float)getHeight() / 2, getHeight()); /** getWidth() changes when the view is on the edge of the screen, use getHeight() instead */
        path.lineTo(getHeight(), 0);
        path.close();

        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(getResources().getColor(R.color.black));
        strokePath.moveTo(0, 0);
        strokePath.lineTo((float)getHeight() / 2, getHeight());
        strokePath.lineTo(getHeight(), 0);
        canvas.drawPath(strokePath, paint);
    }
}
