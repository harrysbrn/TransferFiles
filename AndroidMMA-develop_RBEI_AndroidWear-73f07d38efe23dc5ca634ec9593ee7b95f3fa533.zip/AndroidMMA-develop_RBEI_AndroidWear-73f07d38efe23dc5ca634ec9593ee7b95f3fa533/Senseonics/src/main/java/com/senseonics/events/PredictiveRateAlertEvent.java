package com.senseonics.events;

import com.senseonics.util.Utils;

import java.util.Objects;

public class PredictiveRateAlertEvent {
    private AlertEventPoint aep;
    private int notificationId;

    public PredictiveRateAlertEvent(AlertEventPoint aepIn, int notificationId) {
        this.aep = aepIn;
        this.notificationId = notificationId;
    }

    public AlertEventPoint getAlertEventPoint() {
        return aep;
    }

    @Override
    public int hashCode() {
        return Objects.hash(aep.getEventType(), aep.getPredictiveMinutes());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final PredictiveRateAlertEvent other = (PredictiveRateAlertEvent) obj;
        return Objects.equals(this.aep.getEventType(), other.aep.getEventType())
                && Objects.equals(this.aep.getPredictiveMinutes(), other.aep.getPredictiveMinutes());
    }

    public int getNotificationId() {
        return notificationId;
    }

}
