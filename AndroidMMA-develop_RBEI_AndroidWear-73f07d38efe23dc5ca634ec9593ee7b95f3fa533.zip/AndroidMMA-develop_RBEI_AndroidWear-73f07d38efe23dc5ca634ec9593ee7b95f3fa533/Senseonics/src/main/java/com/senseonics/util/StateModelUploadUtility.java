package com.senseonics.util;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;

import com.senseonics.model.StateModelUpload.DMSStateModelAppInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelSensorInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelThresholdInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelTransmitterInfo;
import com.senseonics.model.StateModelUpload.DMSStateModelUserInfo;
import com.senseonics.model.TransmitterStateModel;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class StateModelUploadUtility {
    public enum StateModelType {
        StateModelType_TxInfo,
        StateModelType_SxInfo,
        StateModelType_ThresholdInfo,
        StateModelType_AppInfo,
        StateModelType_CheckAndUpdatePassword /** #3707 */
    }

    private final boolean TRANSMITTER_ACTIVE = true;
    private final boolean SENSOR_ACTIVE = true;
    private final boolean APP_ACTIVE = true;

    public final String kStateModelUploadTransmitterInfoWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/UploadTransmitterInfo";
    public final String kStateModelUploadSensorInfoWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/UploadSensorInfo";
    public final String kStateModelUploadThresholdInfoWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/UploadThresholds_CareApp";
    public final String kStateModelUploadAppInfoWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/UploadAppInfo";

    private final String Tag = "DMS(StateModelUploadUtility)";

    private AccountConstants accountConstants;
    private Context context;
    private TransmitterStateModel transmitterStateModel;

    @Inject
    public StateModelUploadUtility(
            AccountConstants accountConstantsIn,
            Context contextIn,
            TransmitterStateModel transmitterStateModelIn
    ) {
        this.accountConstants = accountConstantsIn;
        this.context = contextIn;
        this.transmitterStateModel = transmitterStateModelIn;
    }

    public DMSStateModelUserInfo fetchStateModelUserInfo() {
        String userID = accountConstants.getAccountUserIDFromPreference();
        String password = accountConstants.getAccountPasswordFromPreference();
        String passwordHashed = accountConstants.generateBase64RFC2898(password);
        String passwordBinary = accountConstants.stringToBase64Data(password);
        String username = accountConstants.getAccountUsernameFromPreference();

        DMSStateModelUserInfo userInfo = new DMSStateModelUserInfo(userID, passwordHashed, passwordBinary, username);
        return userInfo;
    }

    /** Get State model info */
    public DMSStateModelTransmitterInfo fetchStateModelTransmitterInfo() {
        DMSStateModelTransmitterInfo transmitterInfo = new DMSStateModelTransmitterInfo(
                accountConstants.fetchTxSerialNoFromModel(), // might be ""
                transmitterStateModel.getTransmitterName(),
                "", // txAddress
                fetchStateModelUserInfo(),
                transmitterStateModel.getTransmitterModelNumber(),
                transmitterStateModel.getFormattedTransmitterVersionNumber(),
                "", // versionExt
                transmitterStateModel.getAlgorithmParameterFormatVersion(),
                accountConstants.FormattedGMTDateAndTimeString(transmitterStateModel.getStartCalibrationPhaseDateAndTime()),
                accountConstants.getLastCriticalFaults(),
                transmitterStateModel.getCurrentPhaseNotTranslated(),
                transmitterStateModel.getSamplingIntervalInSeconds(),
                TRANSMITTER_ACTIVE
        );

        return transmitterInfo;
    }

    public DMSStateModelSensorInfo fetchStateModelSensorInfo() {
        DMSStateModelSensorInfo sensorInfo = new DMSStateModelSensorInfo(
                accountConstants.fetchSensorIDFromModel(), // might be "0"
                accountConstants.fetchSensorIDFromModel(), // might be "0"
                transmitterStateModel.getUnLinkedSensorId(),
                accountConstants.FormattedGMTDateAndTimeString(transmitterStateModel.getSensorInsertionDateAndTime()),
                fetchStateModelUserInfo(),
                String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f,%.4f",
                        transmitterStateModel.getMEPSavedValue(),
                        transmitterStateModel.getMEPSavedRefChannelMetric(),
                        transmitterStateModel.getMEPSavedDriftMetric(),
                        transmitterStateModel.getMEPSavedLowRefMetric(),
                        transmitterStateModel.getMEPSavedSpike()
                ),
                String.format(Locale.US, "%.4f", transmitterStateModel.getEEP24MSP()),
                SENSOR_ACTIVE
        );

        return sensorInfo;
    }

    public DMSStateModelThresholdInfo fetchStateModelThresholdInfo() {
        DMSStateModelThresholdInfo thresholdInfo = new DMSStateModelThresholdInfo(
                fetchStateModelUserInfo(),
                accountConstants.getGlucoseUnit() + 1,
                transmitterStateModel.getLowGlucoseTarget(),
                transmitterStateModel.getHighGlucoseTarget(),
                transmitterStateModel.getLowGlucoseAlertThreshold(),
                transmitterStateModel.getHighGlucoseAlertThreshold(),
                transmitterStateModel.getLowGlucoseAlarmThreshold(),
                transmitterStateModel.getHighGlucoseAlarmThreshold(),
                transmitterStateModel.isPredictiveAlertsActivated(),
                transmitterStateModel.isRateAlertsActivated(),
                transmitterStateModel.getPredictiveFallingRateAlertMinuteInterval(),
                GetRateValueWithoutUnitsLabel(transmitterStateModel.getRateAlertFallingThreshold())
        );

        return thresholdInfo;
    }

    public DMSStateModelAppInfo fetchStateModelAppInfo() {
        String appVersion = "";

        try {
            appVersion = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName + " (" + context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode + ")";
        }
        catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        DMSStateModelAppInfo appInfo = new DMSStateModelAppInfo(
                "Android OS",
                appVersion,
                fetchStateModelUserInfo(),
                getDeviceName(),
                Build.VERSION.RELEASE + " (" + Build.VERSION.SDK_INT + ")",
                APP_ACTIVE,
                getCountryInformation()
        );

        return appInfo;
    }

    private String replaceNullStringWithEmpty(String stringIn) {
        if (stringIn == null) {
            return "";
        }
        else {
            return stringIn;
        }
    }

    /** Generate State model requests */
    public String generateStateModelTransmitterInfoRequest(DMSStateModelTransmitterInfo transmitterInfo) {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction%</wsa:Action>"
                + "<wsa:To>%wsaTo%</wsa:To>"
                + "</soap:Header>\n"
                + "<soap:Body>\n"

                + "<tem:UploadTransmitterInfo>\n"

                + "<tem:TxSNo>%TxSNo%</tem:TxSNo>\n"
                + "<tem:TxName>%TxName%</tem:TxName>\n"
                + "<tem:TxAddress>%TxAddress%</tem:TxAddress>\n"
                + "<tem:userID>%userID%</tem:userID>\n"
                + "<tem:PasswordHash>%pwdHash%</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary%</tem:PasswordBinary>\n"
                + "<tem:pw>%pw%</tem:pw>\n"
                + "<tem:TxModelNo>%TxModelNo%</tem:TxModelNo>\n"
                + "<tem:TxVersion>%TxVersion%</tem:TxVersion>\n"
                + "<tem:TxVersionExtn>%TxVersionExtn%</tem:TxVersionExtn>\n"
                + "<tem:TxFormatVersion>%TxFormatVersion%</tem:TxFormatVersion>\n"
                + "<tem:TxStartCalibrationPhaseDt>%TxStartCalibrationPhaseDt%</tem:TxStartCalibrationPhaseDt>\n"
                + "<tem:TxLastFaultCritical>%TxLastFaultCritical%</tem:TxLastFaultCritical>\n"
                + "<tem:TXCurrentCalibPhase>%TXCurrentCalibPhase%</tem:TXCurrentCalibPhase>\n"
                + "<tem:TxSamplingInterval>%TxSamplingInterval%</tem:TxSamplingInterval>\n"
                + "<tem:TxActive>%TxActive%</tem:TxActive>\n"

                + "</tem:UploadTransmitterInfo>\n"

                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction%", kStateModelUploadTransmitterInfoWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo%", replaceNullStringWithEmpty(accountConstants.getDMSServerURL()));

        requestString = requestString.replace("%TxSNo%", replaceNullStringWithEmpty(transmitterInfo.getTxID()));
        requestString = requestString.replace("%TxName%", replaceNullStringWithEmpty(transmitterInfo.getTxName()));
        requestString = requestString.replace("%TxAddress%", replaceNullStringWithEmpty(transmitterInfo.getTxAddress()));
        requestString = requestString.replace("%userID%", replaceNullStringWithEmpty(transmitterInfo.getUserInfo().getUserID()));
        requestString = requestString.replace("%pwdHash%", replaceNullStringWithEmpty(transmitterInfo.getUserInfo().getPWHash()));
        requestString = requestString.replace("%pwdBinary%", replaceNullStringWithEmpty(transmitterInfo.getUserInfo().getPWBinary()));
        requestString = requestString.replace("%TxModelNo%", replaceNullStringWithEmpty(transmitterInfo.getTxModel()));
        requestString = requestString.replace("%TxVersion%", replaceNullStringWithEmpty(transmitterInfo.getTxSoftwareVersion()));
        requestString = requestString.replace("%TxVersionExtn%", replaceNullStringWithEmpty(transmitterInfo.getTxSoftwareVersionExt()));
        requestString = requestString.replace("%TxFormatVersion%", transmitterInfo.getAlgoFormatVersion()+"");
        requestString = requestString.replace("%TxStartCalibrationPhaseDt%", replaceNullStringWithEmpty(transmitterInfo.getDateOfCurrentCalibrationPhase()));
        requestString = requestString.replace("%TxLastFaultCritical%", replaceNullStringWithEmpty(transmitterInfo.getLastCriticalFault()));
        requestString = requestString.replace("%TXCurrentCalibPhase%", replaceNullStringWithEmpty(transmitterInfo.getCurrentCalibrationPhase()));
        requestString = requestString.replace("%TxSamplingInterval%", transmitterInfo.getSamplingInterval()+"");
        requestString = requestString.replace("%TxActive%", boolToInt(transmitterInfo.isTxActive())+"");

        Utils.printLongLog(Tag, "TRANSMITTER Request:" + requestString);

        return requestString;
    }

    public String generateStateModelSensorInfoRequest(DMSStateModelSensorInfo sensorInfo) {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction%</wsa:Action>"
                + "<wsa:To>%wsaTo%</wsa:To>"
                + "</soap:Header>\n"
                + "<soap:Body>\n"
                + "<tem:UploadSensorInfo>\n"

                + "<tem:SnSNo>%SnSNo%</tem:SnSNo>\n"
                + "<tem:SNLnkdSNID>%SNLnkdSNID%</tem:SNLnkdSNID>\n"
                + "<tem:SNUNLnkdSNID>%SNUNLnkdSNID%</tem:SNUNLnkdSNID>\n"
                + "<tem:SNInsertionDT>%SNInsertionDT%</tem:SNInsertionDT>\n"
                + "<tem:UserID>%UserID%</tem:UserID>\n"
                + "<tem:PasswordHash>%pwdHash%</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary%</tem:PasswordBinary>\n"
                + "<tem:SNMEP>%SNMEP%</tem:SNMEP>\n"
                + "<tem:SNMSP>%SNMSP%</tem:SNMSP>\n"
                + "<tem:SnActive>%SnActive%</tem:SnActive>\n"

                + "</tem:UploadSensorInfo>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction%", kStateModelUploadSensorInfoWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo%", replaceNullStringWithEmpty(accountConstants.getDMSServerURL()));

        requestString = requestString.replace("%SnSNo%", replaceNullStringWithEmpty(sensorInfo.getSensorID()));
        requestString = requestString.replace("%SNLnkdSNID%", replaceNullStringWithEmpty(sensorInfo.getLinkedSensorID()));
        requestString = requestString.replace("%SNUNLnkdSNID%", replaceNullStringWithEmpty(sensorInfo.getUnlinkedSensorID()));
        requestString = requestString.replace("%SNInsertionDT%", replaceNullStringWithEmpty(sensorInfo.getSensorInsertionDate()));
        requestString = requestString.replace("%UserID%", replaceNullStringWithEmpty(sensorInfo.getUserInfo().getUserID()));
        requestString = requestString.replace("%pwdHash%", replaceNullStringWithEmpty(sensorInfo.getUserInfo().getPWHash()));
        requestString = requestString.replace("%pwdBinary%", replaceNullStringWithEmpty(sensorInfo.getUserInfo().getPWBinary()));
        requestString = requestString.replace("%SNMEP%", replaceNullStringWithEmpty(sensorInfo.getMEP()));
        requestString = requestString.replace("%SNMSP%", replaceNullStringWithEmpty(sensorInfo.getMSP()));
        requestString = requestString.replace("%SnActive%", boolToInt(sensorInfo.isSensorActive())+"");

        Utils.printLongLog(Tag, "SENSOR Request:" + requestString);

        return requestString;
    }

    public String generateStateModelThresholdInfoRequest(DMSStateModelThresholdInfo thresholdInfo) {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction%</wsa:Action>"
                + "<wsa:To>%wsaTo%</wsa:To>"
                + "</soap:Header>\n"
                + "<soap:Body>\n"
                + "<tem:UploadThresholds_CareApp>\n"

                + "<tem:UserID>%userID%</tem:UserID>\n"
                + "<tem:PasswordHash>%pwdHash%</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary%</tem:PasswordBinary>\n"
                + "<tem:GlucoseUnitOfMeasure>%GlucoseUnitOfMeasure%</tem:GlucoseUnitOfMeasure>\n"
                + "<tem:GlucoseLowThreshold>%GlucoseLowThreshold%</tem:GlucoseLowThreshold>\n"
                + "<tem:GlucoseHighThreshold>%GlucoseHighThreshold%</tem:GlucoseHighThreshold>\n"
                + "<tem:GlucoseAlertLowThreshold>%GlucoseAlertLowThreshold%</tem:GlucoseAlertLowThreshold>\n"
                + "<tem:GlucoseAlertHighThreshold>%GlucoseAlertHighThreshold%</tem:GlucoseAlertHighThreshold>\n"
                + "<tem:GlucoseAlarmLowThreshold>%GlucoseAlarmLowThreshold%</tem:GlucoseAlarmLowThreshold>\n"
                + "<tem:GlucoseAlarmHighThreshold>%GlucoseAlarmHighThreshold%</tem:GlucoseAlarmHighThreshold>\n"
                + "<tem:PredectiveFlag>%PredectiveFlag%</tem:PredectiveFlag>\n"
                + "<tem:RateFlag>%RateFlag%</tem:RateFlag>\n"
                + "<tem:PredectiveMins>%PredectiveMins%</tem:PredectiveMins>\n"
                + "<tem:RateOfChange>%RateOfChange%</tem:RateOfChange>\n"

                + "</tem:UploadThresholds_CareApp>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction%", kStateModelUploadThresholdInfoWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo%", replaceNullStringWithEmpty(accountConstants.getDMSServerURL()));

        requestString = requestString.replace("%userID%", replaceNullStringWithEmpty(thresholdInfo.getUserInfo().getUserID()));
        requestString = requestString.replace("%pwdHash%", replaceNullStringWithEmpty(thresholdInfo.getUserInfo().getPWHash()));
        requestString = requestString.replace("%pwdBinary%", replaceNullStringWithEmpty(thresholdInfo.getUserInfo().getPWBinary()));
        requestString = requestString.replace("%GlucoseUnitOfMeasure%", thresholdInfo.getGlucoseUnit()+"");
        requestString = requestString.replace("%GlucoseLowThreshold%", thresholdInfo.getTargetLow()+"");
        requestString = requestString.replace("%GlucoseHighThreshold%", thresholdInfo.getTargetHigh()+"");
        requestString = requestString.replace("%GlucoseAlertLowThreshold%", thresholdInfo.getAlertLow()+"");
        requestString = requestString.replace("%GlucoseAlertHighThreshold%", thresholdInfo.getAlertHigh() + "");
        requestString = requestString.replace("%GlucoseAlarmLowThreshold%", thresholdInfo.getAlarmLow() + "");
        requestString = requestString.replace("%GlucoseAlarmHighThreshold%", thresholdInfo.getAlarmHigh() + "");
        requestString = requestString.replace("%PredectiveFlag%", boolToInt(thresholdInfo.isPredictiveAlertEnabled()) + "");
        requestString = requestString.replace("%RateFlag%", boolToInt(thresholdInfo.isRateAlertEnabled()) + "");
        requestString = requestString.replace("%PredectiveMins%", thresholdInfo.getPredictiveMins() + "");
        requestString = requestString.replace("%RateOfChange%", replaceNullStringWithEmpty(thresholdInfo.getRateSlope()));

        Utils.printLongLog(Tag, "THRESHOLD Request:" + requestString);

        return requestString;
    }

    public String generateStateModelAppInfoRequest(DMSStateModelAppInfo appInfo) {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction%</wsa:Action>"
                + "<wsa:To>%wsaTo%</wsa:To>"
                + "</soap:Header>\n"
                + "<soap:Body>\n"
                + "<tem:UploadAppInfo>\n"

                + "<tem:AppOS>%AppOS%</tem:AppOS>\n"
                + "<tem:AppVersion>%AppVersion%</tem:AppVersion>\n"
                + "<tem:UserID>%UserID%</tem:UserID>\n"
                + "<tem:PasswordHash>%pwdHash%</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary%</tem:PasswordBinary>\n"
                + "<tem:DeviceType>%DeviceType%</tem:DeviceType>\n"
                + "<tem:AppOSVersion>%AppOSVersion%</tem:AppOSVersion>\n"
                + "<tem:CountryLanguage>%CountryLanguage%</tem:CountryLanguage>\n"
                + "<tem:AppActive>%AppActive%</tem:AppActive>\n"

                + "</tem:UploadAppInfo>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction%", kStateModelUploadAppInfoWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo%", replaceNullStringWithEmpty(accountConstants.getDMSServerURL()));

        requestString = requestString
                .replace("%AppOS%", replaceNullStringWithEmpty(appInfo.getAppOS()));
        requestString = requestString
                .replace("%AppVersion%", replaceNullStringWithEmpty(appInfo.getAppVersion()));
        requestString = requestString
                .replace("%UserID%", replaceNullStringWithEmpty(appInfo.getUserInfo().getUserID()));
        requestString = requestString
                .replace("%pwdHash%", replaceNullStringWithEmpty(appInfo.getUserInfo().getPWHash()));
        requestString = requestString
                .replace("%pwdBinary%", replaceNullStringWithEmpty(appInfo.getUserInfo().getPWBinary()));
        requestString = requestString
                .replace("%DeviceType%", replaceNullStringWithEmpty(appInfo.getDeviceType()));
        requestString = requestString
                .replace("%AppOSVersion%", replaceNullStringWithEmpty(appInfo.getAppOSVersion()));
        requestString = requestString
                .replace("%CountryLanguage%", replaceNullStringWithEmpty(appInfo.getCountryLanguage()));
        requestString = requestString
                .replace("%AppActive%", boolToInt(appInfo.isAppActive()) + "");

        Utils.printLongLog(Tag, "APP Request:" + requestString);

        return requestString;
    }

    private int boolToInt(boolean boolVal) {
        return (boolVal == true) ? 1 : 0;
    }

    private String GetRateValueWithoutUnitsLabel(float rateInMgDlMin) {
        if (accountConstants.getGlucoseUnit() == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal()) {
            return String.format(Locale.US, "%.1f", rateInMgDlMin);
        } else {
            float glucoseMMol = Convert.MLConvertMgToMmol(rateInMgDlMin);
            return String.format(Locale.US, "%.2f", glucoseMMol);
        }
    }

    /** Returns the consumer friendly device name */
    private static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        }
        return capitalize(manufacturer) + " " + model;
    }

    private static String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] arr = str.toCharArray();
        boolean capitalizeNext = true;
        String phrase = "";
        for (char c : arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase += Character.toUpperCase(c);
                capitalizeNext = false;
                continue;
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            }
            phrase += c;
        }
        return phrase;
    }

    private static String getCountryInformation() {
        String localeString = Locale.getDefault().toString(); /** e.g. en_US */

        Calendar calendar = Calendar.getInstance();
        TimeZone mTimeZone = calendar.getTimeZone();

        String mTimeZoneID = mTimeZone.getID(); /** e.g. America/New_York */

        Date now = new Date();
        int mGMTOffsetInMinutes = mTimeZone.getOffset(now.getTime()) / 1000 / 60; /** -300, 330, etc. */

        return localeString + "|" + mTimeZoneID + "|" + mGMTOffsetInMinutes;
    }

}
