package com.senseonics.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;

import java.util.ArrayList;

public class MenuAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<Menu> items;
	private LayoutInflater inflater;

	public MenuAdapter(Context context, ArrayList<Menu> items) {
		inflater = LayoutInflater.from(context);
		this.context = context;
		this.items = items;
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		View view = inflater.inflate(R.layout.drawer_list_item, null);
		Menu menu = items.get(position);
		ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
		TextView textView = (TextView) view.findViewById(R.id.text);

		imageView.setImageResource(menu.getDrawableId());
		
		if (!menu.isActive()) {
			textView.setTextColor(context.getResources().getColor(R.color.light_gray));
			imageView.setImageAlpha(60);
		}
		else
		{
			textView.setTextColor(context.getResources().getColor(R.color.black));
		}
		
		textView.setText(menu.getMenuName());
		
		// Highlight selection menu cell
		LinearLayout linearLay = (LinearLayout) view.findViewById(R.id.contentLayout);
		if (position == MainActivity.currentMenu)
	    {
			linearLay.setBackgroundColor(context.getResources().getColor(R.color.highlighted_text_holo_light));
	    }
	    else
	    {
	    	linearLay.setBackgroundColor(context.getResources().getColor(R.color.transparent));
	    }
		
		return view;
	}
	
	@Override
	public boolean isEnabled(int position) 
	{
		// if the Menu is not active, disable the cell item
		return items.get(position).isActive();
	}
}
