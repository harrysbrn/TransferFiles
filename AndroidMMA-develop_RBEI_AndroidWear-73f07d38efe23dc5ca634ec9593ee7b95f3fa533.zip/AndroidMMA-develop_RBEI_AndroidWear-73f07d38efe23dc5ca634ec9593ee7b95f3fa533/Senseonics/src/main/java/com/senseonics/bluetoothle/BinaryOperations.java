package com.senseonics.bluetoothle;

import android.util.Log;

public class BinaryOperations {

    // returns an int value representing the CRC value for a byte array
    public static int GenerateChecksumCRC16(int bytes[]) {
        int crc = 0xFFFF;

        int temp;
        int crc_byte;
        for (int byte_index = 0; byte_index < bytes.length; byte_index++) {
            crc_byte = bytes[byte_index];
            for (int bit_index = 0; bit_index < 8; bit_index++) {
                temp = ((crc >> 15)) ^ ((crc_byte >> 7));
                crc <<= 1;
                crc &= 0xFFFF;
                if (temp > 0) {
                    crc ^= 0x1021;
                    crc &= 0xFFFF;
                }
                crc_byte <<= 1;
                crc_byte &= 0xFF;
            }
        }
        return crc;
    }

    // returns a 2 byte array from an int value (LSByte first, on index 0)
    public static int[] data16BitsFromIntLSByteFirst(int value) {

        int[] payload;

        if (value > 255) {
            payload = new int[2];
            payload[0] = (value & 0xff);
            payload[1] = ((value & 0xff00) >> 8);

        } else {
            payload = new int[] { value, 0x00 };
        }

        return payload;
    }

    // returns the value of a 2 byte array (given with LSByte on index 0).
    public static int dataIntFrom16BitsLSByteFirst(int[] bytes) {

        int returnValue = 0;

        if (bytes.length != 2) {
            Log.d("DATA", "Parameter length error");
            return returnValue;
        }

        return dataIntFrom16BitsLSByteFirst(bytes[0], bytes[1]);
    }

    public static int dataIntFrom16BitsLSByteFirst(int byteOne, int byteTwo) {
        int returnValue;
        returnValue = (byteOne | (byteTwo << 8));

        return returnValue;
    }

    // returns a 3 byte array from an int value (LSByte first, on index 0)
    static public int[] data24BitsFromIntLSByteFirst(int value) {

        int[] payload = new int[3];

        payload[0] = value & 0xFF;
        payload[1] = (value >> 8) & 0xFF;
        payload[2] = (value >> 16) & 0xFF;
        return payload;
    }

    // returns the value of a 3 byte array (given with LSByte on index 0).
    public static int dataIntFrom24BitsLSByteFirst(int[] bytes) {

        int returnValue = 0;

        if (bytes.length != 3) {
            Log.d("DATA", "Parameter length error");
            return returnValue;
        }

        returnValue = (bytes[0] | (bytes[1] << 8) | (bytes[2] << 16));
        return returnValue;
    }

    // returns a 4 byte array from an int value (LSByte first, on index 0)
    static public int[] data32BitsFromIntLSByteFirst(int value) {

        int[] payload = new int[4];

        payload[0] = value & 0xFF;
        payload[1] = (value >> 8) & 0xFF;
        payload[2] = (value >> 16) & 0xFF;
        payload[3] = (value >> 24) & 0xFF;
        return payload;
    }

    // returns from Year, Month, Day (given as an int) a 2 byte data.
    public static int[] calculateDateBytes(int year, int month, int day) {

        int[] returnValue = new int[2];

        returnValue[1] = (year - 2000) << 1;
        if (month > 7)
            returnValue[1] = returnValue[1] + 1;
        returnValue[0] = (((month & 7) << 5) | day);

        return returnValue;
    }

//	Testing date time bytes conversion: the function is hehaving as expected
//	int[] dateR = BinaryOperations.calculateDateFromBytes(new int[]{19, 29});
//	int[] timeR = BinaryOperations.calculateTimeFromBytes(new int[]{0, 127});
//	
//	String dateString = "";
//	for(int i=0; i<dateR.length; i++)
//	{
//		dateString += " " + dateR[i];
//	}
//	
//	String timeString = "";
//	for(int i=0; i<timeR.length; i++)
//	{
//		timeString += " " + timeR[i];
//	}
//	
//	Log.d("DateTime", "Date:" + dateString);
//	Log.d("DateTime", "Time:" + timeString);

    // return year, month, day from 2 byte data given (LSByte first, on index 0)
    public static int[] calculateDateFromBytes(int[] bytes) {

        int year;
        int month;
        int day;

        int returnValue[] = new int[3];

        year = bytes[1];
        year = ((year >> 1) + 2000);

        month = bytes[0];
        month = month >> 5;
        if (bytes[1] % 2 == 1)
            month = month + 8;

        day = bytes[0];
        day = day & 31;

        returnValue[0] = year;
        returnValue[1] = month;
        returnValue[2] = day;

        return returnValue;
    }

    // returns from Hours, Minutes, Seconds (given as an int) a 2 byte data.
    public static int[] calculateTimeBytes(int h, int m, int s) {

        int[] returnValue = new int[2];
        int m3MSB = ((m & 56) >> 3);
        int m3LSB = ((m & 7) << 5);
        int sPer2 = s / 2;

        returnValue[1] = ((h << 3) | m3MSB);
        returnValue[0] = (sPer2 | m3LSB);

        return returnValue;
    }

    // returns the hours, minutes, seconds from 2 byte data given (LSByte first)
    public static int[] calculateTimeFromBytes(int[] bytes) {

        int hour;
        int minute;
        int second;

        int[] returnValue = new int[3];

        hour = bytes[1];
        hour = hour >> 3;

        minute = bytes[0];
        int m3MSB = (bytes[1] & 7) << 3;
        minute = (minute >> 5) | m3MSB;

        second = bytes[0];
        second = (second & 31) * 2;

        returnValue[0] = hour;
        returnValue[1] = minute;
        returnValue[2] = second;

        return returnValue;
    }

    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character
                    .digit(s.charAt(i + 1), 16));
        }
        return data;
    }
}
