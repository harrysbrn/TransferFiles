package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;
public class ReadWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse implements SingleByteMemoryMapParsedResponse{
    @Inject
    public ReadWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.lowGlucoseAlarmRepeatIntervalNightTimeAddress;
    }

    @Override
    public void apply(int dataOne, TransmitterStateModel model) {
        model.setLowGlucoseAlarmRepeatIntervalNightTime(dataOne);
    }
}
