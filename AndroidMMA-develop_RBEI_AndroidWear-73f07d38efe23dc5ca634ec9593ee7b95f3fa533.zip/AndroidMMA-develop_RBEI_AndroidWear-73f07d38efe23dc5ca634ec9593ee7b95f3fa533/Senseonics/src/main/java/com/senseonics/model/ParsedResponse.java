package com.senseonics.model;

public interface ParsedResponse {
    int getExpectedResponseId();
    boolean check(int[] data);
    void apply(int[] data, TransmitterStateModel model);
}
