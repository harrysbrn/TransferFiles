package com.senseonics.model;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

public class ReadCurrentTransmitterDateAndTimeParsedResponse implements ParsedResponse {
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;

    @Inject
    public ReadCurrentTransmitterDateAndTimeParsedResponse(BluetoothServiceCommandClient bluetoothServiceCommandClient) {
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadCurrentTrasmitterDateAndTimeResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadCurrentTrasmitterDateAndTimeResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        long lastReadDatetime = model.getLastReadTransmitterDatetimeTimestamp();
        long currentDatetime = Calendar.getInstance().getTimeInMillis();
        long diff = currentDatetime - lastReadDatetime;

        /** Important */
        model.setLastReadTransmitterDatetimeTimestamp(0L); // <= reset it

        Transmitter.CONNECTION_STATE connectionState = model.getTransmitterConnectionState();
//        Log.d("#3734", "Connection state:" + connectionState);
        if ((connectionState != Transmitter.CONNECTION_STATE.CONNECTED) &&
                (connectionState != Transmitter.CONNECTION_STATE.TRANSPORT_CONNECTED)) {
//            Log.d("#3734", "!PANIC: incorrect state:" + connectionState);
            return;
        }

//        Log.d("#3734", ReadCurrentTransmitterDateAndTimeParsedResponse.class.getSimpleName() + ": lastReadDatetime:" + lastReadDatetime + "|now:" + currentDatetime + "|diff:" + diff);
        if (diff < 0) {
//            Log.d("#3734", "!PANIC: invalid last read time");
            return;
        }
        else {
            if (diff > 5 * GraphUtils.SECOND) { // if delay is over 5 seconds, then bail.
//                Log.d("#3734", "!PANIC: delay is over 5 seconds ->" + diff);
                return;
            }
        }

        /** When delay is within 5 seconds, continue */

        /** Get the Transmitter clock */
        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{data[1], data[2]});
        int[] time = BinaryOperations.calculateTimeFromBytes(new int[]{data[3], data[4]});
        int[] timeZoneOffsetTx = BinaryOperations.calculateTimeFromBytes(new int[]{data[5], data[6]});
        int timeZoneOffsetSignTx = data[7];
        long transmitterTime =  Utils.getGMTCalendarFrom(date, time).getTimeInMillis();
        long diffTxHHD = currentDatetime-transmitterTime;
//        Log.d("#3734", "transmitterTime: " + transmitterTime + "|diff:" + diffTxHHD + "|abs diff:" + Math.abs(diffTxHHD));

        /** save the transmitter time */
//        Log.d("#4021", "Tx time before: " + model.getTransmitterTime());
        model.setTransmitterTime(transmitterTime);
//        Log.d("#4021", "Tx time after: " + model.getTransmitterTime());

        if (!model.noCalEventInSpecificTimeRange()) {
//            Log.d("#3734", "!PANIC: there is cal in last 40 mins");
            return;
        }

        boolean needWriteDatetime = false;

        /** 1. compare time */
        if (Math.abs(diffTxHHD) > 2 * GraphUtils.MINUTE) { // if GMT time diff is more than 2 minutes
//            Log.d("#3734", "more than 2 minutes:" + diffTxHHD);
            needWriteDatetime = true;
        }

        /** 2. compare offset */
        int[] HHDTimeZoneOffset = getTimeZoneOffset();
//        Log.d("#3734", "timeZoneOffsetTx: hour->" + timeZoneOffsetTx[0] + " min->" + timeZoneOffsetTx[1]);
//        Log.d("#3734", "HHDTimeZoneOffset: hour->" + HHDTimeZoneOffset[0] + " min->" + HHDTimeZoneOffset[1]);
        if (Math.abs(timeZoneOffsetTx[0]) != Math.abs(HHDTimeZoneOffset[0])) {
//            Log.d("#3734", "Different timezone offset hour");
            needWriteDatetime = true;
        }

        if (Math.abs(timeZoneOffsetTx[1]) != Math.abs(HHDTimeZoneOffset[1])) {
//            Log.d("#3734", "Different timezone offset minute");
            needWriteDatetime = true;
        }

        /** 3. compare the offset sign */
        int HHDTimeZoneOffsetSign = getTimeZoneOffsetSign(HHDTimeZoneOffset[0]);
//        Log.d("#3734", "timeZoneOffsetSignTx: " + timeZoneOffsetSignTx + "|HHD sign:" + HHDTimeZoneOffsetSign);
        if (timeZoneOffsetSignTx != HHDTimeZoneOffsetSign) {
//            Log.d("#3734", "Different timezone offset sign");
            needWriteDatetime = true;
        }

//        Log.d("#3734", "needWriteDatetime? " + needWriteDatetime);
        if (needWriteDatetime) {
            bluetoothServiceCommandClient.postSendCurrentDateAndTimeToTransmitter();
        }
    }

    private int[] getTimeZoneOffset() { /** got from sendCurrentDateAndTimeToTransmitter() in Request.java */
        Calendar calendar = Calendar.getInstance();

        TimeZone mTimeZone = calendar.getTimeZone();

        int mUTCOffset = mTimeZone.getOffset((new Date()).getTime());
        int mGMTOffsetInMinutes = (int) TimeUnit.MINUTES.convert(mUTCOffset,
                TimeUnit.MILLISECONDS);
//        Log.d("#3734", "getTimeZoneOffset: mGMTOffsetInMinutes->" + mGMTOffsetInMinutes);

        int UTCHours = mGMTOffsetInMinutes / 60;
        int UTCMinutes = Math.abs(mGMTOffsetInMinutes) % 60;

        return new int[]{UTCHours, UTCMinutes};
    }

    private int getTimeZoneOffsetSign(int UTCHours) {
        int TimeZoneOffsetSign;
        if (UTCHours >= 0)
            TimeZoneOffsetSign = 0x00;
        else
            TimeZoneOffsetSign = 0xFF;

        return TimeZoneOffsetSign;
    }
}
