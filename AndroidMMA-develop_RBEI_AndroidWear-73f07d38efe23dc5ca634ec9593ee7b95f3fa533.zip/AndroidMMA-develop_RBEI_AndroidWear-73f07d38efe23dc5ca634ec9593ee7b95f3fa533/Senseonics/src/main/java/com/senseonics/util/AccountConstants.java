package com.senseonics.util;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Base64;

import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;
import com.senseonics.events.EventUtils;
import com.senseonics.events.ExerciseEventPoint;
import com.senseonics.events.HealthEventPoint;
import com.senseonics.events.InsulinEventPoint;
import com.senseonics.events.MealEventPoint;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.util.Glucose;
import com.senseonics.model.TransmitterStateModel;

import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;

import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class AccountConstants {
    public enum Server {
        DMS_Staging,
        DMS_Production
    }
    private final String GMT_DATETIME_INVALID = "2000-01-01T00:00:00";
    private final int FETCH_LIMIT_ALERT = 10;

    public static Server server = Server.DMS_Staging; // #2947 this value would be modified in Teamcity

    private final String DMSCreateAccount_Staging = "https://harmonystaging.eversensedms.com/Account/Register";
    private final String DMSForgotPassword_Staging = "https://harmonystaging.eversensedms.com/Account/ForgotPassword";
    private final String DMSServerURL_Staging = "https://harmonystagingservice.eversensedms.com/AgentServerHost.svc";

    private final String DMSCreateAccount_Production = "https://www.eversensedms.com/Account/Register";
    private final String DMSForgotPassword_Production = "https://www.eversensedms.com/Account/ForgotPassword";
    private final String DMSServerURL_Production = "https://harmonyservice.eversensedms.com/AgentServerHost.svc";

    public final String getUserIDByUserEmailWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/GetUserIDByUserEmail";
    public final String uploadDeviceEventsWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/UploadDeviceEvents_CareApp";
    public final String checkAndUpdatePasswordWebserviceFunctionCall = "http://tempuri.org/IAgentServerService/CheckAndUpdatePassword"; /** #3707 */

    /** #3707 */
    public final String TAG_CHECK_AND_UPDATE_PASSWORD_RESULT = "CheckAndUpdatePasswordResult";

    private final String kGetUserIDTagStart = "<GetUserIDByUserEmailResult>";
    private final String kGetUserIDTagEnd = "</GetUserIDByUserEmailResult>";
    private final String kGetUploadResultTagStart = "<b:int>";
    private final String kGetUploadResultTagEnd = "</b:int>";
    public final int kUploadResultCount = 3;
    private final String Tag = "DMS(AccountConstants)";
    public final String FORCE_LOGOUT_BUNDLE_KEY = "force_logout";

    private Context context;
    private SharedPreferences sharedPreferences;
    private UserInfoSecureStorer userInfoSecureStorer;
    private TransmitterStateModel transmitterStateModel;
    private DatabaseManager databaseManager;

    public enum MLDMSResult {
        InvalidDeviceType(-3),
        InvalidUserCredentials(-2),
        GeneralErrorSavingData(-1),
        DataSaved(0),
        Timeout(1),
        NotConnectedToWifi(2),
        ServerError(3),
        IDNotFound(4),
        None(5);

        private final int id;
        MLDMSResult(int id) {this.id = id;}
        public int getValue() {return id;}

        public static MLDMSResult fromValue(int id) {
            for (MLDMSResult err: values()) {
                if (err.getValue() == id) {
                    return err;
                }
            }
            return null;
        }
    }

    /** #3707 */
    public enum CheckAndUpdatePasswordResult {
        PwdUpdatedAndAuthenticated(1),
        NoPwdUpdateNeededAndAuthenticated(2),
        InvalidCredentials(3),
        EmailNotExist(4),
        ServerError(5);

        private final int id;
        CheckAndUpdatePasswordResult(int id) {this.id = id;}
        public int getValue() {return id;}

        public static CheckAndUpdatePasswordResult fromValue(int id) {
            for (CheckAndUpdatePasswordResult val: values()) {
                if (val.getValue() == id) {
                    return val;
                }
            }
            return ServerError;
        }
    }

    @Inject
    public AccountConstants(Context contextIn, SharedPreferences sharedPreferences, UserInfoSecureStorer userInfoSecureStorerIn, TransmitterStateModel transmitterStateModelIn, DatabaseManager databaseManagerIn) {
        this.context = contextIn;
        this.sharedPreferences = sharedPreferences;
        this.userInfoSecureStorer = userInfoSecureStorerIn;
        this.transmitterStateModel = transmitterStateModelIn;
        this.databaseManager = databaseManagerIn;
    }

    public String getAccountUsernameFromPreference() {
        return userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserName);
    }

    public String getAccountUserIDFromPreference() {
        return userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserID);
    }

    public String getAccountPasswordFromPreference() {
        return userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserPassword);
    }

    /** #3707 */
    public void setMigrationPasswordUpdated(boolean newValue) {
        Utils.saveSettings(context, Utils.prefAccountMigrationPasswordUpdated, newValue);
    }

    public boolean getMigrationPasswordUpdated() {
        return Utils.getSettingsBoolean(context, Utils.prefAccountMigrationPasswordUpdated);
    }

    public void resetLastSyncedOnInPreference() {
        Utils.saveSettings(context, Utils.prefAccountLastSyncedOnDateTime, 0L);
    }

    public void setCurrentDateTimeToLastSyncedOnInPreference() {
        long timeInMillis = Calendar.getInstance().getTimeInMillis();
        Utils.saveSettings(context, Utils.prefAccountLastSyncedOnDateTime, timeInMillis);
    }

    public long getLastSyncedOnDateTimeFromPreference() {
        long timeInMills = Utils.getSettingsForLong(context, Utils.prefAccountLastSyncedOnDateTime);
        return timeInMills;
    }

    public void resetLastSyncedStartInPreference() {
        Utils.saveSettings(context, Utils.prefAccountLastSyncedStartDateTime, 0L);
    }

    public void setCurrentDateTimeToLastSyncedStartInPreference() {
        long timeInMillis = Calendar.getInstance().getTimeInMillis();
        Utils.saveSettings(context, Utils.prefAccountLastSyncedStartDateTime, timeInMillis);
    }

    public long getLastSyncedStartDateTimeFromPreference() {
        long timeInMills = Utils.getSettingsForLong(context, Utils.prefAccountLastSyncedStartDateTime);
        return timeInMills;
    }

    public void resetDiagnosticDataLastSyncedOnInPreference() {
        Utils.saveSettings(context, Utils.prefAccountDiagnosticDataLastSyncedOnDateTime, 0L);
    }

    public void setCurrentDateTimeToDiagnosticDataLastSyncedOnInPreference() {
        long timeInMillis = Calendar.getInstance().getTimeInMillis();
        Utils.saveSettings(context, Utils.prefAccountDiagnosticDataLastSyncedOnDateTime, timeInMillis);
    }

    public long getDiagnosticDataLastSyncedOnDateTimeFromPreference() {
        long timeInMills = Utils.getSettingsForLong(context, Utils.prefAccountDiagnosticDataLastSyncedOnDateTime);
        return timeInMills;
    }

    public int getGlucoseUnit() {
        int unit = sharedPreferences.getInt(Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal());
        return unit;
    }

    public String getLastSyncedOnDateTimeStringFromPreference() {
        long timeInMills = getLastSyncedOnDateTimeFromPreference();
        if (timeInMills == 0L) {
            return Utils.unknownString;
        }
        else {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(timeInMills);
            String dateString = Utils.formatDate(cal, TimeZone.getDefault(), context);
            return dateString;
        }
    }

    public int getSyncDaysFromPreference() {
        return Utils.getSettingsForDefault(context, Utils.prefAccountSyncDays, Utils.DEFAULT_SYNC_DAYS);
    }

    public boolean getAccountEnableAutoSync() {
        setDefaultEnableAutoSyncIfNotExist();
        return Utils.getSettingsBoolean(context, Utils.prefAccountEnableAutoSync);
    }

    public void initAccountSecurePreference() {
        if (!userInfoSecureStorer.contains(Utils.prefAccountUserName)) {
            userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserName, "");
        }

        if (!userInfoSecureStorer.contains(Utils.prefAccountUserID)) {
            userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserID, "");
        }

        if (!userInfoSecureStorer.contains(Utils.prefAccountUserPassword)) {
            userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserPassword, "");
        }
    }

    public void initAccountPreferences() {
        if (!sharedPreferences.contains(Utils.prefAccountSyncDays)) {
            Utils.saveSettings(context, Utils.prefAccountSyncDays, Utils.DEFAULT_SYNC_DAYS);
        }

        if (!sharedPreferences.contains(Utils.prefAccountLastSyncedOnDateTime)) {
            Utils.saveSettings(context, Utils.prefAccountLastSyncedOnDateTime, 0L);
        }

        if (!sharedPreferences.contains(Utils.prefAccountLastSyncedStartDateTime)) {
            Utils.saveSettings(context, Utils.prefAccountLastSyncedStartDateTime, 0L);
        }

        if (!sharedPreferences.contains(Utils.prefAccountDiagnosticDataLastSyncedOnDateTime)) {
            Utils.saveSettings(context, Utils.prefAccountDiagnosticDataLastSyncedOnDateTime, 0L);
        }

        if (!sharedPreferences.contains(Utils.prefAccountSyncInterval)) {
            Utils.saveSettings(context, Utils.prefAccountSyncInterval, "30 Mins");
        }

        setDefaultLoggedInIfNotExist();
        setDefaultEnableAutoSyncIfNotExist();
    }

    public void setDefaultLoggedIn() {
        Utils.saveSettings(context, Utils.prefAccountIsLoggedIn, false);
    }

    public void setDefaultLoggedInIfNotExist() {
        if (!sharedPreferences.contains(Utils.prefAccountIsLoggedIn)) {
            setDefaultLoggedIn();
        }
    }

    private void setDefaultEnableAutoSync() {
        Utils.saveSettings(context, Utils.prefAccountEnableAutoSync, true); // #2511 Auto sync default is enabled
    }

    public void setDefaultEnableAutoSyncIfNotExist() {
        if (!sharedPreferences.contains(Utils.prefAccountEnableAutoSync)) {
            setDefaultEnableAutoSync();
        }
    }

    public String getCoveredUserName(String userName) {
        int charCount = userName.length();
        int bound = 4;
        String displayString = null;
        String asterisk = "*****";

        if (charCount > bound) {
            displayString = userName.substring(0, bound);
            displayString = displayString.concat(asterisk);
        }
        else if((charCount <= bound) && (charCount >=3)) {
            displayString = userName.substring(0, 2);
            displayString = displayString.concat(asterisk);
        }
        else if((charCount <= 2) && (charCount >=1 )) {
            displayString = userName.concat(asterisk);
        }
        else {
            displayString = "";
        }

        return displayString;
    }

    private boolean checkIfVersionChanged(String keyInPreference) {
        boolean isChanged = false;

        String currentVersion = null;
        String versionOfLastRun = Utils.getSettingsForString(context, keyInPreference);

        if (context != null) {
            try {
                currentVersion = context.getPackageManager().getPackageInfo(
                        context.getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException e) {
                currentVersion = null;
                e.printStackTrace();
            }

            if (currentVersion == null) {
                isChanged = true;
            }
            else {
                if (versionOfLastRun.equals("")) {
                    isChanged = true;
                } else if (!versionOfLastRun.equals(currentVersion)) {
                    isChanged = true;
                }

                Utils.saveSettings(context, keyInPreference, currentVersion);
            }
        }
        else {
            isChanged = true;
        }

        if (isChanged == true) {
            /** #3628 */
            Answers.getInstance().logCustom(new CustomEvent("Logout")
                    .putCustomAttribute("Reason", "V Change"));
        }

        return isChanged;
    }

    // this function would be called in Splash Screen
    public void presetLoggedInAndEnableAutoSync() {
        // Set default values if they are not in preference
        setDefaultLoggedInIfNotExist();
        setDefaultEnableAutoSyncIfNotExist();

        /** #3628 */
        if(checkIfVersionChanged("VersionOfLastRun")) {
            setDefaultEnableAutoSync();
        }
        else if(!HasValidAccountInfo()) {
            /** #3628 */
            Answers.getInstance().logCustom(new CustomEvent("Logout")
                    .putCustomAttribute("Reason", "No Valid Account Info"));
        }
    }

    private boolean checkIfValidString(String info) {
        if((info == null) || (info.equals(""))) {
            return false;
        }

        return true;
    }

    public boolean HasValidAccountInfo() {
        if(!checkIfValidString(userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserName))
            || !checkIfValidString(userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserID))
            || !checkIfValidString(userInfoSecureStorer.getSecureSettingsForString(Utils.prefAccountUserPassword)) )
        {
            return false;
        }

        return true;
    }

    public void OpenCreateAccountURL(Context ctx) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(getDMSCreateAccount()));
        try {
            ctx.startActivity(i);
        }
        catch (ActivityNotFoundException e) {
            Utils.makeAlwaysShownToast(ctx, ctx.getResources().getString(R.string.no_browser_found_2));
        }
    }

    public void OpenForgotPasswordURL(Context ctx) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(getDMSForgotPassword()));
        try {
            ctx.startActivity(i);
        }
        catch (ActivityNotFoundException e) {
            Utils.makeAlwaysShownToast(ctx, ctx.getResources().getString(R.string.no_browser_found_2));
        }
    }

    private int[] getDateArrayFromGMTTimeStamp(long recordTimeStamp) {
        Calendar calendar = Calendar.getInstance();

        calendar.setTimeInMillis(recordTimeStamp);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        int[] DateGMT = BinaryOperations.calculateDateBytes(year, month, day);

        return DateGMT;
    }

    private int[] getTimeArrayFromGMTTimeStamp(long recordTimeStamp) {
        Calendar calendar = Calendar.getInstance();

        calendar.setTimeInMillis(recordTimeStamp);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        int s = calendar.get(Calendar.SECOND);

        int[] TimeGMT = BinaryOperations.calculateTimeBytes(h, m, s);

        return TimeGMT;
    }

    private String getBase64SensorData(int hoursBack, String sensorID) {
        // get all sensor glucose data
        Calendar calendarStart = Calendar.getInstance();
        calendarStart.add(Calendar.HOUR_OF_DAY, -hoursBack);
        ArrayList<Glucose> sensorLogs = databaseManager.getSensorLogsStartingFrom(calendarStart, Calendar.getInstance());

        // convert to bytes
        String headArr = new String();
        headArr += "8C";
        headArr += "00"; // unit
        headArr += "010000"; // start record number -> set to 1
        int[] lastRecord = BinaryOperations.data24BitsFromIntLSByteFirst(sensorLogs.size());
        headArr += IntArrayToHexString(lastRecord);
        //Log.d(Tag,"headArr:" + headArr);

        for (int i = 0; i < sensorLogs.size(); i++) {
            Glucose thisRecord = sensorLogs.get(i);

            // Get the values
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            int glucoseValue = thisRecord.getGlucoseLevel();
            int recordNumber = thisRecord.getRecordNumber();

//            Log.d(Tag, "Time:" + recordGMTTimeStamp + "|Glucose:" + glucoseValue
//                    + "|record#:" + recordNumber);

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);

//            Log.d(Tag, "Date:" + DateGMT[0] +" " + DateGMT[1] + "|Time:"+TimeGMT[0]+" " + TimeGMT[1]);

            // Add record number : 3 bytes
            headArr += IntArrayToHexString(BinaryOperations.data24BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            // Add Glucose value : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(glucoseValue));

            // Add Flag: 1 byte
            headArr += "00";

            // Add Sensor ID: 4 bytes
            headArr += IntArrayToHexString(BinaryOperations.data32BitsFromIntLSByteFirst(Integer.parseInt(sensorID)));

            /** #3194 */
            int raw1 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1); // Temperature
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(raw1));

            int raw2 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2); // Signal On
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(raw2));

            int raw3 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3); // Ref On
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(raw3));

//            int raw4 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4); // LED Voltage -> Not used
//            int raw5 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5); // Field Current -> Not used
//            int raw6 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6); // Diagnostic -> Not used

            int raw7 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7); // Signal Off
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(raw7));

            int raw8 = thisRecord.getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8); // Ref Off
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(raw8));

            // rest: 3 bytes
            headArr += "000000";
        }

//        Log.d(Tag,"headArr:" + headArr);

        // convert to base64
        byte[] headByteArr = BinaryOperations.hexStringToByteArray(headArr);

        String base64String = new String(Base64.encode(headByteArr, Base64.DEFAULT));

//        Log.d(Tag, "base64String:" + base64String);

        return base64String;
    }

    private ArrayList<EventPoint> getAllEvents(int hoursBack) {
        Calendar calendarStart = Calendar.getInstance();
        calendarStart.add(Calendar.HOUR_OF_DAY, -hoursBack);

        ArrayList<EventPoint> allLogs = databaseManager.getAllDMSEventPointsStartingFrom(calendarStart);

//		for(EventPoint ep : allLogs){
//			Utils.printLongLog(Tag, ep.toString());
//		}

        return allLogs;
    }

    private String getBase64BGMData(ArrayList<EventPoint> allLogs){
        // get all calibration and manual glucose events
        ArrayList<EventPoint> BloodGlucoseEventLogs = new ArrayList<EventPoint>();

        for(EventPoint ep : allLogs){
            Utils.EVENT_TYPE eType = ep.getEventType();
            if((eType == Utils.EVENT_TYPE.CALIBRATION) || (eType == Utils.EVENT_TYPE.GLUCOSE_EVENT)) {
                // only add synced and NO Hidden events
                boolean syncedIn = ep.isEventSynced();
                boolean hiddenIn = ep.isEventHidden();

                if(syncedIn && !hiddenIn) {
                    BloodGlucoseEventLogs.add(ep);
                }
            }
        }

//        for(EventPoint ep : BloodGlucoseEventLogs){
//            Utils.printLongLog(Tag, ep.toString());
//        }

        // convert to bytes
        String headArr = new String();
        headArr += "98";
        headArr += "0100"; // start record number -> set to 1
        int[] lastRecord = BinaryOperations.data16BitsFromIntLSByteFirst(BloodGlucoseEventLogs.size());
        headArr += IntArrayToHexString(lastRecord);
        headArr += "00"; // unit

//        Log.d(Tag,"headArr:" + headArr);

        for (int i = 0; i < BloodGlucoseEventLogs.size(); i++) {
            EventPoint thisRecord = BloodGlucoseEventLogs.get(i);

            // Get the values
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            int glucoseValue = thisRecord.getGlucoseLevel();
            int recordNumber = i+1; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless
            int useFlag = thisRecord.getCustomField();

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);

//            Log.d(Tag, "Date:" + DateGMT[0] +" " + DateGMT[1] + "|Time:"+TimeGMT[0]+" " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            // Add Glucose value : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(glucoseValue));

            // Meter id: 2 bytes
            headArr += "0000";

            // Add Flag: 1 byte
            headArr += IntArrayToHexString(new int[]{useFlag});

            // record number of the closest past glucose reading
            headArr += "000000";

        }
//        Log.d(Tag,"headArr:" + headArr);

        // convert to base64
        byte[] headByteArr = BinaryOperations.hexStringToByteArray(headArr);

        String base64String = new String(Base64.encode(headByteArr, Base64.DEFAULT));

//        Log.d(Tag, "base64String:" + base64String);

        return base64String;
    }

    private String getBase64MealEventLogData(ArrayList<EventPoint> eventPoints, int recordNo){
        // convert to bytes
        String headArr = new String();
        for (int i = 0; i < eventPoints.size(); i++) {
            EventPoint thisRecord = eventPoints.get(i);
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            EventUtils.MEAL_TYPE strMealType = ((MealEventPoint) thisRecord).getMealType();

            int mealID = strMealType.ordinal();
            int carbs = ((MealEventPoint) thisRecord).getCarbs();
            int recordNumber = recordNo ++; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);

//            Log.d(Tag, "Date:" + DateGMT[0] + " " + DateGMT[1] + "|Time:" + TimeGMT[0] + " " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            //Patient Event Type - Meal 2

            headArr += IntArrayToHexString(new int[]{2});

            //Patient Event Subtype Identifier

            headArr += IntArrayToHexString((BinaryOperations.data16BitsFromIntLSByteFirst(mealID)));

            //Patient Event Subtype Quantity

            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(carbs));

            // Patient Event Free Text: 1 bytes
            headArr += "00";
        }

//        Log.d(Tag,"headArr Patient:" + headArr);

        return headArr;
    }

    private String getBase64InsulinEventLogData(ArrayList<EventPoint> eventPoints, int recordNo){
        // convert to bytes
        String headArr = new String();
        for (int i = 0; i < eventPoints.size(); i++) {
            EventPoint thisRecord = eventPoints.get(i);
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            EventUtils.INSULIN_TYPE insulinType = ((InsulinEventPoint) thisRecord).getInsulinType();

            int insulinID = insulinType.ordinal();
            int units = (int)(((InsulinEventPoint) thisRecord).getUnits()*10);
            int recordNumber = recordNo ++; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);
//            Log.d(Tag, "Date:" + DateGMT[0] + " " + DateGMT[1] + "|Time:" + TimeGMT[0] + " " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            //Patient Event Type - Insulin 1

            headArr += IntArrayToHexString(new int[]{1});

            //Patient Event Subtype Identifier

            headArr += IntArrayToHexString((BinaryOperations.data16BitsFromIntLSByteFirst(insulinID)));

            //Patient Event Subtype Quantity

            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(units));

            // Patient Event Free Text: 1 bytes
            headArr += "00";
        }

//        Log.d(Tag,"headArr Patient:" + headArr);

        return headArr;
    }

    private String getBase64HealthEventLogData(ArrayList<EventPoint> eventPoints, int recordNo) {
        // convert to bytes
        String headArr = new String();
        for (int i = 0; i < eventPoints.size(); i++) {
            EventPoint thisRecord = eventPoints.get(i);
            long recordGMTTimeStamp = thisRecord.getTimestamp();

            EventUtils.HEALTH_CONDITION healthType = ((HealthEventPoint) thisRecord).getHealthCondition();

            int healthTypeID = healthType.ordinal();
            EventUtils.HEALTH_SEVERITY healthSeverity = ((HealthEventPoint) thisRecord).getHealthSeverity();
            int healthSeverityID = healthSeverity.getSubType();
            int recordNumber = recordNo ++; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);
//            Log.d(Tag, "Date:" + DateGMT[0] + " " + DateGMT[1] + "|Time:" + TimeGMT[0] + " " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            //Patient Event Type - Health 8

            headArr += IntArrayToHexString(new int[]{8});

            //Patient Event Subtype Identifier

            headArr += IntArrayToHexString((BinaryOperations.data16BitsFromIntLSByteFirst(healthTypeID)));

            //Patient Event Subtype Quantity

            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(healthSeverityID));

            // Patient Event Free Text: 1 bytes
            headArr += "00";
        }
        return headArr;
    }

    private String getBase64ExerciseEventLogData(ArrayList<EventPoint> eventPoints, int recordNo){
        // convert to bytes
        String headArr = new String();
        for (int i = 0; i < eventPoints.size(); i++) {
            EventPoint thisRecord = eventPoints.get(i);
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            EventUtils.EXERCISE_INTENSITY exerciseIntensityType = ((ExerciseEventPoint)thisRecord).getIntensity();

            int exerciseTypeID = exerciseIntensityType.getSubType();
            int duration = (int)((ExerciseEventPoint) thisRecord).getDuration();
            int recordNumber = recordNo ++; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);
//            Log.d(Tag, "Date:" + DateGMT[0] + " " + DateGMT[1] + "|Time:" + TimeGMT[0] + " " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            //Patient Event Type - Exercise Event 4

            headArr += IntArrayToHexString(new int[]{4});

            //Patient Event Subtype Identifier

            headArr += IntArrayToHexString((BinaryOperations.data16BitsFromIntLSByteFirst(exerciseTypeID)));

            //Patient Event Subtype Quantity

            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(duration));

            // Patient Event Free Text: 1 bytes
            headArr += "00";
        }
        return headArr;
    }

    private String getBase64PatientEventData(int hoursBack) {
        // get all calibration and manual glucose events
        Calendar calendarStart = Calendar.getInstance();
        calendarStart.add(Calendar.HOUR_OF_DAY, -hoursBack);
        ArrayList<EventPoint> eventsLog = databaseManager
                .getEventsBetween(calendarStart, Calendar.getInstance(), 40, 400);

        ArrayList<EventPoint> mealEventLog = new ArrayList<EventPoint>();
        ArrayList<EventPoint> insulinEventLog = new ArrayList<EventPoint>();
        ArrayList<EventPoint> healthEventLog = new ArrayList<EventPoint>();
        ArrayList<EventPoint> exerciseEventLog = new ArrayList<EventPoint>();

        if(eventsLog != null) {
            for (int i = 0; i < eventsLog.size(); i++) {
                EventPoint thisRecord = eventsLog.get(i);
                switch (thisRecord.getEventType()) {

                    case MEAL_EVENT:
                        mealEventLog.add(thisRecord);
                        break;
                    case INSULIN_EVENT:
                        insulinEventLog.add(thisRecord);
                        break;
                    case HEALTH_EVENT:
                        healthEventLog.add(thisRecord);
                        break;
                    case EXERCISE_EVENT:
                        exerciseEventLog.add(thisRecord);
                        break;
                }
            }
        }

        String headArr = new String();
        headArr += "9E";
        headArr += "0100"; // start record number -> set to 1

        int mealEventSize = mealEventLog.size();
        int insulinEventSize = insulinEventLog.size();
        int healthEventSize = healthEventLog.size();
        int exerciseEventSize = exerciseEventLog.size();

        int[] lastRecord = BinaryOperations.data16BitsFromIntLSByteFirst(
                mealEventSize+
                insulinEventSize+
                healthEventSize+
                exerciseEventSize);
        headArr += IntArrayToHexString(lastRecord);

        String eventsString  = headArr;
        int recordStartIdx = 1;
        eventsString += getBase64MealEventLogData(mealEventLog, recordStartIdx);

        recordStartIdx += mealEventSize;
        eventsString += getBase64InsulinEventLogData(insulinEventLog, recordStartIdx);

        recordStartIdx += insulinEventSize;
        eventsString += getBase64HealthEventLogData(healthEventLog, recordStartIdx);

        recordStartIdx += healthEventSize;
        eventsString += getBase64ExerciseEventLogData(exerciseEventLog, recordStartIdx);

        byte[] headByteArr = BinaryOperations.hexStringToByteArray(eventsString);
        String base64String = new String(Base64.encode(headByteArr, Base64.DEFAULT));
        return base64String;
    }

    private String getGlucoseAlertsData(ArrayList<EventPoint> allLogs, String sensorId){
        // get all glucose alerts and alarms
        ArrayList<EventPoint> glucoseAlertEventLogs = new ArrayList<EventPoint>();

        for(EventPoint ep : allLogs){
            Utils.EVENT_TYPE eType = ep.getEventType();
            int customField = ep.getCustomField();
            int customField2 = ep.getCustomField2();
            int unknownErrorCode = ep.getUnknownErrorCode();

            int alertId = Utils.getSensorGlucoseAlertRecordTypeID(eType, customField, customField2, unknownErrorCode);
            if(alertId != -1) {
                // only add synced and NO Hidden events
                boolean syncedIn = ep.isEventSynced();
                boolean hiddenIn = ep.isEventHidden();

                if(syncedIn && !hiddenIn) {
                    glucoseAlertEventLogs.add(ep);
                }
            }
        }

        // convert to bytes
        String headArr = new String();
        headArr += "93";
        headArr += "0100"; // start record number -> set to 1
        int[] lastRecord = BinaryOperations.data16BitsFromIntLSByteFirst(glucoseAlertEventLogs.size());
        headArr += IntArrayToHexString(lastRecord);
        headArr += IntArrayToHexString(BinaryOperations.data32BitsFromIntLSByteFirst(Integer.parseInt(sensorId))); // Add Sensor ID: 4 bytes
        headArr += "00"; // unit

//        Log.d(Tag,"headArr:" + headArr);

        for (int i = 0; i < glucoseAlertEventLogs.size(); i++) {
            EventPoint thisRecord = glucoseAlertEventLogs.get(i);

            // Get the values
            long recordGMTTimeStamp = thisRecord.getTimestamp();
            int glucoseValue = thisRecord.getGlucoseLevel();
            int recordNumber = i+1; //thisRecord.getHighestExpectedRecordNumber();-> currently all = -1, like useless
            Utils.EVENT_TYPE eType = thisRecord.getEventType();
            int customField = thisRecord.getCustomField();
            int customField2 = thisRecord.getCustomField2();
            int unknownErrorCode = thisRecord.getUnknownErrorCode();
            int alertId = Utils.getSensorGlucoseAlertRecordTypeID(eType, customField, customField2, unknownErrorCode);

            int[] DateGMT = getDateArrayFromGMTTimeStamp(recordGMTTimeStamp);
            int[] TimeGMT = getTimeArrayFromGMTTimeStamp(recordGMTTimeStamp);
//            Log.d(Tag, "Date:" + DateGMT[0] +" " + DateGMT[1] + "|Time:"+TimeGMT[0]+" " + TimeGMT[1]);

            // Add record number : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(recordNumber));

            // Add date and time : 4 bytes
            headArr += IntArrayToHexString(DateGMT);
            headArr += IntArrayToHexString(TimeGMT);

            // Add alert log type : 1 byte
            headArr += IntArrayToHexString(new int[]{alertId});

            // Add Glucose value : 2 bytes
            headArr += IntArrayToHexString(BinaryOperations.data16BitsFromIntLSByteFirst(glucoseValue));

            // Add trend value : 2 bytes
            headArr += "0000";

            // Add thresholdOrInterval : 2 bytes
            headArr += "0000";
        }
//        Log.d(Tag,"headArr:" + headArr);

        // convert to base64
        byte[] headByteArr = BinaryOperations.hexStringToByteArray(headArr);

        String base64String = new String(Base64.encode(headByteArr, Base64.DEFAULT));

//        Log.d(Tag, "base64String:" + base64String);

        return base64String;
    }

    private String IntArrayToHexString(int[] intArr) {
        String output = "";

        for(int i : intArr) {
            output += IntToHexString(i);
        }

        return output;
    }

    private String IntToHexString(int value) {
        return String.format("%02x", (0xFF & value)).toUpperCase(Locale.ENGLISH);
    }

    private String base64EncodingForTimeZoneOffsetInSeconds() {

        Calendar calendar = Calendar.getInstance();
        TimeZone mTimeZone = calendar.getTimeZone();
        Date now = new Date();
        int mGMTOffsetInSec = mTimeZone.getOffset(now.getTime()) / 1000;

//        Log.d(Tag, "mGMTOffsetInSec:"+mGMTOffsetInSec);

        int[] offsetInSecArr = BinaryOperations.data32BitsFromIntLSByteFirst(mGMTOffsetInSec);
        String offsetInSecString = IntArrayToHexString(offsetInSecArr);
//        Log.d(Tag, "offsetInSecString:"+offsetInSecString);

        // convert to base64
        byte[] headByteArr = BinaryOperations.hexStringToByteArray(offsetInSecString);

        String base64String = new String(Base64.encode(headByteArr, Base64.DEFAULT));

//        Log.d(Tag, "base64String:"+base64String);

        return base64String;
    }

    /** #3707 */
    public String generateCheckAndUpdatePassword(String userEmail, String pwdHash, String pwdBinary) {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope \n"
                + "xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction</wsa:Action>"
                + "<wsa:To>%wsaTo</wsa:To>"
                + "</soap:Header>"
                + "<soap:Body>\n"
                + "<tem:CheckAndUpdatePassword>\n"
                + "<tem:Email>%userEmail</tem:Email>\n"
                + "<tem:PasswordHash>%pwdHash</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary</tem:PasswordBinary>\n"
                + "</tem:CheckAndUpdatePassword>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction", checkAndUpdatePasswordWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo", getDMSServerURL());
        requestString = requestString.replace("%userEmail", String.valueOf(userEmail));
        requestString = requestString.replace("%pwdHash", String.valueOf(pwdHash));
        requestString = requestString.replace("%pwdBinary", String.valueOf(pwdBinary));

//        Log.d(Tag, "Request String:" + requestString);

        return requestString;
    }

    public String generateGetUserIDByEmailRequestString(String userName)
    {
        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">"
                + "<wsa:Action>%wsaAction</wsa:Action>"
                + "<wsa:To>%wsaTo</wsa:To>"
                + "</soap:Header>\n"
                + "<soap:Body>\n"
                + "<tem:GetUserIDByUserEmail>\n"
                + "<tem:userEmail>%userEmail</tem:userEmail>\n"
                + "</tem:GetUserIDByUserEmail>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        requestString = requestString.replace("%wsaAction", getUserIDByUserEmailWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo", getDMSServerURL());

        requestString = requestString
                .replace("%userEmail", String.valueOf(userName));

//        Log.d(Tag, "Request String:" + requestString);

        return requestString;
    }

    public String getUserIDFromResponse(String webDataString)
    {
//        Log.d(Tag, webDataString);
        String uid = null;

        int startIndex = webDataString.indexOf(kGetUserIDTagStart);
        int endIndex = webDataString.indexOf(kGetUserIDTagEnd);

        if(startIndex != -1 && endIndex != -1)
        {
            uid = webDataString.substring(startIndex+kGetUserIDTagStart.length(), endIndex);
        }
        else
        {
            uid = "N/A";
        }

//        Log.d(Tag, "uid:"+uid);

        return uid;
    }

    public String prepareRequestStringForUploadingData(int hoursBack) {
        String requestStringForUploadData = null;

        String userID = getAccountUserIDFromPreference();
        String password = getAccountPasswordFromPreference();
        String pwdHash = generateBase64RFC2898(password);
        String pwdBinary = stringToBase64Data(password);

        if (pwdHash != null && !pwdHash.matches("") && pwdBinary != null && !pwdBinary.matches("")) {
            requestStringForUploadData = generateUploadDeviceDataRequestString(
                    userID,
                    pwdHash,
                    pwdBinary,
                    fetchTxSerialNoFromModel(),
                    hoursBack,
                    fetchSensorIDFromModel(),
                    false
            );
        }

        return requestStringForUploadData;
    }

    public String prepareRequestStringForUploadingLoginData(String password, String userID) {
        String requestStringForUploadData = null;

        String pwdHash = generateBase64RFC2898(password);
        String pwdBinary = stringToBase64Data(password);

        if (pwdHash != null && !pwdHash.matches("") && pwdBinary != null && !pwdBinary.matches("")) {
            requestStringForUploadData = generateUploadDeviceDataRequestString(
                    userID,
                    pwdHash,
                    pwdBinary,
                    fetchTxSerialNoFromModel(),
                    0,
                    fetchSensorIDFromModel(),
                    true
            );
        }

        return requestStringForUploadData;
    }

    public String generateUploadDeviceDataRequestString(String userID,
                                                               String pwdHash,
                                                               String pwdBinary,
                                                               String txSerialNo,
                                                               int hoursBack,
                                                               String sensorId,
                                                               boolean emptyData) {
//        Log.d(Tag, "generateUploadDeviceDataRequestString:" + Thread.currentThread());

        String base64Sensor, base64BGM, base64PatientEvents, base64Alert;

        if (emptyData == false) {
            // Get Sensor Glucose Data
            base64Sensor = getBase64SensorData(hoursBack, sensorId);

            // Get Manual Glucose Data
            ArrayList<EventPoint> allLogs = getAllEvents(hoursBack);
            base64BGM = getBase64BGMData(allLogs);

            // Get Patient Events
            base64PatientEvents = getBase64PatientEventData(hoursBack);

            // Get Alerts and Alarms
            base64Alert = getGlucoseAlertsData(allLogs, sensorId);
        }
        else {
            base64Sensor = "jAABAAAAAAA=";
            base64BGM = "mAEAAAAA";
            base64PatientEvents = "ngEAAAA=";
            base64Alert = "kwEAAAAAAAAAAA==";
        }

        String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
                + "<soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">\n"
                + "<wsa:Action>%wsaAction</wsa:Action>\n"
                + "<wsa:To>%wsaTo</wsa:To>\n"
                + "</soap:Header>\n"

                + "<soap:Body>\n"

                + "<tem:UploadDeviceEvents_CareApp>\n"

                + "<tem:userID>%userID</tem:userID>\n"
                + "<tem:PasswordHash>%pwdHash</tem:PasswordHash>\n"
                + "<tem:PasswordBinary>%pwdBinary</tem:PasswordBinary>\n"
                + "<tem:deviceType>%devicetype</tem:deviceType>\n"
                + "<tem:deviceName>%devicename</tem:deviceName>\n"
                + "<tem:deviceID>%deviceID</tem:deviceID>\n"
                + "<tem:data xmlns:b=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
                + "<b:base64Binary>%timezoneoffset</b:base64Binary>\n"// Timezone offset in seconds
                + "<b:base64Binary>%sensorglucose</b:base64Binary>\n" // Sensor Glucose: 0x0C
                + "<b:base64Binary>%manualglucose</b:base64Binary>\n" // Manual Glucose: 0x18
                + "<b:base64Binary>%patientevents</b:base64Binary>\n" // Patient Events: 0x1E
                + "<b:base64Binary>%alertalarm</b:base64Binary>\n" // Alerts/Alarms:  0x13

                + "</tem:data>\n"
                + "</tem:UploadDeviceEvents_CareApp>\n"
                + "</soap:Body>\n"
                + "</soap:Envelope>\n";

        //, self.userID, [pwdSHA1 uppercaseString], @"SMSIMeter", @"Senseonics Transmitter",
        //self.stateCopy.transmitterID, [self base64EncodingForTimeZoneOffsetInSeconds],
        //sensorBase64, bgmBase64, alertBase64];

        requestString = requestString.replace("%wsaAction", uploadDeviceEventsWebserviceFunctionCall);
        requestString = requestString.replace("%wsaTo", getDMSServerURL());

        requestString = requestString.replace("%userID", userID);
        requestString = requestString.replace("%pwdHash", pwdHash);
        requestString = requestString.replace("%pwdBinary", pwdBinary);
        requestString = requestString.replace("%devicetype", "SMSIMeter");
        requestString = requestString.replace("%devicename", "Smart Transmitter (Android)");

        if (emptyData == false) {
            requestString = requestString.replace("%deviceID", txSerialNo);
        }
        else {
            requestString = requestString.replace("%deviceID", "");
        }

        requestString = requestString.replace("%timezoneoffset", base64EncodingForTimeZoneOffsetInSeconds());
        requestString = requestString.replace("%sensorglucose", base64Sensor);
        requestString = requestString.replace("%manualglucose", base64BGM);
        requestString = requestString.replace("%patientevents", base64PatientEvents);
        requestString = requestString.replace("%alertalarm", base64Alert);

        /*Utils.printLongLog(Tag, "Request String:" + requestString);*/

        return requestString;
    }

    public ArrayList<String> getUploadResultFromResponse(String webDataString)
    {
        ArrayList<String> resultArr = new ArrayList<String>();
        int startIndex = 0;
        int endIndex = 0;

        for(int i = 0; i<kUploadResultCount; i++){
            startIndex = webDataString.indexOf(kGetUploadResultTagStart);
            endIndex = webDataString.indexOf(kGetUploadResultTagEnd);

            if(startIndex != -1 && endIndex != -1)
            {
                String result_single = webDataString.substring(startIndex+kGetUploadResultTagStart.length(), endIndex);

                resultArr.add(result_single);

                // cut the webdatastring
                webDataString = webDataString.substring(startIndex+kGetUploadResultTagStart.length()+kGetUploadResultTagEnd.length());
            }
            else
            {
                resultArr = null;
                break;
            }
        }

        return resultArr;
    }

    public HttpPost formHttpPost(String url, String action, StringEntity entity) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type", "application/soap+xml; charset=utf-8");
        httpPost.setHeader("SOAPAction", action);
        httpPost.setEntity(entity);

        return httpPost;
    }

    public HttpClient createHttpClient(SSLSocketFactory sf) {
        HttpParams httpParameters = new BasicHttpParams();
        HttpConnectionParams
                .setConnectionTimeout(httpParameters, 20000);
        HttpConnectionParams.setSoTimeout(httpParameters, 20000);
        HttpProtocolParams.setHttpElementCharset(httpParameters,
                HTTP.UTF_8);
        HttpProtocolParams.setVersion(httpParameters, HttpVersion.HTTP_1_1);

        sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        SchemeRegistry registry = new SchemeRegistry();
        registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        registry.register(new Scheme("https", sf, 443));

        ClientConnectionManager ccm = new ThreadSafeClientConnManager(httpParameters, registry);

        HttpClient client = new DefaultHttpClient(ccm, httpParameters);

        return client;
    }

    public String stringToBase64Data(String stringIn) {
        String retValue = Base64.encodeToString(stringIn.getBytes(), Base64.DEFAULT);
//        Log.d(Tag,"stringToBase64Data:" + stringIn + "->" + retValue);
        return retValue;
    }

    private byte[] generateSalt(int length) {
        byte[] salt = new byte[length];
        Random random = new SecureRandom();
        random.nextBytes(salt);
        return salt;
    }

    public String generateBase64RFC2898(String passwordString) {
        final int SALT_LENGTH = 16;
        final int KEY_LEN = 32;
        final int ROUND = 1000;

        char[] password = passwordString.toCharArray();
        byte[] salt = this.generateSalt(SALT_LENGTH);

        PBEKeySpec pbeKeySpec = new PBEKeySpec(password, salt, ROUND, KEY_LEN * 8);
        Arrays.fill(password, Character.MIN_VALUE);

        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            Key secretKey = factory.generateSecret(pbeKeySpec);

            byte[] keyData = new byte[KEY_LEN];
            System.arraycopy(secretKey.getEncoded(), 0, keyData, 0, KEY_LEN);

            byte[] data = new byte[1 + salt.length + keyData.length];
            data[0] = 0x00;
            System.arraycopy(salt, 0, data, 1, salt.length);
            System.arraycopy(keyData, 0, data, 1 + salt.length, keyData.length);

            String base64Data = Base64.encodeToString(data, Base64.DEFAULT);
            return base64Data;
        }
        catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            return null;
        } finally {
            pbeKeySpec.clearPassword();
        }
    }

    public String fetchTxSerialNoFromModel() {
        String retVal = "";

        if (transmitterStateModel == null) {
            retVal = "";
        }
        else {
            retVal = transmitterStateModel.getTransmitterSerialNumber();
            if(retVal == null) {
                retVal = "";
            }
        }

//        Log.d(Tag, "Tx serial #:" + retVal);
        return retVal;
    }

    public String fetchSensorIDFromModel() {
        String retVal = "0";

        if (transmitterStateModel == null) {
            retVal = "0";
        }
        else {
            retVal = transmitterStateModel.getLinkedSensorId();
            if(retVal == null) {
                retVal = "0";
            }
        }

//        Log.d(Tag, "Sensor ID:" + retVal);
        return retVal;
    }

    public String getDMSCreateAccount() {
        String retValue = DMSCreateAccount_Staging;

        switch (server) {
            case DMS_Staging:
                retValue = DMSCreateAccount_Staging;
                break;
            case DMS_Production:
                retValue = DMSCreateAccount_Production;
                break;
            default:
                break;
        }

//        Log.d(Tag, "getDMSCreateAccount:" + retValue);
        return retValue;
    }

    public String getDMSForgotPassword() {
        String retValue = DMSForgotPassword_Staging;

        switch (server) {
            case DMS_Staging:
                retValue = DMSForgotPassword_Staging;
                break;
            case DMS_Production:
                retValue = DMSForgotPassword_Production;
                break;
            default:
                break;
        }

//        Log.d(Tag, "getDMSForgotPassword:" + retValue);
        return retValue;
    }

    public String getDMSServerURL() {
        String retValue = DMSServerURL_Staging;

        switch (server) {
            case DMS_Staging:
                retValue = DMSServerURL_Staging;
                break;
            case DMS_Production:
                retValue = DMSServerURL_Production;
                break;
            default:
                break;
        }

//        Log.d(Tag, "getDMSServerURL:" + retValue);
        return retValue;
    }

    public String FormattedGMTDateAndTimeString(Calendar calendar) {
        if (calendar == null) {
            return GMT_DATETIME_INVALID;
        }
        else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
            String s = sdf.format(calendar.getTime());
            return s;
        }
    }

    public String getLastCriticalFaults() {
        ArrayList<Notification> alarms = new ArrayList<Notification>();
        alarms = getList(Arrays.asList(
                Utils.EVENT_TYPE.CALIBRATE_EXPIRED_EVENT,
                Utils.EVENT_TYPE.CALIBRATE_GRACE_EVENT,
                Utils.EVENT_TYPE.NOTIFICATION_EVENT_RED,
                Utils.EVENT_TYPE.ALARM_EVENT,
                Utils.EVENT_TYPE.NOTIFICATION_EVENT_YELLOW)); /** #3692 Sync more alerts to DMS (Android) */

        String alarmString = "";
        int size = alarms.size();
        for (int i=0; i<size; i++) {
            Notification thisNotif = alarms.get(i);

            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(thisNotif.getTimestamp());

            EventPoint ep = thisNotif.getEventPoint();
            int ECCode = -1;
            if (ep.getNotificationEventType() != null) {
                ECCode = ep.getNotificationEventType().ordinal();
            }
            alarmString += FormattedGMTDateAndTimeString(calendar) + "," + ECCode + "," + thisNotif.getTitle();

            if (i!=(size-1)) {
                alarmString += ";";
            }
        }
        return alarmString;
    }

    private ArrayList<Notification> getList(List<Utils.EVENT_TYPE> eventTypes) {
        Calendar currentDateEnd = Calendar.getInstance();
        currentDateEnd.add(Calendar.DAY_OF_YEAR, 1);

        return databaseManager.getNotificationsBetween(context, Utils.getDayStart(Utils.startDate),
            currentDateEnd, eventTypes, 1,
                false, false, FETCH_LIMIT_ALERT+"", false);
    }
}
