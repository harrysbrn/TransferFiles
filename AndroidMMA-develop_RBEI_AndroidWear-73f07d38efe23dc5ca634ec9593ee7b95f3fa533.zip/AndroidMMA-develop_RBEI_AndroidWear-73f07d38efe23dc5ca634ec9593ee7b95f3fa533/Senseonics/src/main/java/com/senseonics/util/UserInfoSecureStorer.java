package com.senseonics.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.securepreferences.SecurePreferences;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class UserInfoSecureStorer {
    private SecurePreferences securePrefs;
    private final String fileName = "user_prefs";
    private Context context;

    @Inject
    public UserInfoSecureStorer(Context contextIn) {
        this.context = contextIn;
    }

    private SharedPreferences getSecurePreferences() {
        if(securePrefs==null){
            securePrefs = new SecurePreferences(context, "", fileName);
            SecurePreferences.setLoggingEnabled(false);
        }
        return securePrefs;
    }

    public void saveSecureSettings(String key, String value) {
        SharedPreferences prefs = this.getSecurePreferences();
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public String getSecureSettingsForString(String key) {
        SharedPreferences prefs = this.getSecurePreferences();
        return prefs.getString(key, "");
    }

    public boolean contains(String key) {
        return this.getSecurePreferences().contains(key);
    }

}
