package com.senseonics.gen12androidapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.util.AccountConstants;
import com.senseonics.util.Utils;

import java.util.Locale;

public class UserAccountLoginActivity extends UserAccountBaseActivity {
    private EditText txtUserNameCover, txtUserName, txtPassword;
    private TextView tvCreateAccount, tvForgotPassword, tvUserNameOrEmail;
    private String Tag = "DMS(UALoginActivity)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        contentLayout.addView(
                layoutInflater.inflate(R.layout.activity_userlogin, null),
                parms_content);

        // Configure the status header
        statusBarDrawerButton.setVisibility(View.GONE);

        // Configure the navigation bar
        naviBarTitle.setVisibility(View.GONE);
        naviBarTitleImageView.setVisibility(View.VISIBLE);
        naviBarTitleImageView.setImageResource(R.drawable.company_logo_white);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        // Find the views
        findViewsForAccountInfo();
        findViewForBtnSync();

        // Fetch the preferences
        txtUserName.setText(accountConstants.getAccountUsernameFromPreference());

        /** #3498 */
        tvUserNameOrEmail.setText(getString(R.string.email));

        if (!txtUserName.getText().toString().equals("")) {
            txtUserNameCover.setText(accountConstants.getCoveredUserName(accountConstants.getAccountUsernameFromPreference()));
            txtUserNameCover.setVisibility(View.VISIBLE);
        } else {
            txtUserNameCover.setVisibility(View.GONE);
        }

        txtUserNameCover.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    txtUserName.setText("");
                    txtUserNameCover.setVisibility(View.GONE);

                    Handler handler = new android.os.Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            txtUserName.requestFocus();
                            // force the soft keyboard to show up
                            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.showSoftInput(txtUserName, InputMethodManager.SHOW_IMPLICIT);
                        }
                    }, 100);
                }
            }
        });

        txtUserName.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        txtUserName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    txtPassword.requestFocus();
                }
                return false;
            }
        });


        txtPassword.setImeOptions(EditorInfo.IME_ACTION_GO);
        txtPassword.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    btnSync.performClick();
                }
                return false;
            }
        });

        setupTvCreateAccountAndTvForgotPassword();

        setupBtnSyncOnClickEvent();
        btnSync.setText(btnSync.getText().toString().toUpperCase(Locale.ENGLISH));

        Bundle extras = getIntent().getExtras();
        if ((extras != null) && (extras.containsKey(accountConstants.FORCE_LOGOUT_BUNDLE_KEY))) {
            displayDialogWithTitleAndMessage(null, getString(R.string.force_logout_text_w_email));
        }
    }

    private void findViewsForAccountInfo() {
        txtUserNameCover = (EditText) findViewById(R.id.etUserNameCover);
        txtUserName = (EditText) findViewById(R.id.etUserName);
        txtPassword = (EditText) findViewById(R.id.etPassword);
        tvCreateAccount = (TextView) findViewById(R.id.tvCreateAccount);
        tvForgotPassword = (TextView) findViewById(R.id.tvForgotPassword);
        tvUserNameOrEmail = (TextView) findViewById(R.id.tvUserNameOrEmail);
    }

    private void setupTvCreateAccountAndTvForgotPassword() {
        tvCreateAccount.setText(Html.fromHtml("<a href='#'>" + tvCreateAccount.getText() + "</a>" + " "));
        tvCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accountConstants.OpenCreateAccountURL(UserAccountLoginActivity.this);
            }
        });

        tvForgotPassword.setText(Html.fromHtml("<a href='#'>" + tvForgotPassword.getText() + "</a>" + " "));
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accountConstants.OpenForgotPasswordURL(UserAccountLoginActivity.this);

                /** #3628 */
                Answers.getInstance().logCustom(new CustomEvent("Forgot Password")
                        .putCustomAttribute("Info", "User Clicked"));
            }
        });
    }

    @Override
    protected void setupBtnSyncOnClickEvent() {
        btnSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // #3279 Convert the username field all to lowercase after button click
                txtUserName.setText(txtUserName.getText().toString().toLowerCase());

                String userName = txtUserName.getText().toString();
                String passWord = txtPassword.getText().toString();

//                Log.d(Tag, "on click:" + userName + "|" + passWord);

                if (userName.matches("")) {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.invalid_email), Toast.LENGTH_SHORT).show();

                } else if (passWord.matches("")) {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.invalid_password), Toast.LENGTH_SHORT).show();
                } else {
                    if (Utils
                            .haveNetworkConnection(UserAccountLoginActivity.this)) {
                        progressDialog.show();
                        /** #3707 */
                        new checkAndUpdatePasswordAsynctask(txtUserName.getText().toString(),
                                txtPassword.getText().toString())
                                .execute();
                    } else {
                        dmsError = AccountConstants.MLDMSResult.NotConnectedToWifi;
                        displayDMSResult(dmsError);
                    }
                }
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // Result coming back from the unit selection page when the Finish button is pressed
        if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
            setResult(resultCode);
            finish();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void displayDMSResult(AccountConstants.MLDMSResult error, Integer result2, Integer result3) {
        String title = "", message = "";
        switch (error) {

            case DataSaved:
                title = getString(R.string.congratulations);
                message = getString(R.string.login_success);

                // save the username, password, uid, logged
                Utils.saveSettings(UserAccountLoginActivity.this, Utils.prefAccountIsLoggedIn, true);

                userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserName, txtUserName.getText().toString());
                userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserID, userID);
                userInfoSecureStorer.saveSecureSettings(Utils.prefAccountUserPassword, txtPassword.getText().toString());
                break;

            case InvalidUserCredentials:
                title = getString(R.string.invalid_user_credentials_w_email);
                message = getString(R.string.invalid_user_credentials_text_w_email);
                break;

            case GeneralErrorSavingData:
            case InvalidDeviceType:
            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.unknown_error_text);
                break;
        }

        if (error == AccountConstants.MLDMSResult.DataSaved) {
            displayLoginSuccessDialogWithTitleAndMessage(title, message);
        } else {
            displayDialogWithTitleAndMessage(title, message);
        }
    }

    private void displayLoginSuccessDialogWithTitleAndMessage(String title, String message) {
        if (this.isThisActivityTop()) {
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }

            final DialogUtils.WarningDialogInfo warningDialogInfo = new DialogUtils.WarningDialogInfo(-1,
                    title, message);

            dialog = dialogUtils.createWarningDialog(this, warningDialogInfo, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    dialogUtils.removeDialogFromCustomDialogs(warningDialogInfo);

                    if (Utils.checkIfFirstRun(UserAccountLoginActivity.this)) {
                        startActivityForResult(new Intent(UserAccountLoginActivity.this,
                                WelcomeScreenActivity.class), Utils.WELCOME_UNIT_SELECTION_RESULT);
                    } else {
                        startActivity(new Intent(UserAccountLoginActivity.this, MainActivity.class));
                        finish();
                    }
                }
            });
            dialog.show();
        }
    }

    @Override
    public void TaskDone(AccountConstants.MLDMSResult dmsResult, Integer secondResult, Integer thirdResult) {
        displayDMSResult(dmsResult, secondResult, thirdResult);
        resetBtnTextDismissProgressDialog();
    }

}
