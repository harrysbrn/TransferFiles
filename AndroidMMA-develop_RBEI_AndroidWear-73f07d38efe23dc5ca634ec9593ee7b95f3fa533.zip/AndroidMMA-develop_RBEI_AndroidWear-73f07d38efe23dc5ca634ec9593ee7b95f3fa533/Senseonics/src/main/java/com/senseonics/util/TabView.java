package com.senseonics.util;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;

import java.util.ArrayList;

public class TabView extends RelativeLayout {
	LinearLayout allTab, tab1, tab2, tab3, tab4, tab5;
	ArrayList<Integer> drawables = new ArrayList<Integer>();
	ArrayList<Integer> selectedDrawables = new ArrayList<Integer>();
	LinearLayout layout;
	
	public TabView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView(context, attrs);
	}

	public TabView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView(context, attrs);
	}

	public TabView(Context context) {
		super(context);
	}

	private void initView(Context context, AttributeSet attrs) {
		layout = (LinearLayout) View.inflate(context,
				R.layout.tabview_layout, null);
		
		// Get the action bar height
		final TypedArray styledAttributes = context.getTheme()
				.obtainStyledAttributes(
						new int[] { android.R.attr.actionBarSize });
		int mActionBarSize = (int) styledAttributes.getDimension(0, 0);
		styledAttributes.recycle();
		
		// make the height of the tab bar a fraction of the action bar height
		addView(layout, new LayoutParams(LayoutParams.MATCH_PARENT,
				(int)3*mActionBarSize/4));

		allTab = (LinearLayout) layout.findViewById(R.id.allTab);
		TextView tvAll = (TextView) allTab.findViewById(R.id.allTabTextView);
		tvAll.setText(tvAll.getText().toString().toUpperCase());

		tab1 = (LinearLayout) layout.findViewById(R.id.tab1);
		tab2 = (LinearLayout) layout.findViewById(R.id.tab2);
		tab3 = (LinearLayout) layout.findViewById(R.id.tab3);
		tab4 = (LinearLayout) layout.findViewById(R.id.tab4);
		tab5 = (LinearLayout) layout.findViewById(R.id.tab5);

		TypedArray a = context.obtainStyledAttributes(attrs,
				R.styleable.TabView);

		final int N = a.getIndexCount();
		for (int i = 0; i < N; ++i) {
			int attr = a.getIndex(i);
			int resource_id = 0;
			switch (attr) {
			case R.styleable.TabView_group_1_drawable:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				((ImageView) tab1.findViewById(R.id.iconGroup1))
						.setImageResource(resource_id);
				drawables.add(resource_id);
				break;
			case R.styleable.TabView_group_2_drawable:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				((ImageView) tab2.findViewById(R.id.iconGroup2)).setImageResource(resource_id);
				drawables.add(resource_id);
				break;
			case R.styleable.TabView_group_3_drawable:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				((ImageView) tab3.findViewById(R.id.iconGroup3))
						.setImageResource(resource_id);
				drawables.add(resource_id);
				break;
			case R.styleable.TabView_group_4_drawable:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				((ImageView) tab4.findViewById(R.id.iconGroup4))
						.setImageResource(resource_id);
				drawables.add(resource_id);
				break;
			case R.styleable.TabView_group_5_drawable:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				((ImageView) tab5.findViewById(R.id.iconGroup5))
						.setImageResource(resource_id);
				drawables.add(resource_id);
				break;
			case R.styleable.TabView_group_1_drawable_selected:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				selectedDrawables.add(resource_id);
				break;
			case R.styleable.TabView_group_2_drawable_selected:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				selectedDrawables.add(resource_id);
				break;
			case R.styleable.TabView_group_3_drawable_selected:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				selectedDrawables.add(resource_id);
				break;
			case R.styleable.TabView_group_4_drawable_selected:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				selectedDrawables.add(resource_id);
				break;
			case R.styleable.TabView_group_5_drawable_selected:
				resource_id = a.getResourceId(attr, R.drawable.alert_icon);
				selectedDrawables.add(resource_id);
				break;
			}
		}
		
		a.recycle();

	}
	
	public Integer getIconGroupIdFromIndex(Integer index) {
		Integer iconGroup = 0;
		
		switch(index) {
		case 0:
			iconGroup = R.id.iconGroup1;
			
			break;

		case 1:
			iconGroup = R.id.iconGroup2;
			
			break;

		case 2:
			iconGroup = R.id.iconGroup3;
			
			break;

		case 3:
			iconGroup = R.id.iconGroup4;
			
			break;

		case 4:
			iconGroup = R.id.iconGroup5;
			
			break;
			
			default:
				iconGroup = R.id.iconGroup1;
				
				break;
		}
		
		return iconGroup;
	}
	
	public void toggleSelectedImage(Integer index, boolean selected) {
		Integer iconGroup = this.getIconGroupIdFromIndex(index);
		
		Integer imageId = selected ? selectedDrawables.get(index) : drawables.get(index);
		
		((ImageView) layout.findViewById(iconGroup)).setImageResource(imageId);
	}

	public void setAllTabSelected(boolean selected) {
		allTab.setSelected(selected);
		
		TextView tv = (TextView) allTab.findViewById(R.id.allTabTextView);

		int color = selected ? getResources().getColor(R.color.graph_white) : Color.parseColor("#587cb0");
		
		tv.setTextColor(color);
	}
	
	public void allTabClickListener(final OnClickListener listener) {
		allTab.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setAllTabSelected(true);

				unselectAll();
				listener.onClick(v);
			}
		});
	}

	public void tab1ClickListener(final OnClickListener listener) {
		tab1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tab1.setSelected(!tab1.isSelected());
				
				toggleSelectedImage(0, tab1.isSelected());
				
				setAllTabSelected(false);
				listener.onClick(v);
				ifNothingIsSelected();
			}
		});
	}

	public void tab2ClickListener(final OnClickListener listener) {
		tab2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tab2.setSelected(!tab2.isSelected());

				toggleSelectedImage(1, tab2.isSelected());
				
				setAllTabSelected(false);
				listener.onClick(v);
				ifNothingIsSelected();
			}
		});
	}

	public void tab3ClickListener(final OnClickListener listener) {
		tab3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tab3.setSelected(!tab3.isSelected());

				toggleSelectedImage(2, tab3.isSelected());
				
				setAllTabSelected(false);
				listener.onClick(v);
				ifNothingIsSelected();
			}
		});
	}

	public void tab4ClickListener(final OnClickListener listener) {
		tab4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tab4.setSelected(!tab4.isSelected());

				toggleSelectedImage(3, tab4.isSelected());
				
				setAllTabSelected(false);
				listener.onClick(v);
				ifNothingIsSelected();
			}
		});
	}

	public void tab5ClickListener(final OnClickListener listener) {
		tab5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				tab5.setSelected(!tab5.isSelected());
				
				toggleSelectedImage(4, tab5.isSelected());
				
				setAllTabSelected(false);
				listener.onClick(v);
				ifNothingIsSelected();
			}
		});
	}

	private void unselectAll() {
		for(int index = 0; index < 5; index++) {
			toggleSelectedImage(index, false);
		}
		
		tab1.setSelected(false);
		tab2.setSelected(false);
		tab3.setSelected(false);
		tab4.setSelected(false);
		tab5.setSelected(false);
	}

	public void ifNothingIsSelected() {
		if (!tab1.isSelected() && !tab2.isSelected() && !tab3.isSelected()
				&& !tab4.isSelected() && !tab5.isSelected())
			allTab.performClick();
	}

	public ArrayList<Integer> getDrawables() {
		return drawables;
	}

	public boolean performClick() {
		return allTab.performClick();
	}

	public void setDrawables(ArrayList<Integer> drawables) {
		this.drawables = drawables;
	}

}
