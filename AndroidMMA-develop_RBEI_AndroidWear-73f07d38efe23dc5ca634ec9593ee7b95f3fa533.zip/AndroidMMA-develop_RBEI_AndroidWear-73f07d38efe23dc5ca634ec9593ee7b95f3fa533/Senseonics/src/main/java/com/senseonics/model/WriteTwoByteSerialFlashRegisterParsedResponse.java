package com.senseonics.model;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;

import java.util.Arrays;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

public class WriteTwoByteSerialFlashRegisterParsedResponse implements ParsedResponse {

    private final Map<int[], TwoByteMemoryMapParsedResponse> children;

    @Inject
    public WriteTwoByteSerialFlashRegisterParsedResponse(@Named("writetwobyteregisters") Map<int[], TwoByteMemoryMapParsedResponse> children) {
        this.children = children;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterResponseID;
    }

    @Override
    public boolean check(int[] response) {
        if (ResponseOperations.isReadTwoByteSerialFlashRegisterResponseCorrect(response)) {
            int[] address = new int[]{response[3], response[2], response[1]};

            for (int[] key : children.keySet()) {
                if (Arrays.equals(key, address)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void apply(int[] response, TransmitterStateModel model) {
        int dataOne = response[4];
        int dataTwo = response[5];
        int[] address = new int[]{response[3], response[2], response[1]};
        for (Map.Entry<int[], TwoByteMemoryMapParsedResponse> entry : children.entrySet()) {
            if (Arrays.equals(entry.getKey(), address)) {
                entry.getValue().apply(dataOne, dataTwo, model);
                break;
            }
        }
    }
}
