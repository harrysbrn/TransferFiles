package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class TransmitterModelNoFourByteMemoryMapParsedResponse implements FourByteMemoryMapParsedResponse {

    @Inject
    public TransmitterModelNoFourByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.transmitterModelNumberAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        int modelNumberInt = dataOne | (dataTwo << 8) | (dataThree << 16)
                | (dataFour << 24);
        model.setTransmitterModelNumber("" + modelNumberInt);
    }
}
