package com.senseonics.db;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class TransmitterPersistor {

    private Context context;
    private Uri authorityUri;

    @Inject
    public TransmitterPersistor(Context context, EventBus eventBus, @Named("transmitter") Uri authorityUri) {
        this.context = context;
        this.authorityUri = authorityUri;
        eventBus.register(this);
    }

    public void onEvent(TransmitterConnectionEvent event) {
        Transmitter transmitter = event.getTransmitter();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConnectedTransmitterTableInfo.NAME_FIELD, transmitter.getName());
        contentValues.put(ConnectedTransmitterTableInfo.ADDRESS_FIELD, transmitter.getAddress());
        contentValues.put(ConnectedTransmitterTableInfo.STATUS_FIELD, transmitter.getConnectionState().name());
        context.getContentResolver().insert(Uri.withAppendedPath(authorityUri, "transmitter"), contentValues);
    }

}
