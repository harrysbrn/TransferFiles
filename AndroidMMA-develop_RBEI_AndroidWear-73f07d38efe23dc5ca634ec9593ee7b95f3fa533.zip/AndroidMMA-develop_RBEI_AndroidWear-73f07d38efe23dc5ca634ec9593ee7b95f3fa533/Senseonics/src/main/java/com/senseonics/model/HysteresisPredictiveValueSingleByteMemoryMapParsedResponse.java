package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class HysteresisPredictiveValueSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {
    @Inject
    public HysteresisPredictiveValueSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.hysteresisPredictiveValueAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        model.setHysteresisLowPredictiveGlucoseValueMgDl(data);
    }
}
