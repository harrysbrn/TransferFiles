package com.senseonics.model;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.util.Range;

import javax.inject.Inject;

public class ReadFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse implements ParsedResponse {

    @Inject
    public ReadFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse() {
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadFirstAndLastSensorGlucoseAlertRecordNumbersResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        int firstSensorGlucoseAlertNr = data[1] | (data[2] << 8);
        int lastSensorGlucoseAlertNr = data[3] | (data[4] << 8);

        model.setAlertRecordRange(new Range(firstSensorGlucoseAlertNr, lastSensorGlucoseAlertNr));
    }
}
