package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.HexHelper;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.bluetoothle.TransmitterSyncRequest;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class SyncModel {
    private RangeWithCurrentValue glucoseRange;
    private RangeWithCurrentValue glucoseAlertRange;
    private RangeWithCurrentValue glucoseLogRange;

    @Inject
    public SyncModel() {
        clearRanges();
    }

    public boolean shouldPostSyncingProgress () {
        boolean retVal = false;

        int totalRecords = glucoseRange.getNumberOfRecordsExpected() + glucoseLogRange.getNumberOfRecordsExpected() + glucoseAlertRange.getNumberOfRecordsExpected();
        int finishedRecords = glucoseRange.getFinished() + glucoseLogRange.getFinished() + glucoseAlertRange.getFinished();

//        Log.d("#3640_2", "finishedRecords:" + finishedRecords + ", totalRecords:" + totalRecords);

        int progress0 = (int)Math.ceil(totalRecords * 0.01f);
        int progress1 = Math.round(totalRecords * 0.25f);
        int progress2 = Math.round(totalRecords * 0.50f);
        int progress3 = Math.round(totalRecords * 0.75f);
        int progress4 = Math.round(totalRecords * 1.00f);

        if ((finishedRecords == progress0) ||
                (finishedRecords == progress1) ||
                (finishedRecords == progress2) ||
                (finishedRecords == progress3) ||
                (finishedRecords == progress4))
        {
            Log.d("#3640_2", "shouldPostSyncingProgress p0:" + progress0 + ",p1:" + progress1 + ",p2:" + progress2 + ",p3:" + progress3 + ",p4:" + progress4);
            retVal = true;
        }

        return retVal;
    }

    public boolean shouldPostRefreshGraph () {
        boolean retVal = false;

        int totalRecords = glucoseRange.getNumberOfRecordsExpected() + glucoseLogRange.getNumberOfRecordsExpected() + glucoseAlertRange.getNumberOfRecordsExpected();
        int finishedRecords = glucoseRange.getFinished() + glucoseLogRange.getFinished() + glucoseAlertRange.getFinished();

//        Log.d("#3640_2", "finishedRecords:" + finishedRecords + ", totalRecords:" + totalRecords);

        int progress1 = Math.round(totalRecords * 1.0f);

        if (finishedRecords == progress1)
        {
            Log.d("#3640_2", "shouldPostRefreshGraph p1:" + progress1);
            retVal = true;
        }

        return retVal;
    }

    public int getSyncingPercent() {
        int glucoseRangePercent = glucoseRange.getPercent();
        int glucoseLogRangePercent = glucoseLogRange.getPercent();
        int glucoseAlertRangePercent = glucoseAlertRange.getPercent();

        int totalRecords = glucoseRange.getNumberOfRecordsExpected() + glucoseLogRange.getNumberOfRecordsExpected() + glucoseAlertRange.getNumberOfRecordsExpected();
        if (totalRecords == 0) {
            return 0;
        }
        Log.d(SyncModel.class.getSimpleName(), "total records: " + totalRecords);
        Log.d(SyncModel.class.getSimpleName(), "weighed Glucose : " + glucoseRangePercent * calculatePercent(glucoseRange.getNumberOfRecordsExpected(), totalRecords));
        Log.d(SyncModel.class.getSimpleName(), "weighted glucose log : " + glucoseLogRangePercent * (calculatePercent(glucoseLogRange.getNumberOfRecordsExpected(), totalRecords)));
        Log.d(SyncModel.class.getSimpleName(), "weighted glucose alert : " + glucoseAlertRangePercent * (calculatePercent(glucoseAlertRange.getNumberOfRecordsExpected(), totalRecords)));

        return Math.round(
                glucoseRangePercent * (calculatePercent(glucoseRange.getNumberOfRecordsExpected(), totalRecords)) +
                glucoseLogRangePercent * (calculatePercent(glucoseLogRange.getNumberOfRecordsExpected(), totalRecords)) +
                glucoseAlertRangePercent * (calculatePercent(glucoseAlertRange.getNumberOfRecordsExpected(), totalRecords)));
    }

    private float calculatePercent(int numberOfRecordsExpected, int totalRecords) {
        return ((float)numberOfRecordsExpected) / totalRecords;
    }

    public void clear() {
        Log.d(SyncModel.class.getSimpleName(), "clear");
        clearRanges();
    }

    public boolean isSyncing() {
        return glucoseRange.isSyncing() || glucoseAlertRange.isSyncing() || glucoseLogRange.isSyncing();
    }

    public boolean isSyncFinished() {
        return getSyncingPercent() == 100;
    }

    public void addSyncingRequests(List<TransmitterSyncRequest> requests) {
        if (!requests.isEmpty()) {
            clearRanges();

            for (TransmitterSyncRequest request : requests) {
                if (request.getExpectedResponseId() == glucoseRange.getResponseId()) {
                    glucoseRange.addRange(request.getHighestExpectedRecordNumber(), request.getExpectResponseCount());
                    Log.d(SyncModel.class.getSimpleName(), "glucoseRange min max now " + glucoseRange + " from data: " + HexHelper.intArrayToString(request.getData()));
                } else if (request.getExpectedResponseId() == glucoseLogRange.getResponseId()) {
                    glucoseLogRange.addRange(request.getHighestExpectedRecordNumber(), request.getExpectResponseCount());
                    Log.d(SyncModel.class.getSimpleName(), "glucose Log Range min max now " + glucoseLogRange + " from data: " + HexHelper.intArrayToString(request.getData()));
                } else if (request.getExpectedResponseId() == glucoseAlertRange.getResponseId()) {
                    glucoseAlertRange.addRange(request.getHighestExpectedRecordNumber(), request.getExpectResponseCount());
                    Log.d(SyncModel.class.getSimpleName(), "glucose alert Range min max now " + glucoseAlertRange + " from data: " + HexHelper.intArrayToString(request.getData()));
                }
            }
        }
    }

    private void clearRanges() {
        glucoseRange = new RangeWithCurrentValue(CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeResponseID);
        glucoseLogRange = new RangeWithCurrentValue(CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID);
        glucoseAlertRange = new RangeWithCurrentValue(CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID);

    }

    public void setCurrentSyncingResponseId(ResponseOperations.Response response) {
        int[] responseData = response.getData();

        if (response.getResponseId() == glucoseRange.getResponseId()) {
            int glucoseRecordNumber = responseData[1] | (responseData[2] << 8) | (responseData[3] << 16);
            glucoseRange.setCurrentRecordNumber(glucoseRecordNumber);
        } else if (response.getResponseId() == glucoseLogRange.getResponseId()) {
            int recordNumber = responseData[1] | (responseData[2] << 8);
            glucoseLogRange.setCurrentRecordNumber(recordNumber);
        } else if (response.getResponseId() == glucoseAlertRange.getResponseId()) {
            int recordNumber = responseData[1] | (responseData[2] << 8);
            glucoseAlertRange.setCurrentRecordNumber(recordNumber);
        }
    }

    public void skippingTheRestOfTheResponses(int responseId) {
        if (responseId == glucoseRange.getResponseId()) {
            glucoseRange.setCurrentToMaxOfCurrentRange();
        } else if (responseId == glucoseLogRange.getResponseId()) {
            glucoseLogRange.setCurrentToMaxOfCurrentRange();
        } else if (responseId == glucoseAlertRange.getResponseId()) {
            glucoseAlertRange.setCurrentToMaxOfCurrentRange();
        }

    }
}
