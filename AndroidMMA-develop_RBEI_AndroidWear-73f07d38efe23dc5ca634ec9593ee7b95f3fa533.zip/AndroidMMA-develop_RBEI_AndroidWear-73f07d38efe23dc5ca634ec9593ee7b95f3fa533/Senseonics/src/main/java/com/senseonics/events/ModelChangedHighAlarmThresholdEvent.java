package com.senseonics.events;

public class ModelChangedHighAlarmThresholdEvent { /** #3160 */
    private int newValue;

    public ModelChangedHighAlarmThresholdEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
