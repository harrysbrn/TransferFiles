package com.senseonics.gen12androidapp;

import android.widget.ImageButton;

public interface ActivityWithNavigationBar {
    ImageButton getRefreshButton();
}
