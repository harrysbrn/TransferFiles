package com.senseonics.pairing;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.senseonics.gen12androidapp.ObjectGraphActivity;

import javax.inject.Inject;

public class BluetoothPairingFragment extends Fragment {
    @Inject
    BluetoothPairingPresenter presenter;
    @Inject
    BluetoothPairingView view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        ((ObjectGraphActivity) getActivity()).inject(this);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        presenter.start();
    }

    @Override
    public void onResume() {
        super.onResume();
        presenter.resume();
    }

    @Override
    public void onStop() {
        super.onStop();
        presenter.stop();
    }
}
