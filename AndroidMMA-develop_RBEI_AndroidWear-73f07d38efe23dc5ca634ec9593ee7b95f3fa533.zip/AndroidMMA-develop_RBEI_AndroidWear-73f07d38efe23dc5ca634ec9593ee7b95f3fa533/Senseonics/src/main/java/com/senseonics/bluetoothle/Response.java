package com.senseonics.bluetoothle;

import android.os.Parcel;
import android.os.Parcelable;

public class Response implements Parcelable{
    private int responseId = 0;
    private boolean responseAccepted;
    private int[] data;

    public Response(boolean responseAccepted, int[] data) {
        this(-1, responseAccepted, data);
    }

    public Response(int responseId, boolean responseAccepted, int[] data) {
        super();
        this.setResponseId(responseId);
        this.setResponseAccepted(responseAccepted);
        this.setData(data);
    }

    public int getResponseId() {
        return responseId;
    }

    public void setResponseId(int responseId) {
        this.responseId = responseId;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data == null ? new int[0] : data;
    }

    public boolean isResponseAccepted() {
        return responseAccepted;
    }

    public void setResponseAccepted(boolean responseAccepted) {
        this.responseAccepted = responseAccepted;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(responseId);
        dest.writeString(responseAccepted ? Boolean.toString(true) : Boolean.toString(false));
        dest.writeInt(data.length);
        dest.writeIntArray(data);
    }

    public static final Creator<Response> CREATOR = new Creator<Response>() {
        @Override
        public Response createFromParcel(Parcel source) {
            int responseId = source.readInt();
            boolean accepted = Boolean.parseBoolean(source.readString());
            int size = source.readInt();
            int[] data = new int[size];
            source.readIntArray(data);
            return new Response(responseId, accepted, data);
        }

        @Override
        public Response[] newArray(int size) {
            return new Response[size];
        }
    };
}
