package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.common.base.Objects;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.bluetoothle.DialogUtils.WarningDialogInfo;
import com.senseonics.events.ModelChangedLinkedSensorIdEvent;
import com.senseonics.events.ModelChangedUnLinkedSensorIdEvent;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class SensorListActivity extends BaseActivity {

    private ProgressDialog progressDialog;
    private Dialog dialog;
    private Dialog avPlaceSensor;
    private LinearLayout linkedSensorLayout, unlinkedSensorLayout,
            linkingLayout, linkDetectedSensorLayout;
    private TextView linkedSensorTextView, unlinkedSensorTextView,
            unlinkedSensorLeftTextView, linkDetectedSensorTextView;
    private Button linkDetectedSensorButton;
    private ProgressBar progressBar1, progressBar2, progressBar3;
    private ImageView imageView1, imageView2, imageView3;

    private static final int MLResponseMessageArgument_CRC = 0;
    private static final int MLResponseMessageArgument_EEPROM = 2;
    private static final int MLResponseMessageArgument_ATCCAL = 3;
    private static final int kNumberEEPROMBlocks = 26;
    private static final String kBaseFileExtension = ".csv";

    private String fileVersionString = null;

    private int[] addressAndValuesEEPROM, addressAndValuesACT;

    public enum LinkingState {
        NONE, STEP1, STEP2, STEP3
    }

    private LinkingState linkingState = LinkingState.NONE;

    public enum MLSensorLinkingError {
        Timeout, IncompatibleSensorFile, NotConnectedToWifi, ServerError, UnableToDownloadSensorFile, CorruptedData, TransmitterError, IncompatibleFWVersion, SyncTransmitterTimeFailure, None
    }

    private MLSensorLinkingError linkingError = MLSensorLinkingError.None;
    private boolean sendNewSensorIdExecuted = false;
    private boolean linkedSensorSerialNumberArrived = false;
    private boolean unlinkedSensorSerialNumberArrived;

    private boolean linkingInProgress;
    private Handler linkCheckHander;
    private int linkCheckCounter;
    private int avPlaceSensorCounter;

    private Calendar oldSensorInsertionDate;

    private Handler checkAndSyncTransmitterDateTimeHandler;
    private int checkTxTimeCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.activity_sensor_list, null),
                parms_content);

        // Configure the navigation bar
        naviBarTitle.setText(R.string.linked_sensor);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);


        linkedSensorLayout = (LinearLayout) findViewById(R.id.linkedSensorLayout);
        unlinkedSensorLayout = (LinearLayout) findViewById(R.id.unlinkedSensorLayout);
        linkedSensorTextView = (TextView) linkedSensorLayout
                .findViewById(R.id.rightTextView);
        unlinkedSensorLeftTextView = (TextView) unlinkedSensorLayout
                .findViewById(R.id.leftTextView);
        unlinkedSensorLeftTextView.setText(getString(R.string.detected_sensor));
        unlinkedSensorTextView = (TextView) unlinkedSensorLayout
                .findViewById(R.id.rightTextView);
        linkDetectedSensorLayout = (LinearLayout) findViewById(R.id.linkDetectedSensorLayout);
        linkDetectedSensorTextView = (TextView) findViewById(R.id.linkDetectedSensorTextView);
        linkDetectedSensorButton = (Button) findViewById(R.id.linkDetectedSensorButton);
        linkingLayout = (LinearLayout) findViewById(R.id.linkingLayout);
        progressBar1 = (ProgressBar) findViewById(R.id.progressBar1);
        progressBar2 = (ProgressBar) findViewById(R.id.progressBar2);
        progressBar3 = (ProgressBar) findViewById(R.id.progressBar3);
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        imageView3 = (ImageView) findViewById(R.id.imageView3);

        registerReceiver(broadcastReceiver, makeIntentFilter());

        linkDetectedSensorButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (transmitterStateModel.isTransmitterConnected()) {
                    if (transmitterStateModel.getUnLinkedSensorId() != null) {
                        if (Utils
                                .haveNetworkConnection(SensorListActivity.this)) {

                            progressDialog.show();
                            linkingInProgress = true;

                            /** #4021 */
                            checkTransmitterDateTimePre();
                        } else {
                            linkingError = MLSensorLinkingError.NotConnectedToWifi;
                            displayLinkingFailure();
                        }
                    }
                }
            }
        });

        updateViews();

        progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(false);

    }

    public void onEventMainThread(ModelChangedUnLinkedSensorIdEvent event) {
        unlinkedSensorSerialNumberArrived = true;
        updateViews();
        if (linkingState == LinkingState.NONE) {

            Log.d("Linking", "linkedSensorSerialNumberArrived:" + linkedSensorSerialNumberArrived + "|" +  transmitterStateModel.getLinkedSensorId() + "|" + transmitterStateModel.getUnLinkedSensorId());

            String unLinkedSensorId = transmitterStateModel.getUnLinkedSensorId();
            String linkedSensorId = transmitterStateModel.getLinkedSensorId();

            if (transmitterStateModel.isTransmitterConnected() && linkedSensorSerialNumberArrived) {
                Boolean shouldShowTextAndButton = true;
                // no detected sensor -> no sensor to link -> no button to show
                if (unLinkedSensorId == null) {
                    shouldShowTextAndButton = false;
                }
                else { // unLinkedSensorId != null
                    if (linkedSensorId == null) {
                        /** do nothing */
                    }
                    else { // linkedSensorId != null
                        if (linkedSensorId.equals(unLinkedSensorId)) {
                            // #1713 - disable relink sensor feature when tx is already linked.
                            shouldShowTextAndButton = false;
                        }
                    }
                }

                Log.d("Linking", "shouldShowTextAndButton:" + shouldShowTextAndButton);

                if (shouldShowTextAndButton) {
                    linkDetectedSensorTextView.setVisibility(View.VISIBLE);
                    linkDetectedSensorButton.setVisibility(View.VISIBLE);
                }
                else {
                    linkDetectedSensorTextView.setVisibility(View.GONE);
                    linkDetectedSensorButton.setVisibility(View.GONE);
                }

                linkDetectedSensorLayout.setVisibility(View.VISIBLE);
            } else {
                linkDetectedSensorLayout.setVisibility(View.VISIBLE);
            }
        }

        if (isAllDataLoaded() && !linkingInProgress) {
            progressDialog.dismiss();
        }
    }

    public void onEventMainThread(ModelChangedLinkedSensorIdEvent event) {
        linkedSensorSerialNumberArrived = true;
        if (sendNewSensorIdExecuted == true) {
            /** #3599
            step3Finished();
            */
            Log.d("Linking", "--- Link Check START ---");
            sendNewSensorIdExecuted = false;

            linkCheckCounter = 0;
            avPlaceSensorCounter = 0;

            /** #3599 keep track of the old insertion date */
            if (transmitterStateModel.getSensorInsertionDateAndTime() == null) {
                oldSensorInsertionDate = null;
            }
            else {
                oldSensorInsertionDate = (Calendar) (transmitterStateModel.getSensorInsertionDateAndTime().clone());
            }
            Log.d("Linking", "0.1 Save old insertion date: " + oldSensorInsertionDate);

            linkCheckHander = null;
            linkCheckHander = new Handler();
            linkCheckHander.post(linkCheckRunnable);
        }

        if (isAllDataLoaded() && !linkingInProgress) {
            progressDialog.dismiss();
        }
    }

    private boolean isAllDataLoaded() {
        boolean result = false;

        if(linkedSensorSerialNumberArrived && unlinkedSensorSerialNumberArrived) {
            result = true;
        }

        return result;
    }


    public IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Utils.WRITE_N_BYTE_FINISHED);
        return intentFilter;
    }

    protected BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (Utils.WRITE_N_BYTE_FINISHED.equals(action)) {
                Log.d("Linking", "WRITE_N_BYTE_FINISHED broadcast received " + "linkingRequestsInitialized:"
                        + BluetoothUtils.linkingRequestsInitialized);

                if (BluetoothUtils.linkingRequestsInitialized) {
                    dataSentToTransmitter();
                }
            }
        }
    };

    public void prepareLinkingLayout() {
        imageView1.setVisibility(View.GONE);
        imageView2.setVisibility(View.GONE);
        imageView3.setVisibility(View.GONE);
        progressBar1.setVisibility(View.VISIBLE);
        progressBar2.setVisibility(View.INVISIBLE);
        progressBar3.setVisibility(View.INVISIBLE);
        imageView1.setImageResource(R.drawable.green_check_mark);
        imageView2.setImageResource(R.drawable.green_check_mark);
        imageView3.setImageResource(R.drawable.green_check_mark);
    }

    public void linkingFailedLayout() {
        progressBar1.setVisibility(View.INVISIBLE);
        progressBar2.setVisibility(View.INVISIBLE);
        progressBar3.setVisibility(View.INVISIBLE);
        imageView1.setVisibility(View.VISIBLE);
        imageView2.setVisibility(View.VISIBLE);
        imageView3.setVisibility(View.VISIBLE);
        imageView1.setImageResource(R.drawable.red_canceled_mark);
        imageView2.setImageResource(R.drawable.red_canceled_mark);
        imageView3.setImageResource(R.drawable.red_canceled_mark);
    }

    public void updateViews() {
        linkedSensorTextView.setText(Objects.firstNonNull(transmitterStateModel.getLinkedSensorId(), Utils.unknownString));
        unlinkedSensorTextView.setText(Objects.firstNonNull(transmitterStateModel.getUnLinkedSensorId(), Utils.unknownString));
    }

    @Override
    protected void onResume() {

        loadData();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                if (!linkingInProgress) {
                    progressDialog.dismiss();
                }
            }
        }, GraphUtils.MINUTE / 6);
        super.onResume();
    }

    // Step 2 finished
    private void dataSentToTransmitter() {
        // tag:linking|array

        progressBar2.setVisibility(View.INVISIBLE);
        imageView2.setVisibility(View.VISIBLE);
        imageView2.setImageResource(R.drawable.green_check_mark);
        progressBar3.setVisibility(View.VISIBLE);

        BluetoothUtils.linkingRequestsInitialized = false;

        if (transmitterStateModel.getUnLinkedSensorId() != null) {
            // 3. link the new sensor
            linkingState = LinkingState.STEP3;
            sendNewSensorIdExecuted = true;
            Log.d("Linking", "Step 3: link the new sensor");
            getService().postWriteSensorID(Long.valueOf(transmitterStateModel.getUnLinkedSensorId()));
            loadData();
        } else {
            imageView3.setVisibility(View.VISIBLE);
            imageView3.setImageResource(R.drawable.red_alert_mark);
        }
    }

    /** #4021 Time change not triggered before linking the sensor */
    private void updateTransmitterTime() {
        transmitterStateModel.adjustLastReadDateTimeWhenSendingReadCommand();
        bluetoothServiceCommandClient.postReadCurrentTransmitterDateAndTime();
    }

    private void checkTransmitterDateTimePre() {
        checkTxTimeCounter = 0;
        updateTransmitterTime();
        checkAndSyncTransmitterDateTimeHandler = null;
        checkAndSyncTransmitterDateTimeHandler = new Handler();
        checkAndSyncTransmitterDateTimeHandler.postDelayed(checkAndSyncTransmitterDateTimeRunnable, 5 * GraphUtils.SECOND);
    }

    private long getTxHHDTimeDiff() {
        long txTime = transmitterStateModel.getTransmitterTime();
        Log.d("#4021", "Pre Sensor linking : tx time -> " + txTime);

        long timeDiff = txTime - Calendar.getInstance().getTimeInMillis();
        Log.d("#4021", "Time diff: " + timeDiff);

        return Math.abs(timeDiff);
    }

    private void resetCheckTxTimeCounter() {
        checkTxTimeCounter = 0;
    }

    private void checkAndSyncTransmitterDateTime() {
        checkTxTimeCounter ++;

        long timeDiff = getTxHHDTimeDiff();

        if (timeDiff > 3 * GraphUtils.MINUTE) {
            if (checkTxTimeCounter >= 5) {
                // fail
                resetCheckTxTimeCounter();

                linkingError = MLSensorLinkingError.SyncTransmitterTimeFailure;
                displayLinkingFailure();

                return;
            }

            updateTransmitterTime();
            if (checkAndSyncTransmitterDateTimeHandler != null) {
                checkAndSyncTransmitterDateTimeHandler.postDelayed(checkAndSyncTransmitterDateTimeRunnable, 5 * GraphUtils.SECOND);
            }
        }
        else {
            resetCheckTxTimeCounter();
            removeCheckAndSyncTransmitterDateTimeCallBack();

            new CheckFWCompatibilityTask().execute();
        }
    }

    private Runnable checkAndSyncTransmitterDateTimeRunnable = new Runnable() {
        @Override
        public void run() {
            checkAndSyncTransmitterDateTime();
        }
    };

    // #3599 Force glucose measurement at the last step of sensor linking process (Android)
    private void linkCheck() {
        linkCheckCounter ++;

        if ((avPlaceSensor == null) || (avPlaceSensor != null && !avPlaceSensor.isShowing())) { /** if no alert is showing */
            avPlaceSensorCounter ++;
        }

        Log.d("Linking", "linkCheckCounter: " + linkCheckCounter);
        Log.d("Linking", "avPlaceSensorCounter: " + avPlaceSensorCounter);

        if (avPlaceSensorCounter % 6 == 0) {
            displayPlaceSensorDialogWithMessageIfNeeded(getString(R.string.complete_sensor_linking_text));
        }

        /** 1. Get state copy */
        Log.d("Linking", "1. Get state copy");

        /** 2. Check Insertion Date */
        Boolean needForceRead = true;
        Boolean insertionDateSet = false;

        Calendar newInsertionDate = transmitterStateModel.getSensorInsertionDateAndTime();
        if (oldSensorInsertionDate == null) {
            if (newInsertionDate != null) {
                insertionDateSet = true;
            }
        }
        else {
            if (newInsertionDate.compareTo(oldSensorInsertionDate) != 0) {
                insertionDateSet = true;
            }
        }

        Log.d("Linking", "2. Check Insertion Date: old->" + oldSensorInsertionDate + " new->" + newInsertionDate + " -> isSet? " + insertionDateSet);
        if (insertionDateSet) {
            /** 3. Read Current Phase */
            Utils.CAL_PHASE currentCalPhase = transmitterStateModel.getCurrentCalibrationPhase();
            Log.d("Linking", "3. Read Current Phase: " + currentCalPhase + "(" + transmitterStateModel.getCurrentPhaseNotTranslated() + ")");

            if (currentCalPhase != Utils.CAL_PHASE.UNKNOWN) {
                needForceRead = false;
            }
        }

        Log.d("Linking", "4. needForceRead? " + needForceRead);

        if (needForceRead == true) {
            getService().postForceGlucoseMeasurement();
            getService().postLinkedSensorId();
            getService().postReadUnlinkedSensorIdRequest();
            getService().postSensorInsertionDate();
            getService().postSensorInsertionTime();
            getService().postCurrentCalibrationPhaseRequest();

            if (linkCheckHander != null) {
                linkCheckHander.postDelayed(linkCheckRunnable, 5 * GraphUtils.SECOND);
            }
        }
        else {
            Log.d("Linking", "5. Link Finished! (" + Thread.currentThread() + ")");

            linkCheckCounter = 0;
            avPlaceSensorCounter = 0;

            if (avPlaceSensor != null && avPlaceSensor.isShowing()) {
                avPlaceSensor.dismiss();
                avPlaceSensor = null;
            }

            removeLinkCheckCallBack();

            /** Finish step 3 */
            step3Finished();
        }
    }

    private Runnable linkCheckRunnable = new Runnable() {
        @Override
        public void run() {
            Log.d("Linking", "--- RUN ---");
            linkCheck();
        }
    };

    // Step 3 finished
    private void step3Finished() {
        progressBar3.setVisibility(View.INVISIBLE);
        imageView3.setVisibility(View.VISIBLE);
        imageView3.setImageResource(R.drawable.green_check_mark);

        // Update alert flags to clear any no-sensor flags that might have been present
        getService().postReadSensorGlucoseAlertsAndStatus();
        getService().postReadSignalStrengthRequest();

        // Re-read sensor info at this point to make sure we are in sync
        /** sendNewSensorIdExecuted = false; */
        loadData();

        progressDialog.dismiss();
        linkingInProgress = false;
    }

    public void loadData() {
        if (transmitterStateModel.isTransmitterConnected()) {
            unlinkedSensorSerialNumberArrived = false;
            linkedSensorSerialNumberArrived = false;
            if (!progressDialog.isShowing()) {
                progressDialog.show();
            }
            getService().postReadSensorIdRequest();
            getService().postReadUnlinkedSensorIdRequest();
        }
    }

    public String createDynamicPassword(String data) {
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        String date = (String) DateFormat.format("MMddyyyy", calendar);
        return createHash(data, date);
    }

    public String createHash(String data, String salt) {
        Mac sha256_HMAC;
        try {
            sha256_HMAC = Mac.getInstance("HmacSHA256");

            SecretKeySpec secret_key = new SecretKeySpec(salt.getBytes(),
                    "HmacSHA256");
            sha256_HMAC.init(secret_key);

            byte[] bytes = sha256_HMAC.doFinal(data.getBytes("ASCII"));

            StringBuffer hash = new StringBuffer();
            for (int i = 0; i < bytes.length; i++) {
                String hex = Integer.toHexString(0xFF & bytes[i]);
                if (hex.length() == 1) {
                    hash.append('0');
                }
                hash.append(hex);
            }
            return hash.toString();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getSensorFileNameBasedOnAlgoFormateVersion(String sensorId) {
        String sensorFileName = null;

        // Get the algorithm format version
        int algoFile_version = transmitterStateModel.getAlgorithmParameterFormatVersion();

        if(algoFile_version >= 4) {
            sensorFileName = algoFile_version + "00Sensor" + sensorId + kBaseFileExtension;
        }
        else {
            sensorFileName = "Sensor" + sensorId + kBaseFileExtension;
        }

        Log.d("Algo format version", "Get sensor file name:" + sensorFileName);

        return sensorFileName;
    }

    private String generatePassword() {
        List<Integer> kBasePWArray = Arrays.asList(97, 100, 109, 105, 110, 49,
                36);
        String password = "";
        for (int i = 0; i < kBasePWArray.size(); ++i) {
            password += (char) kBasePWArray.get(i).intValue();
        }

        return password;
    }

    private String checkMMAandTXcompatibility() {
        String password = generatePassword();
        String username = password.substring(0, 5);

        username = createDynamicPassword(username);
        password = createDynamicPassword(password);

        if (username != null && password != null) {
            try {
                String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">\n"
                        + "<soapenv:Header/>\n"
                        + "<soapenv:Body>\n"
                        + "<tem:CompatibilityFileInputInfo>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:UserName>%username</tem:UserName>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:Password>%password</tem:Password>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:AppOS>1</tem:AppOS>\n" // 1 is Android
                        + "<!--Optional:-->\n"
                        + "<tem:AppVersion>%appversion</tem:AppVersion>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:FWVersion>%fwversion</tem:FWVersion>\n"
                        + "</tem:CompatibilityFileInputInfo>\n"
                        + "</soapenv:Body>\n" + "</soapenv:Envelope>\n";

                String appVersion = "";
                try {
                    PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                    appVersion = String.valueOf(pInfo.versionName);
                }
                catch (PackageManager.NameNotFoundException ex) {
                }

                String fwVersion = transmitterStateModel.getFormattedTransmitterVersionNumber();
                if (fwVersion == null) {
                    fwVersion = "";
                }

                requestString = requestString
                        .replace("%username", username)
                        .replace("%password", password)
                        .replace("%appversion", appVersion)
                        .replace("%fwversion", fwVersion);

                Utils.printLongLog(SensorListActivity.class.getSimpleName(), "checkMMAandTXcompatibility:" + requestString);
                HttpPost httpPost = new HttpPost(Utils.calibrationServer);
                StringEntity entity;

                entity = new StringEntity(requestString, HTTP.UTF_8);
                httpPost.setHeader("Content-Type", "text/xml; charset=utf-8");
                httpPost.setHeader("SOAPAction", Utils.kAppFWCompatibilityCheckWebserviceFunctionCall);
                httpPost.setEntity(entity);

                HttpParams httpParameters = new BasicHttpParams();
                HttpConnectionParams
                        .setConnectionTimeout(httpParameters, 25000);
                HttpConnectionParams.setSoTimeout(httpParameters, 25000);
                HttpProtocolParams.setHttpElementCharset(httpParameters,
                        HTTP.UTF_8);
                HttpClient client = new DefaultHttpClient(httpParameters);
                HttpResponse response;
                try {
                    response = client.execute(httpPost);
                    return EntityUtils.toString(response.getEntity());
                } catch (ClientProtocolException e) {

                    e.printStackTrace();
                } catch (SocketTimeoutException e) {
                    linkingError = MLSensorLinkingError.Timeout;
                    Utils.printLongLog(SensorListActivity.class.getSimpleName(), "Socket timeout");
                } catch (ConnectTimeoutException e) {
                    linkingError = MLSensorLinkingError.Timeout;
                    Utils.printLongLog(SensorListActivity.class.getSimpleName(), "Connect timeout");
                } catch (IOException e) {
                    linkingError = MLSensorLinkingError.ServerError;
                    e.printStackTrace();
                }
                if (linkingError != MLSensorLinkingError.None) {
                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            displayLinkingFailure();
                        }
                    });
                }

                return "-1";
            } catch (UnsupportedEncodingException e) {
                Utils.printLongLog(SensorListActivity.class.getSimpleName(), "exception:" + e.getMessage());
                e.printStackTrace();
                return "-1";
            }
        }
        return null;
    }

    public class CheckFWCompatibilityTask extends AsyncTask<Void, Void, Void> {
        private String response;

        @Override
        protected Void doInBackground(Void... params) {
            response = checkMMAandTXcompatibility();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            Utils.printLongLog(SensorListActivity.class.getSimpleName(), "Compatibility response:" + response);

            if (response != null && !response.equals("-1")) {
                if (response.contains("true")) { // found true
                    // Step 1
                    linkDetectedSensorLayout.setVisibility(View.GONE);
                    linkingState = LinkingState.STEP1;
                    prepareLinkingLayout();
                    linkingLayout.setVisibility(View.VISIBLE);
                    new SenseAsynctask().execute();
                }
                else {
                    linkingError = MLSensorLinkingError.IncompatibleFWVersion;
                    displayLinkingFailure();
                }
            } else {
                if (response == null) {
                    linkingError = MLSensorLinkingError.NotConnectedToWifi;
                    displayLinkingFailure();
                }
            }
            super.onPostExecute(result);
        }

    }

    public String startDownloadingAndSyncingOfEEPROMAndATCCALParameters(
            String sensorId) {
        String password = generatePassword();
        String username = password.substring(0, 5);

        username = createDynamicPassword(username);
        password = createDynamicPassword(password);

        linkingError = MLSensorLinkingError.None;

        if (username != null && password != null) {

            String sensorFileName = this.getSensorFileNameBasedOnAlgoFormateVersion(sensorId);
            String finalString = sensorFileName + "%u%p";
            finalString = finalString.replace("%u", username).replace("%p", password);

            byte[] bytes;
            try {
                Log.d("finalString", finalString + " ");
                bytes = finalString.getBytes("UTF-8");
                int crc = GetCRCValue(bytes);

                String requestString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">\n"
                        + "<soapenv:Header/>\n"
                        + "<soapenv:Body>\n"
                        + "<tem:CalibrationFileInfoEx>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:ATCCALFetchFlag>1</tem:ATCCALFetchFlag>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:CRC>%crc</tem:CRC>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:EEPROMFetchFlag>1</tem:EEPROMFetchFlag>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:FileName>%id</tem:FileName>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:Password>%password</tem:Password>\n"
                        + "<!--Optional:-->\n"
                        + "<tem:UserName>%username</tem:UserName>\n"
                        + "</tem:CalibrationFileInfoEx>\n"
                        + "</soapenv:Body>\n" + "</soapenv:Envelope>\n";

                requestString = requestString
                        .replace("%crc", String.valueOf(crc))
                        .replace("%id", sensorFileName)
                        .replace("%password", password)
                        .replace("%username", username);

                Log.d("request string", requestString + " ");
                HttpPost httpPost = new HttpPost(Utils.calibrationServer);
                StringEntity entity;

                entity = new StringEntity(requestString, HTTP.UTF_8);
                httpPost.setHeader("Content-Type", "text/xml; charset=utf-8");
                httpPost.setHeader("SOAPAction", Utils.webserviceFunction);
                // httpPost.setHeader("Content-Length",
                // String.valueOf(requestString.length()));
                httpPost.setEntity(entity);

                HttpParams httpParameters = new BasicHttpParams();
                HttpConnectionParams
                        .setConnectionTimeout(httpParameters, 25000);
                HttpConnectionParams.setSoTimeout(httpParameters, 25000);
                HttpProtocolParams.setHttpElementCharset(httpParameters,
                        HTTP.UTF_8);
                HttpClient client = new DefaultHttpClient(httpParameters);
                HttpResponse response;
                try {
                    response = client.execute(httpPost);
                    return EntityUtils.toString(response.getEntity());
                } catch (ClientProtocolException e) {

                    e.printStackTrace();
                } catch (SocketTimeoutException e) {
                    linkingError = MLSensorLinkingError.Timeout;
                    Log.d("Socket timeout", " - ");
                } catch (ConnectTimeoutException e) {
                    linkingError = MLSensorLinkingError.Timeout;
                    Log.d("Connect timeout", " - ");
                } catch (IOException e) {
                    linkingError = MLSensorLinkingError.ServerError;
                    e.printStackTrace();
                }
                if (linkingError != MLSensorLinkingError.None)
                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            displayLinkingFailure();
                        }
                    });

                return "-1";
            } catch (UnsupportedEncodingException e) {
                Log.d("exception", "----");
                e.printStackTrace();
                return "-1";
            }
        }
        return null;
    }

    public class SenseAsynctask extends AsyncTask<Void, Void, Void> {

        private String response;

        @Override
        protected Void doInBackground(Void... params) {
            if (transmitterStateModel.getUnLinkedSensorId() != null) {
                response = startDownloadingAndSyncingOfEEPROMAndATCCALParameters(transmitterStateModel.getUnLinkedSensorId());
            }
            else {
                response = "-1";
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            Utils.printLongLog(SensorListActivity.class.getSimpleName(), "get sensor file response:" + response);

            if (response != null && !response.equals("-1")) {
                parseResponse(response);
            } else {
                linkingFailedLayout();
                if (response == null) {
                    linkingError = MLSensorLinkingError.NotConnectedToWifi;
                    displayLinkingFailure();
                }
            }
            super.onPostExecute(result);
        }

    }

    public void parseResponse(String response) {
        linkingState = LinkingState.STEP2;
        XmlPullParserFactory xmlFactoryObject;
        String expectedCRC = null, eepromString = null, atccalString = null;

        try {
            xmlFactoryObject = XmlPullParserFactory.newInstance();
            XmlPullParser parser = xmlFactoryObject.newPullParser();
            InputStream stream = new ByteArrayInputStream(response.getBytes());
            parser.setInput(stream, null);

            int event = parser.getEventType();
            int index = 0;
            while (event != XmlPullParser.END_DOCUMENT) {
                String name = parser.getName();
                if (name != null)
                    Log.d(" PARSE -- NAME --", name);
                switch (event) {
                    case XmlPullParser.START_TAG:
                        break;
                    case XmlPullParser.TEXT:
                        String text = parser.getText();
                        if (text != null) {
                            Log.d("text", text + " " + index);
                            switch (index) {
                                case MLResponseMessageArgument_CRC:
                                    expectedCRC = text;
                                    break;
                                case MLResponseMessageArgument_EEPROM:
                                    eepromString = text;
                                    break;
                                case MLResponseMessageArgument_ATCCAL:
                                    atccalString = text;
                                    break;
                                default:
                                    break;
                            }
                            ++index;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        break;
                }
                event = parser.next();
            }
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Utils.printLongLog(SensorListActivity.class.getSimpleName(), "expectedCRC:" + expectedCRC + "|eepromString:" + eepromString + "|atccalString:" + atccalString);

        if (expectedCRC != null && eepromString != null && atccalString != null) {
            String calculate = eepromString + atccalString;
            byte[] bytes;
            try {
                bytes = calculate.getBytes("UTF-8");
                int actualCRC = GetCRCValue(bytes);

                if (actualCRC != Integer.valueOf(expectedCRC)) {
                    linkingFailedLayout();
                    linkingError = MLSensorLinkingError.UnableToDownloadSensorFile;
                    displayLinkingFailure();
                } else {
                    // if CRC is ok
                    parseAndSendEEPROMAndATCCALString(eepromString,
                            atccalString);
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        else {
            linkingFailedLayout();
            linkingError = MLSensorLinkingError.UnableToDownloadSensorFile;
            displayLinkingFailure();
        }
    }

    public void parseAndSendEEPROMAndATCCALString(String eepromString,
                                                  String atccalString) {
        updateEEPROMAndATCCALValues(eepromString, atccalString);

        // get sensor file version: the first byte in the atc byte
        // array string
        if (atccalString.length() >= 2) {
            fileVersionString = atccalString.substring(0, 2);
            Integer fileVersion = Integer.parseInt(fileVersionString, 16);
            Log.d("Version", fileVersion + " " + fileVersionString);

            // Get the algorithm format version
            int algoFile_version = transmitterStateModel.getAlgorithmParameterFormatVersion();

            Boolean checkPass = true;

            // #2555, 2564: new sensor file version 4
            if(fileVersion >= 4) {
                if(algoFile_version >= 4) {
                    if(fileVersion == algoFile_version) {
                        Log.d("Algo format version", "Compatibility check passes 0");
                    }
                    else {
                        Log.d("Algo format version", "Compatibility check failed 0");
                        checkPass = false;
                    }
                }
                else {
                    Log.d("Algo format version", "Compatibility check failed 1");
                    checkPass = false;
                }
            }
            else if(fileVersion >= 2) {
                if(algoFile_version == 0) {
                    Log.d("Algo format version", "Compatibility check passes 2");
                }
                else {
                    Log.d("Algo format version", "Compatibility check failed 2");
                    checkPass = false;
                }
            }
            else {
                Log.d("Algo format version", "Compatibility check failed 3");
                checkPass = false;
            }

            if(checkPass == true) {
                linkingError = MLSensorLinkingError.None;
            }
            else {
                addressAndValuesEEPROM = null;
                addressAndValuesACT = null;
                linkingError = MLSensorLinkingError.IncompatibleSensorFile;
            }
        }

        if (linkingError == MLSensorLinkingError.None) {
            if (addressAndValuesEEPROM != null && addressAndValuesACT != null) {
                // Step 1 finished
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        progressBar1.setVisibility(View.INVISIBLE);
                        imageView1.setVisibility(View.VISIBLE);
                        progressBar2.setVisibility(View.VISIBLE);
                    }
                });

                // 1. unlink the current sensor
                BluetoothUtils.linkingRequestsInitialized = true;
                BluetoothUtils.linkingPacketsNumber = 0;
                int countOfRequests = 0;

                getService().postWriteSensorID(0xFFFFFFFFL);

                // 2. write new eeprom and atccal
                // (includes glucose paramter version number)
                countOfRequests = getService().postWriteTransmitterChunk(addressAndValuesEEPROM, 0x0A24, 12);
                BluetoothUtils.linkingPacketsNumber += countOfRequests;

                int[] subarray1 = new int[addressAndValuesACT.length - 12];
                System.arraycopy(addressAndValuesACT, 12, subarray1, 0, addressAndValuesACT.length - 12);
                int addressACT = 0x1200;
                countOfRequests = getService().postWriteTransmitterChunk(subarray1, addressACT + 12, 12);
                BluetoothUtils.linkingPacketsNumber += countOfRequests;

                int[] subarray2 = new int[12];
                System.arraycopy(addressAndValuesACT, 0, subarray2, 0, 12);
                countOfRequests = getService().postWriteTransmitterChunk(subarray2, addressACT, 12);
                BluetoothUtils.linkingPacketsNumber += countOfRequests;
                // this chunk must be written last in order to ensure that
                // the Transmitter reads in the new values (0x1200 is used
                // to trigger the transmitter to read in all changes to the
                // memory chunk)
                Log.d("Linking", "linkingPacketsNumber total: " + BluetoothUtils.linkingPacketsNumber);

            } else {
                linkingError = MLSensorLinkingError.UnableToDownloadSensorFile;
            }
        }

        if (linkingError != MLSensorLinkingError.None) {
            linkingFailedLayout();
            displayLinkingFailure();
        }

    }

    public void updateEEPROMAndATCCALValues(String eepromString,
                                            String atccalString) {
        String[] array = eepromString.split(",");

        addressAndValuesEEPROM = new int[kNumberEEPROMBlocks * 2];
        int index = 0;
        for (int i = 3; i < array.length; ++i) {

            int value = Integer.valueOf(array[i]);

            if (index < addressAndValuesEEPROM.length)
                addressAndValuesEEPROM[index] = (value & 0xff);
            ++index;
            if (index < addressAndValuesEEPROM.length)
                addressAndValuesEEPROM[index] = ((value & 0xff00) >> 8);

            // Log.d("----VALUE----", array[i] + ": "
            // + addressAndValuesEEPROM[index - 1] + " "
            // + addressAndValuesEEPROM[index]);
            ++index;
        }

        addressAndValuesACT = new int[atccalString.length() / 2];
        index = 0;
        for (int i = 0; i < atccalString.length(); i += 2) {
            String string = atccalString.substring(i, i + 2);
            if (string.length() > 0) {
                int value = Integer.parseInt(string, 16);
                addressAndValuesACT[index] = value;
                ++index;
            }
        }

        Log.d("Linking", "atccalString:" + atccalString);
    }

    public void displayLinkingFailure() {
        progressDialog.dismiss();
        linkingInProgress = false;

        String title = "", message = "";
        switch (linkingError) {
            case IncompatibleSensorFile:
                title = getString(R.string.incompatible_sensor_file);
                if (fileVersionString != null) {
                    message = getString(R.string.incompatible_sensor_file_text)
                            .replace("%%", fileVersionString);
                } else {
                    message = getString(R.string.incompatible_sensor_file_text)
                            .replace("%%", Utils.NotAvailable);
                }
                break;
            case NotConnectedToWifi:
                title = getString(R.string.wi_fi_disconnected);
                message = getString(R.string.wi_fi_disconnected_text);
                break;
            case ServerError:
                title = getString(R.string.server_error);
                message = getString(R.string.server_error_text);
                break;
            case CorruptedData:
                title = getString(R.string.file_corrupted);
                message = getString(R.string.file_corrupted_text);
                break;
            case UnableToDownloadSensorFile:
                title = getString(R.string.sensor_file_error);
                message = getString(R.string.sensor_file_error_text);
                break;
            case TransmitterError:
                title = getString(R.string.transmitter_error_alarm_title);
                message = getString(R.string.transmitter_error_alarm_message_2);
                break;
            case IncompatibleFWVersion:
                title = getString(R.string.incompatible_fw_version_title_2);
                message = getString(R.string.incompatible_fw_version_body_2);
                break;
            case SyncTransmitterTimeFailure:
                title = getString(R.string.sensor_link_failure_title);
                message = getString(R.string.sensor_link_failure_body);
                break;
            case Timeout:
                title = getString(R.string.request_timeout);
                message = getString(R.string.request_timeout_text);
                break;
            case None:
                break;
            default:
                title = getString(R.string.unknown_error);
                message = getString(R.string.unknown_error_text);
                break;
        }

        if (this.isThisActivityTop()) {
            if (dialog != null && dialog.isShowing())
                dialog.dismiss();
            dialog = dialogUtils.createWarningDialog(this, new WarningDialogInfo(-1,
                    title, message));
            dialog.show();
        }
    }

    // Generate a 16 bit crc (CCITT CRC 16)
    public int GetCRCValue(byte[] bytes) {
        int polynomial = 0x11021;
        int crc = 0xffff;
        int curbyte;
        int bit;

        for (curbyte = 0; curbyte < bytes.length; ++curbyte) {
            int temp = bytes[curbyte];
            crc ^= (temp << 8);

            for (bit = 8; bit > 0; --bit) {
                if ((crc & 0x00008000) > 0)
                    crc = (crc << 1) ^ polynomial;
                else
                    crc = (crc << 1);
            }
        }
        return ((crc) ^ 0x0000);
    }

    private void removeLinkCheckCallBack() {
        if (linkCheckHander != null) {
            Log.d("Linking", "----- removeLinkCheckCallBack -----");
            linkCheckHander.removeCallbacks(linkCheckRunnable);
            linkCheckHander = null;
        }
    }

    private void removeCheckAndSyncTransmitterDateTimeCallBack() {
        if (checkAndSyncTransmitterDateTimeHandler != null) {
            checkAndSyncTransmitterDateTimeHandler.removeCallbacks(checkAndSyncTransmitterDateTimeRunnable);
            checkAndSyncTransmitterDateTimeHandler = null;
        }
    }

    private void displayPlaceSensorDialogWithMessageIfNeeded(String message) {
        if (this.isThisActivityTop()) {
            if (avPlaceSensor == null) {
                Log.d("Linking", "Create avPlaceSensor");
                avPlaceSensor = dialogUtils.createWarningDialog(this, new DialogUtils.WarningDialogInfo(-1, null, message));
            }

            Log.d("Linking", "avPlaceSensor isShowing?" + avPlaceSensor.isShowing());
            if (avPlaceSensor.isShowing() == false) {
                Log.d("Linking", "avPlaceSensor need to show!!");
                avPlaceSensor.show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        removeCheckAndSyncTransmitterDateTimeCallBack();
        removeLinkCheckCallBack();
        unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }
}
