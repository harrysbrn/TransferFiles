package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothManager;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;

import com.senseonics.gen12androidapp.ApplicationModule;
import com.senseonics.gen12androidapp.BuildConfig;
import com.senseonics.graph.GraphCacheIntentService;

import java.util.concurrent.TimeUnit;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;

import static com.senseonics.gen12androidapp.Constants.IS_FOREGROUND;

@Module(
        library = true,
        addsTo = ApplicationModule.class,
        injects = {BluetoothService.class, GraphCacheIntentService.class}
)
public class ServiceModule {
    private Context context;

    public ServiceModule(Context context) {
        this.context = context;
    }

    @Provides
    protected ContentResolver provideContentResolver(Context context) {
        return context.getContentResolver();
    }

    @Provides
    @Named("SCAN_PERIOD_MILLISECONDS")
    protected long provideScanPeriodMilliseconds() {
        return TimeUnit.SECONDS.toMillis(2);
    }

    @Provides
    @Named("DISCONNECT_INTERVAL_INITIAL")
    protected long provideDisconnectIntervalInitial() {
        return TimeUnit.MINUTES.toMillis(3);
    }

    @Provides
    @Named("DISCONNECT_INTERVAL_FOLLOWUP")
    protected long provideDisconnectIntervalFollowUp() {
        return TimeUnit.MINUTES.toMillis(30);
    }

    @Provides
    @Named("DISCONNECT_RETRY_LIMIT")
    protected int provideDisconnectRetryLimit() {
        return 12;
    }

    @Provides
    @Named("DISCONNECT_EXPIRY_PERIOD")
    protected long provideDisconnectExpiryPeriod() {
        return TimeUnit.HOURS.toMillis(6) + provideDisconnectIntervalFollowUp() / 2;
    }

    @Provides
    protected BluetoothManager provideBluetoothManager(Context context) {
        return (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
    }

    @Provides
    @Named("transmitter")
    protected Uri provideTransmitterContentProviderUri() {
        return Uri.parse("content://" + BuildConfig.APPLICATION_ID + ".transmitter");
    }

    @Provides
    protected BluetoothService providesBluetoothService() {
        return (BluetoothService) context;
    }

    @Provides
    @Named(IS_FOREGROUND)
    boolean provideIsForeground() {
        return true;
    }
}
