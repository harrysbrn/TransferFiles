package com.senseonics.bluetoothle;

public class HexHelper {
    private static char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

    public static String intArrayToString(int[] numbers) {
        StringBuilder sb = new StringBuilder();
        if (numbers != null) {
            for (int number : numbers) {
                sb.append(String.format("%02x", number).toUpperCase());//.append('.');
            }
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length());
        }
        return sb.toString().toUpperCase();
    }


    public static String intArrayToString(byte[] bytes) {
        if (bytes == null) {
            return "";
        }
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars).toUpperCase();
    }

    public static int[] calculateDateFromBytes(int[] bytes) {

        int year;
        int month;
        int day;

        int returnValue[] = new int[3];

        year = bytes[1];
        year = ((year >> 1) + 2000);

        month = bytes[0];
        month = month >> 5;
        if (bytes[1] % 2 == 1)
            month = month + 8;

        day = bytes[0];
        day = day & 31;

        returnValue[0] = year;
        returnValue[1] = month;
        returnValue[2] = day;

        return returnValue;
    }

    public static int[] calculateTimeFromBytes(int[] bytes) {

        int hour;
        int minute;
        int second;

        int[] returnValue = new int[3];

        hour = bytes[1];
        hour = hour >> 3;

        minute = bytes[0];
        int m3MSB = (bytes[1] & 7) << 3;
        minute = (minute >> 5) | m3MSB;

        second = bytes[0];
        second = (second & 31) * 2;

        returnValue[0] = hour;
        returnValue[1] = minute;
        returnValue[2] = second;

        return returnValue;
    }
}
