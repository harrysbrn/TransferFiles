package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class UnLinkedSensorIdAddressFourByteMemoryMapParsedResponse implements FourByteMemoryMapParsedResponse {

    @Inject
    public UnLinkedSensorIdAddressFourByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.unlinkedSensorIDAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        long fullSensorID = dataOne | (dataTwo << 8) | (dataThree << 16) | ((long)dataFour << 24);
        int unLinkedsensorID = dataOne | (dataTwo << 8) | (dataThree << 16);

        if (!Utils.isValidSensorID(fullSensorID) || (unLinkedsensorID == 0)) {
            model.setUnLinkedSensorId(null);
        } else {
            model.setUnLinkedSensorId(String.valueOf(unLinkedsensorID));
        }

    }
}
