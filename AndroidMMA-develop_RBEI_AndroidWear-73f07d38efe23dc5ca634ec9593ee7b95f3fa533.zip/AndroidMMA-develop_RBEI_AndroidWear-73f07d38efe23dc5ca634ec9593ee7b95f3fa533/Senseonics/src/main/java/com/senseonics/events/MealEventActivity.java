package com.senseonics.events;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventUtils.MEAL_TYPE;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.util.ArrayList;

public class MealEventActivity extends EventActivity {

	private PickerManager mealTypeManager;
	private String mealTypeName;
	private MEAL_TYPE mealType = MEAL_TYPE.BREAKFAST;
	private TextView mealTypeTextView, carbsTextView;
	private int selectedCarbs = 15;
	private int minCarbs = 1, maxCarbs = 300;
	private Dialog dialog;
	private ArrayList<Item> carbs;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.meal_event);
		
		LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.dialog_meal_event, contentLayout);

		carbs = dialogUtils.getNumbersBetween(minCarbs, maxCarbs, 1);

		RelativeLayout mealTypeLayout = (RelativeLayout) findViewById(R.id.mealTypeLayout);
		RelativeLayout carbsLayout = (RelativeLayout) findViewById(R.id.carbsLayout);

		mealTypeTextView = (TextView) findViewById(R.id.mealType);
		carbsTextView = (TextView) findViewById(R.id.carbsValue);

		mealTypeManager = new PickerManager() {

			@Override
			public void selected(int id) {
				setMealType(id);
			}
		};
		mealTypeLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventUtils.createMealTypePicker(MealEventActivity.this,
						getResources().getString(R.string.type),
						mealTypeManager, mealType.ordinal());
			}
		});

		final PickerManager manager = new PickerManager() {

			@Override
			public void selected(int id) {

				selectedCarbs = dialogUtils.getGlucoseValueMg(carbs.get(id)
						.getValue());
				String carbsString = selectedCarbs + " "
						+ getString(R.string.grams);
				carbsTextView.setText(carbsString);
			}
		};
		carbsLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (dialog != null && dialog.isShowing())
					dialog.dismiss();

				int position = getPosition(selectedCarbs);
				dialog = dialogUtils.createPickerDialog(MealEventActivity.this,
						getString(R.string.carbs), carbs, manager, position);
				dialog.show();
			}
		});

		int position;
		if (eventPoint != null) {
			position = getPosition(((MealEventPoint) eventPoint).getCarbs());
			setMealType(((MealEventPoint) eventPoint).getMealType().ordinal());
		} else {
			position = getPosition(selectedCarbs);
			setMealType(mealType.ordinal());
		}
		manager.selected(position);
	}

	public void setMealType(int id) {
		mealType = EventUtils.MEAL_TYPE.values()[id];
		mealTypeName = EventUtils.getMealTypeName(MealEventActivity.this,
				mealType);
		mealTypeTextView.setText(mealTypeName);
	}

	public int getPosition(int value) {
		return Utils.getItemPosition(carbs, value);
	}

	@Override
	public void onSavePressed() {
		super.onSavePressed();

		MealEventPoint mealEventPoint = null;
		if (isEditing) {
			mealEventPoint = new MealEventPoint(eventPoint.getDatabaseId(),
					currentDate, glucoseLevel, mealType, selectedCarbs,
					notesEditText.getText().toString());
			databaseManager.updateEvent(mealEventPoint);
		} else {
			mealEventPoint = new MealEventPoint(currentDate, glucoseLevel,
					mealType, selectedCarbs, notesEditText.getText().toString());
			int rowId = (int) databaseManager.addEvent(mealEventPoint, false);
			mealEventPoint.setDatabaseId(rowId);
		}

		BluetoothPairBaseActivity.patientEventPoints.add(mealEventPoint);
		getService().postWritePatientEventPoint(mealEventPoint);

		finish();
	}

}
