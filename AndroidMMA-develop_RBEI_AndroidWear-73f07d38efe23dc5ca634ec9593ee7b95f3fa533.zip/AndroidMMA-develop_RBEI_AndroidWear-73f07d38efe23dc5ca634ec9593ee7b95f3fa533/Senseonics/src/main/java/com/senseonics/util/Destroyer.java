package com.senseonics.util;

public class Destroyer {
  public static void destroy(IDestroyable... destroyables) {
    for (IDestroyable destroyable : destroyables) {
      if (destroyable != null) {
        destroyable.destroy();
      }
    }
  }
}
