package com.senseonics.bluetoothle;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.senseonics.gen12androidapp.ObjectGraphApplication;
import com.senseonics.db.TransmitterPersistor;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.PatientEventPoint;
import com.senseonics.util.NotificationUtility;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;

import de.greenrobot.event.EventBus;

import static com.senseonics.gen12androidapp.Constants.BLUETOOTH_SERVICE_ID;
import static com.senseonics.gen12androidapp.Constants.IS_FOREGROUND;

public class BluetoothService extends Service {
    private BroadcastReceiver bondStateChangeReceiver;
    private BroadcastReceiver bluetoothStateChangeReceiver;
    private final IBinder binder = new BluetoothServiceBinder();
  @Inject protected TransmitterScanner transmitterScanner;
  @Inject protected BluetoothAdapterWrapper bluetoothAdapterWrapper;
  @Inject protected Provider<BluetoothAdapterWrapper> bluetoothAdapterWrapperProvider;
  @Inject protected Handler handler;
  @Inject @Named(IS_FOREGROUND) boolean isForeground;
  @Inject @Named("transmitter") protected Uri transmitterAuthorityUri;
  @Inject protected ConnectedTransmitterAsyncQueryHandler asyncQueryHandler;
  @Inject protected ConnectionStateModifier connectionStateModifier;
  @Inject protected EventBus eventBus;
  @Inject protected BluetoothCommunicator bluetoothCommunicator;
  @Inject protected BluetoothConnector bluetoothConnector;
  @Inject protected BluetoothManager bluetoothManager;
  @Inject protected TransmitterConnectionStates transmitterConnectionStates;
  @Inject protected RequestBlockingSet requestBlockingSet;
  @Inject protected TransmitterConnectionNotificationScheduler
      transmitterConnectionNotificationScheduler;
  @Inject protected PushNotificationListener pushNotificationListener;
  @Inject protected TransmitterPersistor transmitterPersistor;
  @Inject public CommandProcessor commandProcessor;
  @Inject protected NotificationUtility notificationUtility;
  @Inject protected MyBluetoothGattCallback bluetoothGattCallback;

  @Override public IBinder onBind(Intent intent) {
        return binder;
    }

  @Override public boolean onUnbind(Intent intent) {
        return true;
    }

  @Override public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

  @Override public void onCreate() {
        super.onCreate();
        Log.i(BluetoothService.class.getSimpleName(), "onCreate");
        ((ObjectGraphApplication) getApplication()).plus(new ServiceModule(this)).inject(this);

        bondStateChangeReceiver = new BroadcastReceiver() {
      @Override public void onReceive(Context context, Intent intent) {
                bluetoothConnector.onReceive(context, intent);
            }
        };
        bluetoothStateChangeReceiver = new BroadcastReceiver() {
      @Override public void onReceive(Context context, Intent intent) {
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
                BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Log.i(BluetoothService.class.getSimpleName(),
            "bluetooth adapter isEnabled? : " + bluetoothAdapter.isEnabled());

                switch (state) {
                    case BluetoothAdapter.STATE_ON:
            bluetoothManager = (BluetoothManager) getApplicationContext().getSystemService(
                Context.BLUETOOTH_SERVICE);
                        bluetoothAdapterWrapper = bluetoothAdapterWrapperProvider.get();
                        handler.postDelayed(new Runnable() {
              @Override public void run() {
                                eventBus.postSticky(new BluetoothConnectionEvent(true));
                                connectToPreviouslyConnectedDevice();
                            }
                        }, 200);
                        break;

                    case BluetoothAdapter.STATE_OFF:
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        eventBus.postSticky(new BluetoothConnectionEvent(false));
                        bluetoothCommunicator.disconnect();
                        bluetoothManager = null;
                        break;
                }
            }
        };
    registerReceiver(bondStateChangeReceiver,
        new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED));
    registerReceiver(bluetoothStateChangeReceiver,
        new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));

        boolean bluetoothConnectionState = bluetoothAdapterWrapper.isBluetoothEnabled();
    Log.w(BluetoothService.class.getSimpleName(),
        "create with: " + bluetoothAdapterWrapper.toString());
        eventBus.postSticky(new BluetoothConnectionEvent(bluetoothConnectionState));
        if (bluetoothConnectionState) {
            connectToPreviouslyConnectedDevice();
        }
    }

  @Override public void onDestroy() {
        Log.i(BluetoothService.class.getSimpleName(), "onDestroy");
        if (bondStateChangeReceiver != null) {
            unregisterReceiver(bondStateChangeReceiver);
        }
        if (bluetoothStateChangeReceiver != null) {
            unregisterReceiver(bluetoothStateChangeReceiver);
        }
        if (bluetoothCommunicator != null) {
            bluetoothCommunicator.disconnect();
        }
        super.onDestroy();
    }

  @Override public int onStartCommand(Intent requestIntent, int flags, int startId) {
        int result = super.onStartCommand(requestIntent, flags, startId);

        Request request = commandProcessor.process(requestIntent);
        if (request != null) {
            requestBlockingSet.put(request);
            Log.d(BluetoothService.class.getSimpleName(), "request queued: " + request);
        }

        if (isForeground) {
          startForeground(BLUETOOTH_SERVICE_ID, notificationUtility.getForegroundServiceNotification());
        }

        return result;
    }

    public void startDiscovery(final DiscoverCallback discoverCallback) {
        if (bluetoothAdapterWrapper.isBluetoothEnabled()) {
            transmitterScanner.scan(discoverCallback);
        } else {
            Log.i(BluetoothService.class.getSimpleName(), "dude, turn bluetooth on!");
        }
    }

    public boolean connect(final Transmitter transmitter, boolean shouldPublishConnecting) {
        if (!bluetoothCommunicator.disconnect()) {//TODO be smarter here, and stay connected to same BluetoothDevice if given transmitter is where we're already connected
      List<Transmitter> transmittersThatNeedDisconnecting =
          transmitterConnectionStates.transmittersThatNeedDisconnecting();
      connectionStateModifier.setConnectionStateAndPublish(transmittersThatNeedDisconnecting,
          Transmitter.CONNECTION_STATE.DISCONNECTED);
        }
        transmitterScanner.stopLeScanIfCurrentlyScanning();

        if (shouldPublishConnecting) {
            connectionStateModifier.setConnectionStateAndPublish(transmitter,
                    Transmitter.CONNECTION_STATE.CONNECTING);
        }

    final BluetoothDevice bluetoothDevice =
        bluetoothAdapterWrapper.getRemoteDevice(transmitter.getAddress());

        if (bluetoothDevice != null) {
            long delayMillis = 0L;
            if (bluetoothDevice.getBondState() == BluetoothDevice.BOND_NONE) {
                delayMillis = 3000L;
                boolean bondResult = bluetoothDevice.createBond();
                Log.i(BluetoothService.class.getSimpleName(), "bond start result: " + bondResult);
            }

            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    final int bondState = bluetoothDevice.getBondState();
                    Log.i(BluetoothService.class.getSimpleName(), "1. FIRST TIME Check state: " + bondState);

                    if (bondState == BluetoothDevice.BOND_BONDED) {
                        bluetoothConnector.beginConnection(bluetoothDevice, bluetoothGattCallback,
                                getApplicationContext());
                    }
                    else if (bondState == BluetoothDevice.BOND_BONDING) {
                        long newDelayMills = 6000L;
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int newBondState = bluetoothDevice.getBondState();
                                Log.i(BluetoothService.class.getSimpleName(), "2. SECOND TIME Check state: " + newBondState);

                                if (newBondState == BluetoothDevice.BOND_BONDED) {
                                    bluetoothConnector.beginConnection(bluetoothDevice, bluetoothGattCallback,
                                            getApplicationContext());
                                }
                                else {
                                    connectionStateModifier.setConnectionStateAndPublish(transmitter,
                                            Transmitter.CONNECTION_STATE.DISCONNECTED);
                                }
                            }
                        }, newDelayMills);
                    }
                    else {
                        connectionStateModifier.setConnectionStateAndPublish(transmitter,
                                Transmitter.CONNECTION_STATE.DISCONNECTED);
                    }
                }
            }, delayMillis);
        }
        return true;
    }

    public void disconnect(Transmitter transmitter) {
        Log.i(BluetoothService.class.getSimpleName(), "disconnect from " + transmitter);
        bluetoothCommunicator.disconnect();
        //connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
        getContentResolver().delete(transmitterAuthorityUri, null, null);
    }

    public void connectToPreviouslyConnectedDevice() {
        Log.i(BluetoothService.class.getSimpleName(), "connectToPreviouslyConnectedDevice was called");
    ConnectedTransmitterAsyncQueryHandler.Callback callback =
        new ConnectedTransmitterAsyncQueryHandler.Callback() {

          @Override public void lastConnectedTransmitter(Transmitter transmitter) {
              connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
                connect(transmitter, false);
            }

          @Override public void noLastConnectedTransmitter() {
                //do nothing here. The user has to navigate to the connections info screen to initiate a scan
            }
        };
        asyncQueryHandler.startQuery(callback);
    }

    public void postSensorGlucoseRecordRangeRequest() {
        requestBlockingSet.put(Request.readFirstAndLastSensorGlucoseRecordNumbers());
    }

    public void postSensorGlucoseAlertRecordRangeRequest() {
        requestBlockingSet.put(Request.readFirstAndLastSensorGlucoseAlertRecordNumbers());
    }

    public void postFirstAndLastBloodGlucoseDataRecordNumberRequest() {
        requestBlockingSet.put(Request.readFirstAndLastBloodGlucoseDataRecordNumber());
    }

    public void postSyncRequest(TransmitterSyncRequest request) {
    requestBlockingSet.put(new Request(request.getExpectedResponseId(), request.getData(),
        request.getHighestExpectedRecordNumber(), request.getExpectResponseCount(),
        Request.SYNC_PRIORITY));
    }

    public void postPingRequest() {
        requestBlockingSet.put(Request.ping());
    }

    public void postGetModelRequest() {
        requestBlockingSet.put(Request.model());
    }

    public void postVersionNumberRequest() {
        requestBlockingSet.put(Request.versionExtension());
        requestBlockingSet.put(Request.version());
    }

    public void postLastCalibrationDateTimeRequest() {
        requestBlockingSet.put(Request.lastCalDate());
        requestBlockingSet.put(Request.lastCalTime());
    }

    public void postPhaseStartDateTimeRequest() {
        requestBlockingSet.put(Request.phaseStartDate());
        requestBlockingSet.put(Request.phaseStartTime());
    }

    public void postCompletedCalibrationsCountRequest() {
        requestBlockingSet.put(Request.completedCalibrationsCount());
    }

    public void postCurrentCalibrationPhaseRequest() {
        requestBlockingSet.put(Request.currentCalibrationPhase());
    }

    public void postBatteryLifeRequest() {
        requestBlockingSet.put(Request.readBatteryLevelRequest());
    }

    public void postHysteresisPercentRequest() {
        requestBlockingSet.put(Request.readHysteresisPercentRequest());
    }

    public void postHysteresisValueRequest() {
        requestBlockingSet.put(Request.readHysteresisValueRequest());
    }

    public void postPredictiveHysteresisPercentRequest() {
        requestBlockingSet.put(Request.readPredictiveHysteresisPercentRequest());
    }

    public void postPredictiveHysteresisValueRequest() {
        requestBlockingSet.put(Request.readPredictiveHysteresisValueRequest());
    }

    public void postReadClinicalModeRequest() {
        requestBlockingSet.put(Request.readClinicalMode());
    }

    public void postSendCurrentDateAndTimeToTransmitter() {
        requestBlockingSet.put(Request.sendCurrentDateAndTimeToTransmitter());
    }

    public void postSensorGlucoseSamplingInterval() {
        requestBlockingSet.put(Request.readSensorGlucoseSamplingInterval());
    }

    public void postReadSensorGlucoseAlertsAndStatus() {
        requestBlockingSet.put(Request.readGlucoseAlertsAndStatus());
    }

    public void postReadMorningCalibrationTime() {
        requestBlockingSet.put(Request.readMorningCalibrationTime());
    }

    public void postReadEveningCalibrationTime() {
        requestBlockingSet.put(Request.readEveningCalibrationTime());
    }

    public void postLinkedSensorId() {
        requestBlockingSet.put(Request.linkedSensorId());
    }

    public void postDetectedSensorId() {
        requestBlockingSet.put(Request.detectedSensorId());
    }

    public void postSensorInsertionDate() {
        requestBlockingSet.put(Request.readSensorInsertionDate());
    }

    public void postSensorInsertionTime() {
        requestBlockingSet.put(Request.readSensorInsertionTime());
    }

    public void readRemoteRSSI() {
        bluetoothCommunicator.readRemoteRSSI();
    }

    public void postReadyForCalibration() {
        requestBlockingSet.put(Request.readReadyForCalibration());
    }

    public void postCalibrationTresholds() {
        requestBlockingSet.put(Request.readMinCalibrationTreshold());
        requestBlockingSet.put(Request.readMaxCalibrationTreshold());
    }

    public void postSensorLifeDays() {
        requestBlockingSet.put(Request.readSensorLifeDays());
    }

    public void postNextCalibrationDate() {
        requestBlockingSet.put(Request.readNextCalibrationDate());
    }

    public void postNextCalibrationTime() {
        requestBlockingSet.put(Request.readNextCalibrationTime());
    }

    public void postMinutesRemainingUntilCalibrationAllowed() {
        requestBlockingSet.put(Request.readMinutesRemainingUntilCalibrationAllowed());
    }

    public void postAlgorithmParameterFormatVersion() {
        requestBlockingSet.put(Request.readAlgorithmParameterFormatVersion());
    }

    // #2936
    public void postMEPMSPInfo() {
        requestBlockingSet.put(Request.readMEPSavedValue());
        requestBlockingSet.put(Request.readMEPSavedRefChannelMetric());
        requestBlockingSet.put(Request.readMEPSavedDriftMetric());
        requestBlockingSet.put(Request.readMEPSavedLowRefMetric());
        requestBlockingSet.put(Request.readMEPSavedSpike());
        requestBlockingSet.put(Request.readEEP24MSP());
    }

    // #2379
    public void postGlucoseAlarmRepeatIntervalAndStartTime() {
        requestBlockingSet.put(Request.readLowGlucoseAlarmRepeatIntervalDayTime());
        requestBlockingSet.put(Request.readHighGlucoseAlarmRepeatIntervalDayTime());
        requestBlockingSet.put(Request.readLowGlucoseAlarmRepeatIntervalNightTime());
        requestBlockingSet.put(Request.readHighGlucoseAlarmRepeatIntervalNightTime());
        requestBlockingSet.put(Request.readDayStartTime());
        requestBlockingSet.put(Request.readNightStartTime());
    }

    public void postWriteLowGlucoseAlarmRepeatIntervalDayTime(int value) {
        requestBlockingSet.put(Request.writeLowGlucoseAlarmRepeatIntervalDayTime(value));
    }

    public void postWriteHighGlucoseAlarmRepeatIntervalDayTime(int value) {
        requestBlockingSet.put(Request.writeHighGlucoseAlarmRepeatIntervalDayTime(value));
    }

    public void postWriteLowGlucoseAlarmRepeatIntervalNightTime(int value) {
        requestBlockingSet.put(Request.writeLowGlucoseAlarmRepeatIntervalNightTime(value));
    }

    public void postWriteHighGlucoseAlarmRepeatIntervalNightTime(int value) {
        requestBlockingSet.put(Request.writeHighGlucoseAlarmRepeatIntervalNightTime(value));
    }

    public void postDayStartTime(int hour, int minutes) {
        requestBlockingSet.put(Request.writeDayStartTime(hour, minutes));
    }

    public void postNightStartTime(int hour, int minutes) {
        requestBlockingSet.put(Request.writeNightStartTime(hour, minutes));
    }

    public void postMinutesBeforeNextCalibrationTime() {
        requestBlockingSet.put(Request.readMinutesBeforeNextCalibrationTime());
    }

    public void postMinutesAfterNextCalibrationTime() {
        requestBlockingSet.put(Request.readMinutesAfterNextCalibrationTime());
    }

    public void postSendBloodGlucoseDataResponse(CalibrationEventPoint calibrationEventPoint) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(calibrationEventPoint.getCalendar().getTimeInMillis());
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);

        int[] date = new int[2];
        date = BinaryOperations.calculateDateBytes(year, month, day);
        int[] time = new int[2];
        time = BinaryOperations.calculateTimeBytes(hour, minute, second);

        int[] value = new int[2];
    value = BinaryOperations.data16BitsFromIntLSByteFirst(calibrationEventPoint.getGlucoseLevel());

        int[] meter = new int[]{0, 0};
    int[] data =
        CommandOperations.operationToSendBloodGlucoseValueToTransmitter(date, time, value, 0, meter,
            true);

        requestBlockingSet.put(Request.sendBloodGlucoseData(data));
    }

    public void postWritePatientEventPoint(PatientEventPoint eventPoint) {
    requestBlockingSet.put(
        Request.writePatientEvent(eventPoint.getTimestamp(), eventPoint.eventTypeId(),
            eventPoint.eventSubTypeId(), eventPoint.quantity()));
    }

    public void postWriteGlucoseEvent(GlucoseEventPoint glucoseEventPoint) {
    requestBlockingSet.put(Request.writeGlucosePatientEvent(glucoseEventPoint.getTimestamp(),
        glucoseEventPoint.getGlucoseLevel()));
    }

    public void postWriteHighGlucoseTarget(int level) {
        requestBlockingSet.put(Request.writeHighGlucoseTarget(level));
    }

    public void postReadHighGlucoseTargetRequest() {
        requestBlockingSet.put(Request.readHighGlucoseTargetRequest());
    }

    public void postWriteLowGlucoseTargetRequest(int level) {
        requestBlockingSet.put(Request.writeLowGlucoseTargetRequest(level));
    }

    public void postReadLowGlucoseTargetRequest() {
        requestBlockingSet.put(Request.readLowGlucoseTargetRequest());
    }

    public void postWriteHighGlucoseAlarmRequest(int glucoseLevel) {
        requestBlockingSet.put(Request.writeHighGlucoseAlarmRequest(glucoseLevel));
    }

    public void postReadHighGlucoseAlarmRequest() {
        requestBlockingSet.put(Request.readHighGlucoseAlarmRequest());
    }

    public void postWriteLowGlucoseAlarmRequest(int glucoseLevel) {
        requestBlockingSet.put(Request.writeLowGlucoseAlarmRequest(glucoseLevel));
    }

    public void postReadLowGlucoseAlarmRequest() {
        requestBlockingSet.put(Request.readLowGlucoseAlarmRequest());
    }

    public void postWritePredictiveAlertsRequest(boolean state) {
        requestBlockingSet.put(Request.writePredictiveAlertsRequest(state));
    }

    public void postReadPredictiveAlertsRequest() {
        requestBlockingSet.put(Request.readPredictiveAlertsRequest());
    }

    public void postWritePredictiveTimeIntervalRequest(int minutes) {
        requestBlockingSet.put(Request.writePredictiveFallingTimeIntervalRequest(minutes));
        requestBlockingSet.put(Request.writePredictiveRisingTimeIntervalRequest(minutes));
    }

    public void postReadPredictiveTimeIntervalRequest() {
        //NOTE: it's curious that write does both falling and rising, but read only reads falling
        requestBlockingSet.put(Request.readPredictiveFallingTimeIntervalRequest());
    }

    public void postWriteRateAlert(boolean state) {
        requestBlockingSet.put(Request.writeRateAlert(state));
    }

    public void postReadRateAlert() {
        requestBlockingSet.put(Request.readRateAlert());
    }

    public void postWriteRateAlertThresholdRequest(int threshold) {
        requestBlockingSet.put(Request.writeRateAlertFallingThresholdRequest(threshold));
        requestBlockingSet.put(Request.writeRateAlertRisingThresholdRequest(threshold));
    }

    public void postReadRateAlertThresholdRequest() {
        requestBlockingSet.put(Request.readRateAlertFallingThresholdRequest());
    }

    public void postReadGlucoseData() {
        requestBlockingSet.put(Request.readGlucoseData());
    }

    /** #3194 */
    public void postReadRawDataValues() {
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7));
        requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8));
    }

    public void postWriteClinicalMode(boolean isClinicalMode) {
        requestBlockingSet.put(Request.writeClinicalModeRequest(isClinicalMode));
    }

    public void postReadVibrateModeRequest() {
        requestBlockingSet.put(Request.readVibrateModeRequest());
    }

    public void postReadDoNotDisturbModeRequest() {
        requestBlockingSet.put(Request.readDoNotDisturbModeRequest());
    }

    public void postWriteVibrateModelRequest(boolean isVibrateMode) {
        requestBlockingSet.put(Request.writeVibrateModeRequest(isVibrateMode));
    }

    public void postwriteDoNotDisturbModeRequest(boolean shouldNotDisturb) {
        requestBlockingSet.put(Request.writeDoNotDisturbModeRequest(shouldNotDisturb));
    }

    public void postReadSensorIdRequest() {
        requestBlockingSet.put(Request.readSensorIdRequest());
    }

    public void postReadUnlinkedSensorIdRequest() {
        requestBlockingSet.put(Request.readUnlinkedSensorIdRequest());
    }

    public void postWriteTransmitterNameRequest(String transmitterName) {
        requestBlockingSet.put(Request.writeFirstFourByteTransmitterNameRequest(transmitterName));
        requestBlockingSet.put(Request.writeLastFourByteTransmitterNameRequest(transmitterName));
    }

    public void postWriteMorningCalibrationTime(int hour, int minutes) {
        requestBlockingSet.put(Request.writeMorningCalibrationTime(hour, minutes));
    }

    public void postWriteEveningCalibrationTime(int hour, int minutes) {
        requestBlockingSet.put(Request.writeEveningCalibrationTime(hour, minutes));
    }

    public void postReadSignalStrengthRequest() {
        requestBlockingSet.put(Request.readSignalStrengthRequest());
    }

    public int postWriteTransmitterChunk(int[] data, int address, int chunkSize) {
        List<Request> requestList = Request.writeTransmitterChunk(data, address, chunkSize);
        requestBlockingSet.putAll(requestList);
        return requestList.size();
    }

    public void postWriteSensorID(long sensorId) {
        requestBlockingSet.put(Request.writeSensorID(sensorId));
    }

    public void postEnterDiagnosticMode() {
        requestBlockingSet.put(Request.enterDiagnosticMode());
    }

    public void postExitDiagnosticMode() {
        requestBlockingSet.put(Request.exitDiagnosticMode());
    }

    public void postWriteAppVersion(String appVersion) {
        requestBlockingSet.put(Request.writeAppVersion(appVersion));
    }

    public void postForceGlucoseMeasurement() {
        requestBlockingSet.put(Request.forceGlucoseMeasurement());
    }

    public class BluetoothServiceBinder extends Binder {
        public BluetoothService getService() {
            return BluetoothService.this;
        }
    }
}
