package com.senseonics.gen12androidapp;

import com.senseonics.util.Utils;

import java.util.List;

public class MealTimeStatistics {
    private List<Integer> glucoseArray;

    private int INVALID = -1;

    private int highAlarm = INVALID;
    private int highTarget = INVALID;
    private int lowTarget = INVALID;
    private int lowAlarm = INVALID;

    private float average = INVALID;
    private float firstStdDev = INVALID;
    private float percentWithin = INVALID;
    private float percentAboveTarget = INVALID;
    private float percentBelowTarget = INVALID;
    private float percentAboveHigh = INVALID;
    private float percentBelowLow = INVALID;

    public MealTimeStatistics(List<Integer> glucoseArrayIn, int highAlarm, int highTarget, int lowTarget, int lowAlarm) {
        this.glucoseArray = glucoseArrayIn;

        this.highAlarm = highAlarm;
        this.highTarget = highTarget;
        this.lowTarget = lowTarget;
        this.lowAlarm = lowAlarm;

        if (this.glucoseArray.size() > 0) {
            // Calculate all 7 values
            calculateAverageValue();
            calculateStdDev();
            calculateTargetsWithData();

        }
    }

    private float getMean()
    {
        double sum = 0.0;
        for(double a : glucoseArray)
            sum += Utils.getGlucoseLevelFloatValue((int)a);
        return (float)sum/this.glucoseArray.size();
    }

    private float getVariance()
    {
        double mean = getMean();
        double temp = 0;

        for(double a :glucoseArray)

            temp += (mean-Utils.getGlucoseLevelFloatValue((int)a))*(mean-Utils.getGlucoseLevelFloatValue((int)a));
        return (float) temp/glucoseArray.size();
    }

    private void calculateStdDev()
    {
        this.firstStdDev = (float) Math.sqrt(getVariance());
    }


    private void calculateAverageValue() {
        int sum = 0;
        for (Integer value: glucoseArray) {
            sum += value;
        }

        this.average = (float)sum / (glucoseArray.size());
    }


    private void calculateTargetsWithData()
    {

        float criticalHigh = Utils.getGlucoseLevelFloatValue(highAlarm);
        float criticalLow =  Utils.getGlucoseLevelFloatValue(lowAlarm);
        float targetHigh = Utils.getGlucoseLevelFloatValue(highTarget);
        float targetLow = Utils.getGlucoseLevelFloatValue(lowTarget);
            float within = 0;
            float above = 0;
            float below = 0;
            float low = 0;
            float high = 0;

            for(Integer value: glucoseArray) {

            if(Utils.getGlucoseLevelFloatValue(value) >= criticalHigh)
                high++;

            if(Utils.getGlucoseLevelFloatValue(value) > targetHigh) {
                above++;

            } else if(Utils.getGlucoseLevelFloatValue(value) >= targetLow && Utils.getGlucoseLevelFloatValue(value) <= targetHigh) {
                within++;

            } else if(Utils.getGlucoseLevelFloatValue(value) < targetLow) {
                below++;
            }

            if(Utils.getGlucoseLevelFloatValue(value) <= criticalLow) {
                low++;
            }
        }
        percentWithin = 100.0f *(within / glucoseArray.size());
        percentAboveTarget = 100.0f * (above / glucoseArray.size());
        percentBelowTarget = 100.0f * (below / glucoseArray.size());
        percentAboveHigh = 100.0f * (high / glucoseArray.size());
        percentBelowLow = 100.0f * (low / glucoseArray.size());
    }

    public float getAverage() {
        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return average;
        else
            return average;

    }

    public void setAverage(float average) {
        this.average = average;
    }

    public float getFirstStdDev() {
        return firstStdDev;
    }

    public void setFirstStdDev(float firstStdDev) {
        this.firstStdDev = firstStdDev;
    }

    public float getPercentWithin() {
        return percentWithin;
    }

    public void setPercentWithin(float percentWithin) {
        this.percentWithin = percentWithin;
    }

    public float getPercentAboveTarget() {
        return percentAboveTarget;
    }

    public void setPercentAboveTarget(float percentAboveTarget) {
        this.percentAboveTarget = percentAboveTarget;
    }

    public float getPercentBelowTarget() {
        return percentBelowTarget;
    }

    public void setPercentBelowTarget(float percentBelowTarget) {
        this.percentBelowTarget = percentBelowTarget;
    }

    public float getPercentAboveHigh() {
        return percentAboveHigh;
    }

    public void setPercentAboveHigh(float percentAboveHigh) {
        this.percentAboveHigh = percentAboveHigh;
    }

    public float getPercentBelowLow() {
        return percentBelowLow;
    }

    public void setPercentBelowLow(float percentBelowLow) {
        this.percentBelowLow = percentBelowLow;
    }
}


