package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class CalibrationPhaseStartDateTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public CalibrationPhaseStartDateTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.startDateOfCalibrationPhaseAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{dataOne, dataTwo});
        model.setCalibrationPhaseStartDateOnly(date);
    }
}
