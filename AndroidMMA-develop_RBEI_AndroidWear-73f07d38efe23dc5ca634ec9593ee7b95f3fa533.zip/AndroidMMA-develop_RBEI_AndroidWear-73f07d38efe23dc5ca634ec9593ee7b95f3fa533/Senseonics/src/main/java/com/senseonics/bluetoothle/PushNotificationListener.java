package com.senseonics.bluetoothle;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.gen12androidapp.MessageCoder;
import com.senseonics.bluetoothle.event.LegacyResponseHandlingEvent;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.AlertOrAlarmEvent;
import com.senseonics.events.CalibrationRequestEvent;
import com.senseonics.events.EventPoint;
import com.senseonics.events.NotificationDialogEvent;
import com.senseonics.events.PredictiveRateAlertEvent;
import com.senseonics.events.RateAlertEvent;
import com.senseonics.events.RefreshGraphEvent;
import com.senseonics.model.SyncModel;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.BlindedGlucoseCauseIdentifier;
import com.senseonics.util.NotificationUtility;
import com.senseonics.util.Utils;

import java.util.Arrays;
import java.util.Calendar;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
class PushNotificationListener {

    private Context context;
    private EventBus eventBus;
    private ApplicationForegroundState applicationForegroundState;
    private NotificationUtility notificationUtility;
    private DatabaseManager databaseManager;
    private TransmitterStateModel model;
    private MessageCoder messageCoder;
    private BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;
    private SharedPreferences sharedPreferences;
    private DialogUtils dialogUtils;
    private DMSSyncManager dmsSyncManager;
    private DMSStateModelSyncManager dmsStateModelSyncManager;
    private TempProfileManager tempProfileManager; /** #3160 */
    private SyncModel syncModel;

    @Inject 
    public PushNotificationListener(Context context, EventBus eventBus, ApplicationForegroundState applicationForegroundState,
                                    NotificationUtility notificationUtility, DatabaseManager databaseManager,
                                    TransmitterStateModel model, MessageCoder messageCoder,
                                    BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier,
                                    BluetoothServiceCommandClient bluetoothServiceCommandClient, SharedPreferences sharedPreferences
            , DialogUtils dialogUtils, DMSSyncManager dmsSyncManagerIn, DMSStateModelSyncManager dmsStateModelSyncManagerIn, TempProfileManager tempProfileManager, SyncModel syncModel
    ) {
        this.context = context;
        this.eventBus = eventBus;
        this.applicationForegroundState = applicationForegroundState;
        this.notificationUtility = notificationUtility;
        this.databaseManager = databaseManager;
        this.model = model;
        this.messageCoder = messageCoder;
        this.blindedGlucoseCauseIdentifier = blindedGlucoseCauseIdentifier;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
        this.sharedPreferences = sharedPreferences;
        this.dialogUtils = dialogUtils;
        this.dmsSyncManager = dmsSyncManagerIn;
        this.dmsStateModelSyncManager = dmsStateModelSyncManagerIn;
        this.tempProfileManager = tempProfileManager;
        this.syncModel = syncModel;
        eventBus.register(this);
    }

    public void onEventMainThread(LegacyResponseHandlingEvent event) {
        Utils.TransmitterMessageCode messageCode = Utils.TransmitterMessageCode.NumberOfMessages;

        if (CommandAndResponseIDs.CalibrationAlarmOrAlertPushNotificationCommandID == event.actualResponseId() && isCalibrationAlarmOrAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                Utils.EVENT_TYPE eventType = null;

                if(model.getCurrentCountdown()==0) {
                    if(model != null) {
//                        Log.d("#3734", PushNotificationListener.class.getSimpleName() + ": onEventMainThread()");
                        model.adjustLastReadDateTimeWhenSendingReadCommand();
                        bluetoothServiceCommandClient.postReadCurrentTransmitterDateAndTime();
                        bluetoothServiceCommandClient.postMEPMSPInfo();
                    }
                }
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForSensorCalibrationFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    eventType = messageCode.getEventType();

                    if (eventType != null) {
                        EventPoint ep = saveCalibrationAlert(eventType, event.getData());
                        if (!(model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm))) {
                            /** APPDEV-4143 */
                            if (!shouldSilentDNDAlarm(messageCode)) {
                                if (!applicationForegroundState.isForeground()) {
                                    if (eventType == Utils.EVENT_TYPE.CALIBRATE_NOW_EVENT) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.CalibrationRequiredAlarm);
                                    } else if (eventType == Utils.EVENT_TYPE.CALIBRATE_EXPIRED_EVENT) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.CalibrationExpiredAlarm);
                                    } else if (eventType == Utils.EVENT_TYPE.CALIBRATE_GRACE_EVENT) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.CalibrationGracePeriodAlarm);
                                    }

                                    dialogUtils.addAPendingCalibrationDialog(ep, messageCode.notificationId());
                                    Log.d(PushNotificationListener.class.getSimpleName(), "pushing dialog into " + dialogUtils.toString());
                                } else {
                                    eventBus.post(new CalibrationRequestEvent(ep, messageCode.notificationId()));
                                }
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.GlucoseRateAlertOrPredictiveAlertPushNotificationCommandID == event.actualResponseId() && isGlucoseRateAlertOrPredictiveAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                Utils.EVENT_TYPE type;
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForRateAlertFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    type = messageCode.getEventType();
                    if (type != null) {
                        float rateValue = sharedPreferences.getFloat(Utils.prefRateValue, Utils.RATE_VALUE);
                        AlertEventPoint aep = saveAlert(type, null, model.getDateTimeCalendarFromPushNotificationResponse(event.getData()), model.getGlucoseLevel(), rateValue, 0, -1, false);
                        if (!(model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm))) {
                            /** APPDEV-4143 */
                            if (!shouldSilentDNDAlarm(messageCode)) {
                                if (!applicationForegroundState.isForeground()) {
                                    if (type == Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.RateFallingAlarm);
                                    } else if (type == Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.RateRisingAlarm);
                                    }
                                    dialogUtils.addAPendingRateOrPredictiveRateAlertDialog(aep, messageCode.notificationId());
                                } else {
                                    eventBus.post(new RateAlertEvent(aep, messageCode.notificationId()));
                                }
                            }
                        }
                    }
                }

                flag = event.getData()[getPushNotificationFlag(event.getData(), 2)];
                tempMC = messageCoder.messageCodeForPredictiveAlertFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    type = messageCode.getEventType();
                    if (type != null) {
                        int predictiveMinutes = sharedPreferences.getInt(Utils.prefPredictiveMinutes, Utils.PREDICTIVE_MINUTES);
                        AlertEventPoint aep = saveAlert(type, null, model.getDateTimeCalendarFromPushNotificationResponse(event.getData()), model.getGlucoseLevel(), 0, predictiveMinutes, -1, false);

                        /** Refresh the graph to show the icon */
                        eventBus.postSticky(new RefreshGraphEvent());

                        if (!(model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm))) {
                            /** APPDEV-4143 */
                            if (!shouldSilentDNDAlarm(messageCode)) {
                                if (!applicationForegroundState.isForeground()) {
                                    if (type == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.PredictiveLowAlarm);
                                    } else if (type == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
                                        notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.PredictiveHighAlarm);
                                    }

                                    dialogUtils.addAPendingRateOrPredictiveRateAlertDialog(aep, messageCode.notificationId());
                                } else {
                                    eventBus.post(new PredictiveRateAlertEvent(aep, messageCode.notificationId()));
                                }
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.GlucoseLevelAlarmPushNotificationCommandID == event.actualResponseId() && isGlucoseLevelAlarmPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.ALERT_TYPE type = decodeGlucoseAlertType(flag);

                int glucoseValueIndex = getPushNotificationFlag(event.getData(), 4);
                int glucoseValue = event.getData()[glucoseValueIndex] | (event.getData()[glucoseValueIndex + 1] << 8);

                if (type != null) {
                    messageCode = messageCoder.messageCodeForGlucoseLevelAlarmFlags(flag);
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);

                    AlertEventPoint aep = saveAlert(messageCode.getEventType(), type, model.getDateTimeCalendarFromPushNotificationResponse(event.getData()), glucoseValue, 0, 0, -1, false);

                    /** #3194 */
                    bluetoothServiceCommandClient.postReadRawDataValues();
                    bluetoothServiceCommandClient.postReadGlucoseData();

                    if (!(model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm))) {
                        /** APPDEV-4143 */
                        if (!shouldSilentDNDAlarm(messageCode)) {
                            if (!applicationForegroundState.isForeground()) {
                                dialogUtils.addAPendingAlertOrAlarmDialog(aep, messageCode.notificationId());
                                notificationUtility.createNotificationFromEvent(messageCode);
                            } else {
                                eventBus.post(new AlertOrAlarmEvent(aep, messageCode.notificationId()));
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.GlucoseLevelAlertPushNotificationCommandID == event.actualResponseId() && isGlucoseLevelAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.ALERT_TYPE type = decodeGlucoseAlertType(flag);

                int glucoseValueIndex = getPushNotificationFlag(event.getData(), 4);
                int glucoseValue = event.getData()[glucoseValueIndex] | (event.getData()[glucoseValueIndex + 1] << 8);

                if (type != null) {
                    messageCode = messageCoder.messageCodeForGlucoseLevelAlertFlags(flag);
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);

                    AlertEventPoint aep = saveAlert(messageCode.getEventType(), type, model.getDateTimeCalendarFromPushNotificationResponse(event.getData()), glucoseValue, 0, 0, -1, false);

                    /** #3194 */
                    bluetoothServiceCommandClient.postReadRawDataValues();
                    bluetoothServiceCommandClient.postReadGlucoseData();

                    if (!(model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm))) {
                        /** APPDEV-4143 */
                        if (!shouldSilentDNDAlarm(messageCode)) {
                            if (!applicationForegroundState.isForeground()) {
                                dialogUtils.addAPendingAlertOrAlarmDialog(aep, messageCode.notificationId());
                                notificationUtility.createNotificationFromEvent(messageCode);
                            } else {
                                eventBus.post(new AlertOrAlarmEvent(aep, messageCode.notificationId()));
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.TransmitterBatteryAlertPushNotificationCommandID == event.actualResponseId() && isTransmitterBatteryAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForTransmitterBatteryAlertFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    EventPoint ep = saveEventPoint(messageCode.getEventType(), messageCode, Utils.BATTERY_EVENT_TAG, -1, Utils.GLUCOSE_LEVEL_UNKNOWN, event.getData());
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    /** APPDEV-4143 */
                    if (!shouldSilentDNDAlarm(messageCode)) {
                        if (!applicationForegroundState.isForeground()) {
                            notificationUtility.createNotificationFromEvent(messageCode);
                            dialogUtils.addAPendingNotificationAlertOrAlarm(ep, messageCode);
                        } else {
                            eventBus.post(new NotificationDialogEvent(ep, messageCode));
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.SensorHWStatusAlarmOrAlertPushNotificationCommandID == event.actualResponseId() && isSensorHWStatusAlarmOrAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForSensorHardwareAndAlertFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    int glucoseLevel = model.getGlucoseLevel();
                    EventPoint ep = saveEventPoint(messageCode.getEventType(), messageCode, "", -1, glucoseLevel, event.getData());
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);

                    /** #3224 since EDR alarms won't setMessageCode on model, fire another event to refresh the graph */
                    if (messageCode == Utils.TransmitterMessageCode.EDRAlarm4) /** #3920 */
                    {
                        eventBus.postSticky(new RefreshGraphEvent());
                    }

                    /** APPDEV-4143 */
                    if (!shouldSilentDNDAlarm(messageCode)) {
                        if (!applicationForegroundState.isForeground()) {
                            notificationUtility.createNotificationFromEvent(messageCode);
                            if (messageCode != Utils.TransmitterMessageCode.SensorAwolAlarm) {
                                dialogUtils.addAPendingNotificationAlertOrAlarm(ep, messageCode);
                            }
                        } else if (messageCode != Utils.TransmitterMessageCode.SensorAwolAlarm) {
                            eventBus.post(new NotificationDialogEvent(ep, messageCode));
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.SensorReplacementAlarmOrAlertPushNotificationCommandID == event.actualResponseId() && isSensorReplacementAlarmOrAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForSensorReplacementFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    Utils.EVENT_TYPE eventType = messageCode.getEventType();

                    if (eventType != null) {
                        EventPoint ep = saveEventPoint(eventType, messageCode, "", -1, Utils.GLUCOSE_LEVEL_UNKNOWN, event.getData());

                        /** APPDEV-4143 */
                        if (!shouldSilentDNDAlarm(messageCode)) {
                            if (!applicationForegroundState.isForeground()) {
                                notificationUtility.createNotificationFromEvent(messageCode);
                                dialogUtils.addAPendingNotificationAlertOrAlarm(ep, messageCode);
                            } else {
                                eventBus.post(new NotificationDialogEvent(ep, messageCode));
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.TransmitterStatusAlarmOrAlertPushNotificationCommandID == event.actualResponseId() && isTransmitterStatusAlarmOrAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForTransmitterStatusAlertFlags(flag);
                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);
                    EventPoint ep = saveEventPoint(messageCode.getEventType(), messageCode, "", -1, Utils.GLUCOSE_LEVEL_UNKNOWN, event.getData());
                    /** APPDEV-4143 */
                    if (!shouldSilentDNDAlarm(messageCode)) {
                        if (!applicationForegroundState.isForeground()) {
                            notificationUtility.createNotificationFromEvent(messageCode);
                            dialogUtils.addAPendingNotificationAlertOrAlarm(ep, messageCode);
                        } else if (messageCode != Utils.TransmitterMessageCode.SensorAwolAlarm) {
                            eventBus.post(new NotificationDialogEvent(ep, messageCode));
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.SensorReadAlertPushNotificationCommandID == event.actualResponseId() && isSensorReadAlertPushNotificationCommandCorrect(event.getData())) {
            Calendar timestamp = model.getDateTimeCalendarFromPushNotificationResponse(event.getData());
            /** #3635 */
            if (model.isValidDate(timestamp)) {
                int flag = event.getData()[getPushNotificationFlag(event.getData(), 1)];
                Utils.TransmitterMessageCode tempMC = messageCoder.messageCodeForSensorReadAlertFlags(flag);

                if (tempMC != null) {
                    messageCode = tempMC;
                    setCurrentMessageCodeIfNeededFromPushCommand(messageCode);

                    int glucoseLevel = model.getGlucoseLevel();
                    Boolean shouldFireNotification = true;

                    if (messageCode == Utils.TransmitterMessageCode.SeriouslyHighAlarm
                            || messageCode == Utils.TransmitterMessageCode.SeriouslyLowAlarm) {
                        glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN;

                        if (model.getCurrentMessageCode().equals(Utils.TransmitterMessageCode.SensorRetiredAlarm)) {
                            shouldFireNotification = false;
                        }

                        /** Refresh the graph to show the icon */
                        eventBus.postSticky(new RefreshGraphEvent());
                    }

                    EventPoint eventPoint = saveEventPoint(messageCode.getEventType(), messageCode, "", -1, glucoseLevel, event.getData());
                    if (shouldFireNotification) {
                        /** APPDEV-4143 */
                        if (!shouldSilentDNDAlarm(messageCode)) {
                            if (!applicationForegroundState.isForeground()) {
                                notificationUtility.createNotificationFromEvent(messageCode);
                                dialogUtils.addAPendingNotificationAlertOrAlarm(eventPoint, messageCode);
                            } else {
                                eventBus.post(new NotificationDialogEvent(eventPoint, messageCode));
                            }
                        }
                    }
                }
            }
        } else if (CommandAndResponseIDs.KeepAliveCommandID == event.actualResponseId() && isKeepAliveCommandCorrect(event.getData())) {
            Utils.turnOffClinicalModeIfNeeded(context, bluetoothServiceCommandClient);
            /** #3160 */
            tempProfileManager.turnOffTempProfileIfNeeded();

            Log.d(PushNotificationListener.class.getSimpleName() + "-DMS", ">>> Keep Alive <<<");

            /** Upload data to DMS server when a Keep Alive is received */
            if (model.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) { // when fully connected
                Log.d(PushNotificationListener.class.getSimpleName() + "-DMS", "Auto uploading");
                dmsStateModelSyncManager.startModelSync();
                dmsSyncManager.startSync();
            }

            if (isResponseIdInRange(event.actualResponseId()) && model.isTransmitterConnected()) {
                /** #3194 */
                bluetoothServiceCommandClient.postReadRawDataValues();
                bluetoothServiceCommandClient.postReadGlucoseData();
            }

            if (!applicationForegroundState.isForeground()) { /** only in background */
                if (model.isTransmitterConnected() && !syncModel.isSyncing()) {
                    long lastSyncingMillis = sharedPreferences.getLong(Utils.prefLastSyncingMillis, -1);
                    long currentTimeAdjustedToGMT = Utils.getLocalTimeInMillisAdjustedToGMT();

                    Log.d(PushNotificationListener.class.getSimpleName() + " PrepareSync", "is it time to sync? " + (currentTimeAdjustedToGMT - lastSyncingMillis) + " if greater than " + Utils.AUTOMATIC_SYNC_ON_PUSH_INTERVAL + ", lastSyncMillis " + lastSyncingMillis);
                    if (currentTimeAdjustedToGMT - lastSyncingMillis > Utils.AUTOMATIC_SYNC_ON_PUSH_INTERVAL) {
                        bluetoothServiceCommandClient.postGetRangesForSyncing();
                    }
                }
            }
        } else {
            if (isResponseIdInRange(event.actualResponseId())) {
                Utils.currentUnknownErrorCode = event.actualResponseId();
                EventPoint ep = saveEventPoint(Utils.EVENT_TYPE.NOTIFICATION_EVENT_RED, Utils.TransmitterMessageCode.NumberOfMessages, "", -1, Utils.GLUCOSE_LEVEL_UNKNOWN, event.getData());
                if (!applicationForegroundState.isForeground()) {
                    notificationUtility.createNotificationFromEvent(Utils.TransmitterMessageCode.NumberOfMessages, event.actualResponseId());
                } else {
                    eventBus.post(new NotificationDialogEvent(ep, Utils.TransmitterMessageCode.NumberOfMessages));
                }
            }
        }

        if (isResponseIdInRange(event.actualResponseId()) && messageCode != null && messageCode != Utils.TransmitterMessageCode.NumberOfMessages && messageCode != Utils.TransmitterMessageCode.NoAlarmActive) {
            Log.i(PushNotificationListener.class.getSimpleName(), "set alert code for snooze:" + messageCode.ordinal() + " : " + messageCode);
            bluetoothServiceCommandClient.postSnooze(messageCode.ordinal());
        }
    }

    /** APPDEV-4143 */
    private boolean shouldSilentDNDAlarm(Utils.TransmitterMessageCode messageCode) {
        boolean isCritical = Utils.isCriticalAlarm(messageCode);
        boolean vibrationEnabled = model.isVibrateMode();
        Log.i(PushNotificationListener.class.getSimpleName(), "Alert: " + messageCode + " | isCritical: " + isCritical + " | isVibrationEnabled: " + vibrationEnabled);

        if (!isCritical && !vibrationEnabled) {
            Log.i(PushNotificationListener.class.getSimpleName(), "--- QUIET: DND is on ---");
            return true;
        }

        return false;
    }

    private boolean isResponseIdInRange(int actualResponseId) {
        return actualResponseId >= 0x40 && actualResponseId < 0x60;
    }

    private Utils.ALERT_TYPE decodeGlucoseAlertType(int flag) {
        Utils.ALERT_TYPE type;
        switch (flag) {
            case 1:
                type = Utils.ALERT_TYPE.LOW_GLUCOSE;
                break;
            case 2:
                type = Utils.ALERT_TYPE.HIGH_GLUCOSE;
                break;
            default:
                type = null;
        }
        return type;
    }

    private EventPoint saveEventPoint(Utils.EVENT_TYPE eventType, Utils.TransmitterMessageCode notificationEventType, String notes, int recordNumber, int glucoseLevel, int[] data) {
        EventPoint eventPoint = new EventPoint(model.getDateTimeCalendarFromPushNotificationResponse(data), glucoseLevel, eventType);
        eventPoint.setNotes(notes);
        eventPoint.setNotificationEventType(notificationEventType);
        eventPoint.setRecordNumber(recordNumber);
        eventPoint.setEventHidden(false);
        if (notificationEventType == Utils.TransmitterMessageCode.NumberOfMessages) {
            eventPoint.setUnknownErrorCode(Utils.currentUnknownErrorCode);
        }

        databaseManager.addEvent(eventPoint, true);

        return eventPoint;
    }

    private EventPoint saveCalibrationAlert(Utils.EVENT_TYPE eventType, int[] data) {
        // save glucose level to be unknown - consistent with ALERT_LOG_RECORD_TYPE
        EventPoint eventPoint = new EventPoint(model.getDateTimeCalendarFromPushNotificationResponse(data), Utils.GLUCOSE_LEVEL_UNKNOWN, eventType);
        eventPoint.setNotes("");
        databaseManager.addEvent(eventPoint, true);
        return eventPoint;
    }

    private AlertEventPoint saveAlert(Utils.EVENT_TYPE eventType, Utils.ALERT_TYPE type,
                                      Calendar calendar, int glucoseValue, float rateValue,
                                      int predictiveMinutes, int recordNumber, boolean hidden) {
        AlertEventPoint alertEvent = new AlertEventPoint(eventType, calendar,
                glucoseValue, type, Utils.GLUCOSE_TYPE.SENSOR_GLUCOSE);
        alertEvent.setRecordNumber(recordNumber);
        // save rate and predictive all to 0 to be in consistent with ALERT_LOG_RECORD_TYPE
        alertEvent.setRateValue(0.0f);
        alertEvent.setPredictiveMinutes(0);
        alertEvent.setEventHidden(hidden);
        databaseManager.addEvent(alertEvent, true);
        return alertEvent;
    }

    private void setCurrentMessageCodeIfNeededFromPushCommand(Utils.TransmitterMessageCode msgCodePushed) {
        if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(msgCodePushed)) {
            // Compare with CurrentMessageCode and assign the smaller ordinal
            Utils.TransmitterMessageCode response = Utils.TransmitterMessageCode.values()[Math.min(
                    model.getCurrentMessageCode().ordinal(), msgCodePushed.ordinal())];

            model.setCurrentMessageCode(response);
        }
    }

    // ------------------------GLUCOSE-LEVEL-ALAR-PUSH-NOTIF-COMM-0x40-----------------------

    // correction check
    private boolean isGlucoseLevelAlarmPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 4, "GlucoseLevelAlarmPushNotificationCommand");
    }

    // -----------------------GLUCOSE-LEVEL-ALERT-PUSH-NOTIF-COMM-0x41------------------------

    // correction check
    private boolean isGlucoseLevelAlertPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 4, "GlucoseLevelAlertPushNotificationCommand");
    }

    // -----------------------GLUCOSE-RATE-ALERT-PUSH-NOTIF-COMM-0x42------------------------

    // correction check
    private boolean isGlucoseRateAlertOrPredictiveAlertPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 5, "GlucoseRateAlertOrPredictiveAlertPushNotificationCommand");
    }

    // -----------------------CALIB-ALERT-OR-ALARM-PUSH-NOTIF-COMMAND-0x43-------------------

    // correction check
    private boolean isCalibrationAlarmOrAlertPushNotificationCommandCorrect(
            int[] response) {

        return checkResponseLengthAndCRC(response, 4, "CalibrationAlarmOrAlertPushNotificationCommand");
    }

    // -----------------------SENSOR-REPLACEMENT-ALARM-PUSH-NOTIF-COMMAND-0x44-------------------

    // correction check
    private boolean isSensorReplacementAlarmOrAlertPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 4, "SensorReplacementAlarmOrAlertPushNotificationCommand");
    }

    // ---------------------SENSOR-HW-STATUS-ALARM-PUSH-NOTIF-COMMAND-0x45----------------

    // correction check
    private boolean isSensorHWStatusAlarmOrAlertPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 4, "SensorHWStatusAlarmOrAlertPushNotificationCommand");
    }

    // ----------------------TRM-STATUS-ALARM-PUSH-NOTIF-COMMAND-0x46-----------------

    // correction check
    private boolean isTransmitterStatusAlarmOrAlertPushNotificationCommandCorrect(
            int[] response) {

        return checkResponseLengthAndCRC(response, 4, "TransmitterStatusAlarmOrAlertPushNotificationCommand");
    }

    // ---------------------TRM-BTTERY-ALERT-OR-ALARM-PUSH-NOTIF-COMMAND-0x47----------------

    // correction check
    private boolean isTransmitterBatteryAlertPushNotificationCommandCorrect(
            int[] response) {

        return checkResponseLengthAndCRC(response, 4, "TransmitterBatteryAlertPushNotificationCommand");
    }

    // ---------------------SENS-READ-ALERT-PUSH-NOTIF-COMMAND-0x49----------------

    // correction check
    private boolean isSensorReadAlertPushNotificationCommandCorrect(
            int[] response) {
        return checkResponseLengthAndCRC(response, 4, "SensorReadAlertPushNotificationCommand");
    }

    // ---------------------------KEEP-ALIVE-0x50---------------------------------------

    // correction check
    private boolean isKeepAliveCommandCorrect(int[] response) {
        return checkResponseLengthAndCRC(response, 3, "KeepAliveCommand");
    }

    // ---------------------------Utility Functions--------------------------

    private int checkIfGlucosePushNotification(int responseID, int correctLength) {
        if (responseID == CommandAndResponseIDs.GlucoseLevelAlarmPushNotificationCommandID ||
                responseID == CommandAndResponseIDs.GlucoseLevelAlertPushNotificationCommandID ||
                responseID == CommandAndResponseIDs.GlucoseRateAlertOrPredictiveAlertPushNotificationCommandID) {
            // 4 is the number of bytes added with FW >= 5.12 in the tail for 0x40,0x41,0x42
            return (correctLength + 4);
        } else {
            return correctLength;
        }
    }

    private int[] appendInt(int[] arr, int element) {
        final int N = arr.length;
        arr = Arrays.copyOf(arr, N + 1);
        arr[N] = element;
        return arr;
    }

    private boolean checkPushNotificationCRC(int[] response, int orgDataLength, String msg, String FWVersion) {
        int[] data = new int[]{};
        int correctDataLength = orgDataLength;
        boolean checkPass = false;

        if (FWVersion.compareTo(Utils.pushNotificationFWBound) >= 0) {
            correctDataLength += Utils.pushNotificationDateTimeLength;
            correctDataLength = checkIfGlucosePushNotification(response[0], correctDataLength);
        }

        for (int i = 0; i < correctDataLength; i++) {
            data = appendInt(data, response[i]);
        }

        int crc = BinaryOperations.GenerateChecksumCRC16(data);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        if (crcArray[0] != response[correctDataLength] || crcArray[1] != response[correctDataLength + 1]) {
            checkPass = false;
        } else {
            checkPass = true;
        }

        Log.d("CHECK_CORRECTION", msg + " CRC good? " + checkPass);

        return checkPass;
    }

    private boolean checkPushNotificationLength(int msgLength, int orgLength, int responseID, String msg, String FWVersion) {
        int correctLength = orgLength;
        boolean checkPass = false;

        if (FWVersion.compareTo(Utils.pushNotificationFWBound) >= 0) {
            correctLength += Utils.pushNotificationDateTimeLength;
            correctLength = checkIfGlucosePushNotification(responseID, correctLength);
        }

        if (msgLength == correctLength) {
            checkPass = true;
        } else {
            Log.d("CHECK_CORRECTION", msg + " msgLength:" + msgLength + " correctLength:" + correctLength);
            checkPass = false;
        }

        Log.d("CHECK_CORRECTION", msg + " length good? " + checkPass);

        return checkPass;
    }

    private String getDefaultFWVersion() {
        String FWVersion = model.getFormattedTransmitterVersionNumber();

        if (FWVersion == null) {
            FWVersion = Utils.pushNotificationFWBound; // default
        }

        return FWVersion;
    }

    private int getPushNotificationFlag(int[] response, int orgIndex) {
        int correctIndex = orgIndex;

        String FWVersion = getDefaultFWVersion();

        if (FWVersion.compareTo(Utils.pushNotificationFWBound) >= 0) {
            correctIndex += Utils.pushNotificationDateTimeLength;
        }

        return correctIndex;
    }

    private boolean checkResponseLengthAndCRC(int[] response, int orgMsgLength, String msg) {
        //tag:check|push
        String FWVersion = getDefaultFWVersion();
        Log.d("Check", "FW version: " + FWVersion);

        try {
            // Check length first
            if (!checkPushNotificationLength(response.length, orgMsgLength,
                    response[0], msg, FWVersion)) {
                return false;
            }

            if (!checkPushNotificationCRC(response, orgMsgLength
                    - Utils.CRCLength, msg, FWVersion)) {
                return false;
            }

            return true;
        } catch (Exception ex) {
            return false;
        }
    }

}
