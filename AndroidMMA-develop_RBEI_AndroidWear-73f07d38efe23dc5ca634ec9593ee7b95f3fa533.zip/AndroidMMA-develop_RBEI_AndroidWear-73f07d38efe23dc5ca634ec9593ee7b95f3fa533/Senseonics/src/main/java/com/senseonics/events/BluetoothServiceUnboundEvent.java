package com.senseonics.events;

public class BluetoothServiceUnboundEvent {
}
