package com.senseonics.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.util.Log;

import com.senseonics.gen12androidapp.CustomCountDownTimer;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.BluetoothConnectionEvent;
import com.senseonics.bluetoothle.HexHelper;
import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.bluetoothle.event.LegacyResponseHandlingEvent;
import com.senseonics.events.CalibrationCountdownEvent;
import com.senseonics.events.ModelChangedBatteryLevelEvent;
import com.senseonics.events.ModelChangedCalibrationTimeEvent;
import com.senseonics.events.ModelChangedCalibrationsMadeInThisPhaseEvent;
import com.senseonics.events.ModelChangedClinicalModeEvent;
import com.senseonics.events.ModelChangedCurrentCalibrationPhaseEvent;
import com.senseonics.events.ModelChangedDoNotDisturbModeEvent;
import com.senseonics.events.ModelChangedHighAlarmThresholdEvent;
import com.senseonics.events.ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent;
import com.senseonics.events.ModelChangedHighTargetThresholdEvent;
import com.senseonics.events.ModelChangedLastCalibrationDateTimeEvent;
import com.senseonics.events.ModelChangedLinkedSensorIdEvent;
import com.senseonics.events.ModelChangedLowAlarmThresholdEvent;
import com.senseonics.events.ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent;
import com.senseonics.events.ModelChangedLowTargetThresholdEvent;
import com.senseonics.events.ModelChangedRefreshGraphEvent;
import com.senseonics.events.ModelChangedSensorInsertDateTimeEvent;
import com.senseonics.events.ModelChangedStartPhaseCalibrationDateTimeEvent;
import com.senseonics.events.ModelChangedTransmitterFirmwareVersionEvent;
import com.senseonics.events.ModelChangedTransmitterModelNoEvent;
import com.senseonics.events.ModelChangedTransmitterSerialNumberEvent;
import com.senseonics.events.ModelChangedUnLinkedSensorIdEvent;
import com.senseonics.events.ModelChangedVibrateModeEvent;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.BlindedGlucoseCauseIdentifier;
import com.senseonics.util.Range;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class TransmitterStateModel {
    static final int DEFAULT_SAMPLING_INTERVAL = (int) TimeUnit.MINUTES.toSeconds(5);
    // #2604 Change the post calibration time to 15 minutes instead of 25 minutes(Android)
    static final int SAMPLING_INTERVAL_MULTIPLIER_FOR_CALIBRATION_DURATION = 3;
    static final int DAYS_TO_FETCH_FOR_SYNC = 3; // 3 days of data
    private static final int DEFAULT_CALIBRATION_MADE_THIS_PHASE = -1;


    private static int CALIBRATIONS_REQUIRED_DURING_INITIALIZATION_PHASE = 4;
    public static int CALIBRATIONS_REQUIRED_BEFORE_GLUCOSE_IN_INITIALIZATION_PHASE = 2;

    private EventBus eventBus;
    Map<Integer, ParsedResponse> responseIdToParsedResponseMap;
    private BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier;
    private SharedPreferences sharedPreferences;
    private Context context;

    // Transmitter Info
    private boolean isBluetoothEnabled;
    private Transmitter transmitter;
    private Transmitter.CONNECTION_STATE transmitterConnectionState;
    private String transmitterAddress;
    private String transmitterSerialNumber;
    private String transmitterModelNumber;
    private String transmitterVersionNumber;
    private String transmitterVersionExtensionNumber;
    private long transmitterTime;
    private Calendar startCalibrationPhaseDateAndTime;
    private Calendar lastCalibrationDateAndTime;
    private long latestCalibrationDateAndTime;

    private Calendar glucoseTimestamp;
    private int glucoseLevel;
    private Utils.ARROW_TYPE glucoseTrendDirection;
    private SIGNAL_STRENGTH signalStrength;
    private BATTERY_LEVEL batteryLevel = BATTERY_LEVEL.UNKNOWN_NEG_1;
    private Utils.TransmitterMessageCode currentMessageCode;
    private boolean placementModeInProgress;
    private boolean clinicalMode;
    private Utils.CAL_PHASE currentCalibrationPhase = Utils.CAL_PHASE.UNDERTERMINED;
    private int calibrationsMadeInThisPhase = -1;
    private int samplingIntervalInSeconds;
    private int algorithmParameterFormatVersion;

    //Sensor Information
    private Calendar sensorInsertionDateAndTime;
    private static CountDownTimer countDownTimer;
    private long currentCountdown;
    private boolean vibrateMode  = true;
    private boolean doNotDisturbMode;
    private String linkedSensorId;
    private String unLinkedSensorId;
    private int highGlucoseTarget;
    private int hysteresisHighGlocosePercent;
    private int hysteresisLowGlucoseValueMgDl;
    private int hysteresisHighPredictiveGlocosePercent;
    private int hysteresisLowPredictiveGlucoseValueMgDl;
    private int lowGlucoseTarget;
    private int highGlucoseAlarmThreshold;
    private int lowGlucoseAlarmThreshold;
    private int highGlucoseAlertThreshold;
    private int lowGlucoseAlertThreshold;
    private boolean predictiveAlertsActivated;
    private int predictiveFallingRateAlertMinuteInterval;
    private float rateAlertFallingThreshold;
    private boolean rateAlertsActivated;
    private int morningCalibrationTimeHour;
    private int morningCalibrationTimeMinute;
    private int eveningCalibrationTimeHour;
    private int eveningCalibrationTimeMinute;

    /** #4080 */
    private int morningCalibrationLocalTimeHour;
    private int morningCalibrationLocalTimeMinute;
    private int eveningCalibrationLocalTimeHour;
    private int eveningCalibrationLocalTimeMinute;

    private String transmitterName;

    // #2936
    private float MEPSavedValue;
    private float MEPSavedRefChannelMetric;
    private float MEPSavedDriftMetric;
    private float MEPSavedLowRefMetric;
    private float MEPSavedSpike;
    private float EEP24MSP;

    // #2379
    private int lowGlucoseAlarmRepeatIntervalDayTime;
    private int highGlucoseAlarmRepeatIntervalDayTime;
    private int lowGlucoseAlarmRepeatIntervalNightTime;
    private int highGlucoseAlarmRepeatIntervalNightTime;
    private int dayStartTimeHour;
    private int dayStartTimeMinute;
    private int nightStartTimeHour;
    private int nightStartTimeMinute;

    private long lastGlucoseSyncedMaxRecordTimestamp;

    private long lastReadTransmitterDatetimeTimestamp;

    private Range sensorGlucoseRecordRange;
    private Range alertRecordRange;
    private Range bloodGlucoseRecordRange;

    private int maxSyncedSensorRecord;
    private int maxSyncedAlertRecord;
    private int maxSyncedBloodGlucoseRecord;

    /** #3194 */
    private int rawDataValue1;
    private int rawDataValue2;
    private int rawDataValue3;
    private int rawDataValue4;
    private int rawDataValue5;
    private int rawDataValue6;
    private int rawDataValue7;
    private int rawDataValue8;

    @Inject
    public TransmitterStateModel(EventBus eventBus, DefaultedHashMap<Integer, ParsedResponse> responseIdToParsedResponseMap, BlindedGlucoseCauseIdentifier blindedGlucoseCauseIdentifier, SharedPreferences sharedPreferences, Context context) {
        this.eventBus = eventBus;
        this.responseIdToParsedResponseMap = responseIdToParsedResponseMap;
        this.blindedGlucoseCauseIdentifier = blindedGlucoseCauseIdentifier;
        this.sharedPreferences = sharedPreferences;
        this.context = context;
        eventBus.register(this);

        isBluetoothEnabled = false;

        //Transmitter Init
        transmitter = null;
        transmitterConnectionState = Transmitter.CONNECTION_STATE.DISCONNECTED;
        transmitterAddress = sharedPreferences.getString(Utils.prefTransmitterAddress, null);
        transmitterName = sharedPreferences.getString(Utils.prefTransmitterName, null);
        transmitterSerialNumber = sharedPreferences.getString(Utils.prefTransmitterSerialNumber, null);
        transmitterModelNumber = sharedPreferences.getString(Utils.prefTransmitterModelNumber, null);
        transmitterVersionNumber = sharedPreferences.getString(Utils.prefTransmitterFirmwareVersion, null);
        transmitterVersionExtensionNumber = sharedPreferences.getString(Utils.prefTransmitterVersionExtensionNumber, null);
        transmitterTime = sharedPreferences.getLong(Utils.prefTransmitterTime, 0L);
        startCalibrationPhaseDateAndTime = getStartCalibrationPhaseDateAndTime();
        lastCalibrationDateAndTime = getlastCalibrationDateAndTime();

        latestCalibrationDateAndTime = getlatestCalibrationDateAndTimeInMillis();
        //Sensor Iinitialization
        sensorInsertionDateAndTime = getSensorInsertionDateAndTime();
        linkedSensorId = sharedPreferences.getString(Utils.prefSensorId, null);
        unLinkedSensorId = sharedPreferences.getString(Utils.prefUnlinkedSensorId, null);

        glucoseTimestamp = null;
        glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN;
        glucoseTrendDirection = Utils.ARROW_TYPE.STALE;
        signalStrength = SIGNAL_STRENGTH.NO_SIGNAL;
        batteryLevel = BATTERY_LEVEL.valueOf(sharedPreferences.getString(Utils.prefTransmitterBatteryLevel, BATTERY_LEVEL.UNKNOWN_NEG_1.name()));
        currentMessageCode = Utils.TransmitterMessageCode.NumberOfMessages;
        placementModeInProgress = false;
        clinicalMode = false;
        currentCalibrationPhase = Utils.CAL_PHASE.valueOf(sharedPreferences.getString(Utils.prefCurrentCalibrationPhase, Utils.CAL_PHASE.UNDERTERMINED.name()));
        calibrationsMadeInThisPhase = sharedPreferences.getInt(Utils.prefTransmitterCalibrationsMadeInThisPhase, DEFAULT_CALIBRATION_MADE_THIS_PHASE);

        samplingIntervalInSeconds = sharedPreferences.getInt(Utils.prefSamplingInterval, DEFAULT_SAMPLING_INTERVAL);
        algorithmParameterFormatVersion = sharedPreferences.getInt(Utils.prefAlgorithmParameterFormatVersion, 0);

        currentCountdown = 0;

        // Initialize glucose thresholds
        highGlucoseTarget = sharedPreferences.getInt(Utils.prefTargetHigh, 140);
        lowGlucoseTarget = sharedPreferences.getInt(Utils.prefTargetLow, 80);
        highGlucoseAlarmThreshold = sharedPreferences.getInt(Utils.prefAlarmHigh, 200);
        lowGlucoseAlarmThreshold = sharedPreferences.getInt(Utils.prefAlarmLow, 70);
        highGlucoseAlertThreshold = 295;
        lowGlucoseAlertThreshold = 60;

        predictiveAlertsActivated = sharedPreferences.getBoolean(Utils.prefPredictiveAlertsActivated, false);
        predictiveFallingRateAlertMinuteInterval = sharedPreferences.getInt(Utils.prefPredictiveMinutes, 20); // minutes
        rateAlertFallingThreshold = sharedPreferences.getFloat(Utils.prefRateValue, 2.5f); // mg/dL/min
        rateAlertsActivated = sharedPreferences.getBoolean(Utils.prefRateAlertsActivated, false);

        hysteresisHighGlocosePercent = sharedPreferences.getInt(Utils.prefHysteresisPercent, 0);
        hysteresisLowGlucoseValueMgDl = sharedPreferences.getInt(Utils.prefHysteresisValue, 0);

        hysteresisHighPredictiveGlocosePercent = sharedPreferences.getInt(Utils.prefHysteresisPredictivePercent, 0);
        hysteresisLowPredictiveGlucoseValueMgDl = sharedPreferences.getInt(Utils.prefHysteresisPredictiveValue, 0);

        vibrateMode = sharedPreferences.getBoolean(Utils.prefVibrationMode, true);

        int[] defaultHourMinuteMorning = Utils.convertHourFromLocaltoGMT(Utils.morningCalibrationHourDefaultLocal, Utils.morningCalibrationMinuteDefault);  // 8:00 local
        morningCalibrationTimeHour = sharedPreferences.getInt(Utils.prefMorningCalHour, defaultHourMinuteMorning[0]);
        morningCalibrationTimeMinute = sharedPreferences.getInt(Utils.prefMorningCalMinute, defaultHourMinuteMorning[1]);

        int[] defaultHourMinuteEvening = Utils.convertHourFromLocaltoGMT(Utils.eveningCalibrationHourDefaultLocal, Utils.eveningCalibrationMinuteDefault);  // 18:00 local
        eveningCalibrationTimeHour = sharedPreferences.getInt(Utils.prefEveningCalHour, defaultHourMinuteEvening[0]);
        eveningCalibrationTimeMinute = sharedPreferences.getInt(Utils.prefEveningCalMinute, defaultHourMinuteEvening[1]);

        /** #4080 */
        morningCalibrationLocalTimeHour = sharedPreferences.getInt(Utils.prefMorningCalLocalHour, -1);
        morningCalibrationLocalTimeMinute = sharedPreferences.getInt(Utils.prefMorningCalLocalMinute, -1);
        eveningCalibrationLocalTimeHour = sharedPreferences.getInt(Utils.prefEveningCalLocalHour, -1);
        eveningCalibrationLocalTimeMinute = sharedPreferences.getInt(Utils.prefEveningCalLocalMinute, -1);

        // #2936
        MEPSavedValue = sharedPreferences.getFloat(Utils.prefMEPSavedValue, Float.NaN);
        Log.d("NewRegisters", "Model init: MEPSavedValue:" + MEPSavedValue);
        MEPSavedRefChannelMetric = sharedPreferences.getFloat(Utils.prefMEPSavedRefChannelMetric, Float.NaN);
        Log.d("NewRegisters", "Model init: MEPSavedRefChannelMetric:" + MEPSavedRefChannelMetric);
        MEPSavedDriftMetric = sharedPreferences.getFloat(Utils.prefMEPSavedDriftMetric, Float.NaN);
        Log.d("NewRegisters", "Model init: MEPSavedDriftMetric:" + MEPSavedDriftMetric);
        MEPSavedLowRefMetric = sharedPreferences.getFloat(Utils.prefMEPSavedLowRefMetric, Float.NaN);
        Log.d("NewRegisters", "Model init: MEPSavedLowRefMetric:" + MEPSavedLowRefMetric);
        MEPSavedSpike = sharedPreferences.getFloat(Utils.prefMEPSavedSpike, Float.NaN);
        Log.d("NewRegisters", "Model init: MEPSavedSpike:" + MEPSavedSpike);
        EEP24MSP = sharedPreferences.getFloat(Utils.prefEEP24MSP, 1.0f);
        Log.d("NewRegisters", "Model init: EEP24MSP:" + EEP24MSP);

        // #2379
        lowGlucoseAlarmRepeatIntervalDayTime = sharedPreferences.getInt(Utils.prefLowGlucoseAlarmRepeatIntervalDayTime, 15);
        Log.d("NewRegisters", "Model init: Day Low:" + lowGlucoseAlarmRepeatIntervalDayTime);

        highGlucoseAlarmRepeatIntervalDayTime = sharedPreferences.getInt(Utils.prefHighGlucoseAlarmRepeatIntervalDayTime, 30);
        Log.d("NewRegisters", "Model init: Day High:" + highGlucoseAlarmRepeatIntervalDayTime);

        lowGlucoseAlarmRepeatIntervalNightTime = sharedPreferences.getInt(Utils.prefLowGlucoseAlarmRepeatIntervalNightTime, 15);
        Log.d("NewRegisters", "Model init: Night Low:" + lowGlucoseAlarmRepeatIntervalNightTime);

        highGlucoseAlarmRepeatIntervalNightTime = sharedPreferences.getInt(Utils.prefHighGlucoseAlarmRepeatIntervalNightTime, 30);
        Log.d("NewRegisters", "Model init: Night High:" + highGlucoseAlarmRepeatIntervalNightTime);

        int[] defaultHourMinuteDayStart = Utils.convertHourFromLocaltoGMT(Utils.dayStartTimeHourDefaultLocal, Utils.dayStartTimeMinuteDefault); //  8:00 local
        dayStartTimeHour = sharedPreferences.getInt(Utils.prefDayStartTimeHour, defaultHourMinuteDayStart[0]);
        dayStartTimeMinute = sharedPreferences.getInt(Utils.prefDayStartTimeMinute, defaultHourMinuteDayStart[1]);
        Log.d("NewRegisters", "Model init: dayStartTimeHour:" + dayStartTimeHour);
        Log.d("NewRegisters", "Model init: dayStartTimeMinute:" + dayStartTimeMinute);

        int[] defaultHourMinuteNightStart = Utils.convertHourFromLocaltoGMT(Utils.nightStartTimeHourDefaultLocal, Utils.nightStartTimeMinuteDefault); // 20:00 local
        nightStartTimeHour = sharedPreferences.getInt(Utils.prefNightStartTimeHour, defaultHourMinuteNightStart[0]);
        nightStartTimeMinute = sharedPreferences.getInt(Utils.prefNightStartTimeMinute, defaultHourMinuteNightStart[1]);
        Log.d("NewRegisters", "Model init: nightStartTimeHour:" + nightStartTimeHour);
        Log.d("NewRegisters", "Model init: nightStartTimeMinute:" + nightStartTimeMinute);

        lastGlucoseSyncedMaxRecordTimestamp = sharedPreferences.getLong(Utils.prefLastGlucoseSyncedMaxRecordTimestamp, 0L);

		sensorGlucoseRecordRange = new Range(sharedPreferences.getInt(Utils.prefsensorGlucoseRecordRangeFrom, 0), sharedPreferences.getInt(Utils.prefsensorGlucoseRecordRangeTo, 0));
        alertRecordRange = new Range(sharedPreferences.getInt(Utils.prefalertRecordRangeFrom, 0), sharedPreferences.getInt(Utils.prefalertRecordRangeTo, 0));
        bloodGlucoseRecordRange = new Range(sharedPreferences.getInt(Utils.prefbloodGlucoseRecordRangeFrom, 0), sharedPreferences.getInt(Utils.prefbloodGlucoseRecordRangeTo, 0));

        maxSyncedSensorRecord = sharedPreferences.getInt(Utils.prefMaxSyncedSensorRecord, 0);
        maxSyncedAlertRecord = sharedPreferences.getInt(Utils.prefMaxSyncedAlertRecord, 0);
        maxSyncedBloodGlucoseRecord = sharedPreferences.getInt(Utils.prefMaxSyncedBloodGlucoseRecord, 0);
		
        /** #3194 */
        rawDataValue1 = 0;
        rawDataValue2 = 0;
        rawDataValue3 = 0;
        rawDataValue4 = 0;
        rawDataValue5 = 0;
        rawDataValue6 = 0;
        rawDataValue7 = 0;
        rawDataValue8 = 0;

        this.lastReadTransmitterDatetimeTimestamp = sharedPreferences.getLong(Utils.prefLastReadTransmitterDatetimeTimestamp, 0L);
    }

    public void adjustLastReadDateTimeWhenSendingReadCommand() {
        long lastReadDatetime = getLastReadTransmitterDatetimeTimestamp();
        long currentDatetime = Calendar.getInstance().getTimeInMillis();
        long diff = currentDatetime - lastReadDatetime;
//        Log.d("#3734", TransmitterStateModel.class.getSimpleName() + ": lastReadDatetime:" + lastReadDatetime + "|now:" + currentDatetime + "|diff:" + diff);

        if (diff < 0) {
//            Log.d("#3734", "PANIC: invalid last read time => reset it (1)");
            setLastReadTransmitterDatetimeTimestamp(0L);
        }
        else {
            if (diff > 5 * GraphUtils.SECOND) { // older than 5s
//                Log.d("#3734", "older than 5s =>" + diff);
                setLastReadTransmitterDatetimeTimestamp(currentDatetime);
            }
            else { // within 5 seconds, do not update the time
//                Log.d("#3734", "within 5s =>" + diff);
            }
        }
    }

    public long getLastReadTransmitterDatetimeTimestamp() {
        return lastReadTransmitterDatetimeTimestamp;
    }

    public void setLastReadTransmitterDatetimeTimestamp(long timestampIn) {
        this.lastReadTransmitterDatetimeTimestamp = timestampIn;
        sharedPreferences.edit().putLong(Utils.prefLastReadTransmitterDatetimeTimestamp, timestampIn).commit();
    }

    public long getLastGlucoseSyncedMaxRecordTimestamp() {
        return lastGlucoseSyncedMaxRecordTimestamp;
    }

    public void setLastGlucoseSyncedMaxRecordTimestamp(long timestampIn) {
        this.lastGlucoseSyncedMaxRecordTimestamp = timestampIn;
        sharedPreferences.edit().putLong(Utils.prefLastGlucoseSyncedMaxRecordTimestamp, timestampIn).apply();
    }

	    public Range getSensorGlucoseRecordRange() {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "Model sensorGlucoseRecordRange:" + sensorGlucoseRecordRange.toString());
        return sensorGlucoseRecordRange;
    }

    public void setSensorGlucoseRecordRange(Range range) {
        this.sensorGlucoseRecordRange = range;
        sharedPreferences.edit().putInt(Utils.prefsensorGlucoseRecordRangeFrom, range.getFrom()).apply();
        sharedPreferences.edit().putInt(Utils.prefsensorGlucoseRecordRangeTo, range.getTo()).apply();
    }

    public Range getAlertRecordRange() {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "Model alertRecordRange:" + alertRecordRange.toString());
        return alertRecordRange;
    }

    public void setAlertRecordRange(Range range) {
        this.alertRecordRange = range;
        sharedPreferences.edit().putInt(Utils.prefalertRecordRangeFrom, range.getFrom()).apply();
        sharedPreferences.edit().putInt(Utils.prefalertRecordRangeTo, range.getTo()).apply();
    }

    public Range getBloodGlucoseRecordRange() {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "Model bloodGlucoseRecordRange:" + bloodGlucoseRecordRange.toString());
        return bloodGlucoseRecordRange;
    }

    public void setBloodGlucoseRecordRange(Range range) {
        this.bloodGlucoseRecordRange = range;
        sharedPreferences.edit().putInt(Utils.prefbloodGlucoseRecordRangeFrom, range.getFrom()).apply();
        sharedPreferences.edit().putInt(Utils.prefbloodGlucoseRecordRangeTo, range.getTo()).apply();
    }

    public int getMaxSyncedSensorRecord() {
        return maxSyncedSensorRecord;
    }

    public void setMaxSyncedSensorRecord(int value) {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "*** setMaxSyncedSensorRecord:" + value);
        this.maxSyncedSensorRecord = value;
        sharedPreferences.edit().putInt(Utils.prefMaxSyncedSensorRecord, value).apply();
    }

    public int getMaxSyncedAlertRecord() {
        return maxSyncedAlertRecord;
    }

    public void setMaxSyncedAlertRecord(int value) {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "*** setMaxSyncedAlertRecord:" + value);
        this.maxSyncedAlertRecord = value;
        sharedPreferences.edit().putInt(Utils.prefMaxSyncedAlertRecord, value).apply();
    }

    public int getMaxSyncedBloodGlucoseRecord() {
        return maxSyncedBloodGlucoseRecord;
    }

    public void setMaxSyncedBloodGlucoseRecord(int value) {
        Log.d(TransmitterStateModel.class.getSimpleName() + " PrepareSync", "*** setMaxSyncedBloodGlucoseRecord:" + value);
        this.maxSyncedBloodGlucoseRecord = value;
        sharedPreferences.edit().putInt(Utils.prefMaxSyncedBloodGlucoseRecord, value).apply();
    }

    public void resetSyncRecordNumbersIfNeeded() {
        Log.d(TransmitterStateModel.class.getSimpleName() + " preparesync", "--- resetSyncRecordNumbersIfNeeded ---");
        setMaxSyncedSensorRecord(0);
        setMaxSyncedAlertRecord(0);
        setMaxSyncedBloodGlucoseRecord(0);
    }

    public int getHysteresisHighGlocosePercent() {
        return hysteresisHighGlocosePercent;
    }

    public void setHysteresisHighGlocosePercent(int hysteresisHighGlocosePercent) {
        this.hysteresisHighGlocosePercent = hysteresisHighGlocosePercent;
        sharedPreferences.edit().putInt(Utils.prefHysteresisPercent, hysteresisHighGlocosePercent).apply();
    }

    public int getHysteresisLowGlucoseValueMgDl() {
        return hysteresisLowGlucoseValueMgDl;
    }

    public void setHysteresisLowGlucoseValueMgDl(int hysteresisLowGlucoseValueMgDl) {
        this.hysteresisLowGlucoseValueMgDl = hysteresisLowGlucoseValueMgDl;
        sharedPreferences.edit().putInt(Utils.prefHysteresisValue,hysteresisLowGlucoseValueMgDl).apply();
    }

    public int getHysteresisHighPredictiveGlocosePercent() {
        return hysteresisHighPredictiveGlocosePercent;
    }

    public void setHysteresisHighPredictiveGlocosePercent(int hysteresisHighPredictiveGlocosePercent) {
        this.hysteresisHighPredictiveGlocosePercent = hysteresisHighPredictiveGlocosePercent;
        sharedPreferences.edit().putInt(Utils.prefHysteresisPredictivePercent, hysteresisHighPredictiveGlocosePercent).apply();
    }

    public int getHysteresisLowPredictiveGlucoseValueMgDl() {
        return hysteresisLowPredictiveGlucoseValueMgDl;
    }

    public void setHysteresisLowPredictiveGlucoseValueMgDl(int hysteresisLowPredictiveGlucoseValueMgDl) {
        this.hysteresisLowPredictiveGlucoseValueMgDl = hysteresisLowPredictiveGlucoseValueMgDl;
        sharedPreferences.edit().putInt(Utils.prefHysteresisPredictiveValue, hysteresisLowPredictiveGlucoseValueMgDl).apply();
    }

    public void onEvent(LegacyResponseHandlingEvent event) {
        Log.i(TransmitterStateModel.class.getSimpleName(), "onEvent: " + HexHelper.intArrayToString(event.getData()));

        ParsedResponse parsedResponse = responseIdToParsedResponseMap.get(event.actualResponseId());
        if (parsedResponse instanceof NoOpParsedResponse) {
            Log.w(TransmitterStateModel.class.getSimpleName(), "responseId (" + Integer.toString(event.actualResponseId(), 16) + ") was not handled. " + HexHelper.intArrayToString(event.getData()));
        }
        Log.i(TransmitterStateModel.class.getSimpleName(), "parsed response:" + parsedResponse);

        if (parsedResponse.check(event.getData())) {
            parsedResponse.apply(event.getData(), this);
        }
    }

    private void updateTransmitterNameInPreference() {
        if (transmitterName == null) {
            sharedPreferences.edit().remove(Utils.prefTransmitterName).apply();
        } else {
            sharedPreferences.edit().putString(Utils.prefTransmitterName, transmitterName).apply();
        }
    }

    private void updateTransmitterAddressInPreference() {
        if (transmitterAddress == null) {
            sharedPreferences.edit().remove(Utils.prefTransmitterAddress).apply();
        } else {
            sharedPreferences.edit().putString(Utils.prefTransmitterAddress, transmitterAddress).apply();
        }
    }

    public void onEvent(TransmitterConnectionEvent event) {
        Transmitter.CONNECTION_STATE state = event.getTransmitter().getConnectionState();
        Log.d("statusbar", "onEvent " + event + " with old state " + transmitterConnectionState);
        if (state != Transmitter.CONNECTION_STATE.CONNECTED
                && state != Transmitter.CONNECTION_STATE.TRANSPORT_CONNECTED
                && transmitterAddress != null
                && !event.getTransmitter().getAddress().equals(transmitterAddress)) {
            Log.d("statusbar", "skipping disconnect from another tx " + event);
        } else {
            transmitter = event.getTransmitter();
            String newAddress = transmitter.getAddress();
            Boolean isSameTransmitter = (transmitterAddress != null) && (newAddress != null) && (transmitterAddress.equals(newAddress));

            /** APPDEV-4058 only update the address and name if it's a different transmitter */
            if (!isSameTransmitter) {
                setTransmitterAddress(newAddress);
                setTransmitterName(transmitter.getName());
            }
        }

        transmitterConnectionState = state;

        if (event.getTransmitter().getConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED) {
            this.glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN;
            this.glucoseTrendDirection = Utils.ARROW_TYPE.STALE;
            signalStrength = SIGNAL_STRENGTH.NO_SIGNAL;
        }
        long timestampCalib = 0;
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
        long DSToffset = calendar.get(Calendar.DST_OFFSET);
        long currentTimeStamp = calendar.getTimeInMillis()-timeZoneDiff-DSToffset;
        long calibMinsInMillis = getCalibrationDuration() * GraphUtils.MINUTE;

        if (sharedPreferences.contains(Utils.prefCalibrationDateTime)) {
            timestampCalib = sharedPreferences.getLong(Utils.prefCalibrationDateTime, 0);
        }

        long diffInMillis = currentTimeStamp - timestampCalib;
        if((diffInMillis <= calibMinsInMillis) && (diffInMillis >= 0)) {
            currentCountdown = calibMinsInMillis - diffInMillis;
        } else {
            currentCountdown = 0;
        }
        fireChangeEvent();
        if(currentCountdown > 0) {
            if (countDownTimer == null) {
                countDownTimer = new CustomCountDownTimer(eventBus, currentCountdown, 1000);
            } else {
                countDownTimer.cancel();
                countDownTimer = null;
                countDownTimer = new CustomCountDownTimer(eventBus, currentCountdown, 1000);
            }
            countDownTimer.start();
        }
    }

    public void onEvent(BluetoothConnectionEvent event) {
        isBluetoothEnabled = event.isBluetoothEnabled();
        fireChangeEvent();
    }

    public void onEvent(CalibrationCountdownEvent event) {
        Log.d("statusBar", event.toString());
        if (transmitterConnectionState == Transmitter.CONNECTION_STATE.CONNECTED) {
            currentCountdown = event.getCurrentCountdownMillis();
            fireChangeEvent();
        }
    }

    public Transmitter.CONNECTION_STATE getTransmitterConnectionState() {
        return this.transmitterConnectionState;
    }

    public Calendar getSensorInsertionDateAndTime() {
        if(this.sensorInsertionDateAndTime == null) {
            long sensorInsertionDateAndTimeMilli = sharedPreferences.getLong(Utils.prefSensorInsertionDateTime, 0L);
            if (sensorInsertionDateAndTimeMilli == 0L) {
                return null;
            } else {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(sensorInsertionDateAndTimeMilli);
                return calendar;
            }
        }
        else {
            return this.sensorInsertionDateAndTime;
        }
    }

    public void setSensorInsertionDateAndTime(Calendar sensorInsertionDateAndTimeIn) {
        this.sensorInsertionDateAndTime = sensorInsertionDateAndTimeIn;

        if (sensorInsertionDateAndTimeIn == null) {
            sharedPreferences.edit().putLong(Utils.prefSensorInsertionDateTime, 0L).apply();
        }
        else {
            sharedPreferences.edit().putLong(Utils.prefSensorInsertionDateTime, sensorInsertionDateAndTimeIn.getTimeInMillis()).apply();
        }

        Log.i("Insertion Debug", "fire change event");
        fireChangeEvent();
        eventBus.post(new ModelChangedSensorInsertDateTimeEvent(sensorInsertionDateAndTime));
    }

    public void setSensorInsertionDateOnly(int[] date) {
        if (date[0] == 2000 && date[1] == 0 && date[2] == 0) { // this means 0 in the Tx
            this.sensorInsertionDateAndTime = null;
            sharedPreferences.edit().putLong(Utils.prefSensorInsertionDateTime, 0L).apply();
        } else {
            Calendar dateTimeToSet = this.sensorInsertionDateAndTime;
            if (dateTimeToSet == null) {
                dateTimeToSet = Calendar.getInstance();
            }

            dateTimeToSet.setTimeZone(TimeZone.getTimeZone("GMT"));
            dateTimeToSet.set(Calendar.YEAR, date[0]);
            dateTimeToSet.set(Calendar.MONTH, date[1] - 1);
            dateTimeToSet.set(Calendar.DAY_OF_MONTH, date[2]);
            dateTimeToSet.set(Calendar.HOUR_OF_DAY, 0);
            dateTimeToSet.set(Calendar.MINUTE, 0);
            dateTimeToSet.set(Calendar.SECOND, 0);

            Log.i("Insertion Debug", "set date only");
            this.sensorInsertionDateAndTime = dateTimeToSet;
        }
    }

    public boolean isBluetoothEnabled() {
        return this.isBluetoothEnabled;
    }

    public void setIsBluetoothEnabled(boolean enabled) {
        this.isBluetoothEnabled = enabled;
    }

    public Transmitter getTransmitter() {
        return this.transmitter;
    }

    public String getTransmitterName() {
        return this.transmitterName;
    }

    public void setTransmitterName(String transmitterName) {
        this.transmitterName = transmitterName;
        updateTransmitterNameInPreference();
    }

    public String getTransmitterAddress() {
        return this.transmitterAddress;
    }

    public void setTransmitterAddress(String newTransmitterAddress) {
        this.transmitterAddress = newTransmitterAddress;
        updateTransmitterAddressInPreference();
    }

    public String getTransmitterSerialNumber() {
        return transmitterSerialNumber;
    }

    public void setTransmitterSerialNumber(String newTransmitterSerialNumber) {
        this.transmitterSerialNumber = newTransmitterSerialNumber;
        sharedPreferences.edit().putString(Utils.prefTransmitterSerialNumber, transmitterSerialNumber).apply();
        eventBus.post(new ModelChangedTransmitterSerialNumberEvent(transmitterSerialNumber));
        fireChangeEvent();
    }

    public String getTransmitterModelNumber() {
        return transmitterModelNumber;
    }

    public void setTransmitterModelNumber(String newTransmitterModelNumber) {
        this.transmitterModelNumber = newTransmitterModelNumber;
        sharedPreferences.edit().putString(Utils.prefTransmitterModelNumber, transmitterModelNumber).apply();
        eventBus.post(new ModelChangedTransmitterModelNoEvent(newTransmitterModelNumber));
        fireChangeEvent();
    }

    public boolean isFormattedTransmitterVersionXL() {
        String formattedTxVersion = getFormattedTransmitterVersionNumber();
        boolean isXL = false;

        if (formattedTxVersion != null) {
            if (formattedTxVersion.toUpperCase().endsWith("X")
                    || formattedTxVersion.toUpperCase().endsWith("Y")
                    || formattedTxVersion.toUpperCase().endsWith("Z")
                    || formattedTxVersion.toUpperCase().endsWith("E")) {
                isXL = true;
            }
        }

        return isXL;
    }

    public String getFormattedTransmitterVersionNumber() {
        String extensionNumber = getTransmitterVersionExtensionNumber();
        String versionNumber = getTransmitterVersionNumber();
        if (extensionNumber == null) {
            return versionNumber;
        } else {
            if (Utils.countOccurrancesInString(versionNumber, ".") == 1) {
                return (versionNumber + extensionNumber).replaceFirst("^0+", "");
            }
        }

        return versionNumber;
    }

    private String getTransmitterVersionNumber() {
        return transmitterVersionNumber;
    }

    private String getTransmitterVersionExtensionNumber() {
        return transmitterVersionExtensionNumber;
    }

    public void setTransmitterVersionNumber(String newTransmitterVersionNumber) {
        this.transmitterVersionNumber = newTransmitterVersionNumber;
        sharedPreferences.edit().putString(Utils.prefTransmitterFirmwareVersion, transmitterVersionNumber).apply();
        eventBus.post(new ModelChangedTransmitterFirmwareVersionEvent(newTransmitterVersionNumber));
        fireChangeEvent();
    }

    public void setTransmitterVersionExtensionNumber(String transmitterVersionExtensionNumber) {
        this.transmitterVersionExtensionNumber = transmitterVersionExtensionNumber;
        sharedPreferences.edit().putString(Utils.prefTransmitterVersionExtensionNumber, transmitterVersionExtensionNumber).apply();
    }

    public long getTransmitterTime() {
        return transmitterTime;
    }

    public void setTransmitterTime(long newTransmitterTime) {
        this.transmitterTime = newTransmitterTime;
        sharedPreferences.edit().putLong(Utils.prefTransmitterTime, transmitterTime).apply();
    }

    public Calendar getStartCalibrationPhaseDateAndTime() {
        if (startCalibrationPhaseDateAndTime == null) {
            long millis = sharedPreferences.getLong(Utils.prefTransmitterCalibrationStartDate, 0L);
            if (millis == 0L) {
                return null;
            } else {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(millis);
                return calendar;
            }
        }
        else {
            return startCalibrationPhaseDateAndTime;
        }
    }

    public void setStartCalibrationPhaseDateAndTime(Calendar newstartCalibrationPhaseDateAndTime) {
        this.startCalibrationPhaseDateAndTime = newstartCalibrationPhaseDateAndTime;

        if (newstartCalibrationPhaseDateAndTime == null) {
            sharedPreferences.edit().putLong(Utils.prefTransmitterCalibrationStartDate, 0L).apply();
        }
        else {
            sharedPreferences.edit().putLong(Utils.prefTransmitterCalibrationStartDate, startCalibrationPhaseDateAndTime.getTimeInMillis()).apply();
        }

        eventBus.post(new ModelChangedStartPhaseCalibrationDateTimeEvent(startCalibrationPhaseDateAndTime));
        fireChangeEvent();
    }

    public void setCalibrationPhaseStartDateOnly(int[] date) {
        if (date[0] == 2000 && date[1] == 0 && date[2] == 0) { // this means 0 in the Tx
            this.startCalibrationPhaseDateAndTime = null;
            sharedPreferences.edit().putLong(Utils.prefTransmitterCalibrationStartDate, 0L).apply();
        } else {
            Calendar dateTimeToSet = this.startCalibrationPhaseDateAndTime;
            if (dateTimeToSet == null) {
                dateTimeToSet = Calendar.getInstance();
            }

            dateTimeToSet.setTimeZone(TimeZone.getTimeZone("GMT"));
            dateTimeToSet.set(Calendar.YEAR, date[0]);
            dateTimeToSet.set(Calendar.MONTH, date[1] - 1);
            dateTimeToSet.set(Calendar.DAY_OF_MONTH, date[2]);
            dateTimeToSet.set(Calendar.HOUR_OF_DAY, 0);
            dateTimeToSet.set(Calendar.MINUTE, 0);
            dateTimeToSet.set(Calendar.SECOND, 0);
            this.startCalibrationPhaseDateAndTime = dateTimeToSet;
        }
    }

    @Nullable
    public Calendar getlastCalibrationDateAndTime() {
        if (this.lastCalibrationDateAndTime == null) {
            long lastCalibrationDateAndTimeFromPreferences = sharedPreferences.getLong(Utils.prefTransmitterLastCalibration, 0L);
            if (lastCalibrationDateAndTimeFromPreferences == 0L) {
                return null;
            } else {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(lastCalibrationDateAndTimeFromPreferences);
                return calendar;
            }
        }
        else {
            return this.lastCalibrationDateAndTime;
        }
    }

    // this is the getting the last user enterred calibration time in the app, not read from the Transmitter
    public long getlatestCalibrationDateAndTimeInMillis() {
        if (this.latestCalibrationDateAndTime == 0L) {
            long latestCalibrationDateAndTimeFromPreferences = sharedPreferences.getLong(Utils.prefCalibrationDateTime, 0L);
            if (latestCalibrationDateAndTimeFromPreferences == 0L) {
                return 0L;
            } else {
                return latestCalibrationDateAndTimeFromPreferences;
            }
        }
        return this.latestCalibrationDateAndTime;
    }

    public boolean noCalEventInSpecificTimeRange() {
        boolean retVal = false;

        long timestampCalib = getlatestCalibrationDateAndTimeInMillis();

        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        long timeZoneDiff = Utils.getTimeZoneOffset(calendar);
        long DSToffset = calendar.get(Calendar.DST_OFFSET);
        long currentTimeStamp = calendar.getTimeInMillis()-timeZoneDiff-DSToffset;
        long calibMinsInMillis = 40*60*1000;

        Log.d("TimeChange", "currentTimestamp:" + currentTimeStamp);
        Log.d("TimeChange", "timestampCalib:" + timestampCalib);
        Log.d("TimeChange", "calibMinsInMillis:" + calibMinsInMillis);
        Log.d("TimeChange", "diff:" + (currentTimeStamp - timestampCalib));

        long diffInMillis = currentTimeStamp - timestampCalib;
        if ((diffInMillis > calibMinsInMillis) || (diffInMillis < 0)) {
            retVal = true;
        }

        Log.d("TimeChange", "noCalEventInSpecificTimeRange?:" + retVal);

        return retVal;
    }

    public boolean couldWriteTransmitterDateTime() {
        boolean retVal = false;

        Transmitter.CONNECTION_STATE state = getTransmitterConnectionState();
        Log.d("TimeChange", "couldWriteTransmitterDateTime state:" + state);

        /** #3635 Sync Date and Time to Transmitter if the Time is set to 1/1/2000 */
        if(state == Transmitter.CONNECTION_STATE.CONNECTED) {
            if (noCalEventInSpecificTimeRange()) {
                retVal = true;
            }
        }

        Log.d("TimeChange", "couldWriteTransmitterDateTime:" + retVal);

        return retVal;
    }

    /** #3724 */
    public boolean couldWriteTransmitterDateTimeWhenStateSync() {
        boolean retVal = false;

        Transmitter.CONNECTION_STATE state = getTransmitterConnectionState();
        Log.d("TimeChange", "couldWriteTransmitterDateTimeWhenStateSync state:" + state);

        if (noCalEventInSpecificTimeRange()) {
            retVal = true;
        }

        Log.d("TimeChange", "couldWriteTransmitterDateTimeWhenStateSync:" + retVal);

        return retVal;
    }

    public void setLastCalibrationDateAndTime(Calendar lastCalibrationDateAndTime) {
        this.lastCalibrationDateAndTime = lastCalibrationDateAndTime;

        /** #3544 */
        if (lastCalibrationDateAndTime == null) {
            sharedPreferences.edit().putLong(Utils.prefTransmitterLastCalibration, 0L).apply();
        }
        else {
            sharedPreferences.edit().putLong(Utils.prefTransmitterLastCalibration, lastCalibrationDateAndTime.getTimeInMillis()).apply();
        }

        eventBus.post(new ModelChangedLastCalibrationDateTimeEvent(lastCalibrationDateAndTime));
        fireChangeEvent();
    }

    public void setlastCalibrationDateOnly(int[] date) {
        if (date[0] == 2000 && date[1] == 0 && date[2] == 0) { // this means 0 in the Tx
            this.lastCalibrationDateAndTime = null;
            sharedPreferences.edit().putLong(Utils.prefTransmitterLastCalibration, 0L).apply();
        } else {
            Calendar dateTimeToSet = this.lastCalibrationDateAndTime;
            if (dateTimeToSet == null) {
                dateTimeToSet = Calendar.getInstance();
            }
            dateTimeToSet.setTimeZone(TimeZone.getTimeZone("GMT"));
            dateTimeToSet.set(Calendar.YEAR, date[0]);
            dateTimeToSet.set(Calendar.MONTH, date[1] - 1);
            dateTimeToSet.set(Calendar.DAY_OF_MONTH, date[2]);
            dateTimeToSet.set(Calendar.HOUR_OF_DAY, 0);
            dateTimeToSet.set(Calendar.MINUTE, 0);
            dateTimeToSet.set(Calendar.SECOND, 0);
            this.lastCalibrationDateAndTime = dateTimeToSet;
        }
    }

    public SIGNAL_STRENGTH getSignalStrength() {
        return this.signalStrength;
    }

    public void setSignalStrength(SIGNAL_STRENGTH signalStrengthIn) {
        this.signalStrength = signalStrengthIn;
        fireChangeEvent();
    }

    public BATTERY_LEVEL getBatteryLevel() {
        return this.batteryLevel;
    }

    public void setBatteryLevel(BATTERY_LEVEL batteryLevel) {
        this.batteryLevel = batteryLevel;
        sharedPreferences.edit().putString(Utils.prefTransmitterBatteryLevel, batteryLevel.name()).apply();
        eventBus.post(new ModelChangedBatteryLevelEvent(batteryLevel));
        fireChangeEvent();
    }

    public String getBatteryLife() {
        return Utils.getBatteryPercentStringForLevel(getBatteryLevel());
    }

    public void setGlucoseTimestamp(Calendar glucoseTimestampIn) {
        this.glucoseTimestamp = glucoseTimestampIn;
    }

    public Calendar getGlucoseTimestamp() {
        return this.glucoseTimestamp;
    }

    public void setGlucoseLevel(int glucoseLevel) {
        Log.d("#3640", "setGlucoseLevel:" + glucoseLevel);
        this.glucoseLevel = glucoseLevel;
        fireChangeEvent();
        fireRefreshGraphEvent();
    }

    public int getGlucoseLevel() {
        return glucoseLevel;
    }

    public void setGlucoseTrendDirection(Utils.ARROW_TYPE glucoseTrendDirection) {
        this.glucoseTrendDirection = glucoseTrendDirection;
        fireChangeEvent();
    }

    public Utils.ARROW_TYPE getGlucoseTrendDirection() {
        return glucoseTrendDirection;
    }

    public boolean isGlucoseLevelWithinRange() {
        return glucoseLevel >= Utils.GLUCOSE_VALID_MIN && glucoseLevel <= Utils.GLUCOSE_VALID_MAX;
    }

    public boolean checkIfNonGlucoseShowingPhase() {
        if ((getCurrentCalibrationPhase() == Utils.CAL_PHASE.WARM_UP)
                || ((getCurrentCalibrationPhase()== Utils.CAL_PHASE.INITIALIZATION && getCalibrationsMadeInThisPhase() <= 1)))
            return true;
        else
            return false;
    }

    public void setCurrentMessageCode(Utils.TransmitterMessageCode currentMessageCode) {
        this.currentMessageCode = currentMessageCode;
        //may want to add logic to only fire change event if the new messageCode is > the old one
        fireChangeEvent();
    }

    public Utils.TransmitterMessageCode getCurrentMessageCode() {
        return currentMessageCode;
    }

    public boolean canCurrentMessageCodeBeReasonForBlinded() {
        return blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(currentMessageCode);
    }

    public void setPlacementModeInProgress(boolean placementModeInProgress) {
        boolean oldValue = this.placementModeInProgress;
        this.placementModeInProgress = placementModeInProgress;

        if (oldValue != this.placementModeInProgress) {
            fireChangeEvent();
        }
    }

    public boolean isPlacementModeInProgress() {
        return placementModeInProgress;
    }

    public void setClinicalMode(boolean clinicalMode) {
        this.clinicalMode = clinicalMode;

        sharedPreferences.edit().putBoolean(Utils.prefClinicalMode, clinicalMode).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedClinicalModeEvent(clinicalMode));
    }

    public boolean isClinicalMode() {
        return clinicalMode;
    }

    public Utils.CAL_PHASE getCurrentCalibrationPhase() {
        return currentCalibrationPhase;
    }

    public void setCurrentCalibrationPhase(Utils.CAL_PHASE currentCalibrationPhase) {
        this.currentCalibrationPhase = currentCalibrationPhase;
        sharedPreferences.edit().putString(Utils.prefCurrentCalibrationPhase, currentCalibrationPhase.name()).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedCurrentCalibrationPhaseEvent(currentCalibrationPhase));
    }

    public String getCurrentPhase() {
        // only display Warm Up, Initialization, and Daily Calibration; for all
        // other phases display "N/A"
        switch (getCurrentCalibrationPhase()) {
            case WARM_UP:
                return context.getString(R.string.warm_up_phase);
            case DAILY_CALIBRATION:
                return context.getString(R.string.daily_calibration);
            case INITIALIZATION:
                return context.getString(R.string.init_phase);
            case SUSPICIOUS:
            case UNKNOWN:
            case DEBUG:
            case DROPOUT:
            case UNDERTERMINED:
            default:
                return context.getString(R.string.next_schedule_cal_unknown);
        }
    }

    public String getCurrentPhaseNotTranslated() {
        switch (getCurrentCalibrationPhase()) {
            case WARM_UP:
                return "Warm Up";
            case DAILY_CALIBRATION:
                return "Daily Calibration";
            case INITIALIZATION:
                return "Initialization";
            case SUSPICIOUS:
                return "Suspicious Fingerstick";
            case UNKNOWN:
                return "Unknown";
            case DEBUG:
                return "Debug/Test";
            case DROPOUT:
                return "Dropout";
            case UNDERTERMINED:
            default:
                return "Not Available";
        }
    }

    public void setCalibrationsMadeInThisPhase(int calibrationsMadeInThisPhase) {
        this.calibrationsMadeInThisPhase = calibrationsMadeInThisPhase;
        sharedPreferences.edit().putInt(Utils.prefTransmitterCalibrationsMadeInThisPhase, calibrationsMadeInThisPhase).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedCalibrationsMadeInThisPhaseEvent(calibrationsMadeInThisPhase));
    }

    public int getCalibrationsMadeInThisPhase() {
        return calibrationsMadeInThisPhase;
    }

    public int getCalibrationsRemaining() {
        return CALIBRATIONS_REQUIRED_DURING_INITIALIZATION_PHASE - calibrationsMadeInThisPhase;
    }

    public long getCurrentCountdown() {
        return this.currentCountdown;
    }

    public void setCurrentCountdown(long countdownIn) {
        this.currentCountdown = countdownIn;
    }

    public int getSamplingIntervalInSeconds() {
        return samplingIntervalInSeconds;
    }

    public void setSamplingIntervalInSeconds(int samplingIntervalInSeconds) {
        this.samplingIntervalInSeconds = samplingIntervalInSeconds;
        sharedPreferences.edit().putInt(Utils.prefSamplingInterval, samplingIntervalInSeconds).apply();
    }

    public int getSamplingIntervalInMinutes() {
        int samplingIntervalInMin = samplingIntervalInSeconds / 60;

        if (samplingIntervalInMin < 1) {
            samplingIntervalInMin = 1;
        }

        return samplingIntervalInMin;
    }

    public int getAlgorithmParameterFormatVersion() {
        return algorithmParameterFormatVersion;
    }

    public void setAlgorithmParameterFormatVersion(int algorithmParameterFormatVersion) {
        Log.d("Algo format version", "Model set:"+algorithmParameterFormatVersion);
        this.algorithmParameterFormatVersion = algorithmParameterFormatVersion;
        sharedPreferences.edit().putInt(Utils.prefAlgorithmParameterFormatVersion, algorithmParameterFormatVersion).apply();
    }

    public int getCalibrationDuration() {
        int samplingIntervalInMin = samplingIntervalInSeconds / 60;

        int duration = SAMPLING_INTERVAL_MULTIPLIER_FOR_CALIBRATION_DURATION * samplingIntervalInMin;

        if (duration < 1)
            duration = 1;

        return duration;
    }

    public int getMaxGlucoseRecordsToSync() {
        int numberOfSamplesInHour = (60 * 60) / getSamplingIntervalInSeconds();
        return (DAYS_TO_FETCH_FOR_SYNC * 24) * numberOfSamplesInHour;
    }

    public int getHoursLeftForWarmupPhase() {
        int hours = 0;

        if ((getCurrentCalibrationPhase() == Utils.CAL_PHASE.WARM_UP)
                && (getSensorInsertionDateAndTime() != null)) {

            Calendar expectedWarmUpEnd = Calendar.getInstance();
            expectedWarmUpEnd.setTimeInMillis(getSensorInsertionDateAndTime().getTimeInMillis());
            expectedWarmUpEnd.add(Calendar.HOUR, 24);
            Calendar currentDateTime = Calendar.getInstance();
            long diffMillis = expectedWarmUpEnd.getTimeInMillis() - currentDateTime.getTimeInMillis();
            if (diffMillis >= 0) {
                return (int) ((diffMillis / 1000) / 60) / 60;
            }
        }
        return hours;
    }

    public boolean isVibrateMode() {
        return vibrateMode;
    }

    public void setVibrateMode(boolean vibrateMode) {
        this.vibrateMode = vibrateMode;
        sharedPreferences.edit().putBoolean(Utils.prefVibrationMode, vibrateMode).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedVibrateModeEvent(vibrateMode));
    }

    public void setDoNotDisturbMode(boolean doNotDisturbMode) {
        this.doNotDisturbMode = doNotDisturbMode;
        fireChangeEvent();
        eventBus.post(new ModelChangedDoNotDisturbModeEvent(doNotDisturbMode));
    }

    public void setLinkedSensorId(String linkedSensorId) {
        this.linkedSensorId = linkedSensorId;
        sharedPreferences.edit().putString(Utils.prefSensorId, linkedSensorId).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedLinkedSensorIdEvent(this.linkedSensorId));
    }

    public String getLinkedSensorId() {
        return linkedSensorId;
    }

    public void setUnLinkedSensorId(String unLinkedSensorId) {
        this.unLinkedSensorId = unLinkedSensorId;
        sharedPreferences.edit().putString(Utils.prefUnlinkedSensorId, unLinkedSensorId).apply();
        fireChangeEvent();
        eventBus.post(new ModelChangedUnLinkedSensorIdEvent(this.unLinkedSensorId));
    }

    public String getUnLinkedSensorId() {
        return unLinkedSensorId;
    }


    public void setHighGlucoseTarget(int highGlucoseTarget) {
        boolean shouldRefreshGraph = (this.highGlucoseTarget != highGlucoseTarget);
        Log.d("#3640_2", "setHighGlucoseTarget shouldRefreshGraph?" + shouldRefreshGraph + "|" + this.highGlucoseTarget + "|" + highGlucoseTarget);

        this.highGlucoseTarget = highGlucoseTarget;
        sharedPreferences.edit().putInt(Utils.prefTargetHigh, highGlucoseTarget).apply();
        Utils.GLUCOSE_TARGET_HIGH = highGlucoseTarget;

        /** #3160 */
        eventBus.post(new ModelChangedHighTargetThresholdEvent(highGlucoseTarget));

        fireChangeEvent();

        if (shouldRefreshGraph) {
            fireRefreshGraphEvent();
        }
    }

    public int getHighGlucoseTarget() {
        return highGlucoseTarget;
    }

    public void setLowGlucoseTarget(int lowGlucoseTarget) {
        boolean shouldRefreshGraph = (this.lowGlucoseTarget != lowGlucoseTarget);
        Log.d("#3640_2", "setLowGlucoseTarget shouldRefreshGraph?" + shouldRefreshGraph + "|" + this.lowGlucoseTarget + "|" + lowGlucoseTarget);

        this.lowGlucoseTarget = lowGlucoseTarget;
        sharedPreferences.edit().putInt(Utils.prefTargetLow, lowGlucoseTarget).apply();
        Utils.GLUCOSE_TARGET_LOW = lowGlucoseTarget;

        /** #3160 */
        eventBus.post(new ModelChangedLowTargetThresholdEvent(lowGlucoseTarget));

        fireChangeEvent();

        if (shouldRefreshGraph) {
            fireRefreshGraphEvent();
        }
    }

    public int getLowGlucoseTarget() {
        return lowGlucoseTarget;
    }

    public void setHighGlucoseAlarmThreshold(int highGlucoseAlarmThreshold) {
        boolean shouldRefreshGraph = (this.highGlucoseAlarmThreshold != highGlucoseAlarmThreshold);
        Log.d("#3640_2", "setHighGlucoseAlarmThreshold shouldRefreshGraph?" + shouldRefreshGraph + "|" + this.highGlucoseAlarmThreshold + "|" + highGlucoseAlarmThreshold);

        this.highGlucoseAlarmThreshold = highGlucoseAlarmThreshold;
        sharedPreferences.edit().putInt(Utils.prefAlarmHigh, highGlucoseAlarmThreshold).apply();
        Utils.GLUCOSE_ALARM_LEVEL_HIGH = highGlucoseAlarmThreshold;

        /** #3160 */
        eventBus.post(new ModelChangedHighAlarmThresholdEvent(highGlucoseAlarmThreshold));

        fireChangeEvent();

        if (shouldRefreshGraph) {
            fireRefreshGraphEvent();
        }
    }

    public int getHighGlucoseAlarmThreshold() {
        return highGlucoseAlarmThreshold;
    }

    public int getHighGlucoseAlertThreshold() {
        return highGlucoseAlertThreshold;
    }

    public int getLowGlucoseAlertThreshold() {
        return lowGlucoseAlertThreshold;
    }

    public void setLowGlucoseAlarmThreshold(int lowGlucoseAlarmThreshold) {
        boolean shouldRefreshGraph = (this.lowGlucoseAlarmThreshold != lowGlucoseAlarmThreshold);
        Log.d("#3640_2", "setLowGlucoseAlarmThreshold shouldRefreshGraph?" + shouldRefreshGraph + "|" + this.lowGlucoseAlarmThreshold + "|" + lowGlucoseAlarmThreshold);

        this.lowGlucoseAlarmThreshold = lowGlucoseAlarmThreshold;
        sharedPreferences.edit().putInt(Utils.prefAlarmLow, lowGlucoseAlarmThreshold).apply();
        Utils.GLUCOSE_ALARM_LEVEL_LOW = lowGlucoseAlarmThreshold;

        /** #3160 */
        eventBus.post(new ModelChangedLowAlarmThresholdEvent(lowGlucoseAlarmThreshold));

        fireChangeEvent();

        if (shouldRefreshGraph) {
            fireRefreshGraphEvent();
        }
    }

    public int getLowGlucoseAlarmThreshold() {
        return lowGlucoseAlarmThreshold;
    }

    public void setPredictiveAlertsActivated(boolean predictiveAlertsActivated) {
        this.predictiveAlertsActivated = predictiveAlertsActivated;
        sharedPreferences.edit().putBoolean(Utils.prefPredictiveAlertsActivated, predictiveAlertsActivated).apply();
        Utils.predictiveAlertsActivated = predictiveAlertsActivated;
        fireChangeEvent();
    }

    public boolean isPredictiveAlertsActivated() {
        return predictiveAlertsActivated;
    }

    public void setPredictiveFallingRateAlertMinuteInterval(int predictiveFallingRateAlertMinuteInterval) {
        this.predictiveFallingRateAlertMinuteInterval = predictiveFallingRateAlertMinuteInterval;
        sharedPreferences.edit().putInt(Utils.prefPredictiveMinutes, predictiveFallingRateAlertMinuteInterval).apply();
        Utils.PREDICTIVE_MINUTES = predictiveFallingRateAlertMinuteInterval;
        fireChangeEvent();
    }

    public int getPredictiveFallingRateAlertMinuteInterval() {
        return predictiveFallingRateAlertMinuteInterval;
    }

    public void setRateAlertFallingThreshold(float rateAlertFallingThreshold) {
        this.rateAlertFallingThreshold = rateAlertFallingThreshold;
        sharedPreferences.edit().putFloat(Utils.prefRateValue, rateAlertFallingThreshold).apply();
        Utils.RATE_VALUE = rateAlertFallingThreshold;
        fireChangeEvent();
    }

    public float getRateAlertFallingThreshold() {
        return rateAlertFallingThreshold;
    }

    public void setRateAlertsActivated(boolean rateAlertsActivated) {
        this.rateAlertsActivated = rateAlertsActivated;
        sharedPreferences.edit().putBoolean(Utils.prefRateAlertsActivated, rateAlertsActivated).apply();
        Utils.rateAlertsActivated = rateAlertsActivated;
        fireChangeEvent();
    }

    public boolean isRateAlertsActivated() {
        return rateAlertsActivated;
    }

    public void setMorningCalibrationTimeHour(int morningCalibrationTimeHour) {
        this.morningCalibrationTimeHour = morningCalibrationTimeHour;
        sharedPreferences.edit().putInt(Utils.prefMorningCalHour, morningCalibrationTimeHour).apply();
        eventBus.post(new ModelChangedCalibrationTimeEvent());
        fireChangeEvent();
    }

    public int getMorningCalibrationTimeHour() {
        return morningCalibrationTimeHour;
    }

    public void setMorningCalibrationTimeMinute(int morningCalibrationTimeMinute) {
        this.morningCalibrationTimeMinute = morningCalibrationTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefMorningCalMinute, morningCalibrationTimeMinute).apply();
        eventBus.post(new ModelChangedCalibrationTimeEvent());
        fireChangeEvent();
    }

    public int getMorningCalibrationTimeMinute() {
        return morningCalibrationTimeMinute;
    }

    public void setEveningCalibrationTimeHour(int eveningCalibrationTimeHour) {
        this.eveningCalibrationTimeHour = eveningCalibrationTimeHour;
        sharedPreferences.edit().putInt(Utils.prefEveningCalHour, eveningCalibrationTimeHour).apply();
        eventBus.post(new ModelChangedCalibrationTimeEvent());
        fireChangeEvent();
    }

    public int getEveningCalibrationTimeHour() {
        return eveningCalibrationTimeHour;
    }

    public void setEveningCalibrationTimeMinute(int eveningCalibrationTimeMinute) {
        this.eveningCalibrationTimeMinute = eveningCalibrationTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefEveningCalMinute, eveningCalibrationTimeMinute).apply();
        eventBus.post(new ModelChangedCalibrationTimeEvent());
        fireChangeEvent();
    }

    public int getEveningCalibrationTimeMinute() {
        return eveningCalibrationTimeMinute;
    }

    /** #4080 */
    public int getMorningCalibrationLocalTimeHour() {
        return morningCalibrationLocalTimeHour;
    }

    public void setMorningCalibrationLocalTimeHour(int morningCalibrationLocalTimeHour) {
        this.morningCalibrationLocalTimeHour = morningCalibrationLocalTimeHour;
        sharedPreferences.edit().putInt(Utils.prefMorningCalLocalHour, morningCalibrationLocalTimeHour).apply();
    }

    public int getMorningCalibrationLocalTimeMinute() {
        return morningCalibrationLocalTimeMinute;
    }

    public void setMorningCalibrationLocalTimeMinute(int morningCalibrationLocalTimeMinute) {
        this.morningCalibrationLocalTimeMinute = morningCalibrationLocalTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefMorningCalLocalMinute, morningCalibrationLocalTimeMinute).apply();
    }

    public int getEveningCalibrationLocalTimeHour() {
        return eveningCalibrationLocalTimeHour;
    }

    public void setEveningCalibrationLocalTimeHour(int eveningCalibrationLocalTimeHour) {
        this.eveningCalibrationLocalTimeHour = eveningCalibrationLocalTimeHour;
        sharedPreferences.edit().putInt(Utils.prefEveningCalLocalHour, eveningCalibrationLocalTimeHour).apply();
    }

    public int getEveningCalibrationLocalTimeMinute() {
        return eveningCalibrationLocalTimeMinute;
    }

    public void setEveningCalibrationLocalTimeMinute(int eveningCalibrationLocalTimeMinute) {
        this.eveningCalibrationLocalTimeMinute = eveningCalibrationLocalTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefEveningCalLocalMinute, eveningCalibrationLocalTimeMinute).apply();
    }

    // #2936
    public float getMEPSavedValue() {
        return MEPSavedValue;
    }

    public void setMEPSavedValue(float MEPSavedValue) {
        this.MEPSavedValue = MEPSavedValue;
        sharedPreferences.edit().putFloat(Utils.prefMEPSavedValue, MEPSavedValue).apply();
        Log.d("NewRegisters", "MEP Saved Value:" + this.MEPSavedValue);
    }

    public float getMEPSavedRefChannelMetric() {
        return MEPSavedRefChannelMetric;
    }

    public void setMEPSavedRefChannelMetric(float MEPSavedRefChannelMetric) {
        this.MEPSavedRefChannelMetric = MEPSavedRefChannelMetric;
        sharedPreferences.edit().putFloat(Utils.prefMEPSavedRefChannelMetric, MEPSavedRefChannelMetric).apply();
        Log.d("NewRegisters", "MEP Saved Ref Channel Metric:" + this.MEPSavedRefChannelMetric);
    }

    public float getMEPSavedDriftMetric() {
        return MEPSavedDriftMetric;
    }

    public void setMEPSavedDriftMetric(float MEPSavedDriftMetric) {
        this.MEPSavedDriftMetric = MEPSavedDriftMetric;
        sharedPreferences.edit().putFloat(Utils.prefMEPSavedDriftMetric, MEPSavedDriftMetric).apply();
        Log.d("NewRegisters", "MEP Saved Drift Metric:" + this.MEPSavedDriftMetric);
    }

    public float getMEPSavedLowRefMetric() {
        return MEPSavedLowRefMetric;
    }

    public void setMEPSavedLowRefMetric(float MEPSavedLowRefMetric) {
        this.MEPSavedLowRefMetric = MEPSavedLowRefMetric;
        sharedPreferences.edit().putFloat(Utils.prefMEPSavedLowRefMetric, MEPSavedLowRefMetric).apply();
        Log.d("NewRegisters", "MEP Saved Low Ref Metric:" + this.MEPSavedLowRefMetric);
    }

    public float getMEPSavedSpike() {
        return MEPSavedSpike;
    }

    public void setMEPSavedSpike(float MEPSavedSpike) {
        this.MEPSavedSpike = MEPSavedSpike;
        sharedPreferences.edit().putFloat(Utils.prefMEPSavedSpike, MEPSavedSpike).apply();
        Log.d("NewRegisters", "MEP Saved Spike:" + this.MEPSavedSpike);
    }

    public float getEEP24MSP() {
        return EEP24MSP;
    }

    public void setEEP24MSP(float EEP24MSP) {
        this.EEP24MSP = EEP24MSP;
        sharedPreferences.edit().putFloat(Utils.prefEEP24MSP, EEP24MSP).apply();
        Log.d("NewRegisters", "EEP24 MSP:" + this.EEP24MSP);
    }

    // #2379
    public int getDayStartTimeHour() {
        return dayStartTimeHour;
    }

    public void setDayStartTimeHour(int dayStartTimeHour) {
        this.dayStartTimeHour = dayStartTimeHour;
        sharedPreferences.edit().putInt(Utils.prefDayStartTimeHour, dayStartTimeHour).apply();
        Log.d("NewRegisters", "Day Start Time Hour:" + this.dayStartTimeHour);
    }

    public int getDayStartTimeMinute() {
        return dayStartTimeMinute;
    }

    public void setDayStartTimeMinute(int dayStartTimeMinute) {
        this.dayStartTimeMinute = dayStartTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefDayStartTimeMinute, dayStartTimeMinute).apply();
        Log.d("NewRegisters", "Day Start Time Minute:" + this.dayStartTimeMinute);
    }

    public int getNightStartTimeHour() {
        return nightStartTimeHour;
    }

    public void setNightStartTimeHour(int nightStartTimeHour) {
        this.nightStartTimeHour = nightStartTimeHour;
        sharedPreferences.edit().putInt(Utils.prefNightStartTimeHour, nightStartTimeHour).apply();
        Log.d("NewRegisters", "Night Start Time Hour:" + this.nightStartTimeHour);
    }

    public int getNightStartTimeMinute() {
        return nightStartTimeMinute;
    }

    public void setNightStartTimeMinute(int nightStartTimeMinute) {
        this.nightStartTimeMinute = nightStartTimeMinute;
        sharedPreferences.edit().putInt(Utils.prefNightStartTimeMinute, nightStartTimeMinute).apply();
        Log.d("NewRegisters", "Night Start Time Minute:" + this.nightStartTimeMinute);
    }

    public int getHighGlucoseAlarmRepeatIntervalDayTime() {
        return highGlucoseAlarmRepeatIntervalDayTime;
    }

    public void setHighGlucoseAlarmRepeatIntervalDayTime(int highGlucoseAlarmRepeatIntervalDayTime) {
        this.highGlucoseAlarmRepeatIntervalDayTime = highGlucoseAlarmRepeatIntervalDayTime;
        sharedPreferences.edit().putInt(Utils.prefHighGlucoseAlarmRepeatIntervalDayTime, highGlucoseAlarmRepeatIntervalDayTime).apply();
        Log.d("NewRegisters", "High Day:" + this.highGlucoseAlarmRepeatIntervalDayTime);
        eventBus.post(new ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent(highGlucoseAlarmRepeatIntervalDayTime));
    }

    public int getHighGlucoseAlarmRepeatIntervalNightTime() {
        return highGlucoseAlarmRepeatIntervalNightTime;
    }

    public void setHighGlucoseAlarmRepeatIntervalNightTime(int highGlucoseAlarmRepeatIntervalNightTime) {
        this.highGlucoseAlarmRepeatIntervalNightTime = highGlucoseAlarmRepeatIntervalNightTime;
        sharedPreferences.edit().putInt(Utils.prefHighGlucoseAlarmRepeatIntervalNightTime, highGlucoseAlarmRepeatIntervalNightTime).apply();
        Log.d("NewRegisters", "High Night:" + this.highGlucoseAlarmRepeatIntervalNightTime);
    }

    public int getLowGlucoseAlarmRepeatIntervalDayTime() {
        return lowGlucoseAlarmRepeatIntervalDayTime;
    }

    public void setLowGlucoseAlarmRepeatIntervalDayTime(int lowGlucoseAlarmRepeatIntervalDayTime) {
        this.lowGlucoseAlarmRepeatIntervalDayTime = lowGlucoseAlarmRepeatIntervalDayTime;
        sharedPreferences.edit().putInt(Utils.prefLowGlucoseAlarmRepeatIntervalDayTime, lowGlucoseAlarmRepeatIntervalDayTime).apply();
        Log.d("NewRegisters", "Low Day:" + this.lowGlucoseAlarmRepeatIntervalDayTime);
        eventBus.post(new ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent(lowGlucoseAlarmRepeatIntervalDayTime));
    }

    public int getLowGlucoseAlarmRepeatIntervalNightTime() {
        return lowGlucoseAlarmRepeatIntervalNightTime;
    }

    public void setLowGlucoseAlarmRepeatIntervalNightTime(int lowGlucoseAlarmRepeatIntervalNightTime) {
        this.lowGlucoseAlarmRepeatIntervalNightTime = lowGlucoseAlarmRepeatIntervalNightTime;
        sharedPreferences.edit().putInt(Utils.prefLowGlucoseAlarmRepeatIntervalNightTime, lowGlucoseAlarmRepeatIntervalNightTime).apply();
        Log.d("NewRegisters", "Low Night:" + this.lowGlucoseAlarmRepeatIntervalNightTime);
    }

    /** #3194 */
    public int[] getRawDataValues() {
        Log.d("RawValue", rawDataValue1 + "|" + rawDataValue2 + "|" + rawDataValue3 + "|" + rawDataValue4 + "|" + rawDataValue5 + "|" + rawDataValue6 + "|" + rawDataValue7 + "|" + rawDataValue8);
        return new int[] {rawDataValue1, rawDataValue2, rawDataValue3, rawDataValue4, rawDataValue5, rawDataValue6, rawDataValue7, rawDataValue8};
    }

    /** #3194 */
    public void setRawDataValue(MemoryMap.RAW_DATA_INDEX index, int newValue) {
        switch (index) {
            case RAW_DATA_INDEX_1:
                rawDataValue1 = newValue;
                break;

            case RAW_DATA_INDEX_2:
                rawDataValue2 = newValue;
                break;

            case RAW_DATA_INDEX_3:
                rawDataValue3 = newValue;
                break;

            case RAW_DATA_INDEX_4:
                rawDataValue4 = newValue;
                break;

            case RAW_DATA_INDEX_5:
                rawDataValue5 = newValue;
                break;

            case RAW_DATA_INDEX_6:
                rawDataValue6 = newValue;
                break;

            case RAW_DATA_INDEX_7:
                rawDataValue7 = newValue;
                break;

            case RAW_DATA_INDEX_8:
                rawDataValue8 = newValue;
                break;
        }
    }


    private void fireChangeEvent() {
        eventBus.postSticky(new ModelChangedEvent(this));
    }

    /** #3640 */
    private void fireRefreshGraphEvent() {
        eventBus.postSticky(new ModelChangedRefreshGraphEvent());
    }

    public boolean isTransmitterConnected() {
        return transmitterConnectionState == Transmitter.CONNECTION_STATE.CONNECTED;
    }

    public Calendar getDateTimeCalendarFromPushNotificationResponse(int[] data) {
        int[] date = BinaryOperations
                .calculateDateFromBytes(new int[]{data[1], data[2]});
        int[] time = BinaryOperations
                .calculateTimeFromBytes(new int[]{data[3], data[4]});

        return Utils.getGMTCalendarFrom(date, time);
    }

    public boolean isValidDate(Calendar calToCheck) {
        Calendar oldestDateToFetch = Calendar.getInstance();
        oldestDateToFetch.setTimeZone(TimeZone.getTimeZone("GMT"));
        oldestDateToFetch.add(Calendar.DATE, -Utils.kNumberOfDaysToFetch);

//        Log.d("CheckValidDate", "calToCheck:" + calToCheck.getTimeInMillis());
//        Log.d("CheckValidDate", "oldestDateToFetch:" + oldestDateToFetch.getTimeInMillis());

        Calendar now = Calendar.getInstance();
        now.setTimeZone(TimeZone.getTimeZone("GMT"));
//        Log.d("CheckValidDate", "now:" + now.getTimeInMillis());

//        Log.d("CheckValidDate", "******* diff in sec from NOW:" + (now.getTimeInMillis() - calToCheck.getTimeInMillis()) / 1000);

        if (calToCheck.getTimeInMillis() < oldestDateToFetch.getTimeInMillis()) {
//            Log.d("CheckValidDate", "valid? NO");
            return false;
        }

//        Log.d("CheckValidDate", "valid? YES");
        return true;
    }
}

