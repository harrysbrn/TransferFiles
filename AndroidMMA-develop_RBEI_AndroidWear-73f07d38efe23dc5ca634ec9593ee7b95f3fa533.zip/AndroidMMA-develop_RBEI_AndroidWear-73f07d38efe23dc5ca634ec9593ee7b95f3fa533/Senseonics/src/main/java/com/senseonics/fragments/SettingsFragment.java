package com.senseonics.fragments;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.gen12androidapp.DailyCalibrationActivity;
import com.senseonics.gen12androidapp.GlucoseSettingsActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.MealTimesActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.SoundSettingsSimplifiedActivity;
import com.senseonics.gen12androidapp.SystemSettingsActivity;
import com.senseonics.gen12androidapp.TempGlucoseProfileActivity;
import com.senseonics.gen12androidapp.UserAccountLoginActivity;

public class SettingsFragment extends BaseFragment {

	private LinearLayout content;
	private LayoutInflater inflater;
	private SettingsManager manager;
	public interface SettingsManager {
		void redirectToMainActivity();
	}

	public void setManager(SettingsManager manager) {
		this.manager = manager;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		View view = inflater.inflate(R.layout.layout_content, null);

		content = (LinearLayout) view.findViewById(R.id.content);
		this.inflater = inflater;

		addView(getString(R.string.glucose_event), 
				R.drawable.notification_menu_icon,
				new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), GlucoseSettingsActivity.class);
				getActivity().startActivity(intent);
			}
		});

		addView(getString(R.string.daily_calibration), 
				R.drawable.calibrate_menu_icon,
				new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(),
						DailyCalibrationActivity.class);
				getActivity().startActivity(intent);
			}
		});

		addView(getString(R.string.system), 
				R.drawable.settings_menu_icon2,
				new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(),
						SystemSettingsActivity.class);
				getActivity().startActivity(intent);
			}
		});
		
		addView(getString(R.string.meal_times),
				R.drawable.statistics_menu_icon,
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(getActivity(),
								MealTimesActivity.class);
						getActivity().startActivity(intent);
					}
				});

		addView(getString(R.string.sound_settings),
				R.drawable.icon_menu_sys_soundsetting,
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(getActivity(),
								SoundSettingsSimplifiedActivity.class);
						getActivity().startActivity(intent);
					}
				});

		/** #3160 */
		addView(getString(R.string.temp_profile_title),
				R.drawable.icon_menu_tempprofile,
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(getActivity(),
								TempGlucoseProfileActivity.class);
						getActivity().startActivity(intent);
					}
				});

		addView(getString(R.string.log_out),
				R.drawable.icon_menu_sys_logout,
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						createDialog(getString(R.string.warning),
								getString(R.string.log_out_text));
					}
				});

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();

		/** #3664 */
		if (getActivity() instanceof MainActivity) {
			((MainActivity) getActivity()).refreshAfterFragmentChanged();
		}
	}

	public void addView(String name, int imageIndex, OnClickListener onClickListener) {

		View view = (View) inflater.inflate(R.layout.simple_item, null);
		RelativeLayout parentLayout = (RelativeLayout) view
				.findViewById(R.id.layout);
		ImageView itemImg = (ImageView) view
				.findViewById(R.id.itemImg);
		itemImg.setImageResource(imageIndex);
		parentLayout.setOnClickListener(onClickListener);
		TextView nameTextView = (TextView) view.findViewById(R.id.name);
		nameTextView.setText(name);
        nameTextView.setTypeface(Typeface.DEFAULT_BOLD);
		content.addView(view);
	}

	protected void createDialog(String title, String text) {
		final Dialog dialog = new Dialog(getActivity(),
				R.style.PickerDialog);

		LayoutInflater inflater = LayoutInflater.from(getActivity());
		View view = inflater.inflate(R.layout.dialog, null);

		TextView textView = (TextView) view.findViewById(R.id.textView);
		textView.setText(text);

		TextView titleView = (TextView) view.findViewById(R.id.title);
		titleView.setVisibility(View.VISIBLE);
		titleView.setText(title);

		TextView cancelText = (TextView) view.findViewById(R.id.cancel);
		cancelText.setText(getString(R.string.no));
		cancelText.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		TextView okText = (TextView) view.findViewById(R.id.ok);
		okText.setText(getString(R.string.yes));
		okText.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();

				accountConstants.setDefaultLoggedIn();

				Intent intent = new Intent(getActivity(), UserAccountLoginActivity.class);
				getActivity().startActivity(intent);

				// must finish this fragment's activity - MainActivity
				getActivity().finish();

				/** #3628 */
				Answers.getInstance().logCustom(new CustomEvent("Logout")
						.putCustomAttribute("Reason", "User Clicked"));
			}
		});

		dialog.setContentView(view);
		dialog.show();
	}
	
}
