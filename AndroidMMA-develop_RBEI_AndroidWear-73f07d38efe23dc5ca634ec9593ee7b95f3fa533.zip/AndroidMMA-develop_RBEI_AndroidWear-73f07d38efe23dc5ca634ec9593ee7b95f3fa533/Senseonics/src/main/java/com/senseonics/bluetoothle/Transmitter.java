package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothProfile;

public class Transmitter {
    private CONNECTION_STATE connectionState;

    public enum CONNECTION_STATE {CONNECTED, DISCONNECTED, CONNECTING, NEGOTIATING, SEARCHING, TRANSPORT_CONNECTED;

        public static CONNECTION_STATE fromBluetoothState(int state) {
            switch (state){
                case BluetoothProfile.STATE_CONNECTED:
                    return CONNECTED;
                case BluetoothProfile.STATE_DISCONNECTED:
                    return DISCONNECTED;
                default:
                    return DISCONNECTED;
            }
        }
    }
    private final String address;
    private final String name;

    public Transmitter(String address, String name) {
        this(address, name, CONNECTION_STATE.DISCONNECTED);
    }

    public Transmitter(String address, String name, CONNECTION_STATE connectionState) {
        this.address = address;
        this.name = name;
        this.connectionState = connectionState;
    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public void setConnectionState(CONNECTION_STATE connectionState) {
        this.connectionState = connectionState;
    }

    public CONNECTION_STATE getConnectionState() {
        return connectionState;
    }

    @Override
    public String toString() {

        return name + ", address:" + address + ", connectionState: " + connectionState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Transmitter)) return false;

        Transmitter that = (Transmitter) o;

        if (address != null ? !address.equals(that.address) : that.address != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return address != null ? address.hashCode() : 0;
    }
}
