package com.senseonics.graph.util;

import android.graphics.Rect;

import com.google.common.base.Objects;
import com.senseonics.bluetoothle.MemoryMap;

import java.util.Calendar;

public class Glucose {
	private int glucoseLevel;
	private float x, y;

	private long timestamp;
	private int groupId = -1;
	private int recordNumber = -1;

	private int[] rawValues; /** #3194 */

	public Glucose(long timestamp, int glucoseLevel, int groupId,
			int recordNumber) {
		super();
		this.setGlucoseLevel(glucoseLevel);
		this.setTimestamp(timestamp);
		this.setGroupId(groupId);
		this.setRecordNumber(recordNumber);

		this.rawValues = new int[8];
	}

	public Glucose(long timestamp, int glucoseLevel, int groupId,
				   int recordNumber, int[] rawValues) {
		this(timestamp, glucoseLevel, groupId, recordNumber);
		this.rawValues = rawValues;
	}

	public Glucose(float x, float y) {
		super();
		this.setX(x);
		this.setY(y);
	}

	public void setRect(Rect rect, Calendar startDate, Calendar endDate) {
		setX(GraphUtils.getPositionX(rect.width(), startDate.getTimeInMillis(), endDate.getTimeInMillis(), timestamp));
		setY(GraphUtils.getPositionYForGlucose(glucoseLevel, rect));
	}

	public int getGlucoseLevel() {
		return glucoseLevel;
	}

	public void setGlucoseLevel(int glucoseLevel) {
		this.glucoseLevel = glucoseLevel;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}

	/** #3194 */
	public int getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX index) {
		int retValue = 0;
		switch (index) {
			case RAW_DATA_INDEX_1:
				retValue = this.rawValues[0];
				break;

			case RAW_DATA_INDEX_2:
				retValue = this.rawValues[1];
				break;

			case RAW_DATA_INDEX_3:
				retValue = this.rawValues[2];
				break;

			case RAW_DATA_INDEX_4:
				retValue = this.rawValues[3];
				break;

			case RAW_DATA_INDEX_5:
				retValue = this.rawValues[4];
				break;

			case RAW_DATA_INDEX_6:
				retValue = this.rawValues[5];
				break;

			case RAW_DATA_INDEX_7:
				retValue = this.rawValues[6];
				break;

			case RAW_DATA_INDEX_8:
				retValue = this.rawValues[7];
				break;
		}
		return retValue;
	}

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("glucoseLevel", glucoseLevel)
                .add("x", x)
				.add("y", y)
                .add("timestamp", timestamp)
                .add("groupId", groupId)
                .add("recordNumber", recordNumber)
				.add("raw1", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1))
				.add("raw2", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2))
				.add("raw3", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3))
				.add("raw4", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4))
				.add("raw5", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5))
				.add("raw6", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6))
				.add("raw7", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7))
				.add("raw8", getRawValuesAtIndex(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8))
				.toString();
    }
}
