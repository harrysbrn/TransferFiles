package com.senseonics.events;

import android.graphics.Rect;

import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;
import com.senseonics.util.Utils.TransmitterMessageCode;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

public class EventPoint implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private int databaseId = -1;
    private Calendar calendar, calendarEventHidden;
    private float x, y;
    private float xOnScreen, yOnScreen;
    private int glucoseLevel;
    private EVENT_TYPE eventType;
    private boolean eventSynced = false, eventHidden = false;
    private long recordNumber = -1;
    private float rateValue = 0;
    private int predictiveMinutes = 0;
    private String transmitterName = null;
    private int customField = -1;
    private int customField2 = -1;

    private TransmitterMessageCode notificationEventType = null;
    private int unknownErrorCode = -1;

    private String notes = " ";

    public EventPoint(Calendar calendar, int glucoseLevel) {
        this.calendar = calendar;
        this.glucoseLevel = glucoseLevel;
        if (Utils.transmitterName != null)
            setTransmitterName(Utils.transmitterName);
    }

    public EventPoint(int databaseId, Calendar calendar, int glucoseLevel) {
        this.databaseId = databaseId;
        this.calendar = calendar;
        this.glucoseLevel = glucoseLevel;
        if (Utils.transmitterName != null)
            setTransmitterName(Utils.transmitterName);
    }

    public EventPoint(Calendar calendar, int glucoseLevel, EVENT_TYPE eventType) {
        this.calendar = calendar;
        this.glucoseLevel = glucoseLevel;
        this.eventType = eventType;
        if (Utils.transmitterName != null)
            setTransmitterName(Utils.transmitterName);
    }

    public EventPoint(Calendar GMTcalendarIn, int glucoseLevelIn, EVENT_TYPE eventTypeIn,
                      long recordNumberIn, boolean syncedIn, boolean hiddenIn, String txNameIn,
                      int customFieldIn, int customField2In, int unknownErrorCodeIn) {
        this.calendar = GMTcalendarIn;
        this.glucoseLevel = glucoseLevelIn;
        this.eventType = eventTypeIn;
        this.recordNumber = recordNumberIn;
        this.eventSynced = syncedIn;
        this.eventHidden = hiddenIn;
        this.transmitterName = txNameIn;
        this.customField = customFieldIn;
        this.customField2 = customField2In;
        this.unknownErrorCode = unknownErrorCodeIn;
    }

    public String toString() {
        String output = "<EVENT>GMT Time:" + Utils.formatDate_TimeZone(this.calendar, TimeZone.getTimeZone("GMT"));
        output += "|Glucose:" + this.glucoseLevel;
        output += "|Event Type:" + this.eventType;
        output += "|Record#:" + this.recordNumber;
        output += "|Synced:" + this.eventSynced;
        output += "|Hidden:" + this.eventHidden;
        output += "|TxName:" + this.transmitterName;
        output += "|Custom Field:" + this.customField;
        output += "|Custom Field2:" + this.customField2;
        output += "|Unknown Error Code:" + this.unknownErrorCode;
        output += "|Notes:" + this.notes;
        output += "</EVENT>";

        return output;
    }

    public void setRect(Rect rect, Calendar startDate, Calendar endDate) {
        setX(GraphUtils
                .getPositionX(rect.width(), startDate, endDate, calendar));

        if (glucoseLevel > Utils.GLUCOSE_MAX) {
            setY(GraphUtils.getPositionYForGlucose(Utils.GLUCOSE_MAX, rect));
        } else if (glucoseLevel < Utils.GLUCOSE_MIN) {
            setY(GraphUtils.getPositionYForGlucose(Utils.GLUCOSE_MIN, rect));
        } else {
            setY(GraphUtils.getPositionYForGlucose(glucoseLevel, rect));
        }
    }

    public Calendar getCalendar() {
        return calendar;
    }

    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public long getTimestamp() {
        return calendar.getTimeInMillis();
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getGlucoseLevel() {
        return glucoseLevel;
    }

    public void setGlucoseLevel(int glucoseLevel) {
        this.glucoseLevel = glucoseLevel;
    }

    public int getDatabaseId() {
        return databaseId;
    }

    public void setDatabaseId(int databaseId) {
        this.databaseId = databaseId;
    }

    public EVENT_TYPE getEventType() {
        return eventType;
    }

    public void setEventType(EVENT_TYPE eventType) {
        this.eventType = eventType;
    }

    public float getxOnScreen() {
        return xOnScreen;
    }

    public void setxOnScreen(float xOnScreen) {
        this.xOnScreen = xOnScreen;
    }

    public float getyOnScreen() {
        return yOnScreen;
    }

    public void setyOnScreen(float yOnScreen) {
        this.yOnScreen = yOnScreen;
    }

    public TransmitterMessageCode getNotificationEventType() {
        return notificationEventType;
    }

    public void setNotificationEventType(
            TransmitterMessageCode notificationEventType) {
        this.notificationEventType = notificationEventType;
    }

    public int getUnknownErrorCode() {
        return unknownErrorCode;
    }

    public void setUnknownErrorCode(int errorCode_in) {
        this.unknownErrorCode = errorCode_in;
    }

    public boolean isEventSynced() {
        return eventSynced;
    }

    public void setEventSynced(boolean eventSynced) {
        this.eventSynced = eventSynced;
    }

    public long getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(long recordNumber) {
        this.recordNumber = recordNumber;
    }

    public float getRateValue() {
        return rateValue;
    }

    public void setRateValue(float rateValue) {
        this.rateValue = rateValue;
    }

    public int getPredictiveMinutes() {
        return predictiveMinutes;
    }

    public void setPredictiveMinutes(int predictiveMinutes) {
        this.predictiveMinutes = predictiveMinutes;
    }

    public boolean isEventHidden() {
        return eventHidden;
    }

    public void setEventHidden(boolean eventHidden) {
        this.eventHidden = eventHidden;
    }

    public Calendar getCalendarEventHidden() {
        return calendarEventHidden;
    }

    public void setCalendarEventHidden(Calendar calendarEventHidden) {
        this.calendarEventHidden = calendarEventHidden;
    }

    public String getTransmitterName() {
        return transmitterName;
    }

    public void setTransmitterName(String transmitterName) {
        this.transmitterName = transmitterName;
    }

    public int getCustomField() {
        return customField;
    }

    public void setCustomField(int customFieldIn) {
        this.customField = customFieldIn;
    }

    public int getCustomField2() {
        return customField2;
    }

    public void setCustomField2(int customField2In) {
        this.customField2 = customField2In;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EventPoint that = (EventPoint) o;
        return Objects.equals(getEventType(), that.getEventType()) &&
                Objects.equals(getNotificationEventType(), that.getNotificationEventType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEventType(), getNotificationEventType());
    }
}
