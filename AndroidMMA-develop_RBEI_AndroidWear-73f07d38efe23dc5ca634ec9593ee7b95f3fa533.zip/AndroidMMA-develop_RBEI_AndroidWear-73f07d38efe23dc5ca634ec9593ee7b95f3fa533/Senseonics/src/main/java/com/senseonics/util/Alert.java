package com.senseonics.util;

public class Alert {
	
	private long startTime;
	private long endTime;
	private int glucoseLevel;
	private int alertCode;
	private int recordNumber;
	
	public Alert(long startTime, long endTime, int glucoseLevel, int alertCode,
			int recordNumber) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
		this.glucoseLevel = glucoseLevel;
		this.alertCode = alertCode;
		this.recordNumber = recordNumber;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public int getGlucoseLevel() {
		return glucoseLevel;
	}

	public void setGlucoseLevel(int glucoseLevel) {
		this.glucoseLevel = glucoseLevel;
	}

	public int getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(int alertCode) {
		this.alertCode = alertCode;
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
}
