package com.senseonics.fragments;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.MyReportsActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.UserAccountActivity;

public class ComingSoonFragment extends Fragment {
	private LinearLayout content;
	private LayoutInflater inflater;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.layout_content, null);

		content = (LinearLayout) view.findViewById(R.id.content);
		this.inflater = inflater;

		addView(getString(R.string.my_account_sync), 
				R.drawable.icon_menu_share_sync,
				new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), UserAccountActivity.class);
				getActivity().startActivity(intent);
			}
		});

		/** DI-208 Remove My Reports page
		addView(getString(R.string.my_reports),
				R.drawable.icon_menu_share_report,
				new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MyReportsActivity.class);
				getActivity().startActivity(intent);
			}
		});*/
		
		return view;
	}

	@Override
	public void onResume() {
		super.onResume();

		/** #3664 */
		if (getActivity() instanceof MainActivity) {
			((MainActivity) getActivity()).refreshAfterFragmentChanged();
		}
	}

	public void addView(String name, int imageIndex, OnClickListener onClickListener) {

		View view = (View) inflater.inflate(R.layout.simple_item, null);
		RelativeLayout parentLayout = (RelativeLayout) view
				.findViewById(R.id.layout);
		ImageView itemImg = (ImageView) view
				.findViewById(R.id.itemImg);
		itemImg.setImageResource(imageIndex);
		
		parentLayout.setOnClickListener(onClickListener);

		TextView nameTextView = (TextView) view.findViewById(R.id.name);
		nameTextView.setText(name);
        nameTextView.setTypeface(Typeface.DEFAULT_BOLD);
		content.addView(view);
	}
	
}
