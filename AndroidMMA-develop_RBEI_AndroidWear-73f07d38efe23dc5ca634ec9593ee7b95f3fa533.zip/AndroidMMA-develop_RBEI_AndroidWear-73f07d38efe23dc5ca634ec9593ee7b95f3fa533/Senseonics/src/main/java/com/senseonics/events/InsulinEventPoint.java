package com.senseonics.events;

import com.senseonics.events.EventUtils.INSULIN_TYPE;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;

public class InsulinEventPoint extends EventPoint implements PatientEventPoint {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private float units;
	private INSULIN_TYPE insulinType;

	public InsulinEventPoint(Calendar calendar, int glucoseLevel, float units,
			INSULIN_TYPE insulinType, String notes) {
		super(calendar, glucoseLevel);
		setUnits(units);
		setInsulinType(insulinType);
		setNotes(notes);
		setEventType(EVENT_TYPE.INSULIN_EVENT);
	}

	public InsulinEventPoint(int databaseId, Calendar calendar,
			int glucoseLevel, float units, INSULIN_TYPE insulinType,
			String notes) {
		super(databaseId, calendar, glucoseLevel);
		setUnits(units);
		setInsulinType(insulinType);
		setNotes(notes);
		setEventType(EVENT_TYPE.INSULIN_EVENT);
	}

	public float getUnits() {
		return units;
	}

	public void setUnits(float units) {
		this.units = units;
	}

	public INSULIN_TYPE getInsulinType() {
		return insulinType;
	}

	public void setInsulinType(INSULIN_TYPE insulinType) {
		this.insulinType = insulinType;
	}

	@Override
	public int eventTypeId() {
		return EventUtils.eventTypeInsulin;
	}

	@Override
	public int eventSubTypeId() {
		return insulinType.ordinal();
	}

	@Override
	public int quantity() {
		return (int) (getUnits() * 10);
	}

}
