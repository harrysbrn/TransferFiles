package com.senseonics.bluetoothle;

import com.google.common.base.Objects;

public class TransmitterConnectionEvent {
    private Transmitter transmitter;

    public TransmitterConnectionEvent(Transmitter transmitter) {
        this.transmitter = transmitter;
    }

    public Transmitter getTransmitter() {
        return transmitter;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("transmitter", transmitter).toString();
    }
}
