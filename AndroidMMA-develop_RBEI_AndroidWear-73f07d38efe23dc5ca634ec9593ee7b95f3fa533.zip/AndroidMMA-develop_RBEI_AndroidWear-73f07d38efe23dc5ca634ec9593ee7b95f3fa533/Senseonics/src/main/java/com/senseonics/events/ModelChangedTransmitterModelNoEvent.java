package com.senseonics.events;

public class ModelChangedTransmitterModelNoEvent {
    private String transmitterModelNo;

    public ModelChangedTransmitterModelNoEvent(String transmitterModelNoIn){
        this.transmitterModelNo = transmitterModelNoIn;
    }

    public String getTransmitterModelNo() {
        return transmitterModelNo;
    }
}
