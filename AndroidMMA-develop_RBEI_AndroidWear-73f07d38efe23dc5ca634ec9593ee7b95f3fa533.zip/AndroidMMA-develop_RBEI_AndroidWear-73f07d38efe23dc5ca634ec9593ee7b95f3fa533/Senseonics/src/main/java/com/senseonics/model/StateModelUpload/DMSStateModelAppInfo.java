package com.senseonics.model.StateModelUpload;

public class DMSStateModelAppInfo {
    private String AppOS;
    private String AppVersion;
    private DMSStateModelUserInfo UserInfo;
    private String DeviceType;
    private String AppOSVersion;
    private boolean AppActive;
    private String CountryLanguage;

    public DMSStateModelAppInfo(
            String appOS,
            String appVersion,
            DMSStateModelUserInfo userInfo,
            String deviceType,
            String appOSVersion,
            boolean appActive,
            String countryLanguage
    ) {
        AppActive = appActive;
        AppOS = appOS;
        AppOSVersion = appOSVersion;
        AppVersion = appVersion;
        DeviceType = deviceType;
        UserInfo = userInfo;
        CountryLanguage = countryLanguage;
    }

    public boolean isAppActive() {
        return AppActive;
    }

    public String getAppOS() {
        return AppOS;
    }

    public String getAppOSVersion() {
        return AppOSVersion;
    }

    public String getAppVersion() {
        return AppVersion;
    }

    public String getDeviceType() {
        return DeviceType;
    }

    public DMSStateModelUserInfo getUserInfo() {
        return UserInfo;
    }

    public String getCountryLanguage() {
        return CountryLanguage;
    }
}
