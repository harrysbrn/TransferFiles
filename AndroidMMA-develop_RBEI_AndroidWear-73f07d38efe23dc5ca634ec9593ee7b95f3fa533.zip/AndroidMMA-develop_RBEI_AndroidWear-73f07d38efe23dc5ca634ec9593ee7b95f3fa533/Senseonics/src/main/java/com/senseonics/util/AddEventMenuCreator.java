package com.senseonics.util;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.events.ExerciseEventActivity;
import com.senseonics.events.GlucoseEventActivity;
import com.senseonics.events.HealthEventActivity;
import com.senseonics.events.InsulinEventActivity;
import com.senseonics.events.MealEventActivity;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.ArrayList;
import java.util.Calendar;

public class AddEventMenuCreator {
    // Event menu dialog
    public static void createLogEventMenuDialog(final Context ctx, Calendar eventDefaultTime) {

        final Dialog dialog = new Dialog(ctx, R.style.NotificationDialogTransparentTheme);

        final LayoutInflater inflater = LayoutInflater.from(ctx);

        View view = inflater.inflate(R.layout.dialog_add_event, null);

        LinearLayout content = (LinearLayout) view.findViewById(R.id.content);

        ArrayList<Menu> menuItems = new ArrayList<Menu>();
        menuItems.add(new Menu(EVENT_TYPE.GLUCOSE_EVENT,
                ctx.getString(R.string.glucose_event),
                R.drawable.icon_graph_glucose));
        menuItems.add(new Menu(EVENT_TYPE.MEAL_EVENT,
                ctx.getString(R.string.meal_event), R.drawable.icon_graph_meal));
        menuItems.add(new Menu(EVENT_TYPE.INSULIN_EVENT,
                ctx.getString(R.string.insulin_event),
                R.drawable.icon_graph_insulin));
        menuItems
                .add(new Menu(EVENT_TYPE.HEALTH_EVENT,
                        ctx.getString(R.string.health_event),
                        R.drawable.icon_graph_health));
        menuItems.add(new Menu(EVENT_TYPE.EXERCISE_EVENT,
                ctx.getString(R.string.exercise_event),
                R.drawable.icon_graph_exercise));

        menuItems.add(new Menu(null,
                ctx.getString(R.string.cancel),
                R.drawable.icon_cancel));

        Calendar startDateLocal = Calendar.getInstance();
        startDateLocal.add(Calendar.DATE, -Utils.ADD_EDIT_EVENT_MAX_DAYS_AGO);

        Calendar endDateLocal = Utils.sanitizeDate(Calendar.getInstance());

        final Bundle bundle = new Bundle();
        bundle.putSerializable("startdate", startDateLocal);
        bundle.putSerializable("currentdate", eventDefaultTime);
        bundle.putSerializable("enddate", endDateLocal);

        // Glucose
        addView(content, menuItems.get(0), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ctx,
                        GlucoseEventActivity.class);
                intent.putExtras(bundle);
                ctx.startActivity(intent);
            }
        }, inflater, ctx);

        // Meal
        addView(content, menuItems.get(1), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ctx,
                        MealEventActivity.class);
                intent.putExtras(bundle);
                ctx.startActivity(intent);
            }
        }, inflater, ctx);

        // Insulin
        addView(content, menuItems.get(2), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ctx,
                        InsulinEventActivity.class);
                intent.putExtras(bundle);
                ctx.startActivity(intent);
            }
        }, inflater, ctx);

        // Health
        addView(content, menuItems.get(3), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ctx,
                        HealthEventActivity.class);
                intent.putExtras(bundle);
                ctx.startActivity(intent);
            }
        }, inflater, ctx);

        // Exercise
        addView(content, menuItems.get(4), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ctx,
                        ExerciseEventActivity.class);
                intent.putExtras(bundle);
                ctx.startActivity(intent);
            }
        }, inflater, ctx);

        addView(content, menuItems.get(5), new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        }, inflater, ctx);

        dialog.setContentView(view);
        dialog.setCanceledOnTouchOutside(true);

        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);

    }

    public static void addView(LinearLayout parent, Menu menu, View.OnClickListener clickListener, LayoutInflater inflater, Context ctx) {

        View view = inflater.inflate(R.layout.event_dialog_item, null);

        ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
        imageView.setImageResource(menu.getDrawableId());

        TextView textView = (TextView) view.findViewById(R.id.text);
        textView.setText(menu.getMenuName());

        View divider = (View) view.findViewById(R.id.divider);
        divider.setVisibility(View.VISIBLE);

        parent.addView(view);
        view.setClickable(true);

        parent.setBackground(ctx.getResources().getDrawable(R.drawable.bkg_asheet));

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)parent.getLayoutParams();
        params.setMargins(0,(int)ctx.getResources().getDimension(R.dimen.add_event_menu_margin), 0, 0);
        parent.setLayoutParams(params);

        view.setOnClickListener(clickListener);
    }
}
