package com.senseonics.bluetoothle;

import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import com.senseonics.db.ConnectedTransmitterTableInfo;

import javax.inject.Inject;
import javax.inject.Named;

public class ConnectedTransmitterAsyncQueryHandler extends AsyncQueryHandler {

    public static final int CONNECTED_TRANSMITTER_QUERY_TOKEN = 101;
    private final Uri uri;

    @Inject
    public ConnectedTransmitterAsyncQueryHandler(ContentResolver contentResolver, @Named("transmitter") Uri uri) {
        super(contentResolver);
        this.uri = uri;
    }

    @Override
    protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
        Callback callback = (Callback) cookie;
        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndex(ConnectedTransmitterTableInfo.NAME_FIELD));
            String address = cursor.getString(cursor.getColumnIndex(ConnectedTransmitterTableInfo.ADDRESS_FIELD));
            String statusString = cursor.getString(cursor.getColumnIndex(ConnectedTransmitterTableInfo.STATUS_FIELD));
            Transmitter transmitter = new Transmitter(address, name, Transmitter.CONNECTION_STATE.valueOf(statusString));
            Log.i(ConnectedTransmitterAsyncQueryHandler.class.getSimpleName(), "have last transmitter: " + transmitter);
            callback.lastConnectedTransmitter(transmitter);
        } else {
            Log.i(ConnectedTransmitterAsyncQueryHandler.class.getSimpleName(), "Found noLastConnectedTransmitter");
            callback.noLastConnectedTransmitter();
        }
    }

    public void startQuery(Callback callback) {
        super.cancelOperation(CONNECTED_TRANSMITTER_QUERY_TOKEN);
        super.startQuery(CONNECTED_TRANSMITTER_QUERY_TOKEN, callback, uri, null, null, null, null);
    }

    interface Callback {
        void lastConnectedTransmitter(Transmitter transmitter);

        void noLastConnectedTransmitter();
    }
}
