package com.senseonics.events;

public class ModelChangedHighTargetThresholdEvent { /** #3160 */
    private int newValue;

    public ModelChangedHighTargetThresholdEvent(int newValue) {
        this.newValue = newValue;
    }

    public int getNewValue() {
        return this.newValue;
    }
}
