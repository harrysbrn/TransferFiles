package com.senseonics.graph;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.jjoe64.graphview.Graph.EventGroup;
import com.jjoe64.graphview.Graph.ScaleManager;
import com.jjoe64.graphview.LineGraphView;
import com.senseonics.events.EventPoint;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.util.EventsListAdapter;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class GraphView extends RelativeLayout {

    private Context context;
    private RelativeLayout.LayoutParams scrollViewParams;
    private RelativeLayout relativeLayout;
    private int daysCount, slideStepSize;
    private com.jjoe64.graphview.Graph glucoseView;

    private VerticalLineHolder verticalLineHolder;
    private int screenWidth, height, graphPaddingTop;

    private ScrollManager scrollManager;
    private boolean autoScrollIsOn;

    private RelativeLayout popUpListView;
    private EventsListAdapter eventsListAdapter;

    public enum DAY_TYPE {
        THIRDWIDTH_2SECTION, HALFWIDTH_6SECTION, WIDTHX2_12SECTION, WIDTHX4_24SECTION, WIDTHX8_TO_WIDTHX12_48SECTION
    }

    private LayoutInflater layoutInflater;

    public GraphView(Context context, int positionY, int screenWidth,
                     int height, int daysCount, Calendar currentDate) {
        super(context);

        this.context = context;
        this.screenWidth = screenWidth;
        this.height = height;
        this.daysCount = daysCount;
        this.graphPaddingTop = height / 10;

        eventsListAdapter = new EventsListAdapter(context,
                new ArrayList<EventPoint>());

        layoutInflater = LayoutInflater.from(context);

        GraphUtils.loadBitmaps(context, screenWidth);

        if (Utils.daySubviewWidth < 0) {
            Utils.daySubviewWidth = screenWidth / 3;
        }
        init();
    }

    public GraphView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public GraphView(Context context) {
        super(context);
    }

    public int numberOfDaysBetweenStartDate(Calendar startDate,
                                            Calendar currentDate) {
        long difference = currentDate.getTimeInMillis()
                - startDate.getTimeInMillis();
        int numberOfDays = (int) (difference / 1000) / 60 / 60 / 24;
        return numberOfDays;
    }

    public void init() {
        removeAllViews();

        scrollViewParams = new RelativeLayout.LayoutParams(screenWidth, height);

        // adding relativeLayout
        relativeLayout = new RelativeLayout(context);
        LayoutParams relativeLayoutParams = new LayoutParams(screenWidth,
                height);
        relativeLayout.setLayoutParams(relativeLayoutParams);

        addView(relativeLayout);

        if (screenWidth > 350)
            slideStepSize = screenWidth / 40;
        else
            slideStepSize = screenWidth / 25;

        verticalLineHolder = new VerticalLineHolder(context, screenWidth, height);
        verticalLineHolder.setLayoutParams(scrollViewParams);
        addView(verticalLineHolder);

        verticalLineHolder.setScrollManager(lineScrollManager);
    }

    private LineScrollManager lineScrollManager = new LineScrollManager() {

        @Override
        public void scrollRight() {

            if (!autoScrollIsOn) {
                autoScrollIsOn = true;
                new SlideRightAsyncTask().execute();
            }
        }

        @Override
        public void scrollLeft() {

            if (!autoScrollIsOn) {
                autoScrollIsOn = true;
                new SlideLeftAsyncTask().execute();
            }
        }

        @Override
        public void stopScroll() {
            autoScrollIsOn = false;
        }

        @Override
        public void positionChanged(float x) {
            EventPoint eventPoint = glucoseView.ifEventAtPosition(x);
            Glucose glucose = glucoseView.ifGlucoseAtPosition(x);

//            if(eventPoint != null) {
//                Log.i(GraphView.class.getSimpleName(), "EventPoint:" + eventPoint.toString());
//            }

//            if (glucose != null) {
//                Log.i(GraphView.class.getSimpleName(), "Glucose:" + glucose.toString());
//            }

            if (eventPoint != null) {
                scrollManager.showEventPopUpTop(x, eventPoint);
            } else if (glucose != null) {
                scrollManager.showGlucosePopUpTop(x, glucose);
            } else {
                scrollManager.showNoGlucoseReadingPopUp(x);
            }
        }

        @Override
        public void actionCancelled() {
            scrollManager.hideEventGlucosePopUpTop();
        }
    };

    public class SlideRightAsyncTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            slide(-slideStepSize);
            return null;
        }
    }

    public class SlideLeftAsyncTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            slide(slideStepSize);
            return null;
        }
    }

    public void slide(final int stepSize) {
        if (autoScrollIsOn) {
            //
            ((Activity) context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    glucoseView.slide((float) stepSize);
                }
            });
            postDelayed(new Runnable() {

                @Override
                public void run() {
                    if (autoScrollIsOn)
                        slide(stepSize);
                }
            }, 20);
        }
    }

    public void scrollToPosition(int x) {
        glucoseView.scrollTo(x, 0);
    }

    public void selectDay(Calendar calendar) {
        if (glucoseView == null) {
            return;
        }

        float oldPosition = (float) (GraphUtils.viewportStart + GraphUtils.viewportSize / 2);
        Calendar currentCalendar =
                GraphUtils.getDateForPositionX(glucoseView.getRectWidth(), Utils.startDate,
                        Utils.endDateFinished, oldPosition);

        boolean isToday = false;

        // if today
        if (Utils.currentDate.getTimeInMillis() - calendar.getTimeInMillis() < GraphUtils.DAY) {
            isToday = true;

            if (Utils.currentDate.get(Calendar.DAY_OF_MONTH)
                    - calendar.get(Calendar.DAY_OF_MONTH) < 0)
                calendar.set(Calendar.HOUR_OF_DAY,
                        Utils.currentDate.get(Calendar.HOUR_OF_DAY));
            calendar.set(Calendar.MINUTE,
                    Utils.currentDate.get(Calendar.MINUTE));
            calendar.set(Calendar.SECOND,
                    Utils.currentDate.get(Calendar.SECOND));
            calendar.set(Calendar.MILLISECOND,
                    Utils.currentDate.get(Calendar.MILLISECOND));
        } else {
            calendar.set(Calendar.HOUR_OF_DAY,
                    currentCalendar.get(Calendar.HOUR_OF_DAY));
            calendar.set(Calendar.MINUTE, currentCalendar.get(Calendar.MINUTE));
            calendar.set(Calendar.SECOND, currentCalendar.get(Calendar.SECOND));
            calendar.set(Calendar.MILLISECOND,
                    currentCalendar.get(Calendar.MILLISECOND));

        }

        double newPosition;

        if (isToday) {
            newPosition = getDefaultViewPortStart();
        }
        else {
            newPosition = GraphUtils.getPositionX(glucoseView.getRectWidth(), Utils.startDate,
                    Utils.endDateFinished, calendar)
                    - (float) GraphUtils.viewportSize / 2;
        }

        glucoseView.setViewPort(newPosition, GraphUtils.viewportSize);
        glucoseView.redrawAll();
    }

    private double getDefaultViewPortStart() {
        double maxScroll = glucoseView.getMaxScroll();
        double maxPos = maxScroll - GraphUtils.viewportSize * 0.1f;
        double retVal = maxPos - GraphUtils.viewportSize;

        return retVal;
    }

    public Calendar getCurrentVisibleDate() {
        return glucoseView != null ?
                GraphUtils.getDateForPositionX(glucoseView.getRectWidth(),
                        Utils.startDate,
                        Utils.endDateFinished,
                        (float) ((float) GraphUtils.viewportStart + GraphUtils.viewportSize / 2))
                :
                null;
    }

    LineGraphView.EventsManager eventsManager = new LineGraphView.EventsManager() {

        @Override
        public void onEventClick(float x, float y, EventGroup eventGroup) {

            if (GraphUtils.listPopUpIsVisible)
                hidePopUp();
            else {
                GraphUtils.popUpY = y;
                GraphUtils.popUpCalendar =
                        GraphUtils.getDateForPositionX(glucoseView.getRectWidth(), Utils.startDate,
                                Utils.endDateFinished, eventGroup.x);

                // Log.d("position date",
                // x + " -> " + Utils.formatDate(GraphUtils.popUpCalendar));
                createEventsPopUp(x, y, eventGroup);
            }
        }

        @Override
        public void onClick() {
            hidePopUp();
        }

        @Override
        public void hidePopUpEvent() {
            hidePopUp();
        }

        @Override
        public void tapAddNewEvent(Calendar calendar) {
            scrollManager.tapAddNewEvent(calendar);
        }
    };

    ScaleManager scaleManager = new ScaleManager() {

        @Override
        public void onScaleEvent() {
            scrollManager.refreshGlucoseData();
        }
    };

    public void addGlucoseSubView(List<List<Glucose>> glucosePoints, List<EventPoint> eventPoints) {

        int dayCount = (int) ((Utils.endDate.getTimeInMillis() - Utils.startDate
                .getTimeInMillis()) / GraphUtils.DAY);

        int startOffset = Utils.startDate.get(Calendar.DST_OFFSET);
        int endOffset = Utils.endDateFinished.get(Calendar.DST_OFFSET);

        int width = (int) Utils.daySubviewWidth * dayCount;
        if (startOffset != endOffset) {
            if (endOffset != 0) {
                int percentInDay = (int) ((endOffset * 100) / GraphUtils.DAY);
                int offsetDayInt = (int) (Utils.daySubviewWidth * percentInDay) / 100;
                width -= offsetDayInt;
            }
        }
        glucoseView = new LineGraphView(getContext(), "", Utils.startDate,
                Utils.endDateFinished, width, height, screenWidth,
                graphPaddingTop, true, true);
        glucoseView.addSeries(glucosePoints);
        glucoseView.setEventPoints(eventPoints, Utils.startDate,
                Utils.endDateFinished);
        glucoseView.setScalable(true);
        glucoseView.setScrollable(true);

        glucoseView.setManager(scrollManager);
        glucoseView.setVerticalLineManager(verticalLineHolder.getVerticalLineManager());

        GraphUtils.viewportStart = getDefaultViewPortStart();

        glucoseView.setViewPort(GraphUtils.viewportStart,
                GraphUtils.viewportSize);

        // Max zoom is 3 days, min zoom is 3 hours.
        GraphUtils.maxViewPortSize = screenWidth;
        GraphUtils.minViewPortSize = Utils.daySubviewWidth / 8;

        ((LineGraphView) glucoseView).setDrawBackground(true);
        ((LineGraphView) glucoseView).setEventsManager(eventsManager);

        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                screenWidth, height);
        glucoseView.setLayoutParams(layoutParams);
        glucoseView.setScaleManager(scaleManager);
        relativeLayout.addView(glucoseView);
    }

    public void redrawGraphWithNewStartEndDates(List<List<Glucose>> glucosePoints,
                                                List<EventPoint> eventPoints) {
        if (glucoseView != null) {
            glucoseView.setStartDate(Utils.startDate);
            glucoseView.setEndDate(Utils.endDateFinished);
            glucoseView.addSeries(glucosePoints);
            glucoseView.setEventPoints(eventPoints, Utils.startDate,
                    Utils.endDateFinished);
            glucoseView.setViewPort(GraphUtils.viewportStart,
                    GraphUtils.viewportSize);
            glucoseView.redrawAll();

            showEventPopUp();
        }
    }

    public void redrawGraphWithExistingStartEndDates(List<List<Glucose>> glucosePoints,
                                                     List<EventPoint> eventPoints) {
        if (glucoseView != null) {
            glucoseView.addSeries(glucosePoints);
            glucoseView.setEventPoints(eventPoints, Utils.startDate, Utils.endDateFinished);
            glucoseView.setViewPort(GraphUtils.viewportStart, GraphUtils.viewportSize);
            glucoseView.redrawAll();
        } else {
            addGlucoseSubView(glucosePoints, eventPoints);
        }

        showEventPopUp();
    }

    public void showEventPopUp() {
        if (GraphUtils.listPopUpIsVisible) {
            if (GraphUtils.popUpCalendar != null) {

                float v = GraphUtils.getPositionX(glucoseView.getRectWidth(), Utils.startDate,
                        Utils.endDateFinished,
                        GraphUtils.popUpCalendar);
                GraphUtils.popUpX = glucoseView.getPosOnScreen(v);
                GraphUtils.listPopUpIsVisible = false;
                glucoseView.clickEvent(GraphUtils.popUpX, GraphUtils.popUpY);
            }

        }
    }

    public void createEventsPopUp(final float x, final float y,
                                  final EventGroup eventGroup) {

        hidePopUp();
        popUpListView = (RelativeLayout) layoutInflater.inflate(
                R.layout.popup_listview, null);
        final ListView listView = (ListView) popUpListView
                .findViewById(R.id.listView);
        listView.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        final ArrayList<EventPoint> events = eventGroup.getEvents();

        if (events.size() == 1 && events.get(0) != null) {
            scrollManager.onEventSelected(events.get(0));
        } else {

            eventsListAdapter.setEvent(events.get(0));
            listView.setAdapter(eventsListAdapter);

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                    LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

            final Rect rect = new Rect();

            params.leftMargin = screenWidth;
            params.topMargin = (int) y - height;
            popUpListView.setLayoutParams(params);

            addView(popUpListView);

            popUpListView.setVisibility(View.INVISIBLE);

            ViewTreeObserver vto = popUpListView.getViewTreeObserver();
            vto.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

                private boolean firstAppear = true;

                @Override
                public void onGlobalLayout() {

                    if (firstAppear) {
                        firstAppear = false;
                        int itemHeight = popUpListView.getMeasuredHeight();

                        int paddingSize = 0;
                        int arrowSize = (itemHeight * 2) / 3;

                        int showItem = events.size();
                        if (showItem > 3)
                            showItem = 3;

                        int listViewHeight = itemHeight * showItem;
                        int listViewWidth = 0;
                        if (screenWidth > 400) {
                            listViewWidth = itemHeight * 6;
                        } else
                            listViewWidth = itemHeight * 5;

                        int height = listViewHeight + (paddingSize * 2)
                                + arrowSize;
                        int popUpWidth = listViewWidth + (paddingSize * 2);

                        int arrowPadding = popUpWidth / 8;
                        int newLeftMargin = (int) x - arrowPadding;
                        int popUpRightPos = (int) (x + popUpWidth)
                                - arrowPadding;
                        if (popUpRightPos > screenWidth) {
                            newLeftMargin = newLeftMargin
                                    - (popUpRightPos - screenWidth);

                            // if arrow is on the right
                            if (newLeftMargin + popUpWidth < x + arrowSize / 2
                                    + arrowPadding)
                                newLeftMargin += arrowPadding;

                        }

                        int popUpTopMargin, listviewTopMargin, arrowTopMargin, backgroundTopMargin, arrowDrawable, arrowBgDrawable, backgroundDrawable;
                        if (y - height <= 0) {
                            popUpTopMargin = (int) y;
                            listviewTopMargin = paddingSize + arrowSize;
                            arrowTopMargin = 0;
                            arrowDrawable = R.drawable.popover_bot_inv;
                            arrowBgDrawable = R.drawable.popover_bot_bg_inv;
                            backgroundDrawable = R.drawable.popover_inv;
                            backgroundTopMargin = arrowSize;
                        } else {
                            popUpTopMargin = (int) y - height;
                            listviewTopMargin = paddingSize;
                            arrowTopMargin = height - arrowSize;
                            arrowDrawable = R.drawable.popover_bot;
                            arrowBgDrawable = R.drawable.popover_bot_bg;
                            backgroundDrawable = R.drawable.popover;
                            backgroundTopMargin = 0;
                        }

                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                                popUpWidth, height);
                        params.leftMargin = newLeftMargin;
                        params.topMargin = popUpTopMargin;
                        params.rightMargin = screenWidth - newLeftMargin
                                - popUpWidth;
                        popUpListView.setLayoutParams(params);
                        popUpListView.invalidate();

                        // setting up listview layoutparams
                        RelativeLayout.LayoutParams paramsListView = new RelativeLayout.LayoutParams(
                                listViewWidth, listViewHeight);
                        paramsListView.leftMargin = paddingSize;
                        paramsListView.topMargin = listviewTopMargin;
                        listView.setLayoutParams(paramsListView);

                        // setting up background image
                        ImageView backgroundImage = (ImageView) popUpListView
                                .findViewById(R.id.backgroundImage);

                        RelativeLayout.LayoutParams paramsBackground = new RelativeLayout.LayoutParams(
                                popUpWidth, height - arrowSize);
                        paramsBackground.topMargin = backgroundTopMargin;
                        backgroundImage.setLayoutParams(paramsBackground);
                        backgroundImage.setImageResource(backgroundDrawable);

                        // adding bottom arrow background
                        ImageView bottomBackgroundImage = new ImageView(context);
                        bottomBackgroundImage.setImageResource(arrowBgDrawable);
                        bottomBackgroundImage.setScaleType(ScaleType.FIT_XY);
                        RelativeLayout.LayoutParams bottomParams = new RelativeLayout.LayoutParams(
                                LayoutParams.MATCH_PARENT, arrowSize);
                        bottomParams.topMargin = arrowTopMargin;
                        bottomBackgroundImage.setLayoutParams(bottomParams);
                        popUpListView.addView(bottomBackgroundImage);

                        // adding bottom arrow image
                        ImageView bottomArrowImage = new ImageView(context);
                        bottomArrowImage.setImageResource(arrowDrawable);
                        bottomArrowImage.setScaleType(ScaleType.FIT_XY);

                        RelativeLayout.LayoutParams arrowParams = new RelativeLayout.LayoutParams(
                                arrowSize, arrowSize);
                        int posXInPopUpView = (int) (x - rect.left - newLeftMargin);
                        arrowParams.leftMargin = posXInPopUpView - arrowSize
                                / 2;
                        arrowParams.topMargin = arrowTopMargin;
                        bottomArrowImage.setLayoutParams(arrowParams);
                        popUpListView.addView(bottomArrowImage);

                        eventsListAdapter.setEvents(events);
                        eventsListAdapter.notifyDataSetChanged();

                        popUpListView.setVisibility(View.VISIBLE);
                        GraphUtils.listPopUpIsVisible = true;

                        listView.setOnItemClickListener(new OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> arg0,
                                                    View arg1, int arg2, long arg3) {

                                scrollManager
                                        .onEventSelected((EventPoint) eventsListAdapter
                                                .getItem(arg2));
                                hidePopUp();
                            }
                        });
                    }
                }
            });
        }
    }

    public void hidePopUp() {
        if (popUpListView != null)
            popUpListView.setVisibility(View.GONE);
        GraphUtils.listPopUpIsVisible = false;
    }

    // ------------------------------------------------------------
    // Interface for verticalLineHolder
    public interface LineScrollManager {

        void scrollRight();

        void scrollLeft();

        void stopScroll();

        void positionChanged(float x);

        void actionCancelled();
    }

    // Interface for GraphManagerView
    public interface ScrollManager {

        void showEventPopUpTop(float x, EventPoint eventPoint);

        void showGlucosePopUpTop(float x, Glucose glucose);

        void showNoGlucoseReadingPopUp(float x);

        void hideEventGlucosePopUpTop();

        void onEventSelected(EventPoint eventPoint);

        void dayChanged(Date fromDay, Date toDay);

        void dayChanged(Date day);

        void refreshGlucoseData();

        void tapAddNewEvent(Calendar calendar);
    }

    public void setScrollManager(ScrollManager scrollManager) {
        this.scrollManager = scrollManager;
    }

    public DAY_TYPE getDayType(int dayWidth) {
        return DAY_TYPE.THIRDWIDTH_2SECTION;
    }

}
