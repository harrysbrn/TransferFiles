package com.senseonics.events;

import java.util.Calendar;

public class ModelChangedLastCalibrationDateTimeEvent {
    private Calendar lastCalibrationDateAndTime;

    public ModelChangedLastCalibrationDateTimeEvent(Calendar lastCalibrationDateAndTime){
        this.lastCalibrationDateAndTime = lastCalibrationDateAndTime;
    }

    public Calendar getLastCalibrationDateAndTime() {
        return lastCalibrationDateAndTime;
    }
}
