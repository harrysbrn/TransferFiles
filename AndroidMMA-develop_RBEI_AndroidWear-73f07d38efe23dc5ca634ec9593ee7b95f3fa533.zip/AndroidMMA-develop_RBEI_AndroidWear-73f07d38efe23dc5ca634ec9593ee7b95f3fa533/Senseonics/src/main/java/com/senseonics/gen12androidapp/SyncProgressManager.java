package com.senseonics.gen12androidapp;

import android.app.ActionBar;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.senseonics.events.SyncingProgressUpdateEvent;
import com.senseonics.model.SyncModel;

import de.greenrobot.event.EventBus;

public class SyncProgressManager {
    private boolean progressBarShowing = false;
    private ProgressBar syncingProgressBar;
    private FrameLayout progressBarLayout;
    private Activity activity;
    private SyncModel syncModel;
    private SharedPreferences sharedPreferences;
    private EventBus eventBus;

    public SyncProgressManager(Activity activity, SyncModel syncModel, EventBus eventBus, SharedPreferences sharedPreferences) {
        this.activity = activity;
        this.syncModel = syncModel;
        this.sharedPreferences = sharedPreferences;
        this.eventBus = eventBus;
        eventBus.register(this);
    }

    public void update() {
        Log.d(SyncProgressManager.class.getSimpleName(), "syncing: " + syncModel.getSyncingPercent() + "%");
        if (syncModel.isSyncFinished()) {
            finish();
        } else {
            Log.d(SyncProgressManager.class.getSimpleName(), "update");
            if (syncModel.isSyncing()) {
                if (!progressBarShowing)
                    addTopProgressBar();
                updateSyncingProgress();
            } else {
                finish();
            }
        }
    }

    public void remove() {
        if (progressBarShowing)
            hideTopProgressBar();

        eventBus.unregister(this);
    }

    public void onEventMainThread(SyncingProgressUpdateEvent event) {
//        Log.d("#3640_2", "sync bar update -> isSyncing?" + syncModel.isSyncing() + ", isFinish?" + syncModel.isSyncFinished() + ", percent:" + syncModel.getSyncingPercent());
        update();
    }

    private void finish() {
        if (syncingProgressBar != null) {
            syncingProgressBar.setProgress(100);
        }
        if (progressBarShowing)
            hideTopProgressBar();
    }


    private void addTopProgressBar() {
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ViewGroup wrapperView = setContentViewWithWrapper((getStatusBarHeight()));
        createTopProgressBarLayout();
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ((getStatusBarHeight())));
        params.gravity = Gravity.TOP;
        params.topMargin = 0;
        progressBarLayout.setLayoutParams(params);
        syncingProgressBar.setProgress(syncModel.getSyncingPercent());
        if (wrapperView.findViewById(R.id.PROGRESS_BAR_LAYOUT) == null)
            wrapperView.addView(progressBarLayout);

        progressBarLayout.bringToFront();
        progressBarShowing = true;
    }

    private ViewGroup setContentViewWithWrapper(int progressBarHeight) {
        ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
        ViewGroup decorChild = (ViewGroup) decorView.getChildAt(0);

        // Removing decorChild, we'll add it back soon
        decorView.removeAllViews();

        ViewGroup wrapperView = new FrameLayout(activity);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);

        params.topMargin = progressBarHeight;
        params.gravity = Gravity.TOP;
        decorChild.setId(R.id.DECOR_CHILD);
        wrapperView.addView(decorChild, params);
        wrapperView.setId(R.id.ACTIVITY_LAYOUT_WRAPPER);
        decorView.addView(wrapperView, ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);

        return wrapperView;
    }

    private void hideTopProgressBar() {

        ViewGroup wrapperView = (ViewGroup) activity.findViewById(R.id.ACTIVITY_LAYOUT_WRAPPER);
        if (wrapperView != null) {
            View progressBarLayout = wrapperView.findViewById(R.id.PROGRESS_BAR_LAYOUT);
            if (progressBarLayout != null)
                wrapperView.removeView(progressBarLayout);
        }
        ViewGroup decorChild = (ViewGroup) activity.findViewById(R.id.DECOR_CHILD);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        params.topMargin = 0;
        params.gravity = Gravity.TOP;

        if (decorChild != null)
            decorChild.setLayoutParams(params);
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        progressBarShowing = false;
    }

    private int getStatusBarHeight() {
        int result = 0;
        int resourceId = activity.getResources().getIdentifier("status_bar_height",
                "dimen", "android");
        if (resourceId > 0) {
            result = activity.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private void createTopProgressBarLayout() {
        if (progressBarLayout == null) {
            progressBarLayout = new FrameLayout(activity);
            progressBarLayout.setId(R.id.PROGRESS_BAR_LAYOUT);


            TypedValue tv = new TypedValue();
            activity.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv,
                    true);
            FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,getStatusBarHeight());
            syncingProgressBar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
            syncingProgressBar.setProgressDrawable(activity.getResources().getDrawable(
                    R.drawable.progress_drawable));
            syncingProgressBar.setLayoutParams(progressParams);
            syncingProgressBar.setProgress(0);
            progressBarLayout.setLayoutParams(progressParams);
            progressBarLayout.addView(syncingProgressBar);

            TextView textView = new TextView(activity);
            textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setText(activity.getString(R.string.syncing));
            textView.setLayoutParams(progressParams);
            textView.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL);
            textView.setTextColor(activity.getResources()
                    .getColor(android.R.color.white));
            progressBarLayout.addView(textView);
        }
    }

    private void updateSyncingProgress() {
        if (syncingProgressBar != null) {
            syncingProgressBar.setProgress(syncModel.getSyncingPercent());
        }
    }
}
