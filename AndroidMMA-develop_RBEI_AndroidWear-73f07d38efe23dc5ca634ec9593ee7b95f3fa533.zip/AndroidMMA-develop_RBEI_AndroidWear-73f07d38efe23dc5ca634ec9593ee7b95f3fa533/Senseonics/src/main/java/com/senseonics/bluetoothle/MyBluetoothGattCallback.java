package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.os.Handler;
import android.util.Log;

import com.senseonics.bluetoothle.event.BluetoothGattErrorEvent;
import com.senseonics.bluetoothle.event.TransmitterRSSIEvent;
import com.senseonics.bluetoothle.event.TransportConnectionEvent;

import java.util.UUID;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class MyBluetoothGattCallback extends BluetoothGattCallback {
    public static final int LET_BLUETOOTH_CATCH_ITS_BREATH_BETWEEN_CONNECT_AND_DISCOVER = 2000;
    private EventBus eventBus;
    private final Handler handler;
    private final ConnectionStateModifier connectionStateModifier;
    private BluetoothManager bluetoothManager;
    private boolean needServices = true;
    private String lastCommandWritten;

    @Inject
    public MyBluetoothGattCallback(EventBus eventBus, Handler handler, ConnectionStateModifier connectionStateModifier, BluetoothManager bluetoothManager) {
        this.eventBus = eventBus;
        this.handler = handler;
        this.connectionStateModifier = connectionStateModifier;
        this.bluetoothManager = bluetoothManager;
    }

    @Override
    public void onConnectionStateChange(final BluetoothGatt gatt, final int status, final int newState) {
        int connectionStateFromManagerForGatt = bluetoothManager.getConnectionState(gatt.getDevice(), BluetoothProfile.GATT);
        int connectionStateFromManagerForGattServer = bluetoothManager.getConnectionState(gatt.getDevice(), BluetoothProfile.GATT_SERVER);
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "status changed " + status + ", new state: " + newState + ", bond state is " + gatt.getDevice().getBondState() + ", connectionStateFromManagerForGattServer is " + connectionStateFromManagerForGattServer + ", on device " + gatt.getDevice().getName());

        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "connectionStateFromManagerForGatt: " + connectionStateFromManagerForGatt + ", connectionStateFromManagerForGattServer: " + connectionStateFromManagerForGattServer);

        boolean haveTransportConnection = false;
        if (status == BluetoothGatt.GATT_SUCCESS && connectionStateFromManagerForGattServer == BluetoothProfile.STATE_CONNECTED && gatt.getDevice().getBondState() == BluetoothDevice.BOND_BONDED) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                haveTransportConnection = true;
                eventBus.post(new TransportConnectionEvent(createTransmitterFromGattDevice(gatt.getDevice())));
            }
            else {
                Transmitter transmitter = createTransmitterFromGattDevice(gatt.getDevice());
                connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
            }
        } else if ((status == BluetoothGatt.GATT_SUCCESS && connectionStateFromManagerForGattServer == BluetoothProfile.STATE_CONNECTED && gatt.getDevice().getBondState() != BluetoothDevice.BOND_BONDED)) {
            /** If not BONDED, mark as disconnect */
            Transmitter transmitter = createTransmitterFromGattDevice(gatt.getDevice());
            connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
        } else {
            if (status == 0x85) { /** ERROR CODE 133 from GATT (Samsung devices) */
                eventBus.post(new BluetoothGattErrorEvent(gatt.getDevice()));
            }
            else {
                final Transmitter transmitter = createTransmitterFromGattDevice(gatt.getDevice());
                if (lastCommandSentWas69()) {
                    connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.NEGOTIATING);
                } else {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
                        }
                    });
                }
            }
        }

        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "connectionStateFromManager is " + connectionStateFromManagerForGattServer + ", haveTransportConnection: " + haveTransportConnection);

        if (needServices && status == BluetoothGatt.GATT_SUCCESS && haveTransportConnection && gatt.getDevice().getBondState() == BluetoothDevice.BOND_BONDED) {
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    gatt.discoverServices();
                }
            }, LET_BLUETOOTH_CATCH_ITS_BREATH_BETWEEN_CONNECT_AND_DISCOVER);
        }
    }

    private Transmitter createTransmitterFromGattDevice(BluetoothDevice bluetoothDevice) {
        return new Transmitter(bluetoothDevice.getAddress(), bluetoothDevice.getName());
    }

    private boolean lastCommandSentWas69() {
        String stringDataOfBondingCommand = HexHelper.intArrayToString(Request.saveBondingInformation().getData());
        boolean result = stringDataOfBondingCommand.equalsIgnoreCase(lastCommandWritten);
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "was last command sent a 69? " + result + ", " + lastCommandWritten + "?=" + stringDataOfBondingCommand);
        return result;
    }

    @Override
    public void onServicesDiscovered(final BluetoothGatt gatt, int status) {
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "services discovered with status " + status);

        if (status == BluetoothGatt.GATT_SUCCESS) {
            BluetoothGattService gattService = gatt.getService(GattAttributes.SENSEONICS_SERVICE_HANDLE);
            if (gattService == null) {
                Log.d("Bluetooth", "******** PANIC: gattService:" + gattService + " ********");
                eventBus.post(new BluetoothGattErrorEvent(gatt.getDevice()));
                return;
            }

            BluetoothGattCharacteristic commandCharacteristic = gattService.getCharacteristic(GattAttributes.COMMAND_CHARACTERISTIC_HANDLE);
            BluetoothGattCharacteristic commandResponseCharacteristic = gattService.getCharacteristic(GattAttributes.COMMAND_RESPONSE_CHARACTERISTIC_HANDLE);

            if (commandResponseCharacteristic != null && commandCharacteristic != null) {
                gatt.setCharacteristicNotification(commandResponseCharacteristic, true);
                gatt.setCharacteristicNotification(commandCharacteristic, true);

                BluetoothGattDescriptor descriptor = commandResponseCharacteristic.getDescriptor(GattAttributes.MAGIC_DESCRIPTOR);
                if (descriptor != null) {
                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    boolean enabledNotifications = gatt.writeDescriptor(descriptor);
                    Log.i(MyBluetoothGattCallback.class.getSimpleName(), "harvested characteristics, did enable notifications? " + enabledNotifications);
                }
            }
        } else {
            Transmitter transmitter = new Transmitter(gatt.getDevice().getAddress(), gatt.getDevice().getName());
            connectionStateModifier.setConnectionStateAndPublish(transmitter, Transmitter.CONNECTION_STATE.DISCONNECTED);
        }

    }

    private void sendConnectionEstablishedEvents(final BluetoothGatt gatt, final BluetoothGattCharacteristic commandCharacteristic) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                final Transmitter transmitter = new Transmitter(gatt.getDevice().getAddress(), gatt.getDevice().getName(), Transmitter.CONNECTION_STATE.CONNECTED);
                eventBus.post(new TransmitterCommunicationEstablishedEvent(commandCharacteristic, gatt, transmitter));
            }
        });
        Log.d("Bluetooth", "&&&&&& NEED SERVICE  ?  last command:" + lastCommandWritten + " was69?" + lastCommandSentWas69());
    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "characteristic changed " + characteristic.getUuid() + ", value " + HexHelper.intArrayToString(characteristic.getValue()) + " on device " + gatt.getDevice().getName() + ", thread: " + Thread.currentThread().getName());

        int[] ints = convertToIntArray(characteristic.getValue());

        String transmitterName = gatt.getDevice().getName();
        final Transmitter transmitter = new Transmitter(gatt.getDevice().getAddress(), transmitterName, Transmitter.CONNECTION_STATE.CONNECTED);

        eventBus.post(new CharacteristicChangedEvent(ints, transmitter));
    }

    private int[] convertToIntArray(byte[] bytes) {
        int[] ints = new int[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] >= 0)
                ints[i] = bytes[i];
            else
                ints[i] = 256 + bytes[i];
        }
        return ints;
    }


    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        super.onCharacteristicRead(gatt, characteristic, status);
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "characteristic read " + HexHelper.intArrayToString(characteristic.getValue()) + " on device " + gatt.getDevice().getName() + ", thread: " + Thread.currentThread().getName());
    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        lastCommandWritten = HexHelper.intArrayToString(characteristic.getValue());
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "characteristic write data: " + lastCommandWritten + ", thread: " + Thread.currentThread().getName());
    }

    @Override
    public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        super.onDescriptorRead(gatt, descriptor, status);
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "onDescriptor read");
    }

    @Override
    public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "onDescriptor (" + descriptor.getUuid() + ") write for characteristic (" + descriptor.getCharacteristic().getUuid() + ")");

        if (isMagicDescriptor(descriptor)) {
            BluetoothGattService gattService = gatt.getService(GattAttributes.SENSEONICS_SERVICE_HANDLE);
            sendConnectionEstablishedEvents(gatt, gattService.getCharacteristic(GattAttributes.COMMAND_CHARACTERISTIC_HANDLE));
        }
    }

    @Override
    public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
        Log.i(MyBluetoothGattCallback.class.getSimpleName(), "onReadRemoteRssi (" + rssi + ")");

        if (status == BluetoothGatt.GATT_SUCCESS) {
            eventBus.post(new TransmitterRSSIEvent(rssi));
        }
    }

    private boolean isMagicDescriptor(BluetoothGattDescriptor descriptor) {
        return (descriptor.getUuid().equals(GattAttributes.MAGIC_DESCRIPTOR) && descriptor.getCharacteristic().getUuid().equals(GattAttributes.COMMAND_RESPONSE_CHARACTERISTIC_HANDLE));
    }


    static class GattAttributes {
        static final UUID MAGIC_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
        static final UUID COMMAND_CHARACTERISTIC_HANDLE = UUID.fromString("6eb0f021-a7ba-7e7d-66c9-6d813f01d273");
        static final UUID COMMAND_RESPONSE_CHARACTERISTIC_HANDLE = UUID.fromString("6eb0f024-bd60-7aaa-25a7-0029573f4f23");
        static final UUID SENSEONICS_SERVICE_HANDLE = UUID.fromString("c3230001-9308-47ae-ac12-3d030892a211");
    }
}
