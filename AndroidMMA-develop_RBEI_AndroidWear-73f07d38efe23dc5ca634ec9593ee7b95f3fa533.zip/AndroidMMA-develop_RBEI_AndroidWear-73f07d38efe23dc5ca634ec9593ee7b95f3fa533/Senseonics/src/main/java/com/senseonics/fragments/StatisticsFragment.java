package com.senseonics.fragments;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.StepPagerStrip;

import java.lang.reflect.Field;

public class StatisticsFragment extends BaseFragment {

	private ViewPager viewPager;
	private MyPagerAdapter adapter;
	private StatisticsWeeklyGraphFragment statisticsWeeklyGraphFragment;
	private StatisticsListFragment statisticsListFragment;
	private StatisticsPieChartFragment statisticsChartFragment;

	private StepPagerStrip stepPagerStrip;
	private final static int ITEM_COUNT = 3;
	private ImageView shareButton;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		View view = inflater.inflate(R.layout.fragment_statistics, null);

		viewPager = (ViewPager) view.findViewById(R.id.viewPager);
		adapter = new MyPagerAdapter(getChildFragmentManager());
		viewPager.setAdapter(adapter);

		stepPagerStrip = (StepPagerStrip) view.findViewById(R.id.strip);
		stepPagerStrip
				.setOnPageSelectedListener(new StepPagerStrip.OnPageSelectedListener() {
					@Override
					public void onPageStripSelected(int position) {
						position = Math.min(adapter.getCount() - 1, position);
						if (viewPager.getCurrentItem() != position) {
							viewPager.setCurrentItem(position);
						}
					}
				});

		viewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int position) {
				if ((getActivity() == null) || ((MainActivity)getActivity()).getStatisticsFragment() == null) {
					return;
				}

				stepPagerStrip.setCurrentPage(position);

				if (position == 1) {
					statisticsChartFragment.updateTabSelection();
				} else if (position == 2) {
					statisticsListFragment.updateTabSelection();
				}
				BaseStatisticsFragment item = adapter.getItem(position);
				setShareButtonEnabled(item.hasData());
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});

		/** All 3 pages would only be initialized once */
		viewPager.setOffscreenPageLimit(2);

		stepPagerStrip.setPageCount(ITEM_COUNT);
		viewPager.setCurrentItem(0);

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();

		if ((getActivity() == null) || ((MainActivity)getActivity()).getStatisticsFragment() == null) {
			Log.d("#3640", "!!destroy me!!");
			getActivity().onBackPressed();
			return;
		}

		/** #3664 */
		if (getActivity() instanceof MainActivity) {
			((MainActivity) getActivity()).refreshAfterFragmentChanged();
		}
	}

	private BaseStatisticsFragment getCurrentSelectedStatisticsFragment () {
		switch (stepPagerStrip.getCurrentPage()) {
			case 0:
				return statisticsWeeklyGraphFragment;
			case 1:
				return statisticsChartFragment;
			case 2:
				return statisticsListFragment;
			default:
				return null;
		}
	}

	@Override
	public void onDetach() {
		super.onDetach();

		try {
			Field childFragmentManager = Fragment.class
					.getDeclaredField("mChildFragmentManager");
			childFragmentManager.setAccessible(true);
			childFragmentManager.set(this, null);

		} catch (NoSuchFieldException e) {
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	public void createShareDialog() {
		getCurrentSelectedStatisticsFragment().formShareEmail();
	}

	public void setShareButton(ImageView shareButton) {
		this.shareButton = shareButton;
	}

	protected void setShareButtonEnabled(boolean enabled) {
		if (shareButton != null) {
			shareButton.setEnabled(enabled);
			shareButton.setAlpha(enabled ? 1.0f : 0.25f);
		}
	}

	private class MyPagerAdapter extends FragmentPagerAdapter {

		public MyPagerAdapter(FragmentManager fm) {
			super(fm);
			statisticsWeeklyGraphFragment = new StatisticsWeeklyGraphFragment();
			statisticsChartFragment = new StatisticsPieChartFragment();
			statisticsListFragment = new StatisticsListFragment();
		}

		@Override
		public BaseStatisticsFragment getItem(int position) {
			switch (position) {
			case 0:
				return statisticsWeeklyGraphFragment;
			case 1:
				return statisticsChartFragment;
			case 2:
				return statisticsListFragment;
			default:
				return null;
			}
		}

		@Override
		public int getCount() {
			return ITEM_COUNT;
		}
	}
}