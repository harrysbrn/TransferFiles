package com.senseonics.events;

import com.google.common.base.Objects;

public class CalibrationCountdownEvent {
    private final long currentCountdownMillis;

    public CalibrationCountdownEvent(long currentCountdownMillis) {
        this.currentCountdownMillis = currentCountdownMillis;
    }

    public long getCurrentCountdownMillis() {
        return currentCountdownMillis;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(CalibrationCountdownEvent.class).add("currentCountdownMillis", currentCountdownMillis).toString();
    }
}
