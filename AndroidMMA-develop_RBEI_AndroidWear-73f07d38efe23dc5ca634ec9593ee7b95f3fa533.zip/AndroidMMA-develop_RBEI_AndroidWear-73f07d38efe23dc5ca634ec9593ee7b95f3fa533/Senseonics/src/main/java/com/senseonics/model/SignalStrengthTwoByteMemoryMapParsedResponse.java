package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class SignalStrengthTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {

    @Inject
    public SignalStrengthTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.sensorFieldCurrentAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        final int signalStrength = dataOne | (dataTwo << 8);
        SIGNAL_STRENGTH newSignalStrength = SIGNAL_STRENGTH.NO_SIGNAL;


        if (signalStrength >= SIGNAL_STRENGTH.EXCELLENT.getThreshold())
            newSignalStrength = SIGNAL_STRENGTH.EXCELLENT;
        else if (signalStrength >= SIGNAL_STRENGTH.GOOD.getThreshold())
            newSignalStrength = SIGNAL_STRENGTH.GOOD;
        else if (signalStrength >= SIGNAL_STRENGTH.LOW.getThreshold())
            newSignalStrength = SIGNAL_STRENGTH.LOW;
        else if (signalStrength >= SIGNAL_STRENGTH.VERY_LOW.getThreshold())
            newSignalStrength = SIGNAL_STRENGTH.VERY_LOW;
        else if (signalStrength >= SIGNAL_STRENGTH.POOR.getThreshold())
            newSignalStrength = SIGNAL_STRENGTH.POOR;

        model.setSignalStrength(newSignalStrength);

        if(newSignalStrength != SIGNAL_STRENGTH.NO_SIGNAL && model.getCurrentMessageCode() == Utils.TransmitterMessageCode.SensorAwolAlarm) {
            model.setCurrentMessageCode(Utils.TransmitterMessageCode.NoAlarmActive);
        }

    }
}
