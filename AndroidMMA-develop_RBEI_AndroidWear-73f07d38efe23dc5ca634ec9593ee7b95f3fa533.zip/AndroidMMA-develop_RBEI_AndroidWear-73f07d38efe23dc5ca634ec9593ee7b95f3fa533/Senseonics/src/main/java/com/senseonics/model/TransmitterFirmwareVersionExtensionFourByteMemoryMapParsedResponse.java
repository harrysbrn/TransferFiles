package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class TransmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse implements FourByteMemoryMapParsedResponse {

    @Inject
    public TransmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.transmitterSoftwareVersionExtAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, int dataThree, int dataFour, TransmitterStateModel model) {
        String versionExtensionNumber = "" + Character.toString((char) dataOne)
                + Character.toString((char) dataTwo)
                + Character.toString((char) dataThree)
                + Character.toString((char) dataFour);

        model.setTransmitterVersionExtensionNumber(versionExtensionNumber);
    }
}
