package com.senseonics.util;

public interface DMSTaskCallback {
    void TaskDone(AccountConstants.MLDMSResult dmsResult);
    void TaskDone(AccountConstants.MLDMSResult dmsResult, Integer secondResult, Integer thirdResult);
}
