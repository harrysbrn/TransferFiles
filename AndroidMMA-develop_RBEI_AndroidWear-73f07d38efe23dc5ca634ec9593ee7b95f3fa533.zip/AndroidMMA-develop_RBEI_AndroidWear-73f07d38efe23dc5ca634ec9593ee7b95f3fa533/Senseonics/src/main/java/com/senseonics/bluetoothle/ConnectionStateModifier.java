package com.senseonics.bluetoothle;

import android.os.Handler;
import android.util.Log;

import java.util.List;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class ConnectionStateModifier {
    private EventBus eventBus;
    private Handler handler;

    @Inject
    public ConnectionStateModifier(EventBus eventBus, Handler handler) {

        this.eventBus = eventBus;
        this.handler = handler;
    }

    public void setConnectionStateAndPublish(final List<Transmitter> transmitters, final Transmitter.CONNECTION_STATE state) {
        if (!transmitters.isEmpty()) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.d(ConnectionStateModifier.class.getSimpleName(), "have " + transmitters.size() + " transmitters to disconnect");
                    for (Transmitter transmitter : transmitters) {
                        transmitter.setConnectionState(state);
                        Log.d(ConnectionStateModifier.class.getSimpleName(), "sending TransmitterConnectionEvent with tx: " + transmitter);
                        eventBus.postSticky(new TransmitterConnectionEvent(transmitter));
                    }
                }
            });
        }
    }

    public void setConnectionStateAndPublish(final Transmitter transmitter, final Transmitter.CONNECTION_STATE state) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                transmitter.setConnectionState(state);
                Log.d(ConnectionStateModifier.class.getSimpleName(), "sending TransmitterConnectionEvent with tx: " + transmitter);
                eventBus.postSticky(new TransmitterConnectionEvent(transmitter));
            }
        });


    }
}
