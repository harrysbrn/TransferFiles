package com.senseonics.db;

public class ConnectedTransmitterTableInfo {
    public static final String CONNECTED_TRANSMITTER_TABLE = "connectedTransmitters";
    public static final String NAME_FIELD = "name";
    public static final String ADDRESS_FIELD = "address";
    public static final String STATUS_FIELD = "status";
}
