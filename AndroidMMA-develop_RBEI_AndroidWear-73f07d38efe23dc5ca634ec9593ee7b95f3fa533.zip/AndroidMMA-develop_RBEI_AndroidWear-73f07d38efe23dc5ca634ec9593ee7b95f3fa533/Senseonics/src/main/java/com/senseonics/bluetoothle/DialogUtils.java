package com.senseonics.bluetoothle;

import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.common.base.Objects;
import com.senseonics.events.AlertEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.events.EventUtils;
import com.senseonics.gen12androidapp.AboutActivity;
import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.CalibrateActivity;
import com.senseonics.gen12androidapp.DailyCalibrationActivity;
import com.senseonics.gen12androidapp.NotificationsActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.SensorListActivity;
import com.senseonics.gen12androidapp.SoundSettingsSimplifiedActivity;
import com.senseonics.gen12androidapp.TempGlucoseProfileActivity;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.Convert;
import com.senseonics.util.CustomEditText;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import net.simonvt.datepicker.DatePicker;
import net.simonvt.numberpicker.NumberPicker;
import net.simonvt.timepicker.TimePicker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DialogUtils {
    private TransmitterStateModel transmitterStateModel;
    private TempProfileManager tempProfileManager; /** #3160 */

    private final List<CustomDialogInfo> customDialogs;
    public boolean enterPasscodeDialogIsShowing = false;
    public Dialog moreThan5AlertDialog;
    public Dialog doNotDisturbAlertDialog;
    private Dialog tempProfileAlertDialog; /** #3160 */
    private Dialog appUpdateDialog; /** #3272 */

    private final int MAX_REPEATED_ALERTS = 2;

    @Inject
    public DialogUtils(TransmitterStateModel transmitterStateModel, TempProfileManager tempProfileManager) {
        this(transmitterStateModel, tempProfileManager, new ArrayList<CustomDialogInfo>());
    }

    protected DialogUtils(TransmitterStateModel transmitterStateModel, TempProfileManager tempProfileManager, ArrayList<CustomDialogInfo> customDialogs) {
        this.transmitterStateModel = transmitterStateModel;
        this.tempProfileManager = tempProfileManager;
        this.customDialogs = customDialogs;
    }

    public void cancelNotification(Context context, int notifyId) {
        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager nMgr = (NotificationManager) context
                .getSystemService(ns);
        nMgr.cancelAll();
    }

    public interface NotificationDialogManager {
        void leftButtonPressed();

        void rightButtonPressed();
    }

    public void showDialogs(BluetoothPairBaseActivity activity) {


        //2222 transmitter is connected bedore showing dialogis (removed connection check.

        if (enterPasscodeDialogIsShowing == false) {
            Log.d("DIALOGS SIZE", "---------------" + customDialogs.size() + "^^^^^^^^^^^^^^^^^^^^^^^^^^");
            if (customDialogs.size() > 0) {
                for(CustomDialogInfo customDialogInfo : customDialogs) {

                    if (customDialogInfo.getDialog() != null) {
                        try {
                            Log.d(DialogUtils.class.getSimpleName(), "try to dismiss existing dialog ---- ");
                            customDialogInfo.getDialog().dismiss();
                        } catch (IllegalArgumentException e) {
                            Log.d(DialogUtils.class.getSimpleName(), "Close dialog ---- ");
                        }
                    }
                    switch (customDialogInfo.getDialogType()) {
                        case ALERT_DIALOG:
                            customDialogInfo.setDialog(createAlertDialog(activity, (AlertDialogInfo) customDialogInfo));
                            break;
                        case CALIBRATE_DIALOG:
                            customDialogInfo.setDialog(createCalibrateDialog(activity, (CalibrateDialogInfo) customDialogInfo, activity.provideCalibrationDialogManager()));
                            break;
                        case PREDICTIVE_RATE_DIALOG:
                            customDialogInfo.setDialog(createPredictiveRateAlertDialog(activity, (PredictiveRateAlertDialogInfo) customDialogInfo));
                            break;
                        case WARNING_DIALOG:
                            customDialogInfo.setDialog(createWarningDialog(activity, (WarningDialogInfo) customDialogInfo));
                            break;
                        case NOTIFICATION_DIALOG:
                            customDialogInfo.setDialog(createNotificationDialog(activity, (NotificationDialogInfo) customDialogInfo));
                            break;
                        case PLACEMENT_DIALOG:
                            customDialogInfo.setDialog(createPlacementDialog(activity, (PlacementDialogInfo) customDialogInfo));
                            break;
                        default:
                            break;
                    }
                    Dialog dialog = customDialogInfo.getDialog();
                    if (!dialog.isShowing()) {
                        Log.d(DialogUtils.class.getSimpleName(), "show dialog --- " + customDialogInfo);
                        dialog.show();
                    } else {
                        Log.d(DialogUtils.class.getSimpleName(), "hide/show " + customDialogInfo);
                        dialog.hide();
                        dialog.show();
                    }

                }
                if (customDialogs.size() >= MAX_REPEATED_ALERTS)
                    createMoreThan5AlertDialog(activity,
                            R.string.alert_notice, R.string.more_than_max_pending_alerts,
                            R.string.view, R.string.dismiss_all, NotificationsActivity.class);
            }
        }
    }

    public Dialog createPlacementDialog(final Activity activity, final PlacementDialogInfo placementDialogInfo) {
        final NotificationDialogManager manager = new NotificationDialogManager() {

            @Override
            public void rightButtonPressed() {
                placementDialogInfo.getNotificationDialogManager().rightButtonPressed();
                customDialogs.remove(placementDialogInfo);
            }

            @Override
            public void leftButtonPressed() {
                placementDialogInfo.getNotificationDialogManager().leftButtonPressed();
                customDialogs.remove(placementDialogInfo);
            }
        };

        String title = activity.getString(R.string.placement_mode_title);
        String text = activity.getString(R.string.placement_mode_body);
        String leftButtonText = activity.getString(R.string.yes);
        String rightButtonText = activity.getString(R.string.home);

        final Dialog dialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);


        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setText(title);
        titleTextView.setVisibility(View.VISIBLE);
        ((TextView) view.findViewById(R.id.textView)).setText(text);

        TextView leftButton = (TextView) view.findViewById(R.id.cancel);
        leftButton.setText(leftButtonText);
        leftButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                manager.leftButtonPressed();
                dialog.dismiss();
            }
        });

        TextView rightButton = (TextView) view.findViewById(R.id.ok);
        rightButton.setText(rightButtonText);
        rightButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                manager.rightButtonPressed();
                dialog.dismiss();
            }
        });
        dialog.setContentView(view);
        dialog.setCancelable(false);
        return dialog;
    }

    public void removeOtherDialogs() {
        if (moreThan5AlertDialog != null && moreThan5AlertDialog.isShowing()) {
            moreThan5AlertDialog.dismiss();
        }

        if (doNotDisturbAlertDialog != null && doNotDisturbAlertDialog.isShowing()) {
            doNotDisturbAlertDialog.dismiss();
        }

        if (tempProfileAlertDialog != null && tempProfileAlertDialog.isShowing()) {
            tempProfileAlertDialog.dismiss();
        }

        if (appUpdateDialog != null && appUpdateDialog.isShowing()) {
            appUpdateDialog.dismiss();
        }
    }

    public void removeDialogs() {
        Log.d(DialogUtils.class.getSimpleName(), "removing dialogs, staring size: " + customDialogs.size());
        final Set<CustomDialogInfo> pendingDialogs = new LinkedHashSet<CustomDialogInfo>();

        for(CustomDialogInfo customDialogInfo : customDialogs) {
            Dialog dialog = customDialogInfo.getDialog();
            if (dialog == null || !dialog.isShowing()) {
                if (dialog != null) {
                    Log.d(DialogUtils.class.getSimpleName(), " preserving dialog, is showing: " + dialog.isShowing());
                } else {
                    Log.d(DialogUtils.class.getSimpleName(), "preserve pending dialaog, it's null ");
                }
                pendingDialogs.add(customDialogInfo);
            } else {
                Log.d(DialogUtils.class.getSimpleName(), "dismiss showing dialog ");
                dialog.dismiss();
            }
        }

        customDialogs.clear();
        customDialogs.addAll(pendingDialogs);

        if (moreThan5AlertDialog != null) {
            moreThan5AlertDialog.dismiss();
        }
    }

    public enum DIALOG_TYPE {
        ALERT_DIALOG, LOW_BATTERY_DIALOG, CALIBRATE_DIALOG, PREDICTIVE_RATE_DIALOG, NOTIFICATION_DIALOG, WARNING_DIALOG, TIME_ZONE_CHANGED_DIALOG, TIME_CHANGE_DIALOG, PLACEMENT_DIALOG
    }

    public static class CustomDialogInfo {
        private DIALOG_TYPE dialogType;
        private Dialog dialog;
        private int notificationId;

        public CustomDialogInfo(DIALOG_TYPE dialogType, int notificationId) {
            super();
            this.notificationId = notificationId;
            this.setDialogType(dialogType);
        }

        public DIALOG_TYPE getDialogType() {
            return dialogType;
        }

        public void setDialogType(DIALOG_TYPE dialogType) {
            this.dialogType = dialogType;
        }

        public Dialog getDialog() {
            return dialog;
        }

        public void setDialog(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof CustomDialogInfo)) return false;
            CustomDialogInfo that = (CustomDialogInfo) o;
            if(notificationId < 0){
                return false;
            }
            return Objects.equal(notificationId, that.notificationId);
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(notificationId);
        }
    }

    // Alert dialog
    public class AlertDialogInfo extends CustomDialogInfo {
        private AlertEventPoint aep;

        public AlertDialogInfo(AlertEventPoint aepIn, int notificationId) {
            super(DIALOG_TYPE.ALERT_DIALOG, notificationId);
            setAlertEventPoint(aepIn);
        }

        public AlertEventPoint getAlertEventPoint() {
            return this.aep;
        }

        public void setAlertEventPoint(AlertEventPoint aepIn) {
            this.aep = aepIn;
        }
    }

    public void createAlertDialogInfo(BluetoothPairBaseActivity activity,
                                      AlertEventPoint aep, int notificationId) {
        addAPendingAlertOrAlarmDialog(aep, notificationId);
        showDialogs(activity);
    }

    public void addAPendingAlertOrAlarmDialog(AlertEventPoint aep, int notificationId) {
        addDialogInfo(new AlertDialogInfo(aep, notificationId));
    }

    private void addDialogInfo(CustomDialogInfo dialogInfo) {
        int index = customDialogs.lastIndexOf(dialogInfo);
        if (index >= 0) {
            CustomDialogInfo oldDialogInfo = customDialogs.get(index);
            customDialogs.remove(oldDialogInfo);
            if (oldDialogInfo.getDialog() != null) {
                oldDialogInfo.getDialog().dismiss();
            }
        }
        customDialogs.add(dialogInfo);
    }

    public Dialog createAlertDialog(Context activity, final AlertDialogInfo alertDialogInfo) {
        AlertEventPoint aep = alertDialogInfo.getAlertEventPoint();
        Utils.EVENT_TYPE eventType = aep.getEventType();
        Utils.ALERT_TYPE alertType = aep.getAlertType();

        int iconImageResId = -1;
        String stateText = "", text = "";
        String titleText = "";
        Utils.TransmitterMessageCode code = null;

        switch (eventType) {
            case ALERT_EVENT:
                iconImageResId = R.drawable.yellow_bg;
                titleText = activity.getString(R.string.alert);
                text = Utils.getAlertEventText(activity, alertType,
                        transmitterStateModel.getHighGlucoseAlertThreshold(),
                        transmitterStateModel.getLowGlucoseAlertThreshold());
                break;
            case ALARM_EVENT:
                iconImageResId = R.drawable.yellow_bg; /** #3214 */ //R.drawable.red_bg;
                titleText = activity.getString(R.string.alert); /** #3214 */ //activity.getString(R.string.alarm);
                text = Utils.getAlarmEventText(activity, alertType,
                        transmitterStateModel.getHighGlucoseAlarmThreshold(),
                        transmitterStateModel.getLowGlucoseAlarmThreshold());
                break;
            default:
                break;
        }

        switch (alertType) {
            case LOW_GLUCOSE:
                switch (eventType) {
                    case ALERT_EVENT:
                        stateText = activity
                                .getString(R.string.low_glucose_alert_title);
                        code = Utils.TransmitterMessageCode.LowGlucoseAlert;
                        break;

                    case ALARM_EVENT:
                        stateText = activity
                                .getString(R.string.low_glucose_alarm_title);
                        code = Utils.TransmitterMessageCode.LowGlucoseAlarm;

                        break;

                    default:
                        break;
                }
                break;

            case HIGH_GLUCOSE:
                switch (eventType) {
                    case ALERT_EVENT:
                        stateText = activity
                                .getString(R.string.high_glucose_alert_title);
                        code = Utils.TransmitterMessageCode.HighGlucoseAlert;

                        break;

                    case ALARM_EVENT:
                        stateText = activity
                                .getString(R.string.high_glucose_alarm_title);
                        code = Utils.TransmitterMessageCode.HighGlucoseAlarm;

                        break;

                    default:
                        break;
                }
                break;

            default:
                break;
        }

        NotificationDialogManager manager = new NotificationDialogManager() {

            @Override
            public void rightButtonPressed() {
                customDialogs.remove(alertDialogInfo);
            }

            @Override
            public void leftButtonPressed() {
                customDialogs.remove(alertDialogInfo);
            }
        };
        Dialog dialog = showCommonNotificationDialog(activity, iconImageResId,
                titleText, stateText, text, manager, activity.getResources()
                        .getString(R.string.ok), "",
                Utils.getNotificationDialogMessageSubTitleStringId(code),
                getNotificationDialogHelpTextString(activity, code),
                aep); // right button text set
        // to ""
        dialog.setCancelable(false);

        return dialog;
    }

    // Calibrate dialog
    public class CalibrateDialogInfo extends CustomDialogInfo {
        EventPoint ep;

        public CalibrateDialogInfo(
                EventPoint ep, int notificationId) {
            super(DIALOG_TYPE.CALIBRATE_DIALOG, notificationId);
            this.ep = ep;
        }

        public EventPoint getEventPoint() {
            return this.ep;
        }

    }

    public void createCalibrateDialogInfo(BluetoothPairBaseActivity activity,
                                          EventPoint ep, int notificationId) {
        addAPendingCalibrationDialog(ep, notificationId);
        showDialogs(activity);
    }

    public void addAPendingCalibrationDialog(EventPoint ep, int notificationId) {
        addDialogInfo(new CalibrateDialogInfo(ep, notificationId));
    }

    public Dialog createCalibrateDialog(final Context activity,
                                        final CalibrateDialogInfo calibrateDialogInfo, final NotificationDialogManager calibrationManager) {

        EventPoint ep = calibrateDialogInfo.getEventPoint();

        NotificationDialogManager manager = new NotificationDialogManager() {

            @Override
            public void rightButtonPressed() {
                calibrationManager.rightButtonPressed();
                customDialogs.remove(calibrateDialogInfo);
            }

            @Override
            public void leftButtonPressed() {
                customDialogs.remove(calibrateDialogInfo);
            }
        };

        int iconImageResId = -1;
        String titleText = "";
        String stateText = "";
        String text = "";
        Utils.TransmitterMessageCode code = null;

        if (ep.getEventType() == Utils.EVENT_TYPE.CALIBRATE_NOW_EVENT) {
            iconImageResId = R.drawable.blue_bg;
            titleText = activity.getString(R.string.notification);
            stateText = activity
                    .getString(R.string.calibrate_now_notification_title);
            text = Utils
                    .replaceCalibrateButtonStringFromString(
                            Utils.replaceTransmitterNameFromString(
                                    activity.getString(R.string.calibrate_now_notification_message),
                                    transmitterStateModel.getTransmitterName()), activity);
            code = Utils.TransmitterMessageCode.CalibrationRequiredAlarm;
        } else if (ep.getEventType() == Utils.EVENT_TYPE.CALIBRATE_GRACE_EVENT) {
            iconImageResId = R.drawable.yellow_bg; /** #3214 */ //R.drawable.red_bg;
            titleText = activity.getString(R.string.alert); /** #3214 */ //activity.getString(R.string.alarm);
            stateText = activity
                    .getString(R.string.calibration_grace_alert_title);
            text = Utils
                    .replaceCalibrateButtonStringFromString(
                            Utils.replaceTransmitterNameFromString(
                                    activity.getString(R.string.calibration_grace_alert_message),
                                    transmitterStateModel.getTransmitterName()), activity);
            code = Utils.TransmitterMessageCode.CalibrationGracePeriodAlarm;

        } else if (ep.getEventType() == Utils.EVENT_TYPE.CALIBRATE_EXPIRED_EVENT) {
            iconImageResId = R.drawable.yellow_bg; /** #3214 */ //R.drawable.red_bg;
            titleText = activity.getString(R.string.alert); /** #3214 */ //activity.getString(R.string.alarm);
            stateText = activity
                    .getString(R.string.calibration_expired_alarm_title);
            text = Utils
                    .replaceCalibrateButtonStringFromString(
                            Utils.replaceTransmitterNameFromString(
                                    activity.getString(R.string.calibration_expired_alarm_message),
                                    transmitterStateModel.getTransmitterName()), activity);
            code = Utils.TransmitterMessageCode.CalibrationExpiredAlarm;

        }

        Dialog dialog = showCommonNotificationDialog(activity, iconImageResId,
                titleText, stateText, text, manager, activity.getResources()
                        .getString(R.string.not_now), activity.getResources()
                        .getString(R.string.calibrate),
                Utils.getNotificationDialogMessageSubTitleStringId(code),
                getNotificationDialogHelpTextString(activity, code),
                ep);
        dialog.setCancelable(false);

        return dialog;
    }

    // Predictive alert dialog
    public class PredictiveRateAlertDialogInfo extends CustomDialogInfo {
        private AlertEventPoint aep;

        public PredictiveRateAlertDialogInfo(AlertEventPoint aepIn, int notificationId) {
            super(DIALOG_TYPE.PREDICTIVE_RATE_DIALOG, notificationId);
            setAlertEventPoint(aepIn);
        }

        public AlertEventPoint getAlertEventPoint() {
            return aep;
        }

        public void setAlertEventPoint(AlertEventPoint aepIn) {
            this.aep = aepIn;
        }
    }

    public void createPredictiveRateAlertDialogInfo(BluetoothPairBaseActivity activity,
                                                    AlertEventPoint aep, int notificationId) {
        addAPendingRateOrPredictiveRateAlertDialog(aep, notificationId);
        showDialogs(activity);
    }

    public void addAPendingRateOrPredictiveRateAlertDialog(AlertEventPoint aep, int notificationId) {
        addDialogInfo(new PredictiveRateAlertDialogInfo(aep, notificationId));
    }

    public Dialog createPredictiveRateAlertDialog(
            final Context activity,
            final PredictiveRateAlertDialogInfo predictiveAlertDialogInfo) {

        AlertEventPoint aep = predictiveAlertDialogInfo.getAlertEventPoint();
        Utils.EVENT_TYPE eventType = aep.getEventType();

        int iconImageResId = R.drawable.yellow_bg;
        String title = activity.getString(R.string.alert);
        String stateText = "", text = "";
        Utils.TransmitterMessageCode code = null;
        if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING
                || predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
            stateText = Utils.getPredictiveAlertTitle(activity, eventType);
            text = Utils.getPredictiveAlertText(activity, eventType,
                    transmitterStateModel.getPredictiveFallingRateAlertMinuteInterval(),
                    transmitterStateModel.getTransmitterName());
        } else if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING
                || predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING) {
            stateText = Utils.getRateAlertTitle(activity, eventType);

            text = Utils.getRateAlertText(activity, eventType,
                    transmitterStateModel.getRateAlertFallingThreshold(),
                    transmitterStateModel.getTransmitterName());
        }

        if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING) {
            code = Utils.TransmitterMessageCode.PredictiveLowAlarm;

        } else if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
            code = Utils.TransmitterMessageCode.PredictiveHighAlarm;

        } else if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING) {
            code = Utils.TransmitterMessageCode.RateFallingAlarm;

        } else if (predictiveAlertDialogInfo.getAlertEventPoint().getEventType() == Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING) {
            code = Utils.TransmitterMessageCode.RateRisingAlarm;

        }

        NotificationDialogManager manager = new NotificationDialogManager() {

            @Override
            public void rightButtonPressed() {
                activity.startActivity(new Intent(activity,
                        NotificationsActivity.class));
                customDialogs.remove(predictiveAlertDialogInfo);
            }

            @Override
            public void leftButtonPressed() {
                customDialogs.remove(predictiveAlertDialogInfo);
            }
        };
        Dialog dialog = showCommonNotificationDialog(activity, iconImageResId,
                title, stateText, text, manager, activity.getResources()
                        .getString(R.string.ok), "",
                Utils.getNotificationDialogMessageSubTitleStringId(code),
                getNotificationDialogHelpTextString(activity, code),
                aep); // right button text set
        // to ""
        dialog.setCancelable(false);

        return dialog;
    }

    // Notification
    public class NotificationDialogInfo extends CustomDialogInfo {
        private EventPoint ep;
        private Utils.TransmitterMessageCode notificationEventType;

        public NotificationDialogInfo(EventPoint epIn,
                                      Utils.TransmitterMessageCode notificationEventType, int notificationid) {
            super(DIALOG_TYPE.NOTIFICATION_DIALOG, notificationid);
            setEventPoint(epIn);
            setNotificationEventType(notificationEventType);
        }

        public EventPoint getEventPoint() {
            return ep;
        }

        public void setEventPoint(EventPoint epIn) {
            this.ep = epIn;
        }

        public Utils.TransmitterMessageCode getNotificationEventType() {
            return notificationEventType;
        }

        public void setNotificationEventType(
                Utils.TransmitterMessageCode notificationEventType) {
            this.notificationEventType = notificationEventType;
        }
    }

    public void createNotificationDialogInfo(BluetoothPairBaseActivity activity,
                                             EventPoint ep, Utils.TransmitterMessageCode notificationEventType) {
        addAPendingNotificationAlertOrAlarm(ep, notificationEventType);
        showDialogs(activity);
    }

    public void addAPendingNotificationAlertOrAlarm(EventPoint ep, Utils.TransmitterMessageCode notificationEventType) {
        addDialogInfo(new NotificationDialogInfo(ep, notificationEventType, notificationEventType.notificationId()));
    }

    public Dialog createNotificationDialog(final Context activity,
                                           final NotificationDialogInfo sensorNotificationDialogInfo) {

        Utils.TransmitterMessageCode notificationEventType = sensorNotificationDialogInfo
                .getNotificationEventType();
        int iconImageResId = Utils.getNotificationDialogIcon(notificationEventType);

        int stateId = Utils.getNotificationDialogTypeStringId(notificationEventType);
        String stateText = "";
        if (stateId > 0)
            stateText = activity.getString(stateId);

        int titleId = Utils.getNotificationDialogMessageTitleStringId(notificationEventType);
        String titleText = "";
        if (titleId > 0) {
            titleText = activity.getString(titleId);

            if (titleId == R.string.unknown_error_alert_title) {
                titleText = Utils.replaceUnknownErrorCodeString(activity, titleText, Utils.currentUnknownErrorCode);
            }
        }

        int textId = Utils.getNotificationDialogTextStringId(notificationEventType);
        String text = "";
        if (textId > 0) {
            text = Utils.replaceTransmitterNameFromString(
                    activity.getString(textId), transmitterStateModel.getTransmitterName());
            // Check if it's out of range glucose alarm
            if (textId == R.string.out_of_range_low_glucose_alarm_message
                    || textId == R.string.out_of_range_high_glucose_alarm_message) {
                text = Utils.replaceOutOfRangeThresholdString(activity, text,
                        textId);
            }
        }

        EventPoint ep = sensorNotificationDialogInfo.getEventPoint();
        Utils.EVENT_TYPE eventType = ep.getEventType();
        NotificationDialogManager manager = null;

        if (notificationEventType == Utils.TransmitterMessageCode.InvalidSensorAlarm) {
            manager = new NotificationDialogManager() {

                @Override
                public void rightButtonPressed() {
                    activity.startActivity(new Intent(activity,
                            SensorListActivity.class));
                    customDialogs.remove(sensorNotificationDialogInfo);
                }

                @Override
                public void leftButtonPressed() {
                    customDialogs.remove(sensorNotificationDialogInfo);
                }
            };
        } else if (notificationEventType == Utils.TransmitterMessageCode.SensorStablity) {
            manager = new NotificationDialogManager() {

                @Override
                public void rightButtonPressed() {
                    activity.startActivity(new Intent(activity,
                            CalibrateActivity.class));
                    customDialogs.remove(sensorNotificationDialogInfo);
                }

                @Override
                public void leftButtonPressed() {
                    customDialogs.remove(sensorNotificationDialogInfo);
                }
            };
        } else {
            if (eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_BLUE
                    || eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_RED
                    || eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_YELLOW) {
                manager = new NotificationDialogManager() {

                    @Override
                    public void rightButtonPressed() {
                        activity.startActivity(new Intent(activity,
                                AboutActivity.class));
                        customDialogs.remove(sensorNotificationDialogInfo);
                    }

                    @Override
                    public void leftButtonPressed() {
                        customDialogs.remove(sensorNotificationDialogInfo);
                    }
                };
            } else {
                manager = new NotificationDialogManager() {

                    @Override
                    public void rightButtonPressed() {
                        activity.startActivity(new Intent(activity,
                                NotificationsActivity.class));
                        customDialogs.remove(sensorNotificationDialogInfo);
                    }

                    @Override
                    public void leftButtonPressed() {
                        customDialogs.remove(sensorNotificationDialogInfo);
                    }
                };
            }
        }

        int rightButtonTextId = Utils.getRightButtonTextId(notificationEventType);
        String rightButtonText = "";
        if (rightButtonTextId > 0) {
            rightButtonText = activity.getString(rightButtonTextId);
        }

        String leftButtonText = activity.getString(R.string.ok);
        if (notificationEventType == Utils.TransmitterMessageCode.SensorStablity ||
                notificationEventType == Utils.TransmitterMessageCode.InvalidSensorAlarm) {
            leftButtonText = activity.getString(R.string.not_now);
        }

        Dialog dialog = showCommonNotificationDialog(activity, iconImageResId,
                stateText, titleText, text, manager,
                leftButtonText, rightButtonText,
                Utils.getNotificationDialogMessageSubTitleStringId(notificationEventType),
                getNotificationDialogHelpTextString(activity, notificationEventType),
                ep);
        dialog.setCancelable(false);

        return dialog;
    }

    private String getNotificationDialogHelpTextString(Context activity, Utils.TransmitterMessageCode notificationEventType) {
        int helpTextId = Utils.getNotificationDialogHelpTextStringId(notificationEventType);
        String helpText = "";

        if (helpTextId > 0) {
            helpText = Utils.replaceTransmitterNameFromString(
                    activity.getString(helpTextId), transmitterStateModel.getTransmitterName());

            int glucoseValue = 0;
            if (notificationEventType == Utils.TransmitterMessageCode.SeriouslyHighAlarm) {
                glucoseValue = Utils.GLUCOSE_VALID_MAX;
            } else if (notificationEventType == Utils.TransmitterMessageCode.SeriouslyLowAlarm) {
                glucoseValue = Utils.GLUCOSE_VALID_MIN;
            } else if (notificationEventType == Utils.TransmitterMessageCode.HighGlucoseAlarm) {
                glucoseValue = transmitterStateModel.getHighGlucoseAlarmThreshold();
            } else if (notificationEventType == Utils.TransmitterMessageCode.LowGlucoseAlarm) {
                glucoseValue = transmitterStateModel.getLowGlucoseAlarmThreshold();
            } else if (notificationEventType == Utils.TransmitterMessageCode.HighGlucoseAlert) {
                glucoseValue = transmitterStateModel.getHighGlucoseAlertThreshold();
            } else if (notificationEventType == Utils.TransmitterMessageCode.LowGlucoseAlert) {
                glucoseValue = transmitterStateModel.getLowGlucoseAlertThreshold();
            }

            helpText = helpText.replace("%value%",
                    Utils.getGlucoseLevelString(activity, glucoseValue));

            helpText = helpText.replace("%predictiveMins%", transmitterStateModel.getPredictiveFallingRateAlertMinuteInterval() + "");

            String rateText = "";
            float rateValue = transmitterStateModel.getRateAlertFallingThreshold();
            if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
                rateText = String.format(Locale.US, "%.1f %s", rateValue, "mg/dL/min");
            } else {
                float glucoseMMol = Convert.MLConvertMgToMmol(rateValue);
                rateText = String.format(Locale.US, "%.2f %s", glucoseMMol, "mmol/L/min");
            }

            helpText = helpText.replace("%rate%", rateText);
        }
        return helpText;
    }

    // Warning dialog

    //ToDo:Need to remove static in the future, explore the ways...

    public static class WarningDialogInfo extends CustomDialogInfo {
        private int imageResId;
        private String title, text;

        public WarningDialogInfo(int imageResId, String title, String text) {
            super(DIALOG_TYPE.WARNING_DIALOG, -1);
            setImageResId(imageResId);
            setTitle(title);
            setText(text);
        }

        public int getImageResId() {
            return imageResId;
        }

        public void setImageResId(int imageResId) {
            this.imageResId = imageResId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

    public void createWarningDialogInfo(BluetoothPairBaseActivity activity,
                                        int imageResId, String title, String text) {
        addDialogInfo(new WarningDialogInfo(imageResId, title, text));
        showDialogs(activity);
    }

    public void removeDialogFromCustomDialogs (WarningDialogInfo warningDialogInfo){
        customDialogs.remove(warningDialogInfo);
    }

    public Dialog createWarningDialog(Context activity,
                                      final WarningDialogInfo warningDialogInfo) {
        return createWarningDialog(activity, warningDialogInfo, null);
    }

    public Dialog createWarningDialog(Context activity,
                                      final WarningDialogInfo warningDialogInfo,
                                      View.OnClickListener onClickListener) {

        int imageResId = warningDialogInfo.getImageResId();
        String title = warningDialogInfo.getTitle();
        String text = warningDialogInfo.getText();

        final Dialog dialog = new Dialog(activity, R.style.PickerDialog);
        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog_warning, null);

        if (title != null) {
            TextView titleTextView = (TextView) view
                    .findViewById(R.id.titleTextView);
            titleTextView.setVisibility(View.VISIBLE);
            titleTextView.setText(title);
        }

        if (imageResId != -1) {
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            imageView.setVisibility(View.VISIBLE);
            imageView.setImageResource(imageResId);
        }

        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(text);

        TextView ok = (TextView) view.findViewById(R.id.ok);
        if(onClickListener == null) {
            ok.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    customDialogs.remove(warningDialogInfo);
                }
            });
        }
        else {
            ok.setOnClickListener(onClickListener);
        }

        dialog.setCancelable(false);
        dialog.setContentView(view);
        return dialog;
    }

    // Warning dialog
    public class TimeZoneChangedDialogInfo extends CustomDialogInfo {

        public TimeZoneChangedDialogInfo() {
            super(DIALOG_TYPE.TIME_ZONE_CHANGED_DIALOG, -1);
        }
    }

    // Warning dialog
    public class TimeChangeDialogInfo extends CustomDialogInfo {

        public TimeChangeDialogInfo() {
            super(DIALOG_TYPE.TIME_CHANGE_DIALOG, -1);
        }
    }

    public void createTimeZoneChangedDialogInfo(BluetoothPairBaseActivity activity) {
        addDialogInfo(new TimeZoneChangedDialogInfo());
        showDialogs(activity);
    }

    public Dialog createTimeZoneChangedDialog(final Context activity,
                                              final TimeZoneChangedDialogInfo timeZoneChangedDialogInfo) {
        final Dialog dialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        String text = activity
                .getString(R.string.timezone_updated_transmitter_notification_message);
        textView.setText(text);

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                customDialogs.remove(timeZoneChangedDialogInfo);
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(R.string.check));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                activity.startActivity(new Intent(activity,
                        DailyCalibrationActivity.class));
                dialog.dismiss();
                customDialogs.remove(timeZoneChangedDialogInfo);
            }
        });
        dialog.setContentView(view);
        return dialog;
    }

    public Dialog createTimeChangedDialog(final Activity activity,
                                          final TimeChangeDialogInfo timeZoneChangeDialogInfo) {
        final Dialog dialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        String text = activity
                .getString(R.string.time_updated_transmitter_notification_message);
        textView.setText(text);

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                customDialogs.remove(timeZoneChangeDialogInfo);
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(R.string.check));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                activity.startActivity(new Intent(activity,
                        DailyCalibrationActivity.class));
                dialog.dismiss();
                customDialogs.remove(timeZoneChangeDialogInfo);
            }
        });
        dialog.setContentView(view);
        return dialog;
    }

    public void createMoreThan5AlertDialog(final Context activity,
                                           int alertTitle, int alertBody, int leftCancelText, int rightOkText,
                                           final Class<NotificationsActivity> newClass) {

        if (moreThan5AlertDialog != null && moreThan5AlertDialog.isShowing())
            moreThan5AlertDialog.dismiss();

        moreThan5AlertDialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setVisibility(View.VISIBLE);
        titleTextView.setText(activity.getString(alertTitle));

        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(activity
                .getString(alertBody));

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setText(activity.getString(leftCancelText));
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                removeDialogs();
                moreThan5AlertDialog.dismiss();
                activity.startActivity(new Intent(activity, newClass));
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(rightOkText));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                removeDialogs();
                moreThan5AlertDialog.dismiss();
            }
        });

        moreThan5AlertDialog.setContentView(view);
        moreThan5AlertDialog.show();
    }

    /** #3272 */
    public void fireUpdateAppPopup(Context c, String newVersion) {
        createUpdateAppPopup(c,
                R.string.app_update_title,
                R.string.app_update_body,
                R.string.no,
                R.string.yes,
                newVersion);
    }

    /** #3272 */
    private void openPlayStore(Context c) {
        final String DEVELOPER_ID = "Senseonics";
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://developer?id=" + DEVELOPER_ID)));
        } catch (android.content.ActivityNotFoundException anfe) {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=" + DEVELOPER_ID)));
        }
    }

    /** #3272 */
    private void createUpdateAppPopup(final Context activity,
                                      int alertTitle, int alertBody, int leftCancelText, int rightOkText, String newVersion) {
        // do not show the dialog again if it's already shown
        if (appUpdateDialog != null && appUpdateDialog.isShowing()) {
            return;
        }

        appUpdateDialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setVisibility(View.VISIBLE);
        titleTextView.setText(activity.getString(alertTitle));

        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(activity
                .getString(alertBody));

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setText(activity.getString(leftCancelText));
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                appUpdateDialog.dismiss();
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(rightOkText));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                appUpdateDialog.dismiss();

                openPlayStore(activity);
            }
        });

        appUpdateDialog.setContentView(view);
        appUpdateDialog.show();
    }

    /** #3160 */
    public void fireTempProfileTurnedOffPopup(Context c, Boolean firePopupNow) {
        boolean shouldShow = false;

        if (tempProfileManager.getTempProfileHasPendingPopup() == true) {
            tempProfileManager.setTempProfileHasPendingPopup(false);
            shouldShow = true;
        }

        if (shouldShow || firePopupNow) {
            createTempProfileTurnedOffPopup(c,
                    R.string.temp_profile_turned_off_title,
                    R.string.temp_profile_turned_off_body,
                    R.string.ok,
                    R.string.temp_profile_title,
                    TempGlucoseProfileActivity.class);
        }
    }

    /** #3160 */
    private void createTempProfileTurnedOffPopup(final Context activity,
                                              int alertTitle, int alertBody, int leftCancelText, int rightOkText,
                                              final Class<TempGlucoseProfileActivity> newClass) {

        if (tempProfileAlertDialog != null && tempProfileAlertDialog.isShowing())
            tempProfileAlertDialog.dismiss();

        tempProfileAlertDialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setVisibility(View.VISIBLE);
        titleTextView.setText(activity.getString(alertTitle));

        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(activity
                .getString(alertBody));

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setText(activity.getString(leftCancelText));
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                tempProfileAlertDialog.dismiss();
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(rightOkText));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                tempProfileAlertDialog.dismiss();

                if (!(activity instanceof TempGlucoseProfileActivity)) {
                    activity.startActivity(new Intent(activity,
                            newClass));
                }
            }
        });

        tempProfileAlertDialog.setContentView(view);
        tempProfileAlertDialog.show();
    }

    public void fireDoNotDisturbAlertDialog(Context c, boolean isDoNotDisturbMode) {
        if (isDoNotDisturbMode) {
            // Show the Do Not Disturb Warning dialog
            createDoNotDisturbAlertDialog(c,
                    R.string.do_not_disturb_warning_title,
                    R.string.do_not_disturb_warning_message_2,
                    R.string.ok, R.string.settings,
                    SoundSettingsSimplifiedActivity.class);
        }
    }

    public void createDoNotDisturbAlertDialog(final Context activity,
                                              int alertTitle, int alertBody, int leftCancelText, int rightOkText,
                                              final Class<SoundSettingsSimplifiedActivity> newClass) {

        if (doNotDisturbAlertDialog != null && doNotDisturbAlertDialog.isShowing())
            doNotDisturbAlertDialog.dismiss();

        doNotDisturbAlertDialog = new Dialog(activity, R.style.PickerDialog);

        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog, null);

        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setVisibility(View.VISIBLE);
        titleTextView.setText(activity.getString(alertTitle));

        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(activity
                .getString(alertBody));

        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setText(activity.getString(leftCancelText));
        cancelText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                doNotDisturbAlertDialog.dismiss();
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(activity.getString(rightOkText));
        okText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                doNotDisturbAlertDialog.dismiss();

                if (!(activity instanceof SoundSettingsSimplifiedActivity)) {
                    activity.startActivity(new Intent(activity,
                            newClass));
                }
            }
        });

        doNotDisturbAlertDialog.setContentView(view);
        doNotDisturbAlertDialog.show();
    }

    public Dialog showCommonNotificationDialog(final Context context,
                                               int iconImageResId, final String titleText, final String stateText,
                                               final String text, final NotificationDialogManager manager,
                                               String leftButtonText, String rightButtonText,
                                               int blindedTitleId, final String helpText,
                                               EventPoint ep) {

        boolean isLandscape = (context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE);

        final Dialog dialog = new Dialog(context, R.style.NotificationDialogTransparentTheme);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.alert_dialog, null);

        if (!isLandscape) {
            WindowManager.LayoutParams wmp = dialog.getWindow().getAttributes();
            wmp.y = wmp.y + 150;
            dialog.getWindow().setAttributes(wmp);
        }

        if (rightButtonText.equals("")) {

            ViewStub viewStub = (ViewStub) view.findViewById(R.id.selectButtonLayout);
            viewStub.setLayoutResource(R.layout.notifications_one_button);
            viewStub.inflate();
        } else {
            ViewStub viewStub = (ViewStub) view.findViewById(R.id.selectButtonLayout);
            viewStub.setLayoutResource(R.layout.notifications_two_buttons);
            viewStub.inflate();
        }

        LinearLayout notificationLayout = (LinearLayout) view.findViewById(R.id.notificationLayout);
        notificationLayout.setBackgroundResource(iconImageResId);

        // Set 1st line type title (NOTIFICATION/ALERT/ALARM)
        TextView titleTextView = (TextView) view
                .findViewById(R.id.titleTextView);
        titleTextView.setText(titleText.toUpperCase());

        // Set the 2nd line message title text
        TextView glucoseStateTextView = (TextView) view
                .findViewById(R.id.glucoseState);
        glucoseStateTextView.setText(stateText);

        // Set 3rd line timestamp
        TextView timeStampTextView = (TextView) view
                .findViewById(R.id.timeStamp);
        long timestampInMilli = ep.getTimestamp();
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestampInMilli);
        timeStampTextView.setText(Utils.formatWeekDateTimeForTimeZone(cal, TimeZone.getDefault(), context).toString());

        // Set 4th line blinded glucose text
        TextView blindedTextView = (TextView) view
                .findViewById(R.id.blindedText);
        String blindedTitleText = " ";
        if (blindedTitleId != -1) {
            blindedTitleText = context.getString(blindedTitleId);
        }
        blindedTextView.setText(blindedTitleText);
        if (isLandscape) {
            ViewGroup.MarginLayoutParams llp = (ViewGroup.MarginLayoutParams)blindedTextView.getLayoutParams();
            llp.setMargins((int) context.getResources().getDimension(R.dimen.box_margin), 0, (int) context.getResources().getDimension(R.dimen.box_margin), 0);
            blindedTextView.setLayoutParams(llp);
        }

        // Set the message body text
        TextView alertTextView = (TextView) view.findViewById(R.id.alertText);
        alertTextView.setMovementMethod(new ScrollingMovementMethod());
        alertTextView.setText(text);
        if (isLandscape) {
            ViewGroup.MarginLayoutParams llp = (ViewGroup.MarginLayoutParams)alertTextView.getLayoutParams();
            llp.setMargins((int) context.getResources().getDimension(R.dimen.box_margin), 0, (int) context.getResources().getDimension(R.dimen.box_margin), 0);
            alertTextView.setLayoutParams(llp);
        }

        // Set the right bottom Transmitter name
        TextView transNameTextView = (TextView) view
                .findViewById(R.id.tranName);
        transNameTextView.setText(transmitterStateModel.getTransmitterName());

        // if the popup background is yellow, change the top 3 lines of text to black
        if (iconImageResId == R.drawable.yellow_bg) {
            titleTextView.setTextColor(context.getResources().getColor(R.color.black));
            glucoseStateTextView.setTextColor(context.getResources().getColor(R.color.black));
            timeStampTextView.setTextColor(context.getResources().getColor(R.color.black));
        }

        // Set the HELP Info button content
        ImageView infoImageView = (ImageView) view.findViewById(R.id.infoImage);
        infoImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

                dialog.setContentView(R.layout.dialog_information);
                // set the custom dialog components - text, image and button
                TextView infoTextView = (TextView) dialog.findViewById(R.id.info_textView);

                infoTextView.setMovementMethod(new ScrollingMovementMethod());
                infoTextView.setText(helpText);

                TextView textInfoTitleTextView = (TextView) dialog.findViewById(R.id.info_title);
                textInfoTitleTextView.setText(stateText);
                // if button is clicked, close the custom dialog
                dialog.show();

            }
        });

        TextView leftButton = (TextView) view.findViewById(R.id.cancel);
        TextView rightButton = (TextView) view.findViewById(R.id.ok);

        // Check if the right button text is empty; if so, remove the button
        if (!rightButtonText.equals("")) {
            rightButton.setText(rightButtonText);
            rightButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    manager.rightButtonPressed();
                }
            });
        }

        leftButton.setText(leftButtonText);
        leftButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                manager.leftButtonPressed();
            }
        });

        dialog.setContentView(view);
        dialog.setCancelable(false);

        int widthToSet = (int) context.getResources().getDimension(
                R.dimen.notification_dialog_width);
        int heightToSet = (int) context.getResources().getDimension(
                R.dimen.notification_dialog_height);

        if (!isLandscape) {
            dialog.getWindow().setLayout(widthToSet, heightToSet);
        }
        else {
            dialog.getWindow().setLayout(heightToSet, widthToSet);
        }

        return dialog;
    }

    public interface DateDialogManager {
        void onDateSelected(Calendar calendar);
    }


    public Dialog createDatePickerDialog(Context context,
                                         Calendar currentDate, Calendar startDate, Calendar endDate,
                                         final DateDialogManager dialogManager) {

        final Dialog dialog = new Dialog(context, R.style.PickerDialog);
        dialog.setCancelable(false);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.datepicker, null);

        final DatePicker datePicker = (DatePicker) view
                .findViewById(R.id.datePicker);
        TextView cancel = (TextView) view.findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        TextView ok = (TextView) view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth();
                int year = datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.HOUR, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);

                dialogManager.onDateSelected(calendar);
                dialog.dismiss();
            }
        });

        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        datePicker.init(year, month, day, null);

        datePicker.setCalendarViewShown(false);
        datePicker.setMinDate(startDate.getTimeInMillis());
        datePicker.setMaxDate(endDate.getTimeInMillis());

        dialog.setContentView(view);

        HideKeyboard(dialog);

        return dialog;
    }

    private TimePicker.OnTimeChangedListener nullTimeChangedListener = new TimePicker.OnTimeChangedListener() {

        public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        }
    };

    public void createDateTimePickerDialog(Context context,
                                           final Calendar currentDate, Calendar startDate, Calendar endDate,
                                           final DateDialogManager dialogManager,
                                           final boolean isCalibrationPicker) {

        final Dialog dialog = new Dialog(context, R.style.PickerDialog);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.datetimepicker, null);

        final DatePicker datePicker = (DatePicker) view
                .findViewById(R.id.datePicker);

        final TimePicker timePicker = (TimePicker) view
                .findViewById(R.id.timePicker);
        timePicker
                .setDescendantFocusability(DatePicker.FOCUS_BLOCK_DESCENDANTS);
        if(DateFormat.is24HourFormat(context)) {
            timePicker.setIs24HourView(true);
        }


        TimePicker.OnTimeChangedListener timeChangedListener = new TimePicker.OnTimeChangedListener() {

            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                Calendar calendar = Calendar.getInstance();
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth();
                int year = datePicker.getYear();

                if (calendar.get(Calendar.YEAR) == year
                        && calendar.get(Calendar.MONTH) == month
                        && calendar.get(Calendar.DAY_OF_MONTH) == day) {

                    int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                    int currentMinute = calendar.get(Calendar.MINUTE);

                    timePicker
                            .setOnTimeChangedListener(nullTimeChangedListener);

                    if (calendar.get(Calendar.DAY_OF_MONTH) == day) {
                        // set hour
                        timePicker
                                .setCurrentHour((hourOfDay > currentHour) ? currentHour
                                        : hourOfDay);
                        // set minute
                        if (currentHour == hourOfDay)
                            timePicker
                                    .setCurrentMinute((minute > currentMinute) ? currentMinute
                                            : minute);
                    }
                    timePicker.setOnTimeChangedListener(this);
                }

                if (isCalibrationPicker == true) {
                    Calendar selectedCal = Calendar.getInstance();
                    selectedCal.set(year, month, day, hourOfDay, minute, 0);
                    selectedCal.set(Calendar.MILLISECOND, 0);
                    Log.d("timepicker", selectedCal.getTimeInMillis() + " ; "
                            + currentDate.getTimeInMillis());

                    // #1003 restrict to only 10 minutes from the current time
                    if (Math.abs(selectedCal.getTimeInMillis()
                            - currentDate.getTimeInMillis()) > 10 * 60 * 1000) {
                        datePicker.init(currentDate.get(Calendar.YEAR),
                                currentDate.get(Calendar.MONTH),
                                currentDate.get(Calendar.DAY_OF_MONTH), null);

                        timePicker.setCurrentHour(currentDate
                                .get(Calendar.HOUR_OF_DAY));
                        timePicker.setCurrentMinute(currentDate
                                .get(Calendar.MINUTE));
                    }
                }
            }
        };

        timePicker.setOnTimeChangedListener(timeChangedListener);

        TextView cancel = (TextView) view.findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        TextView ok = (TextView) view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth();
                int year = datePicker.getYear();

                Integer hour = timePicker.getCurrentHour();
                Integer minute = timePicker.getCurrentMinute();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);
                calendar.set(Calendar.HOUR_OF_DAY, hour);
                calendar.set(Calendar.MINUTE, minute);

                dialogManager.onDateSelected(calendar);
                dialog.dismiss();
            }
        });

        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        datePicker.init(year, month, day, null);

        datePicker.setCalendarViewShown(false);
        datePicker.setMinDate(startDate.getTimeInMillis());
        datePicker.setMaxDate(endDate.getTimeInMillis());

        timePicker.setCurrentHour(currentDate.get(Calendar.HOUR_OF_DAY));
        timePicker.setCurrentMinute(currentDate.get(Calendar.MINUTE));

        dialog.setContentView(view);

        HideKeyboard(dialog);

        dialog.show();
    }


    public interface TimeDialogManager {
        void onTimeSelected(Integer hour, Integer minute);
    }


    public Dialog createTimePickerDialog(Context context,
                                         int currentHour, int currentMinute,
                                         String title,
                                         final TimeDialogManager dialogManager) {

        final Dialog dialog = new Dialog(context, R.style.PickerDialog);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.timepicker, null);

        final TimePicker timePicker = (TimePicker) view
                .findViewById(R.id.timePicker);
        timePicker
                .setDescendantFocusability(DatePicker.FOCUS_BLOCK_DESCENDANTS);
        if(DateFormat.is24HourFormat(context)) {
            timePicker.setIs24HourView(true);
        }

        timePicker.setCurrentHour(currentHour);
        timePicker.setCurrentMinute(currentMinute);

        TextView tvTitle = (TextView) view.findViewById(R.id.title);
        tvTitle.setText(title);

        TextView cancel = (TextView) view.findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        TextView ok = (TextView) view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Integer hour = timePicker.getCurrentHour();
                Integer minute = timePicker.getCurrentMinute();

                dialogManager.onTimeSelected(hour, minute);
                dialog.dismiss();
            }
        });

        dialog.setContentView(view);

        HideKeyboard(dialog);

        // dialog.show();
        return dialog;
    }

    private void HideKeyboard(Dialog dialog) {
        dialog.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public interface PasscodeDialogManager {
        void passcodeEntered();
    }

    public Dialog createEnterPasscodeDialog(final BluetoothPairBaseActivity activity,
                                            final PasscodeDialogManager passcodeDialogManager,
                                            final int passcode) {
        final Dialog dialog = new Dialog(activity,
                R.style.DialogTransparentTheme);
        LayoutInflater inflater = LayoutInflater.from(activity);
        View view = inflater.inflate(R.layout.dialog_enter_passcode, null);

        final TextView text = (TextView) view.findViewById(R.id.textView);
        text.setText(activity.getString(R.string.passcode_text));

        final CustomEditText editText = (CustomEditText) view
                .findViewById(R.id.passcode);
        editText.setOnEditTextImeBackListener(new CustomEditText.EditTextImeBackListener() {

            @Override
            public void onImeBack(CustomEditText ctrl, String text) {
                dialog.dismiss();
            }
        });

        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                text.setTextColor(activity.getResources().getColor(
                        android.R.color.white));
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId,
                                          KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    if (editText.getText().toString()
                            .equals(String.valueOf(passcode))) {
                        passcodeDialogManager.passcodeEntered();
                        text.setText(activity.getString(R.string.passcode_text));
                        text.setTextColor(activity.getResources().getColor(
                                android.R.color.white));
                        InputMethodManager imm = (InputMethodManager) activity
                                .getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(
                                v.getApplicationWindowToken(),
                                InputMethodManager.HIDE_NOT_ALWAYS);
                        dialog.dismiss();
                    } else {
                        text.setText(activity
                                .getString(R.string.invalid_passcode));
                        text.setTextColor(activity.getResources().getColor(
                                R.color.red_invalid_passcode));
                    }

                    return true;
                }

                return false;
            }
        });

        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        dialog.setContentView(view);
        dialog.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {

            @Override
            public boolean onKey(DialogInterface dialog, int keyCode,
                                 KeyEvent event) {
                Log.d("onKey", keyCode + " ");
                if (keyCode == KeyEvent.KEYCODE_BACK
                        && event.getAction() == KeyEvent.ACTION_UP
                        && !event.isCanceled()) {
                    dialog.dismiss();
                    return true;
                }
                return false;
            }
        });
        // dialog.setCancelable(false);

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {
                enterPasscodeDialogIsShowing = false;
                showDialogs(activity);
            }
        });

        return dialog;
    }

    public interface EventPickerManager {
        void newEvent(EventPoint event);
    }

    public ArrayList<Item> getGlucoseLevels(int minGlucose,
                                            int maxGlucose, int incValue) {
        ArrayList<Item> glucoseValues = new ArrayList<Item>();
            glucoseValues = getNumbersBetween(minGlucose, maxGlucose, incValue);

        return glucoseValues;
    }

    public ArrayList<Item> getGlucoseLevels(float minGlucose,
                                            float maxGlucose, float incValue) {

        ArrayList<Item> glucoseValues = new ArrayList<Item>();


            double minValue = minGlucose;
            double maxValue = maxGlucose;
            double i = minValue;
            for (i = minValue; i < maxValue; i += 0.1) {
                String formatted = String.format(Locale.US, "%.1f", i);
                Log.i("getGlucoseLevels","formatted:"+formatted);
                glucoseValues.add(new Item(glucoseValues.size(), formatted));
            }

            if(glucoseValues.size()>0) {
                String lastItemStr = glucoseValues.get(glucoseValues.size() - 1).getValue();
                String maxString = String.format(Locale.US, "%.1f", maxValue);
                if(!lastItemStr.equals(maxString)) {
                    glucoseValues.add(new Item(glucoseValues.size(), String.format(Locale.US, "%.1f", maxValue)));
                }
            }
        return glucoseValues;
    }


    public ArrayList<Item> getRateLevels(float minRate, float maxRate,
                                         float incValue) {

        ArrayList<Item> glucoseValues = new ArrayList<Item>();
        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            for (float i = minRate; i <= maxRate; i += incValue)
                glucoseValues.add(new Item(glucoseValues.size(), String
                        .valueOf(i)));
        } else {

            double minValue = Convert.MLConvertMgToMmol(minRate);
            double maxValue = Convert.MLConvertMgToMmol(maxRate);
            double i = minValue;
            for (i = minValue; i < maxValue; i += 0.02) {
                String formatted = String.format(Locale.US, "%.2f", i);
                Log.i("getGlucoseLevels","formatted:"+formatted);
                glucoseValues.add(new Item(glucoseValues.size(), formatted));
            }
            String lastItemStr = glucoseValues.get(glucoseValues.size()-1).getValue();
            String maxString = String.format(Locale.US, "%.2f", maxValue);
            if(!lastItemStr.equals(maxString)) {
                glucoseValues.add(new Item(glucoseValues.size(), String.format(Locale.US, "%.2f", maxValue)));
            }
        }
        return glucoseValues;
    }

    public ArrayList<Item> getNumbersBetween(int minValue, int maxValue,
                                             int incValue) {
        ArrayList<Item> list = new ArrayList<Item>();
        for (int i = minValue; i <= maxValue; i += incValue)
            list.add(new Item(list.size(), String.valueOf(i)));
        return list;
    }

    public ArrayList<Item> getNumbersBetweenWithSuffix(int minValue, int maxValue,
                                             int incValue, String suffix) {
        ArrayList<Item> list = new ArrayList<Item>();
        for (int i = minValue; i <= maxValue; i += incValue)
            list.add(new Item(list.size(), String.valueOf(i)+suffix));
        return list;
    }

    public ArrayList<Item> getDecimalsBetween(int minValue,
                                              int maxValue, int incValue) {
        ArrayList<Item> list = new ArrayList<Item>();
        for (int i = minValue; i <= maxValue; i += incValue) {
            list.add(new Item(list.size(), "." + i));
        }
        return list;
    }

    public int getGlucoseValueMg(String glucoseString) {
        if (isFloat(glucoseString))
            return Convert.MLConvertMmolToMg(Float.valueOf(glucoseString));
        else
            return Integer.valueOf(glucoseString);
    }

    public boolean isFloat(String s) {
        if (s.contains(".") || s.contains(","))
            return true;
        else
            return false;
    }

    public ArrayList<Item> getMinutes(Context context, int minMinute,
                                      int maxMinute, int incValue) {

        ArrayList<Item> glucoseValues = new ArrayList<Item>();

        for (int i = minMinute; i <= maxMinute; i += incValue) {
            glucoseValues.add(new Item(glucoseValues.size(), String.valueOf(i)
                    + " " + context.getString(R.string.minute)));
        }
        return glucoseValues;
    }

    public interface DoublePickerManager {
        void selected(int id1, int id2);
    }

    public Dialog createPickerDialog(Context context, String title,
                                     ArrayList<Item> items, final EventUtils.PickerManager pickerManager,
                                     int currentSelected) {
        return createPickerDialog(context, title, items, null, pickerManager,
                null, currentSelected, 0, false, false);
    }

    public Dialog createPickerDialog(Context context, String title,
                                     final ArrayList<Item> items, final ArrayList<Item> items2,
                                     final EventUtils.PickerManager pickerManager,
                                     final DoublePickerManager doublePickerManager, int currentSelected,
                                     int currentSelected2, boolean insulin, boolean tempProfileDuration) {

        final Dialog dialog = new Dialog(context, R.style.PickerDialog);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.picker_small_items, null);

        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setText(title);

        final NumberPicker picker = (NumberPicker) view
                .findViewById(R.id.picker);
        String[] array = new String[items.size()];
        for (int i = 0; i < items.size(); i++)
            array[i] = items.get(i).getValue();
        picker.setMinValue(0);
        picker.setMaxValue(items.size() - 1);
        picker.setDisplayedValues(array);
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        picker.setWrapSelectorWheel(false);
        picker.setValue(currentSelected);

        final NumberPicker p = (NumberPicker) view.findViewById(R.id.picker2);
        if (items2 != null) {
            p.setVisibility(View.VISIBLE);
            String[] array2 = new String[items2.size()];
            for (int i = 0; i < items2.size(); i++)
                array2[i] = items2.get(i).getValue();
            p.setMinValue(0);
            p.setMaxValue(items2.size() - 1);
            p.setDisplayedValues(array2);
            p.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
            p.setWrapSelectorWheel(false);
            p.setValue(currentSelected2);
        }

        if (insulin) {
            final int lastItem = Integer.valueOf(items.get(items.size() - 1)
                    .getValue());
            if (currentSelected == lastItem)
                p.setMaxValue(0);
            picker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {

                @Override
                public void onValueChange(NumberPicker picker, int oldVal,
                                          int newVal) {
                    if (newVal == lastItem)
                        p.setMaxValue(0);
                    else
                        p.setMaxValue(items2.size() - 1);
                }
            });
        }

        if (tempProfileDuration) {
            final int firstItem = TempProfileManager.DURATION_MIN_HOUR;
            final int lastItem = TempProfileManager.DURATION_MAX_HOUR;

            if (currentSelected == firstItem) {
                p.setMaxValue(0);
                p.setDisplayedValues(new String[]{items2.get(1).getValue()});
                p.setValue(0);
            }
            else if (currentSelected == lastItem) {
                p.setMaxValue(0);
                p.setDisplayedValues(new String[]{items2.get(0).getValue()});
                p.setValue(0);
            }

            picker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
                @Override
                public void onValueChange(NumberPicker picker, int oldVal,
                                          int newVal) {
                    if (newVal == firstItem) {
                        p.setMaxValue(0);
                        p.setDisplayedValues(new String[]{items2.get(1).getValue()});
                        p.setValue(0);
                    } else if (newVal == lastItem) {
                        p.setMaxValue(0);
                        p.setDisplayedValues(new String[]{items2.get(0).getValue()});
                        p.setValue(0);
                    } else {
                        p.setDisplayedValues(new String[]{items2.get(0).getValue(), items2.get(1).getValue()}); /** do this FIRST */
                        p.setMaxValue(1); /** do this SECOND */
                    }
                }
            });
        }

        final NumberPicker picker2 = p;
        TextView ok = (TextView) view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (pickerManager != null)
                    pickerManager.selected(picker.getValue());
                if (doublePickerManager != null && picker2 != null)
                    doublePickerManager.selected(picker.getValue(),
                            picker2.getValue());

                dialog.dismiss();
            }
        });

        TextView cancel = (TextView) view.findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setContentView(view);
        dialog.setCancelable(false);
        return dialog;
    }

    public static class PlacementDialogInfo extends CustomDialogInfo {
        private NotificationDialogManager notificationDialogManager;

        public PlacementDialogInfo(NotificationDialogManager notificationDialogManager) {
            super(DIALOG_TYPE.PLACEMENT_DIALOG, -1);
            this.notificationDialogManager = notificationDialogManager;
        }

        public NotificationDialogManager getNotificationDialogManager() {
            return notificationDialogManager;
        }
    }
}
