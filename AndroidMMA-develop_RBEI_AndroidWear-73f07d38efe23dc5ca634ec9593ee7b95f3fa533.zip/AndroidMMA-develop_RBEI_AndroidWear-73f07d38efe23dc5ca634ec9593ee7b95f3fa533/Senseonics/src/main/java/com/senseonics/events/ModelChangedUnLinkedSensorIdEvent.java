package com.senseonics.events;

public class ModelChangedUnLinkedSensorIdEvent {

    private String unLinkedsensorId;

    public ModelChangedUnLinkedSensorIdEvent(String unLinkedsensorId){
        this.unLinkedsensorId = unLinkedsensorId;
    }

    public String getUnLinkedsensorId() {
        return unLinkedsensorId;
    }
}
