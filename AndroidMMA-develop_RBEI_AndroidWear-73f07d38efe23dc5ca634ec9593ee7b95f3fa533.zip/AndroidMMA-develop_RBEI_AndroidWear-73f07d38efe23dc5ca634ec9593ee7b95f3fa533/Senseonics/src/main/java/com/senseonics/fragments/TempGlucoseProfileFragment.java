package com.senseonics.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.bluetoothle.DialogUtils.DoublePickerManager;
import com.senseonics.bluetoothle.TempProfileManager;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.EventUtils;
import com.senseonics.events.TempProfileTurnedOffEvent;
import com.senseonics.util.Item;
import com.senseonics.util.ThresholdsController;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class TempGlucoseProfileFragment extends BaseFragment{ /** #3160 */
    private final String TAG = "TempProfileManager_Fragment";
    private final TempProfileManager.GLUCOSE_PROFILE_TYPE Temp = TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP;

    private RelativeLayout durationLayout;
    private TextView durationLeftTextView;
    private TextView durationRightTextView;

    private RelativeLayout targetHighLayout;
    private TextView targetHighLeftTextView;
    private TextView targetHighRightTextView;

    private RelativeLayout targetLowLayout;
    private TextView targetLowLeftTextView;
    private TextView targetLowRightTextView;

    private RelativeLayout alarmHighLayout;
    private TextView alarmHighLeftTextView;
    private TextView alarmHighRightTextView;

    private RelativeLayout alarmLowLayout;
    private TextView alarmLowLeftTextView;
    private TextView alarmLowRightTextView;

    private TextView btnStartStop;

    private Dialog dialog;
    private Timer countDownTimer;

    private ArrayList<Item> values;

    @Inject
    protected ThresholdsController thresholdsController;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_tempglucoseprofile, container, false);

        tempProfileManager.restoreAllGlucoseProfilesToStateValueIfNeeded();
        Utils.printLongLog(TAG, "Non Temp: " + tempProfileManager.nonTempProfileToString());
        Utils.printLongLog(TAG, "Temp: " + tempProfileManager.tempProfileToString());
        Utils.printLongLog(TAG, "Duration: " + tempProfileManager.getTempProfileDuration());

        /** Find all the views */
        durationLayout = (RelativeLayout) view.findViewById(R.id.durationLayout);
        durationLeftTextView = (TextView) view.findViewById(R.id.durationTitleTextView);
        durationRightTextView = (TextView) view.findViewById(R.id.durationValueTextView);
        setupDurationLayoutOnClickEvent();

        targetHighLayout = (RelativeLayout) view.findViewById(R.id.targetHighLayout);
        targetHighLeftTextView = (TextView) view.findViewById(R.id.glucoseTargetHighTextView);
        targetHighRightTextView = (TextView) view.findViewById(R.id.targetHigh);
        setupTargetHighOnClickEvent();

        targetLowLayout = (RelativeLayout) view.findViewById(R.id.targetLowLayout);
        targetLowLeftTextView = (TextView) view.findViewById(R.id.glucoseTargetLowTextView);
        targetLowRightTextView = (TextView) view.findViewById(R.id.targetLow);
        setupTargetLowOnClickEvent();

        alarmHighLayout = (RelativeLayout) view.findViewById(R.id.alarmHighLayout);
        alarmHighLeftTextView = (TextView) view.findViewById(R.id.glucoseAlarmHighTextView);
        alarmHighRightTextView = (TextView) view.findViewById(R.id.alarmHigh);
        setupAlarmHighOnClickEvent();

        alarmLowLayout = (RelativeLayout) view.findViewById(R.id.alarmLowLayout);
        alarmLowLeftTextView = (TextView) view.findViewById(R.id.glucoseAlarmLowTextView);
        alarmLowRightTextView = (TextView) view.findViewById(R.id.alarmLow);
        setupAlarmLowOnClickEvent();

        btnStartStop = (TextView) view.findViewById(R.id.btnStartStop);
        setupBtnStartStopOnClickEvent();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
        updateViews();
    }

    @Override
    public void onPause() {
        EventBus.getDefault().unregister(this);
        invalidateCountDownTimer();
        super.onPause();
    }

    public void onEventMainThread(TempProfileTurnedOffEvent event) {
        stopTempProfileUpdateTable();
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        updateViews();
    }

    private void stopTempProfileUpdateTable() {
        Utils.printLongLog(TAG, "_____stopTempProfileUpdateTable_____");
        tempProfileManager.stopTempProfile();
        updateViews();
    }

    private void invalidateCountDownTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
            countDownTimer = null;
            Utils.printLongLog(TAG, "------ invalidateCountDownTimer ------");
        }
    }

    public void showDialog(String title, ArrayList<Item> items,
                           final EventUtils.PickerManager pickerManager, int currentSelected) {
        if (items.size() > 1) {
            if (dialog != null && dialog.isShowing())
                dialog.hide();
            dialog = dialogUtils.createPickerDialog(getActivity(),
                    title, items, pickerManager, currentSelected);
            dialog.show();
        }
    }

    private class countDownTimerTask extends TimerTask {
        public void run() {
            final long secLeft = tempProfileManager.getTempProfileRemainingTime();
            if (secLeft == tempProfileManager.TEMP_PROFILE_EXPIRE_SECONDS) {
                // only fire the notification when the tx is connected
                if (transmitterStateModel.isTransmitterConnected()) {
                    tempProfileManager.eventBusPostTempOffEvent();
                }
            }
            else {
                if (secLeft > 0L) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Utils.printLongLog(TAG, "--- Countdown Timer tick ---");
                                durationRightTextView.setText(tempProfileManager.formatTempProfileTimeLeftGivenSeconds(secLeft));
                            }
                        });
                    }
                }
            }
        }
    }

    private void updateViews() {
        Boolean connected = false;
        Boolean tempProfileDisabled = !tempProfileManager.getTempProfileEnabled();

        connected = transmitterStateModel.isTransmitterConnected();
        Boolean combined = connected & tempProfileDisabled;

        btnStartStop.setClickable(connected); /** only depend on connected */
        btnStartStop.setTextColor((connected) ? getResources().getColor(R.color.graph_white) : getResources().getColor(R.color.light_gray));

        if (combined) {
            durationLayout.setClickable(true);
            durationLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            durationLeftTextView.setTextColor(getResources().getColor(R.color.black));
            durationRightTextView.setTextColor(getResources().getColor(R.color.black));

            targetHighLayout.setClickable(true);
            targetHighLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            targetHighLeftTextView.setTextColor(getResources().getColor(R.color.black));
            targetHighRightTextView.setTextColor(getResources().getColor(R.color.black));

            targetLowLayout.setClickable(true);
            targetLowLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            targetLowLeftTextView.setTextColor(getResources().getColor(R.color.black));
            targetLowRightTextView.setTextColor(getResources().getColor(R.color.black));

            alarmHighLayout.setClickable(true);
            alarmHighLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            alarmHighLeftTextView.setTextColor(getResources().getColor(R.color.black));
            alarmHighRightTextView.setTextColor(getResources().getColor(R.color.black));

            alarmLowLayout.setClickable(true);
            alarmLowLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            alarmLowLeftTextView.setTextColor(getResources().getColor(R.color.black));
            alarmLowRightTextView.setTextColor(getResources().getColor(R.color.black));
        }
        else {
            durationLayout.setClickable(false);
            durationLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            durationLeftTextView.setTextColor(getResources().getColor(R.color.light_gray));
            durationRightTextView.setTextColor(getResources().getColor(R.color.light_gray));

            targetHighLayout.setClickable(false);
            targetHighLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            targetHighLeftTextView.setTextColor(getResources().getColor(R.color.light_gray));
            targetHighRightTextView.setTextColor(getResources().getColor(R.color.light_gray));

            targetLowLayout.setClickable(false);
            targetLowLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            targetLowLeftTextView.setTextColor(getResources().getColor(R.color.light_gray));
            targetLowRightTextView.setTextColor(getResources().getColor(R.color.light_gray));

            alarmHighLayout.setClickable(false);
            alarmHighLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            alarmHighLeftTextView.setTextColor(getResources().getColor(R.color.light_gray));
            alarmHighRightTextView.setTextColor(getResources().getColor(R.color.light_gray));

            alarmLowLayout.setClickable(false);
            alarmLowLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            alarmLowLeftTextView.setTextColor(getResources().getColor(R.color.light_gray));
            alarmLowRightTextView.setTextColor(getResources().getColor(R.color.light_gray));
        }

        Boolean tempProfileEnabled = !tempProfileDisabled;

        // update the button text
        btnStartStop.setText(tempProfileEnabled ? getActivity().getString(R.string.stop).toUpperCase() : getActivity().getString(R.string.start).toUpperCase());

        /** Set duration text */
        TempProfileManager.TEMP_PROFILE_STATUS status = tempProfileManager.getTempProfileStatus();

        if (status != TempProfileManager.TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_ALREADY_DISABLED) {
            durationRightTextView.setText(tempProfileManager.formatTempProfileTimeLeftGivenSeconds(tempProfileManager.getTempProfileRemainingTime()));

            if (status == TempProfileManager.TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_IN_PROGRESS) {
                // Start countdown timer if needed
                if (countDownTimer == null) {
                    countDownTimer = new Timer();
                    countDownTimer.schedule(new countDownTimerTask(), 0, 1000); // refreshed every 1s
                }
            }
            else if (status == TempProfileManager.TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_NEED_TO_DISABLE) {
                // only fire the notification when the tx is connected
                if (transmitterStateModel.isTransmitterConnected()) {
                    tempProfileManager.eventBusPostTempOffEvent();
                }
            }
        }
        else {
            int durationMins = tempProfileManager.getTempProfileDuration();
            durationRightTextView.setText(getActivity().getString(R.string.temp_profile_duration, durationMins / 60, durationMins % 60));
        }

        if (status != TempProfileManager.TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_IN_PROGRESS) {
            invalidateCountDownTimer();
        }

        targetHighRightTextView.setText(Utils.getGlucoseLevelString(getActivity(), tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH)));

        targetLowRightTextView.setText(Utils.getGlucoseLevelString(getActivity(), tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW)));

        alarmHighRightTextView.setText(Utils.getGlucoseLevelString(getActivity(), tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH)));

        alarmLowRightTextView.setText(Utils.getGlucoseLevelString(getActivity(), tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW)));

    }

    private void setupBtnStartStopOnClickEvent() {
        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean enabledBefore = tempProfileManager.getTempProfileEnabled();

                if (enabledBefore) {
                    tempProfileManager.stopTempProfile();
                    Answers.getInstance().logCustom(new CustomEvent("Temp Profile")
                            .putCustomAttribute("Info", "User Stopped"));
                }
                else {
                    tempProfileManager.startTempProfile(
                            tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW),
                            tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH),
                            tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW),
                            tempProfileManager.getThresholdForProfileTypeForAttribute(TempProfileManager.GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH));
                    Answers.getInstance().logCustom(new CustomEvent("Temp Profile")
                            .putCustomAttribute("Info", "User Started"));
                }

                updateViews();
            }
        });
    }

    private void setupDurationLayoutOnClickEvent() {
        final ArrayList<Item> listHour = dialogUtils.getNumbersBetweenWithSuffix(TempProfileManager.DURATION_MIN_HOUR, TempProfileManager.DURATION_MAX_HOUR, 1, getString(R.string.hr));
        ArrayList<Item> list2 = new ArrayList<>();
        list2.add(new Item(0, TempProfileManager.DURATION_MINUTE_OPTION_0 + getString(R.string.min)));
        list2.add(new Item(1, TempProfileManager.DURATION_MINUTE_OPTION_1 + getString(R.string.min)));
        final ArrayList<Item> listMinute = list2;

        final DoublePickerManager pickerManager = new DialogUtils.DoublePickerManager() {
            @Override
            public void selected(int id1, int id2) {
                int selectedHours = id1;
                int selectedMinute = (id2 == 0) ? TempProfileManager.DURATION_MINUTE_OPTION_0 : TempProfileManager.DURATION_MINUTE_OPTION_1; // normally

                if (id1 == TempProfileManager.DURATION_MIN_HOUR) {
                    selectedMinute = TempProfileManager.DURATION_MINUTE_OPTION_1;
                }
                else if (id1 == TempProfileManager.DURATION_MAX_HOUR) {
                    selectedMinute = TempProfileManager.DURATION_MINUTE_OPTION_0;
                }

                int durationMinute = selectedHours * 60 + selectedMinute;

                tempProfileManager.setTempProfileDuration(durationMinute);
                durationRightTextView.setText(getActivity().getString(R.string.temp_profile_duration, selectedHours, selectedMinute));
            }
        };

        durationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }

                int duration = tempProfileManager.getTempProfileDuration();
                int hour = duration / 60;
                int min = duration % 60;

                int position1 = Utils.getItemPosition(listHour, hour + getString(R.string.hr));
                int position2 = Utils.getItemPosition(listMinute, min + getString(R.string.min));

                dialog = dialogUtils.createPickerDialog(getActivity(),
                        getString(R.string.duration), listHour, listMinute, null,
                        pickerManager, position1, position2, false, true);
                dialog.show();
            }
        });
    }

    private void setupTargetHighOnClickEvent() {
        final EventUtils.PickerManager picker = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
                targetHighRightTextView.setText(Utils.getGlucoseLevelString(
                        getActivity(),
                        selectedVal));

                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE attribute = TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH;
                tempProfileManager.setUsedAtLeastOnceForAttributeForProfileType(true, attribute, Temp);
                tempProfileManager.setThresholdForAttributeForProfileType(selectedVal, attribute, Temp);
            }
        };

        targetHighLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.high_target);

                int valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(Temp,
                        TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH);

                values = thresholdsController.getTargetHighValues(
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW),
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH));

                int position = thresholdsController.getPosition(valueToDisplay, values);
                showDialog(dialogTitle, values, picker,
                        position);
            }
        });
    }

    private void setupTargetLowOnClickEvent() {
        final EventUtils.PickerManager picker = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
                targetLowRightTextView.setText(Utils.getGlucoseLevelString(
                        getActivity(),
                        selectedVal));

                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE attribute = TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW;
                tempProfileManager.setUsedAtLeastOnceForAttributeForProfileType(true, attribute, Temp);
                tempProfileManager.setThresholdForAttributeForProfileType(selectedVal, attribute, Temp);
            }
        };

        targetLowLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.low_target);

                int valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(Temp,
                        TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW);

                values = thresholdsController.getTargetLowValues(
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH),
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW));

                int position = thresholdsController.getPosition(valueToDisplay, values);
                showDialog(dialogTitle, values, picker,
                        position);
            }
        });
    }

    private void setupAlarmHighOnClickEvent() {
        final EventUtils.PickerManager picker = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
                alarmHighRightTextView.setText(Utils.getGlucoseLevelString(
                        getActivity(),
                        selectedVal));

                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE attribute = TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH;
                tempProfileManager.setUsedAtLeastOnceForAttributeForProfileType(true, attribute, Temp);
                tempProfileManager.setThresholdForAttributeForProfileType(selectedVal, attribute, Temp);
            }
        };

        alarmHighLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.high_alert); /** #3214 */

                int valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(Temp,
                        TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH);

                values = thresholdsController.getAlarmHighValues(
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH));

                int position = thresholdsController.getPosition(valueToDisplay, values);
                showDialog(dialogTitle, values, picker,
                        position);
            }
        });
    }

    private void setupAlarmLowOnClickEvent() {
        final EventUtils.PickerManager picker = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                int selectedVal = dialogUtils.getGlucoseValueMg(values.get(id).getValue());
                alarmLowRightTextView.setText(Utils.getGlucoseLevelString(
                        getActivity(),
                        selectedVal));

                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE attribute = TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW;
                tempProfileManager.setUsedAtLeastOnceForAttributeForProfileType(true, attribute, Temp);
                tempProfileManager.setThresholdForAttributeForProfileType(selectedVal, attribute, Temp);
            }
        };

        alarmLowLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.low_alert); /** #3214 */

                int valueToDisplay = tempProfileManager.getThresholdForProfileTypeForAttribute(Temp,
                        TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW);

                values = thresholdsController.getAlarmLowValues(
                        tempProfileManager.getThresholdForProfileTypeForAttribute(
                                Temp,
                                TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW));

                int position = thresholdsController.getPosition(valueToDisplay, values);
                showDialog(dialogTitle, values, picker,
                        position);
            }
        });
    }
}
