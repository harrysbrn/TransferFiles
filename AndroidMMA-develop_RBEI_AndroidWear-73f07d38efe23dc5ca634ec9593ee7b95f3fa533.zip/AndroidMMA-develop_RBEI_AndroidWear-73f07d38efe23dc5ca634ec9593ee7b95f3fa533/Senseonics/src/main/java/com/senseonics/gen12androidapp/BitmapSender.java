package com.senseonics.gen12androidapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import javax.inject.Inject;

public class BitmapSender {
    @Inject
    public BitmapSender() {
    }

    public void sendBitmap(Activity activity, String title, String body, Uri uri) {
        Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, "");
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, title);
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, body);
        emailIntent.setType("application/image");
        emailIntent.putExtra(Intent.EXTRA_STREAM, uri);
        activity.startActivity(emailIntent);
    }
}
