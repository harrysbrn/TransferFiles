package com.senseonics.util;

import java.util.Calendar;
import java.util.TimeZone;

public class StaleDataChecker {
    boolean isStaleData = false;

    public StaleDataChecker(Calendar glucoseTimestamp, int samplingInterval) {
        if (glucoseTimestamp != null) {
            long glucoseTimestampInMilli = glucoseTimestamp.getTimeInMillis();
            Calendar currentTimeCal = Calendar.getInstance();
            currentTimeCal.setTimeZone(TimeZone.getTimeZone("GMT"));
            long currentTimestampInMilli = currentTimeCal.getTimeInMillis();

//            Log.i(this.getClass().getSimpleName(), "#3860 Diff seconds:" + ((glucoseTimestampInMilli / 1000) - ((currentTimestampInMilli / 1000) - (samplingInterval + 60))));

            if((glucoseTimestampInMilli / 1000) < (currentTimestampInMilli / 1000) - (samplingInterval + 60)) {
                isStaleData = true;
            }
        }
        else {
            isStaleData = true;
        }
    }

    public boolean isStaleData() {
//        Log.i(this.getClass().getSimpleName(), "#3860 isStaleData:" + this.isStaleData);
        return this.isStaleData;
    }
}
