package com.senseonics.graph;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.graph.util.GraphUtils.COLOR;
import com.senseonics.graph.util.WeeklyStatValue;
import com.senseonics.util.Convert;
import com.senseonics.util.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public class WeeklyStatGraph extends View {

	private int minX = 0, maxX = 420, interval = 20;
	private Paint centerPaint, simpleLinePaint, dashedLinePaint;
	private ArrayList<WeeklyStatValue> statValues;
	private int paddingBottom, paddingTop, graphHeight, graphBottom;
	private Rect textRect;
	private Bitmap avgStatBitmap;
	private Path path;
	private int INVALID_X_Y = -1;

	public WeeklyStatGraph(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
	}

	public WeeklyStatGraph(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public WeeklyStatGraph(Context context) {
		super(context);
	}

	public WeeklyStatGraph(Context context, Calendar currentCalendar,
			ArrayList<WeeklyStatValue> statValues) {
		super(context);
		centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		centerPaint.setTextAlign(Align.CENTER);
		centerPaint.setTextSize(getResources().getDimension(
				R.dimen.graph_large_text));
		centerPaint.setTypeface(Typeface.DEFAULT_BOLD);
		simpleLinePaint = new Paint();
		dashedLinePaint = new Paint();
		int dashSize = 20;
		dashedLinePaint.setStrokeWidth(8);
		dashedLinePaint.setStyle(Style.STROKE);
		dashedLinePaint.setPathEffect(new DashPathEffect(new float[]{
				dashSize, dashSize}, 1));
		path = new Path();

		this.statValues = statValues;

		for(WeeklyStatValue weeklyStatValue: statValues) {
			Log.i("Report debug", "avg:" + weeklyStatValue.getAvg());
		}

		avgStatBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.avg_simple);
		avgStatBitmap = Bitmap.createScaledBitmap(
				avgStatBitmap, 30, 30, true);
		textRect = GraphUtils.measureText(String.valueOf(maxX), centerPaint);
		paddingBottom = textRect.height() * 7 / 5;
		paddingTop = textRect.height() / 2;
		graphHeight = getHeight() - paddingBottom - paddingTop;
		graphBottom = getHeight() - paddingBottom;
	}

	private String setStartTimeTextView(int hour, int minute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		return Utils.getHour24HrFormat(calendar, TimeZone.getDefault(), getContext());
	}

	@Override
	protected void onDraw(Canvas canvas) {

		graphHeight = getHeight() - paddingBottom - paddingTop;
		graphBottom = getHeight() - paddingBottom;

		int linesCountHorizontal = (maxX - minX) / interval;
		int intervalOnScreen = graphHeight / linesCountHorizontal;

		int paddingRight = textRect.width() * 6 / 5;

		// Draw horizontal lines
		if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
			for (int i = 0; i <= linesCountHorizontal; ++i) {

				int y = i * interval;
				int screenY = i * intervalOnScreen;
				int positionY = graphBottom - screenY;

				if (y == 0 || y == 100 || y == 200 || y == 300 || y == 400) {
					canvas.drawText(String.valueOf(y), paddingRight / 2, positionY
							+ textRect.height() / 2, centerPaint);
					simpleLinePaint.setStrokeWidth(2);
					simpleLinePaint.setColor(getResources().getColor(R.color.black));
				} else {
					simpleLinePaint.setStrokeWidth(1);
					simpleLinePaint.setColor(getResources().getColor(R.color.light_gray));
				}
				canvas.drawLine(paddingRight, positionY, getWidth(), positionY,
						simpleLinePaint);
			}
		}
		else { // mmol/L
			linesCountHorizontal = (int)((maxX - minX) / Convert.kMmolToMg);
			intervalOnScreen = graphHeight / linesCountHorizontal;

			for (int i = 0; i <= linesCountHorizontal; ++i) {

				int y = (int)(i * Convert.kMmolToMg); //interval;
				int screenY = i * intervalOnScreen;
				int positionY = graphBottom - screenY;

				if (y == (int)(0 * Convert.kMmolToMg)
						|| y == (int)(5 * Convert.kMmolToMg)
						|| y == (int)(10 * Convert.kMmolToMg)
						|| y == (int)(15 * Convert.kMmolToMg)
						|| y == (int)(20 * Convert.kMmolToMg)) {
					canvas.drawText(String.valueOf(Math.round(Convert.MLConvertMgToMmol(y))), paddingRight / 2, positionY
							+ textRect.height() / 2, centerPaint);
					simpleLinePaint.setStrokeWidth(2);
					simpleLinePaint.setColor(getResources().getColor(R.color.black));
				} else {
					simpleLinePaint.setStrokeWidth(1);
					simpleLinePaint.setColor(getResources().getColor(R.color.light_gray));
				}
				canvas.drawLine(paddingRight, positionY, getWidth(), positionY,
						simpleLinePaint);
			}
		}

		// Draw level lines
		if (GraphUtils.glucoseLevels != null
				&& GraphUtils.glucoseLevels.size() > 0) {

			for (Map.Entry<Integer, COLOR> entry : GraphUtils.glucoseLevels
					.entrySet()) {
				int level = entry.getKey();
				if (level != GraphUtils.glucoseMinimumLevel
						&& level != GraphUtils.glucoseMaximumLevel) {
					float y = getPositionY(entry.getKey());

					int colorId = getResources().getColor(
							GraphUtils.getLineColorId(entry.getValue()));
					dashedLinePaint.setColor(colorId);

					path.reset();
					path.moveTo(paddingRight, y);

					// line
					path.lineTo(getWidth(), y);
					canvas.drawPath(path, dashedLinePaint);
				}
			}
		}

		// Draw vertical points
		int horizontalInterval = (getWidth() - paddingRight) / statValues.size();

		List<Point> points = new ArrayList<Point>();
		List<Point> pointsDrawStar = new ArrayList<Point>();
		List<Point> pointsLow = new ArrayList<Point>();
		List<Point> pointsHigh = new ArrayList<Point>();
		for (int j = 0; j < statValues.size(); ++j) {
			int positionX = paddingRight + (j * horizontalInterval)
					+ horizontalInterval / 2;
			MealTimeDataHandler mealTimeDataHandler = new MealTimeDataHandler(getContext());

			// draw ruler
			Paint rulerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			rulerPaint.setStrokeWidth(5);
			rulerPaint.setColor(getResources().getColor(R.color.black));


			switch (j) {
				case 0:
					canvas.drawText(setStartTimeTextView(0, 0), positionX, graphBottom + paddingBottom, centerPaint);
					canvas.drawLine(positionX, graphBottom, positionX, graphBottom - 8, rulerPaint);
					break;
				case 5:
					canvas.drawText(setStartTimeTextView(6,0), positionX, graphBottom + paddingBottom, centerPaint);
					canvas.drawLine(positionX, graphBottom, positionX, graphBottom - 8, rulerPaint);
					break;
				case 11:
					canvas.drawText(setStartTimeTextView(12,0), positionX, graphBottom + paddingBottom, centerPaint);
					canvas.drawLine(positionX, graphBottom, positionX, graphBottom - 8, rulerPaint);
					break;
				case 17:
					canvas.drawText(setStartTimeTextView(18,0), positionX, graphBottom + paddingBottom, centerPaint);
					canvas.drawLine(positionX, graphBottom, positionX, graphBottom - 8, rulerPaint);
					break;
				case 23:
					canvas.drawText(setStartTimeTextView(24,0), positionX-30, graphBottom + paddingBottom, centerPaint);
					canvas.drawLine(positionX, graphBottom, positionX, graphBottom - 8, rulerPaint);
					break;

			}

			if (statValues != null && j < statValues.size()
					&& statValues.get(j) != null) {
				// Draw avg value
				int avg = statValues.get(j).getAvg();
				int min = statValues.get(j).getMin();
				int max = statValues.get(j).getMax();
				if(avg != WeeklyStatValue.INVALID_AVG) {
					int thisX = positionX-(avgStatBitmap.getWidth() / 2);
					int thisY = (int)(getPositionY(avg) - avgStatBitmap.getHeight() / 2);
					pointsDrawStar.add(new Point(thisX, thisY));
					int thisYMin = (int)(getPositionY(min) - avgStatBitmap.getHeight() / 2);
					int thisYMax = (int)(getPositionY(max) - avgStatBitmap.getHeight() / 2);
					Log.i("Points:", "Avg:" + avg + "\nMin:" + min + "\nMax:" + max + "\nSize:" + statValues.size());
					thisX += avgStatBitmap.getWidth() / 2;
					thisY += avgStatBitmap.getHeight() / 2;
					thisYMin += avgStatBitmap.getHeight() / 2;
					thisYMax += avgStatBitmap.getHeight() / 2;

					points.add(new Point(thisX, thisY));
					pointsLow.add(new Point(thisX, thisYMin));
					pointsHigh.add(new Point(thisX, thisYMax));

				}
				else {
					points.add(new Point(INVALID_X_Y, INVALID_X_Y));
				}
			}
		}
		if (pointsHigh.size() > 0 && pointsLow.size() >0) {

			Paint connectLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			connectLinePaint.setStrokeWidth(20);
			connectLinePaint.setColor(getResources().getColor(R.color.graph_red));
			connectLinePaint.setAlpha(180);

			for(int i = 0; i< pointsHigh.size(); i++) {
				Point thisPt = pointsLow.get(i);
				Point nextPt = pointsHigh.get(i);
				if(isValidPoint(thisPt) && isValidPoint(nextPt)) {
					canvas.drawLine(thisPt.x, thisPt.y, nextPt.x, nextPt.y, connectLinePaint);
				}
			}
		}


		if (points.size() > 0) {

			Paint connectLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			connectLinePaint.setStrokeWidth(10);
			connectLinePaint.setColor(getResources().getColor(R.color.graph_blue));

			for(int i = 0; i< points.size()-1; i++) {
				Point thisPt = points.get(i);
				Point nextPt = points.get(i+1);
				if(isValidPoint(thisPt) && isValidPoint(nextPt)) {
					canvas.drawLine(thisPt.x, thisPt.y, nextPt.x, nextPt.y, connectLinePaint);
				}
			}

		}

		if (pointsDrawStar.size() > 0) {

			Paint bitmapPaint = new Paint();
			bitmapPaint.setColorFilter(new PorterDuffColorFilter(getResources().getColor(R.color.graph_blue), PorterDuff.Mode.SRC_IN));
			for (int i = 0; i < pointsDrawStar.size(); i++) {
				Point thisPt = pointsDrawStar.get(i);
				canvas.drawBitmap(avgStatBitmap, thisPt.x, thisPt.y, bitmapPaint);//centerPaint);
			}
		}


		// draw the vertical Y axis
		simpleLinePaint.setStrokeWidth(2);
		simpleLinePaint.setColor(getResources().getColor(R.color.black));
		canvas.drawLine(paddingRight, graphBottom, paddingRight, paddingTop,
				simpleLinePaint);

		super.onDraw(canvas);
	}

	private boolean isValidPoint(Point pt) {
		if (pt.x != INVALID_X_Y && pt.y != INVALID_X_Y) {
			return true;
		}

		return false;
	}

	public float getPositionY(int value) {
		return graphBottom - graphHeight / (float) (maxX - minX) * value;
	}

	public String formatDate(Calendar calendar) {
		return (String) DateFormat.format("MM/dd", calendar);
	}
}
