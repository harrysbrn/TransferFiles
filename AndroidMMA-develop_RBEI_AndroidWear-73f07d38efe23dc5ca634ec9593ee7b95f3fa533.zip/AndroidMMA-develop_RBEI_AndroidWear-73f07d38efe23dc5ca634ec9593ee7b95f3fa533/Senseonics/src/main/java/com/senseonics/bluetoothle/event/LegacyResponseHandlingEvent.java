package com.senseonics.bluetoothle.event;

import com.google.common.base.Objects;
import com.senseonics.bluetoothle.HexHelper;

public class LegacyResponseHandlingEvent {
    private final int actualResponseId;
    private int[] data;

    public LegacyResponseHandlingEvent(int[] data) {
        this.data = data;
        actualResponseId = data[0];
    }

    public int[] getData() {
        return data;
    }

    public int actualResponseId() {
        return actualResponseId;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("actualResponseId", actualResponseId)
                .add("data", HexHelper.intArrayToString(data))
                .toString();
    }
}
