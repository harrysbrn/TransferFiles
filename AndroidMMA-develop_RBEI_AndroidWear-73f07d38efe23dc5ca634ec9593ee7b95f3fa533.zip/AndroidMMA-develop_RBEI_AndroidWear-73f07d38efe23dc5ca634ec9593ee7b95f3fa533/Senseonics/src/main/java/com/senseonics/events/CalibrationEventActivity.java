package com.senseonics.events;

import android.os.Bundle;
import android.view.View;

import com.senseonics.gen12androidapp.R;

public class CalibrationEventActivity extends GlucoseEventActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Set navigation bar title
		naviBarTitle.setText(R.string.calibration);

		this.hasSaveButton = false;

		// Hide the bottom layout (Hide and Save)
		findViewById(R.id.bottomLayout).setVisibility(View.GONE);
	}
}
