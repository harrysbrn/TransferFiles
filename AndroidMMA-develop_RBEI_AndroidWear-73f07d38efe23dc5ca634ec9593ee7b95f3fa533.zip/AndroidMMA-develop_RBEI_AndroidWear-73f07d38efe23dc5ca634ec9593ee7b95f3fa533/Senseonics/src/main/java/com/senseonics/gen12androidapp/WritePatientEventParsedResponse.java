package com.senseonics.gen12androidapp;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;
import com.senseonics.model.ParsedResponse;
import com.senseonics.model.SyncModel;
import com.senseonics.model.TransmitterStateModel;

import java.util.ArrayList;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class WritePatientEventParsedResponse implements ParsedResponse {
    private DatabaseManager databaseManager;
    private SyncModel syncModel;
    private EventBus eventBus;

    @Inject
    public WritePatientEventParsedResponse(DatabaseManager databaseManager, SyncModel syncModel, EventBus eventBus) {
        this.databaseManager = databaseManager;
        this.syncModel = syncModel;
        this.eventBus = eventBus;
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.WritePatientEventResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isWritePatientEventResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        ArrayList<EventPoint> patientEventPoints = BluetoothPairBaseActivity.patientEventPoints;
        if (patientEventPoints != null && patientEventPoints.size() > 0) {
            EventPoint eventPoint = patientEventPoints.get(0);
            eventPoint.setEventSynced(true);
            databaseManager.updateEvent(eventPoint);
            patientEventPoints.remove(0);
        }
    }
}
