package com.senseonics.util;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.Log;
import android.view.View;

import com.senseonics.gen12androidapp.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class BitmapFileUtil {

    @Inject
    public BitmapFileUtil() {
    }

    public boolean moveFile(String sourcePath, String destinationPath) throws IOException {
        FileChannel inChannel = new FileInputStream(sourcePath).getChannel();
        FileChannel outChannel = new FileOutputStream(destinationPath).getChannel();
        inChannel.transferTo(0, inChannel.size(), outChannel);
        inChannel.close();
        outChannel.close();
        return new File(destinationPath).exists() && new File(sourcePath).delete();
    }

    public boolean saveBitmapOfView(View contentLayout, String filePath) {
        if ((contentLayout.getMeasuredWidth() > 0 && contentLayout.getMeasuredHeight() > 0)) {
            Bitmap bitmap = Bitmap.createBitmap(contentLayout.getMeasuredWidth(), contentLayout.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(contentLayout.getResources().getColor(R.color.gray_bg));
            contentLayout.draw(canvas);
            try {
                saveImage(bitmap, filePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        } else
            return false;
    }

    private void saveImage(Bitmap bitmap, String filePath) throws IOException {
        File file = new File(filePath);
        file.delete();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 40, bytes);

        Log.i("Bitmap", "FileDir:" + filePath);

        file = new File(filePath);
        file.createNewFile();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(bytes.toByteArray());
        fileOutputStream.close();
    }
}