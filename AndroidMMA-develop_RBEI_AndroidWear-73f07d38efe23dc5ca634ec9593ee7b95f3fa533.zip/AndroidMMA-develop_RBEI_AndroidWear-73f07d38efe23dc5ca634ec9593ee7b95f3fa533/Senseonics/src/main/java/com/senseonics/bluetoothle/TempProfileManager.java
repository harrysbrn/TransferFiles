package com.senseonics.bluetoothle;

import android.content.Context;
import android.util.Log;

import com.senseonics.events.ModelChangedHighAlarmThresholdEvent;
import com.senseonics.events.ModelChangedHighTargetThresholdEvent;
import com.senseonics.events.ModelChangedLowAlarmThresholdEvent;
import com.senseonics.events.ModelChangedLowTargetThresholdEvent;
import com.senseonics.events.TempProfileTurnedOffEvent;
import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.gen12androidapp.R;
import com.senseonics.model.TempProfileModel.GlucoseProfile;
import com.senseonics.model.TransmitterStateModel;
import com.senseonics.util.NotificationUtility;
import com.senseonics.util.PreferenceObjectSaverRetriver;
import com.senseonics.util.Utils;

import java.util.Calendar;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class TempProfileManager { /** #3160 */
    public static final int TEMP_PROFILE_DURATION_DEFAULT_VALUE = 30;
    public static final int TEMP_PROFILE_EXPIRE_SECONDS = -1;
    public static final int DURATION_MIN_HOUR = 0; // 0 hour
    public static final int DURATION_MAX_HOUR = 36; // 36 hours
    public static final int DURATION_MINUTE_OPTION_0 = 0; // 0 min
    public static final int DURATION_MINUTE_OPTION_1 = 30; // 30 mins

    public enum GLUCOSE_PROFILE_ATTRIBUTE {
        GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH,
        GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW,
        GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH,
        GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW
    }

    public enum GLUCOSE_PROFILE_TYPE {
        GLUCOSE_PROFILE_TYPE_NON_TEMP,
        GLUCOSE_PROFILE_TYPE_TEMP
    }

    public enum TEMP_PROFILE_STATUS {
        TEMP_PROFILE_STATUS_ALREADY_DISABLED,
        TEMP_PROFILE_STATUS_NEED_TO_DISABLE,
        TEMP_PROFILE_STATUS_IN_PROGRESS
    }

    private final String TAG = TempProfileManager.class.getSimpleName();
    private final String NonTempGlucoseProfilePref = "prefNonTempGlucoseProfile";
    private final String TempGlucoseProfilePref = "prefTempGlucoseProfile";
    private final String TempProfileEnabledPref = "prefTempProfileEnabled";
    private final String TempProfileUsedAtLeastOncePref = "prefTempProfileUsedAtLeastOnce";
    private final String TempProfileDurationPref = "prefTempProfileDuration";
    private final String TempProfileLastStartOnPref = "prefTempProfileLastStartOn";
    private final String TempProfileHasPendingPopupPref = "prefTempProfileHasPendingPopup";

    private Context context;
    private PreferenceObjectSaverRetriver preferenceObjectSaverRetriver;
    private TransmitterStateModel transmitterStateModel;
    private BluetoothServiceCommandClient bluetoothServiceCommandClient;
    private EventBus eventBus;
    private NotificationUtility notificationUtility;
    private ApplicationForegroundState applicationForegroundState;

    @Inject
    public TempProfileManager(Context context, PreferenceObjectSaverRetriver preferenceObjectSaverRetriver, TransmitterStateModel transmitterStateModel, BluetoothServiceCommandClient bluetoothServiceCommandClient, NotificationUtility notificationUtility, ApplicationForegroundState applicationForegroundState, EventBus eventBus) {
        this.context = context;
        this.preferenceObjectSaverRetriver = preferenceObjectSaverRetriver;
        this.transmitterStateModel = transmitterStateModel;
        this.bluetoothServiceCommandClient = bluetoothServiceCommandClient;
        this.notificationUtility = notificationUtility;
        this.applicationForegroundState = applicationForegroundState;
        this.eventBus = eventBus;
        this.eventBus.register(this);

        if (getNonTempGlucoseProfile() == null) {
            setNonTempGlucoseProfile(new GlucoseProfile());
        }

        if (getTempGlucoseProfile() == null) {
            setTempGlucoseProfile(new GlucoseProfile());
        }

        if (getTempProfileDuration() == 0) {
            setTempProfileDuration(TEMP_PROFILE_DURATION_DEFAULT_VALUE);
        }
    }

    private GlucoseProfile getTempGlucoseProfile() {
        GlucoseProfile profile = preferenceObjectSaverRetriver.retrieveGlucoseProfileFromPreference(TempGlucoseProfilePref);
        return profile;
    }

    private void setTempGlucoseProfile(GlucoseProfile profile) {
        preferenceObjectSaverRetriver.saveGlucoseProfileIntoPreference(TempGlucoseProfilePref, profile);
    }

    private GlucoseProfile getNonTempGlucoseProfile() {
        GlucoseProfile profile = preferenceObjectSaverRetriver.retrieveGlucoseProfileFromPreference(NonTempGlucoseProfilePref);
        return profile;
    }

    private void setNonTempGlucoseProfile(GlucoseProfile profile) {
        preferenceObjectSaverRetriver.saveGlucoseProfileIntoPreference(NonTempGlucoseProfilePref, profile);
    }

    public Boolean getTempProfileEnabled() {
        Boolean value = Utils.getSettingsBoolean(context, TempProfileEnabledPref);
//        Log.d(TAG, "getTempProfileEnabled:" + value);
        return value;
    }

    public void setTempProfileEnabled(Boolean value) {
        Log.d(TAG, "setTempProfileEnabled:" + value);
        Utils.saveSettings(context, TempProfileEnabledPref, value);
    }

    public Boolean getTempProfileUsedAtLeastOnce() {
        Boolean value = Utils.getSettingsBoolean(context, TempProfileUsedAtLeastOncePref);
        Log.d(TAG, "getTempProfileUsedAtLeastOnce:" + value);
        return value;
    }

    public void setTempProfileUsedAtLeastOnce(Boolean value) {
        Log.d(TAG, "setTempProfileUsedAtLeastOnce:" + value);
        Utils.saveSettings(context, TempProfileUsedAtLeastOncePref, value);
    }

    public int getTempProfileDuration() {
        int value = Utils.getSettingsIntValueForKey(context, TempProfileDurationPref, 0);
        Log.d(TAG, "getTempProfileDuration:" + value);
        return value;
    }

    public void setTempProfileDuration(int value) {
        Log.d(TAG, "setTempProfileDuration:" + value);
        Utils.saveSettings(context, TempProfileDurationPref, value);
    }

    public long getTempProfileLastStartOn() {
        long value = Utils.getSettingsForLong(context, TempProfileLastStartOnPref);
        Log.d(TAG, "getTempProfileLastStartOn:" + value);
        return value;
    }

    public void setTempProfileLastStartOn(long value) {
        Log.d(TAG, "setTempProfileLastStartOn:" + value);
        Utils.saveSettings(context, TempProfileLastStartOnPref, value);
    }

    public boolean getTempProfileHasPendingPopup() {
        boolean value = Utils.getSettingsBoolean(context, TempProfileHasPendingPopupPref);
        Log.d(TAG, "getTempProfileHasPendingPopup:" + value);
        return value;
    }

    public void setTempProfileHasPendingPopup(boolean value) {
        Log.d(TAG, "setTempProfileHasPendingPopup:" + value);
        Utils.saveSettings(context, TempProfileHasPendingPopupPref, value);
    }

    /** NO interaction with preferences */

    public String tempProfileToString() {
        return getTempGlucoseProfile().toString();
    }

    public String nonTempProfileToString() {
        return getNonTempGlucoseProfile().toString();
    }

    private String getNameForAttribute(GLUCOSE_PROFILE_ATTRIBUTE attribute) {
        String retValue = "";

        switch (attribute) {
            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH:
                retValue = "\"Target High\"";
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW:
                retValue = "\"Target Low\"";
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH:
                retValue = "\"Alarm High\"";
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW:
                retValue = "\"Alarm Low\"";
                break;

            default:
                break;
        }

        return retValue;
    }

    private GlucoseProfile getProfileByType(GLUCOSE_PROFILE_TYPE type) {
        GlucoseProfile profile = null;

        switch (type) {
            case GLUCOSE_PROFILE_TYPE_NON_TEMP:
                profile = getNonTempGlucoseProfile();
                break;

            case GLUCOSE_PROFILE_TYPE_TEMP:
                profile = getTempGlucoseProfile();
                break;

            default:
                break;
        }

        return profile;
    }

    private void setProfileByType(GlucoseProfile profile, GLUCOSE_PROFILE_TYPE type) {
        switch (type) {
            case GLUCOSE_PROFILE_TYPE_NON_TEMP:
                setNonTempGlucoseProfile(profile);
                break;

            case GLUCOSE_PROFILE_TYPE_TEMP:
                setTempGlucoseProfile(profile);
                break;

            default:
                break;
        }
    }

    public int getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE type, GLUCOSE_PROFILE_ATTRIBUTE attribute) {
        int retValue = 0;

        GlucoseProfile profile = getProfileByType(type);

        if (profile != null) {
            switch (attribute) {
                case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH:
                    retValue = profile.getTargetHigh();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW:
                    retValue = profile.getTargetLow();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH:
                    retValue = profile.getAlarmHigh();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW:
                    retValue = profile.getAlarmLow();
                    break;

                default:
                    break;
            }
        }

        return retValue;
    }

    public void setThresholdForAttributeForProfileType(int value, GLUCOSE_PROFILE_ATTRIBUTE attribute, GLUCOSE_PROFILE_TYPE type) {
        GlucoseProfile profile = getProfileByType(type);

        if (profile == null) {
            Log.d(TAG, "PANIC: getProfileByType returned NULL");
            return;
        }

        switch (attribute) {
            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH:
                profile.setTargetHigh(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW:
                profile.setTargetLow(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH:
                profile.setAlarmHigh(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW:
                profile.setAlarmLow(value);
                break;

            default:
                break;
        }

        // Save to disk
        setProfileByType(profile, type);
    }

    private boolean getUsedAtLeastOnceForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE type, GLUCOSE_PROFILE_ATTRIBUTE attribute) {
        Boolean retValue = false;

        GlucoseProfile profile = getProfileByType(type);

        if (profile != null) {
            switch (attribute) {
                case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH:
                    retValue = profile.isUsedAtLeastOnce_TargetHigh();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW:
                    retValue = profile.isUsedAtLeastOnce_TargetLow();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH:
                    retValue = profile.isUsedAtLeastOnce_AlarmHigh();
                    break;

                case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW:
                    retValue = profile.isUsedAtLeastOnce_AlarmLow();
                    break;

                default:
                    break;
            }
        }

        return retValue;
    }

    public void setUsedAtLeastOnceForAttributeForProfileType(boolean value, GLUCOSE_PROFILE_ATTRIBUTE attribute, GLUCOSE_PROFILE_TYPE type) {
        GlucoseProfile profile = getProfileByType(type);

        if (profile == null) {
            Log.d(TAG, "PANIC: getProfileByType returned NULL");
            return;
        }

        switch (attribute) {
            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH:
                profile.setUsedAtLeastOnce_TargetHigh(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW:
                profile.setUsedAtLeastOnce_TargetLow(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH:
                profile.setUsedAtLeastOnce_AlarmHigh(value);
                break;

            case GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW:
                profile.setUsedAtLeastOnce_AlarmLow(value);
                break;

            default:
                break;
        }

        // Save to disk
        setProfileByType(profile, type);
    }

    private boolean hasValidThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE type, GLUCOSE_PROFILE_ATTRIBUTE attribute) {
        int threshold = getThresholdForProfileTypeForAttribute(type, attribute);

        if (threshold == GlucoseProfile.TEMP_PROFILE_THRESHOLD_INIT_VALUE) {
            return false;
        }

        return true;
    }

    public void updateGlucoseProfileUponTransmitterStateUpdatedForAttributeWithValue(GLUCOSE_PROFILE_ATTRIBUTE attribute, int value)
    {
        if (getTempProfileEnabled() == false) // if temp profile is disabled
        {
            Log.d(TAG, "Set NonTemp Condition I: " + getNameForAttribute(attribute) + " -> " + value);
            setThresholdForAttributeForProfileType(value, attribute, GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP);
        }

        if (hasValidThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, attribute) == false) // no valid temp value
        {
            Log.d(TAG, "Set Temp Condition A: " + getNameForAttribute(attribute) + "  -> " + value);
            setThresholdForAttributeForProfileType(value, attribute, GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP);
        }
        else if (getTempProfileEnabled() == true) // temp profile is enabled
        {
            // check if the incoming value EQUALs stored temp value => might be a different transmitter
            int storedValue = getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, attribute);

            if (storedValue != value) {
                Log.d(TAG, "PANIC: inconsistent value => disable : " + getNameForAttribute(attribute) + " -> " + value);
                setTempProfileEnabled(false);
                setTempProfileLastStartOn(0L);
                setGlucoseProfileToStateValue(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP);
                postTempProfileTurnedOffEvent();
            }
            else {
                // Not needed when same value
                Log.d(TAG, "Set Temp Condition B: " + getNameForAttribute(attribute) + " -> " + value);
                setThresholdForAttributeForProfileType(value, attribute, GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP);
            }
        }
        else if (getTempProfileUsedAtLeastOnce() == false) // never used
        {
            if (getUsedAtLeastOnceForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP, attribute) == false) // & never set by the user manually
            {
                Log.d(TAG, "Set Temp Condition C: " + getNameForAttribute(attribute) + " -> " + value);
                setThresholdForAttributeForProfileType(value, attribute, GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP);
            }
        }
    }

    private void setGlucoseProfileToStateValue(GLUCOSE_PROFILE_TYPE type) {
        GlucoseProfile profile = getProfileByType(type);

        if (profile == null) {
            Log.d(TAG, "PANIC: getProfileByType returned NULL");
            return;
        }

        // set to the state copy values
        setThresholdForAttributeForProfileType(transmitterStateModel.getHighGlucoseTarget(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH, type);
        Log.d(TAG, "Set NonTemp Condition II: " + getNameForAttribute(GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH) + " -> " + transmitterStateModel.getHighGlucoseTarget());

        setThresholdForAttributeForProfileType(transmitterStateModel.getLowGlucoseTarget(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW, type);
        Log.d(TAG, "Set NonTemp Condition II: " + getNameForAttribute(GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW) + " -> " + transmitterStateModel.getLowGlucoseTarget());

        setThresholdForAttributeForProfileType(transmitterStateModel.getHighGlucoseAlarmThreshold(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH, type);
        Log.d(TAG, "Set NonTemp Condition II: " + getNameForAttribute(GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH) + " -> " + transmitterStateModel.getHighGlucoseAlarmThreshold());

        setThresholdForAttributeForProfileType(transmitterStateModel.getLowGlucoseAlarmThreshold(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW, type);
        Log.d(TAG, "Set NonTemp Condition II: " + getNameForAttribute(GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW) + " -> " + transmitterStateModel.getLowGlucoseAlarmThreshold());
    }

    private void restoreOneGlucoseProfileToStateValue(GLUCOSE_PROFILE_TYPE type) {
        GlucoseProfile profile = getProfileByType(type);

        if (profile == null) {
            Log.d(TAG, "PANIC: getProfileByType returned NULL");
            return;
        }

        if (profile.hasInitialValues()) {
            // Restore to state copy values
            setThresholdForAttributeForProfileType(transmitterStateModel.getHighGlucoseTarget(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH, type);
            setThresholdForAttributeForProfileType(transmitterStateModel.getLowGlucoseTarget(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW, type);
            setThresholdForAttributeForProfileType(transmitterStateModel.getHighGlucoseAlarmThreshold(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH, type);
            setThresholdForAttributeForProfileType(transmitterStateModel.getLowGlucoseAlarmThreshold(), GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW, type);
        }
    }

    public void restoreAllGlucoseProfilesToStateValueIfNeeded() {
        restoreOneGlucoseProfileToStateValue(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP);
        restoreOneGlucoseProfileToStateValue(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_TEMP);
    }

    public void writeTargetThresholdLow(int value) {
        bluetoothServiceCommandClient.postWriteLowGlucoseTargetRequest(value);
    }

    public void writeTargetThresholdHigh(int value) {
        bluetoothServiceCommandClient.postWriteHighGlucoseTarget(value);
    }

    public void writeAlarmThresholdLow(int value) {
        bluetoothServiceCommandClient.postWriteLowGlucoseAlarmRequest(value);
    }

    public void writeAlarmThresholdHigh(int value) {
        bluetoothServiceCommandClient.postWriteHighGlucoseAlarmRequest(value);
    }

    public void onEvent(ModelChangedLowTargetThresholdEvent event) {
        Log.d(TAG, "ModelChangedLowTargetThresholdEvent:" + event.getNewValue());
        updateGlucoseProfileUponTransmitterStateUpdatedForAttributeWithValue(TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW, event.getNewValue());
    }

    public void onEvent(ModelChangedHighTargetThresholdEvent event) {
        Log.d(TAG, "ModelChangedHighTargetThresholdEvent:" + event.getNewValue());
        updateGlucoseProfileUponTransmitterStateUpdatedForAttributeWithValue(TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH, event.getNewValue());
    }

    public void onEvent(ModelChangedLowAlarmThresholdEvent event) {
        Log.d(TAG, "ModelChangedLowAlarmThresholdEvent:" + event.getNewValue());
        updateGlucoseProfileUponTransmitterStateUpdatedForAttributeWithValue(TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW, event.getNewValue());
    }

    public void onEvent(ModelChangedHighAlarmThresholdEvent event) {
        Log.d(TAG, "ModelChangedHighAlarmThresholdEvent:" + event.getNewValue());
        updateGlucoseProfileUponTransmitterStateUpdatedForAttributeWithValue(TempProfileManager.GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH, event.getNewValue());
    }

    public void startTempProfile(int lowTarget, int highTarget, int lowAlarm, int highAlarm) {
        if ((getTempProfileUsedAtLeastOnce() == true) &&
                (getTempProfileEnabled() == true) &&
                (getTempProfileLastStartOn() != 0L))
        {
            Log.d(TAG, "PANIC: startTempProfile: already turned on");
            return;
        }

        setTempProfileUsedAtLeastOnce(true); // only set when START

        setTempProfileEnabled(true);
        setTempProfileLastStartOn(Calendar.getInstance().getTimeInMillis());

        // write temp to Tx: assume all successful
        writeTargetThresholdLow(lowTarget);
        writeTargetThresholdHigh(highTarget);
        writeAlarmThresholdLow(lowAlarm);
        writeAlarmThresholdHigh(highAlarm);
    }

    public void stopTempProfile() {

        if ((getTempProfileEnabled() == false) &&
                (getTempProfileLastStartOn() == 0L))
        {
            Log.d(TAG, "PANIC: stopTempProfile: already turned off");
            return;
        }

        setTempProfileEnabled(false);
        setTempProfileLastStartOn(0L);

        // write non-temp to Tx
        writeTargetThresholdLow(getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP, GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_LOW));
        writeTargetThresholdHigh(getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP, GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_TARGET_HIGH));
        writeAlarmThresholdLow(getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP, GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_LOW));
        writeAlarmThresholdHigh(getThresholdForProfileTypeForAttribute(GLUCOSE_PROFILE_TYPE.GLUCOSE_PROFILE_TYPE_NON_TEMP, GLUCOSE_PROFILE_ATTRIBUTE.GLUCOSE_PROFILE_ATTRIBUTE_ALARM_HIGH));
    }

    public long getTempProfileRemainingTime() {
        long retValue = 0L;

        TEMP_PROFILE_STATUS status = getTempProfileStatus();

        if (status == TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_IN_PROGRESS) {
            long lastEnabledTime = getTempProfileLastStartOn();
            long dateNow = Calendar.getInstance().getTimeInMillis();
            long secondsDiff = (dateNow - lastEnabledTime) / 1000;
            long durationInSeconds = getTempProfileDuration() * 60;

            retValue = durationInSeconds - secondsDiff;

            if (retValue < 0) { // might not come here
                retValue = TEMP_PROFILE_EXPIRE_SECONDS;
            }
        }
        else if (status == TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_NEED_TO_DISABLE) {
            retValue = TEMP_PROFILE_EXPIRE_SECONDS;
        }

        Log.d(TAG, "getTempProfileRemainingTime: " + status + " -> " + retValue);

        return retValue;
    }

    public TEMP_PROFILE_STATUS getTempProfileStatus() {
        TEMP_PROFILE_STATUS status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_ALREADY_DISABLED;

        if (getTempProfileEnabled() == true) {
            long lastEnabledTime = getTempProfileLastStartOn();

            if (lastEnabledTime == 0L) {
                Log.d(TAG, "***** PANIC 1: no Last Enabled Time *****");
                status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_NEED_TO_DISABLE;
            }
            else {
                long dateNow = Calendar.getInstance().getTimeInMillis();
                long secondsDiff = (dateNow - lastEnabledTime) / 1000;
                Log.d(TAG, ">> Temp Profile Enabled secondsDiff: " + secondsDiff + " <<");
                long durationInSeconds = getTempProfileDuration() * 60;

                if (secondsDiff < 0) {
                    Log.d(TAG, "***** PANIC 2: invalid Last Enabled Time *****");
                    status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_NEED_TO_DISABLE;
                }
                else if (secondsDiff < durationInSeconds) {
                    status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_IN_PROGRESS;
                }
                else {
                    Log.d(TAG, "***** PANIC 3: Expired *****");
                    status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_NEED_TO_DISABLE;
                }
            }
        }
        else {
            status = TEMP_PROFILE_STATUS.TEMP_PROFILE_STATUS_ALREADY_DISABLED;
        }

        return status;
    }

    public void turnOffTempProfileIfNeeded() {
        long secsLeft = getTempProfileRemainingTime();
        Log.d(TAG, "turnOffTempProfileIfNeeded seconds left: " + secsLeft);
        if (secsLeft == TEMP_PROFILE_EXPIRE_SECONDS) {
            if (transmitterStateModel.isTransmitterConnected() == true) {
                Log.d(TAG, ">>>>>> turnOffTempProfileIfNeeded: turn off <<<<<<");
                stopTempProfile();
                postTempProfileTurnedOffEvent();
            }
        }
    }

    public String formatTempProfileTimeLeftGivenSeconds(long secondsLeft) {
        long totalMinsLeft = secondsLeft / 60;

        if (totalMinsLeft < 1) {
            totalMinsLeft = 1;
        }

        int minLeft = (int)(totalMinsLeft % 60);
        int hourLeft = (int)(totalMinsLeft / 60);

        String retVal = context.getResources().getString(R.string.temp_profile_time_left, hourLeft, minLeft);

        return retVal;
    }

    public void eventBusPostTempOffEvent() {
        Log.d(TAG, "****** eventBusPostTempOffEvent: not bounded?" + !applicationForegroundState.isForeground());

        if (eventBus != null) {
            eventBus.post(new TempProfileTurnedOffEvent());
        }
    }

    private void postTempProfileTurnedOffEvent() {
        Log.d(TAG, "****** postTempProfileTurnedOffEvent: not bounded?" + !applicationForegroundState.isForeground());

        if (!applicationForegroundState.isForeground()) {
            setTempProfileHasPendingPopup(true);
            // set local notification
            notificationUtility.createTempProfileTurnedOffNotification();
        } else {
            eventBusPostTempOffEvent();
        }
    }

}
