package com.senseonics.util;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.events.AlertEventActivity;
import com.senseonics.events.CalibrationEventActivity;
import com.senseonics.events.CalibrationEventPoint;
import com.senseonics.events.EventPoint;
import com.senseonics.events.ExerciseEventActivity;
import com.senseonics.events.GlucoseEventActivity;
import com.senseonics.events.HealthEventActivity;
import com.senseonics.events.InsulinEventActivity;
import com.senseonics.events.MealEventActivity;
import com.senseonics.events.NotificationEventActivity;
import com.senseonics.gen12androidapp.BluetoothServiceCommandClient;
import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.model.BATTERY_LEVEL;
import com.senseonics.model.SIGNAL_STRENGTH;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class Utils {
    public static int LOG_OUT_BACK_RESULT = 4010;
    public static int TAP_HEADER_BACK_RESULT = 3010;
    public static int WELCOME_UNIT_SELECTION_RESULT = 5010;
    public static int DAILY_CALIBRATION_SAVE_RESULT = 6010;
    public static String VERSION_RELEASE_DATE = "04/15/2014"; // * this is updated in Teamcity

    public static int ADD_EDIT_EVENT_MAX_DAYS_AGO = 30;
    public static int kNumberOfDaysToFetch = 3;
    public static int kNumberOfDaysMax = 90; // #2978 Restrict fetching from database to 90 days

    // Diagnostic output switch
    public static boolean showToast = false;//true;

    public static int screenWidth, screenHeight;
    public static float daySubviewWidth = -1;
    public static Calendar currentDate, endDateFinished;
    public static Calendar startDate, endDate, threeDaysAgo;
    public static int daysCount = 60;
    public static int DAYS_TO_FETCH_FOR_SYNC = 3;
    public static int NO_OF_EVENTS_TO_SYNC = 15*DAYS_TO_FETCH_FOR_SYNC;
    public static int NO_OF_ALARMS_TO_SYNC = 20*DAYS_TO_FETCH_FOR_SYNC;

    // Link sensor server
    public static String calibrationServer = "https://sensordataserver.s4ms.com/CalibrationServer9/CalibrationService.svc"; /** #3272 */
    public static String webserviceFunction = "http://tempuri.org/ITransferService/FetchCalibrationDataWithChecksum";
    public static String kAppFWCompatibilityCheckWebserviceFunctionCall = "http://tempuri.org/ITransferService/AppFWCompatibilityCheck"; /** #3272 */

    public static String URL_EULA = "https://intranet.senseonics.com/SE/EULA/";
    public static String URL_IFU = "https://intranet.senseonics.com/SE/IFU/";
    public static String URL_FAQ = "https://intranet.senseonics.com/SE/FAQ/";
    public static String URL_PRIVACY = "https://intranet.senseonics.com/SE/Privacy/";
    public static String INTRANET_UN = "SensorsGuest";
    public static String INTRANET_PW = "smsi";

    public static final long unlinkedSensorValue = 0xFFFFFFFFL;

    public static String BATTERY_EVENT_TAG = "BATTERY";

    // Synchronizing
    public static long SYNC_PERIOD_MILLISECONDS = TimeUnit.MINUTES.toMillis(3);
    public static long AUTOMATIC_SYNC_ON_PUSH_INTERVAL = TimeUnit.MINUTES.toMillis(60); /** Same as iOS app: automaticSyncOnPushInterval */

    public static int LAST_CALIBRATION_VALUE = 0;
    public static CALIBRATION_STATE calibrationState = CALIBRATION_STATE.REASON_UNKNOWN;

    public static int morningCalibrationHourDefaultLocal = 8,
            morningCalibrationMinuteDefault = 0;
    public static int eveningCalibrationHourDefaultLocal = 18,
            eveningCalibrationMinuteDefault = 0;

    public static int dayStartTimeHourDefaultLocal = 8, dayStartTimeMinuteDefault = 0;
    public static int nightStartTimeHourDefaultLocal = 20, nightStartTimeMinuteDefault = 0;

    public static String unknownString = "N/A";
    public static String unknownTime = "-";

    //SystemSettingsActivity - Debug Flag - Enable Disable Glucose Units.
    public static boolean enableGlucoseUnitPanel = false;

    // Calibration screen
    public static int GLUCOSE_DEFAULT_LEVEL = 100;
    // #2644 BG entry should be limited from 20 to 600 mg/dl (Android)
    public static int minBloodGlucose = 20, maxBloodGlucose = 600;
    public static Calendar nextScheduledCalibration;
    // #1513
    public static int minsBeforeNextCalibrationTime = -1;
    public static int minsAfterNextCalibrationTime = -1;
    public static int minutesRemainingUntilCalibrationAllowed = -1;

    public static int EVENT_POSITION = 20;
    public static int INT_MAX = 65535;
    public static int GLUCOSE_MIN_Y = 20;
    public static int GLUCOSE_MIN = 0;
    public static int GLUCOSE_MAX = 400;
    public static int GRAPH_GLUCOSE_MIN = 0;
    public static int GRAPH_GLUCOSE_MAX = 410;
    public static int GLUCOSE_VALID_MIN = 40;
    public static int GLUCOSE_VALID_MAX = 400;
    public static int STATISTICS_GLUCOSE_MIN = 40;
    public static int STATISTICS_GLUCOSE_MAX = 400;

    // Glucose Settings
    public static int GLUCOSE_TARGET_HIGH = 140;
    public static int GLUCOSE_TARGET_LOW = 80;
    public static int GLUCOSE_ALARM_LEVEL_HIGH = 200;
    public static int GLUCOSE_ALARM_LEVEL_LOW = 70;
    public static boolean predictiveAlertsActivated = false;
    public static int PREDICTIVE_MINUTES = 20;
    public static int DEFAULT_SYNC_DAYS = 1;
    public static boolean rateAlertsActivated = false;
    public static float RATE_VALUE = 2.5f;

    public static String SHARED_PREF = "SenseonicsPref";
    public final static String prefFirstRun = "firstRun";
    public final static String prefFirstRunForEULA = "firstRunForEULA";
    public final static String prefTargetHigh = "glucoseTargetHigh";
    public final static String prefTargetLow = "glucoseTargetLow";
    public final static String prefAlarmHigh = "glucoseAlarmHigh";
    public final static String prefAlarmLow = "glucoseAlarmLow";
    public final static String prefPredictiveAlertsActivated = "predictiveAlertsActivated";
    public final static String prefPredictiveMinutes = "predictiveMinutes";
    public final static String prefRateAlertsActivated = "rateAlertsActivated";
    public final static String prefRateValue = "rateAlertValue";
    public final static String prefLastSyncingMillis = "last_syncing_gmt_millis";

    public final static String prefExportDays = "defaultExportDays";
    public final static String prefNotificationSound = "NotificationSound";

    public final static String prefMorningCalHour = "MorningCalHour";
    public final static String prefMorningCalMinute = "MorningCalMinute";
    public final static String prefEveningCalHour = "EveningCalHour";
    public final static String prefEveningCalMinute = "EveningCalMinute";

    /** #4080 */
    public final static String prefMorningCalLocalHour = "MorningCalLocalHour";
    public final static String prefMorningCalLocalMinute = "MorningCalLocalMinute";
    public final static String prefEveningCalLocalHour = "EveningCalLocalHour";
    public final static String prefEveningCalLocalMinute = "EveningCalLocalMinute";

    public final static String prefCalibrationDateTime = "calibrationDateTime";

    // DMS Settings
    public final static String prefAccountUserName = "AccountUserName";
    public final static String prefAccountUserPassword = "AccountUserPassword";
    public final static String prefAccountUserID = "AccountUserID";
    public final static String prefAccountSyncDays = "AccountSyncDays";
    public final static String prefAccountMigrationPasswordUpdated = "AccountMigrationPasswordUpdated"; /** #3707 */
    public final static String prefAccountLastSyncedOnDateTime = "AccountLastSyncedOnDateTime";
    public final static String prefAccountLastSyncedStartDateTime = "AccountLastSyncedStartDateTime";
    public final static String prefAccountDiagnosticDataLastSyncedOnDateTime = "AccountDiagnosticDataLastSyncedOnDateTime";
    public final static String prefAccountSyncInterval = "AccountSyncInterval";
    public final static String prefAccountIsLoggedIn = "AccountIsLoggedIn";
    public final static String prefAccountEnableAutoSync = "AccountEnableAutoSync";

    public final static String prefAppUpdateLastCheckedDateTime = "AppUpdateLastCheckedDateTime";

    // Hysteresis
    public final static String prefHysteresisPercent = "HysteresisPercent";
    public final static String prefHysteresisValue = "HysteresisValue";
    public final static String prefHysteresisPredictivePercent = "HysteresisPredictivePercent";
    public final static String prefHysteresisPredictiveValue = "HysteresisPredictiveValue";

    // System settings
    public final static String prefGlucoseUnit = "currentGlucoseUnit";
    public static GLUCOSE_UNIT currentGlucoseUnit = GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL;

    public final static String pushNotificationFWBound = "5.12";
    public final static int pushNotificationDateTimeLength = 4;
    public final static int CRCLength = 2;

    public enum GLUCOSE_UNIT {
        GLUCOSE_UNIT_MG_DL, GLUCOSE_UNIT_MMOL_L
    }

    public static long clinicalModeDuration = 26 * 60 * 60 * 1000; // default 26 hours

    // This is the global alert code
    public static TransmitterMessageCode msgCodeForSnooze = TransmitterMessageCode.NumberOfMessages;


    public static int currentUnknownErrorCode = -1;
    // System Settings
    public final static String prefVibrationMode = "VibrationMode";

    public final static String prefClinicalMode = "ClinicalMode";
    public final static String prefClinicalModeDuration = "ClinicalModeDuration";

    public final static String prefClinicalModeStartTime = "ClinicalModeStartTime";

    public final static String prefTransmitterSerialNumber = "TransmitterSerialNumber";
    public final static String prefTransmitterName = "TransmitterName";
    public final static String prefTransmitterAddress = "TransmitterAddress";

    public final static String prefTransmitterModelNumber = "ModelNumber";
    public final static String prefTransmitterFirmwareVersion = "FirmwareVersion";
    public final static String prefTransmitterVersionExtensionNumber = "ExtensionNumber";
    public final static String prefTransmitterTime = "TransmitterTime";
    public final static String prefTransmitterLastCalibration = "LastCalibration";
    public final static String prefTransmitterCalibrationStartDate = "CalibrationStartDate";
    public final static String prefTransmitterCalibrationsMadeInThisPhase = "CalibrationsMadeInThisPhase";
    public final static String prefCurrentCalibrationPhase = "CurrentCalibrationPhase";
    public final static String prefTransmitterBatteryLevel = "TransmitterBatterylevel";
    public final static String prefSensorId = "SensorId";
    public final static String prefSensorInsertionDateTime = "SensorInsertionDateTime";
    public final static String prefUnlinkedSensorId = "UnlinkedSensorId";
    public final static String prefSamplingInterval = "prefSamplingInterval";
    public final static String prefAlgorithmParameterFormatVersion = "prefAlgorithmParameterFormatVersion";

    public final static String prefMEPSavedValue = "MEPSavedValue";
    public final static String prefMEPSavedRefChannelMetric = "MEPSavedRefChannelMetric";
    public final static String prefMEPSavedDriftMetric = "MEPSavedDriftMetric";
    public final static String prefMEPSavedLowRefMetric = "MEPSavedLowRefMetric";
    public final static String prefMEPSavedSpike = "MEPSavedSpike";
    public final static String prefEEP24MSP = "EEP24MSP";
    public final static String prefLowGlucoseAlarmRepeatIntervalDayTime = "LowGlucoseAlarmRepeatIntervalDayTime";
    public final static String prefHighGlucoseAlarmRepeatIntervalDayTime = "HighGlucoseAlarmRepeatIntervalDayTime";
    public final static String prefLowGlucoseAlarmRepeatIntervalNightTime = "LowGlucoseAlarmRepeatIntervalNightTime";
    public final static String prefHighGlucoseAlarmRepeatIntervalNightTime = "HighGlucoseAlarmRepeatIntervalNightTime";
    public final static String prefDayStartTimeHour = "DayStartTimeHour";
    public final static String prefDayStartTimeMinute = "DayStartTimeMinute";
    public final static String prefNightStartTimeHour = "NightStartTimeHour";
    public final static String prefNightStartTimeMinute = "NightStartTimeMinute";

    public final static String prefLastGlucoseSyncedMaxRecordTimestamp = "LastGlucoseSyncedMaxRecordTimestamp";

    public final static String prefLastReadTransmitterDatetimeTimestamp = "LastReadTransmitterDatetimeTimestamp";

    public final static String prefsensorGlucoseRecordRangeFrom = "SensorGlucoseRecordRangeFrom";
    public final static String prefsensorGlucoseRecordRangeTo = "SensorGlucoseRecordRangeTo";
    public final static String prefalertRecordRangeFrom = "AlertRecordRangeFrom";
    public final static String prefalertRecordRangeTo = "AlertRecordRangeTo";
    public final static String prefbloodGlucoseRecordRangeFrom = "BloodGlucoseRecordRangeFrom";
    public final static String prefbloodGlucoseRecordRangeTo = "BloodGlucoseRecordRangeTo";

    public final static String prefMaxSyncedSensorRecord = "MaxSyncedSensorRecord";
    public final static String prefMaxSyncedAlertRecord = "MaxSyncedAlertRecord";
    public final static String prefMaxSyncedBloodGlucoseRecord = "MaxSyncedBloodGlucoseRecord";

    public static int GLUCOSE_LEVEL_UNKNOWN = -101;
    public static String GLUCOSE_LEVEL_UNKNOWN_STRING = "---";
    public static String GLUCOSE_LEVEL_OUT_OF_RANGE_HIGH_STRING = "HI";
    public static String GLUCOSE_LEVEL_OUT_OF_RANGE_LOW_STRING = "LO";

    // My transmitter data
    public static String NotAvailable = "N/A";
    public static String transmitterName = null;
    public static String transmitterNameContainer = null;
    public static int maxCalibrationTreshold = -1;
    public static int minCalibrationTreshold = -1;
    public static int sensorLifeDays = -1;


    public static String UNLINKED_SENSOR_SERIAL_NUMBER_ARRIVED = "senseonics.unlinkedsensor.serialnumber";
    public static final String MY_TRANSMITTER_INFO_ARRIVED = "senseonics.transmitter.info";
    public static final String CALIBRATION_STATE_ARRIVED = "senseonics.calibration.state";
    public static String CONNECTED_INTENT_FILTER = "senseonics.warning.connected";
    public static String DISCONNECTED_INTENT_FILTER = "senseonics.warning.disconnected";
    public static String WARNING_DIALOG_INTENT_FILTER = "senseonics.warning.dialog";

    public static String TIME_ZONE_CHANGED = "senseonics.timeZoneChanged";

    public static String SENSOR_REPLACEMENT_INTENT_FILTER = "senseonics.replacement.notification";
    public static String BATTERY_LOW_INTENT_FILTER = "senseonics.battery.low";

    public static String WRITE_N_BYTE_FINISHED = "senseonics.writeNByte.finished";

    // Constants for notification messages
    public static String RETRY_CAL_REJECTED_WAIT_MINUTES = "5";
    public static String RETRY_CAL_BLINDED_WAIT_HOURS = "6";
    public static String RETRY_CAL_NOT_READY_WAIT_MINUTES = "30";
    public static String RETRY_CAL_TOO_DIFFERENT_WAIT_HOURS = "1";
    public static String RETRY_CAL_RATE_WAIT_HOURS = "1";
    public static String REJECTED_CAL_VALUE_ABOVE = "400";
    public static String RETRY_CAL_TOO_HIGH_WAIT_HOURS = "1";
    public static String REJECTED_CAL_VALUE_BELOW = "40";
    public static String RETRY_CAL_TOO_LOW_WAIT_HOURS = "1";

    public enum GLUCOSE_TYPE {
        BLOOD_GLUCOSE, SENSOR_GLUCOSE
    }

    public enum CALIBRATION_STATE {
        READY, NOT_ENOUGH_DATA, GLUCOSE_RATE_TOO_HIGH, TOO_SOON, DROPOUT_PHASE, SENSOR_EOL, NO_SENSOR_LINKED, UNSUPPORTED_MODE, WAITING_POST_CALIBRATION,LED_DISCONNECT_DETECTED ,REASON_UNKNOWN
    }

    /** Same as MLTTransmitterState.h in iOS app */
    public enum CALIBRATION_USE_FLAG
    {
        NOT_ENTERED_FOR_CALIBRATION,
        ACTUALLY_USED_FOR_CALIBRATION,
        MARKED_SUSPICIOUS,
        GLUCOSE_TOO_LOW_TO_READ,
        GLUCOSE_TOO_HIGH_TO_READ,
        GLUCOSE_RAPID_CHANGE,
        INVALID_TIME,
        INSUFFICIENT_DATA,
        SENSOR_EOL,
        DROPOUT_PHASE,
        AUTOLINK_MODE_ACTIVE,
        SENSOR_LED_DISCONNECT,
        OTHER_FAILURE,
        THIS_ONE_USED_PREVIOUS_ONE_DELETED
    }

    public enum CAL_PHASE {
        UNKNOWN, WARM_UP, INITIALIZATION, DAILY_CALIBRATION, SUSPICIOUS, DROPOUT, DEBUG, UNDERTERMINED
    }

    public enum ARROW_TYPE {
        STALE(R.drawable.trend_inactive),
        FALLING_FAST(R.drawable.trend_falling_quickly),
        FALLING(R.drawable.trend_falling),
        FLAT(R.drawable.trend_flat),
        RISING(R.drawable.trend_rising),
        RISING_FAST(R.drawable.trend_rising_quickly);

        private int imageId;

        ARROW_TYPE(@DrawableRes int imageId) {
            this.imageId = imageId;
        }

        @DrawableRes
        public int getImageId() {
            return imageId;
        }
    }


    public enum MLCheckResult {
        Timeout(1),
        NotConnectedToWifi(2),
        ServerError(3),
        None(4),
        Unknown(5);

        private final int id;
        MLCheckResult(int id) {this.id = id;}
        public int getValue() {return id;}

        public static MLCheckResult fromValue(int id) {
            for (MLCheckResult err: values()) {
                if (err.getValue() == id) {
                    return err;
                }
            }
            return null;
        }
    };

    public enum STATISTIC_TYPE {
        STAT_8AM, STAT_12AM, STAT_4PM, STAT_8PM, STAT_12PM, STAT_ALL
    }

    public enum STATISTIC_TYPE2 {
        ABOVE_TARGET_LEVEL, BELOW_TARGET_LEVEL, WITHIN_TARGET_LEVELS
    }

    public enum EVENT_TYPE {
        CALIBRATION, GROUP_EVENT, GLUCOSE_EVENT, MEAL_EVENT, INSULIN_EVENT, HEALTH_EVENT, EXERCISE_EVENT,

        //
        NOTIFICATION_EVENT_RED, NOTIFICATION_EVENT_YELLOW, NOTIFICATION_EVENT_BLUE,

        ALERT_EVENT, ALARM_EVENT,

        PREDICTIVE_ALERT_EVENT_FALLING(R.string.predicted_low_glucose_alert_title), // PredictiveLowAlarm
        PREDICTIVE_ALERT_EVENT_RISING(R.string.predicted_high_glucose_alert_title), // PredictiveHighAlarm
        RATE_ALERT_EVENT_FALLING(R.string.rate_falling_alert_title), // RateFallingAlarm,
        RATE_ALERT_EVENT_RISING(R.string.rate_rising_alert_title), // RateRisingAlarm

        //
        CALIBRATE_NOW_EVENT, // CalibrationRequiredAlarm,
        CALIBRATE_GRACE_EVENT, // CalibrationGracePeriodAlarm,
        CALIBRATE_EXPIRED_EVENT;// CalibrationExpiredAlarm

        private int dialogTitleId;

        private EVENT_TYPE() {
            this(0);
        }

        private EVENT_TYPE(int dialogTitleId) {
            this.dialogTitleId = dialogTitleId;
        }

        public int getDialogTitleId() {
            return dialogTitleId;
        }
    }

    public enum ALERT_TYPE {
        LOW_GLUCOSE(R.string.low_glucose_alert_title, R.string.low_glucose_alarm_title), HIGH_GLUCOSE(R.string.high_glucose_alert_title, R.string.high_glucose_alarm_title);
        private int alertTitleId;
        private int alarmTitleId;

        ALERT_TYPE(@StringRes int alertTitleId, @StringRes int alarmTitleId) {
            this.alertTitleId = alertTitleId;
            this.alarmTitleId = alarmTitleId;
        }

        @StringRes
        public int getAlertTitleId() {
            return alertTitleId;
        }

        @StringRes
        public int getAlarmTitleId() {
            return alarmTitleId;
        }
    }

    // Similar to MLAlert.h in iOS app
    public enum TransmitterMessageCode {
        CriticalFaultAlarm,                                                 /** 0 */
        SensorRetiredAlarm,
        EmptyBatteryAlarm,
        SensorTemperatureAlarm,
        SensorLowTemperatureAlarm,
        ReaderTemperatureAlarm,
        SensorAwolAlarm,
        SensorErrorAlarm,
        InvalidSensorAlarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        HighAmbientLightAlarm,

        Reserved,                                                           /** 10 */
        CalibrationRequiredAlarm(EVENT_TYPE.CALIBRATE_NOW_EVENT) {
            @Override
            public int notificationId() {
                return NumberOfMessages.ordinal() + 1;
            }
        },
        SeriouslyLowAlarm,
        SeriouslyHighAlarm,
        LowGlucoseAlarm(EVENT_TYPE.ALARM_EVENT),
        HighGlucoseAlarm(EVENT_TYPE.ALARM_EVENT),
        LowGlucoseAlert(EVENT_TYPE.ALERT_EVENT),
        HighGlucoseAlert(EVENT_TYPE.ALERT_EVENT),
        PredictiveLowAlarm(EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING),
        PredictiveHighAlarm(EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING),

        RateFallingAlarm(EVENT_TYPE.RATE_ALERT_EVENT_FALLING),              /** 20 */
        RateRisingAlarm(EVENT_TYPE.RATE_ALERT_EVENT_RISING),
        CalibrationGracePeriodAlarm(EVENT_TYPE.CALIBRATE_GRACE_EVENT) {
            @Override
            public int notificationId() {
                return NumberOfMessages.ordinal() + 1;
            }
        }, // -
        CalibrationExpiredAlarm(EVENT_TYPE.CALIBRATE_EXPIRED_EVENT) {
            @Override
            public int notificationId() {
                return NumberOfMessages.ordinal() + 1;
            }
        }, // -
        SensorRetiringSoon1Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorRetiringSoon2Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorRetiringSoon3Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorRetiringSoon4Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorRetiringSoon5Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorRetiringSoon6Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),

        SensorRetiringSoon7Alarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),       /** 30 */
        VeryLowBatteryAlarm(EVENT_TYPE.NOTIFICATION_EVENT_YELLOW),
        LowBatteryAlarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        InvalidClockAlarm(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        SensorStablity,
        TransmitterDisconnected,
        VibrationCurrentAlarm,
        SensorAgedOutAlarm,
        SensorOnHoldAlarm(EVENT_TYPE.NOTIFICATION_EVENT_YELLOW),
        MEPAlarm,

        EDRAlarm0(EVENT_TYPE.NOTIFICATION_EVENT_YELLOW),/** #3224, #3920 */ /** 40 */
        EDRAlarm1(EVENT_TYPE.NOTIFICATION_EVENT_YELLOW),
        EDRAlarm2(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        EDRAlarm3(EVENT_TYPE.NOTIFICATION_EVENT_BLUE),
        EDRAlarm4(EVENT_TYPE.NOTIFICATION_EVENT_YELLOW), /** #3920 */

        NoAlarmActive,

        NumberOfMessages // Must be last item.
        ;
        private EVENT_TYPE eventType;

        TransmitterMessageCode() {
            this(EVENT_TYPE.NOTIFICATION_EVENT_RED);
        }

        TransmitterMessageCode(EVENT_TYPE eventType) {
            this.eventType = eventType;
        }

        public EVENT_TYPE getEventType() {
            return eventType;
        }

        public int notificationId() {
            return ordinal();
        }
    }

    public static long getTimeZoneOffset(Calendar calendar) {
        TimeZone mTimeZone = calendar.getTimeZone();
        int mGMTOffset = mTimeZone.getRawOffset();
        int GMTHours = (int) TimeUnit.HOURS.convert(mGMTOffset, TimeUnit.MILLISECONDS);
        return GMTHours * GraphUtils.HOUR;
    }

    public static long getLocalTimeInMillisAdjustedToGMT() {
        Calendar calendar = Calendar.getInstance();

        return (calendar.getTimeInMillis() - getTimeZoneOffset(calendar));
    }

    public static boolean isFloat(String s) {
        if (s.contains(".") || s.contains(","))
            return true;
        else
            return false;
    }


    public static Calendar getGMTCalendarFrom(int[] date, int[] time) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        int year = date[0];
        int month = date[1];
        int day = date[2];
        int hour = time[0];
        int minute = time[1];
        int second = time[2];

        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, second);
        return calendar;
    }

    public static Calendar sanitizeDate(Calendar calendar) {
        Calendar val = Calendar.getInstance();
        val.setTimeInMillis(calendar.getTimeInMillis());
        val.set(Calendar.MILLISECOND, 0);
        val.set(Calendar.SECOND, 0);
        val.set(Calendar.MINUTE, 0);
        val.set(Calendar.HOUR_OF_DAY, 0);

        return val;
    }

    // Same logic as iOS oldestDayForAnyEntityDaysAgo()
    public static void initDates(long earliestGMTTimeStamp) {
        Log.d("getEarliest", "current milli:" + Calendar.getInstance().getTimeInMillis());
        Log.d("getEarliest", "earliest GMT timestamp:" + earliestGMTTimeStamp);

        Calendar earliestCal = Calendar.getInstance();
        earliestCal.setTimeInMillis(earliestGMTTimeStamp);
        long earliestGMTTimeStampInMillisSantized = Utils.sanitizeDate(earliestCal).getTimeInMillis();

        currentDate = Calendar.getInstance();
        startDate = Calendar.getInstance();
        threeDaysAgo = Calendar.getInstance();

        Calendar calLongTimeAgo = Calendar.getInstance();
        calLongTimeAgo.add(Calendar.DATE, -kNumberOfDaysToFetch);
        Calendar calLongTimeAgoSantized = Utils.sanitizeDate(calLongTimeAgo);
        long calLongTimeAgoSantizedTimeInMillis = calLongTimeAgoSantized.getTimeInMillis();

        Calendar maxTimeAgo = Calendar.getInstance();
        maxTimeAgo.add(Calendar.DATE, -kNumberOfDaysMax);
        Calendar maxTimeAgoSantized = Utils.sanitizeDate(maxTimeAgo);
        long maxTimeAgoSantizedInMills = maxTimeAgoSantized.getTimeInMillis();

        if (earliestGMTTimeStampInMillisSantized > calLongTimeAgoSantizedTimeInMillis) {
            startDate.setTimeInMillis(calLongTimeAgoSantizedTimeInMillis);
        }
        else if (earliestGMTTimeStampInMillisSantized < maxTimeAgoSantizedInMills) {
            startDate.setTimeInMillis(maxTimeAgoSantizedInMills);
        }
        else {
            startDate.setTimeInMillis(earliestGMTTimeStampInMillisSantized);
        }

        // three days before now
        threeDaysAgo.setTimeInMillis(calLongTimeAgoSantizedTimeInMillis);

        // endDate is currently only used in GraphView
        endDate = Utils.sanitizeDate(Calendar.getInstance());
        endDate.add(Calendar.DATE, 1);

        endDateFinished = Calendar.getInstance();
        endDateFinished.setTimeInMillis(currentDate.getTimeInMillis()
                + GraphUtils.DAY);
    }

    private static Calendar calculateEndDateFinished() {
        Calendar retVal = Calendar.getInstance();
        retVal.setTimeInMillis(retVal.getTimeInMillis() + GraphUtils.DAY);
        return retVal;
    }

    public static Calendar getStartDate() {
        if (startDate != null) {
            return startDate;
        }
        else {
            Calendar calDefault = Calendar.getInstance();
            calDefault.setTimeInMillis(calDefault.getTimeInMillis() - kNumberOfDaysMax * GraphUtils.DAY);
            Log.d("DMS", "Get default start date:" + calDefault.getTimeInMillis());
            return calDefault;
        }
    }

    public static Calendar getEndDateFinished() {
        if (endDateFinished != null) {
            return endDateFinished;
        }
        else {
            return calculateEndDateFinished();
        }
    }

    public static Calendar getDayStart(Calendar cal) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(cal.getTimeInMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar;
    }

    public static Calendar copyCalendar(Calendar cal) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(cal.getTimeInMillis());
        calendar.setTimeZone(cal.getTimeZone());
        return calendar;
    }


    public static String formatDate(Calendar calendar, TimeZone timeZone, Context context) {
        if (calendar != null) {

            if(DateFormat.is24HourFormat(context)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "MMM dd, yyyy HH:mm");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }
            else {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "MMM dd, yyyy hh:mm a");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }

        } else
            return " ";
    }

    public static String formatDate_TimeZone(Calendar calendar, TimeZone timeZone) {
        if (calendar != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "MMM dd, yyyy hh:mm a");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
        } else
            return " ";
    }

    public static String getTime(Calendar calendar, TimeZone timeZone) {
        if (calendar != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
            dateFormat.setTimeZone(timeZone);
            return dateFormat.format(calendar.getTime());

        } else
            return " ";
    }


    public static String getHour24HrFormat(Calendar calendar, TimeZone timeZone, Context context) {
        if (calendar != null) {

            if(DateFormat.is24HourFormat(context)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("HH ");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }
            else
            {
                SimpleDateFormat dateFormat = new SimpleDateFormat("haa");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }

        } else
            return " ";
    }



    public static String getTime24HrFormat(Calendar calendar, TimeZone timeZone, Context context) {
        if (calendar != null) {

            if(DateFormat.is24HourFormat(context)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }
            else
            {
                SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }

        } else
            return " ";
    }

    public static String formatDateSimple(Calendar calendar, TimeZone timeZone, Context context) {

            if (calendar != null) {
                if(DateFormat.is24HourFormat(context)) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(
                            "MM/dd/yy, HH:mm");
                    dateFormat.setTimeZone(timeZone);
                    return dateFormat.format(calendar.getTime());
                }
                else {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(
                            "MM/dd/yy, hh:mm a");
                    dateFormat.setTimeZone(timeZone);
                    return dateFormat.format(calendar.getTime());
                }
            }
            else
                return " ";
    }

    public static String formatDate(Calendar calendar) {
        if (calendar != null)
            return (String) DateFormat.format("MMM dd, yyyy", calendar);
        else
            return " ";
    }

    public static Calendar getCalendarForMonthDayYearFromString(String theDate) {
        Calendar retVal = null;

        try {
            if (theDate != null && !theDate.equals("")) {
                retVal = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                retVal.setTime(dateFormat.parse(theDate));
            }
        }
        catch (ParseException ex) {
            retVal = null;
        }

        return retVal;
    }

    public static String formatDateToYearMonthDayString(Calendar calendar) {
        if (calendar != null)
            return (String) DateFormat.format("MMM dd, yyyy", calendar);
        else
            return " ";
    }

    public static String formatDateISO8601(long milliSeconds) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(milliSeconds);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        String s = sdf.format(c.getTime());
        String fDate = s.substring(0, s.length()-2) +":"+s.substring(s.length()-2, s.length());
        return fDate;

    }

    public static String formatWeekDateYearForTimeZone(Calendar calendar, TimeZone timeZone) {
        if (calendar != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "EEEE, MMMM dd, yyyy");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
        } else
        return " ";
    }

    public static String formatWeekDateTimeForTimeZone(Calendar calendar, TimeZone timeZone, Context context) {
        if (calendar != null) {
            if(DateFormat.is24HourFormat(context)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "EEEE, MMMM dd, HH:mm");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }
            else {
                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "EEEE, MMMM dd, hh:mm a");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
            }

        } else
            return " ";
    }

    public static String formatDateOnlyForTimeZone(Calendar calendar, TimeZone timeZone) {
        if (calendar != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat(
                    "MM/dd/yyyy");
            dateFormat.setTimeZone(timeZone);
            return dateFormat.format(calendar.getTime());

        } else
            return " ";
    }

    public static String formatTimeOnlyForTimeZone(Calendar calendar, TimeZone timeZone) {
        if (calendar != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
                dateFormat.setTimeZone(timeZone);
                return dateFormat.format(calendar.getTime());
        } else
            return " ";
    }

    public static boolean haveNetworkConnection(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo network = cm.getActiveNetworkInfo();

        if (network != null && network.isConnected())
            return true;
        else
            return false;
    }

    public static String getEventName(Context context, EVENT_TYPE eventType) {

        switch (eventType) {
            case CALIBRATION:
                return context.getString(R.string.calibration);
            case GLUCOSE_EVENT:
                return context.getString(R.string.glucose_event);
            case MEAL_EVENT:
                return context.getString(R.string.meal_event);
            case INSULIN_EVENT:
                return context.getString(R.string.insulin_event);
            case HEALTH_EVENT:
                return context.getString(R.string.health_event);
            case EXERCISE_EVENT:
                return context.getString(R.string.exercise_event);
            case ALERT_EVENT:
                return context.getString(R.string.alert);
            case ALARM_EVENT:
//                return context.getString(R.string.alarm);
                return context.getString(R.string.alert); /** #3214 */
            case CALIBRATE_NOW_EVENT:
                return context.getString(R.string.calibrate_now_notification_title);
            case CALIBRATE_GRACE_EVENT:
                return context.getString(R.string.calibration_grace_alert_title);
            case CALIBRATE_EXPIRED_EVENT:
                return context.getString(R.string.calibration_expired_alarm_title);
            case PREDICTIVE_ALERT_EVENT_FALLING:
            case PREDICTIVE_ALERT_EVENT_RISING:
                return context.getString(R.string.predictive_alerts);
            case RATE_ALERT_EVENT_FALLING:
            case RATE_ALERT_EVENT_RISING:
                return context.getString(R.string.rate_alerts);
            default:
                return " ";
        }
    }

    public static String getEventNameNotTranslated(Context context, EVENT_TYPE eventType) {

        switch (eventType) {
            case CALIBRATION:
                return "Calibration";
            case GLUCOSE_EVENT:
                return "Glucose";
            case MEAL_EVENT:
                return "Meal";
            case INSULIN_EVENT:
                return "Insulin";
            case HEALTH_EVENT:
                return "Health";
            case EXERCISE_EVENT:
                return "Exercise";
            case ALERT_EVENT:
                return "Alert";
            case ALARM_EVENT:
                return "Alarm";
            case CALIBRATE_NOW_EVENT:
                return "Calibrate Now";
            case CALIBRATE_GRACE_EVENT:
                return "Calibration Past Due";
            case CALIBRATE_EXPIRED_EVENT:
                return "Calibration Expired";
            case PREDICTIVE_ALERT_EVENT_FALLING:
            case PREDICTIVE_ALERT_EVENT_RISING:
                return "Predictive Alerts";
            case RATE_ALERT_EVENT_FALLING:
            case RATE_ALERT_EVENT_RISING:
                return "Rate Alerts";
            default:
                return " ";
        }
    }

    public static int getEventImageResId(EventPoint eventPoint) {

        EVENT_TYPE eventType = eventPoint.getEventType();
        switch (eventType) {
            case CALIBRATION:
                CalibrationEventPoint calibrationEvent = (CalibrationEventPoint) eventPoint;
                if (calibrationEvent.isCalibrationUsed())
                    return R.drawable.icon_graph_calibrate;
                else
                    return R.drawable.icon_graph_glucose;
            case GLUCOSE_EVENT:
                return R.drawable.icon_graph_glucose;
            case CALIBRATE_NOW_EVENT:
                return R.drawable.icon_graph_glucose;
            case CALIBRATE_GRACE_EVENT:
            case CALIBRATE_EXPIRED_EVENT:
//                return R.drawable.icon_graph_glucose_red;
                return R.drawable.icon_graph_glucose_yellow;  /** #3214 */
            case MEAL_EVENT:
                return R.drawable.icon_graph_meal;
            case INSULIN_EVENT:
                return R.drawable.icon_graph_insulin;
            case HEALTH_EVENT:
                return R.drawable.icon_graph_health;
            case EXERCISE_EVENT:
                return R.drawable.icon_graph_exercise;
            case ALERT_EVENT:
                return R.drawable.alert_icon_yellow;
            case ALARM_EVENT:
//                return R.drawable.alarm_icon_red;
                return R.drawable.alert_icon_yellow; /** #3214 */
            case PREDICTIVE_ALERT_EVENT_FALLING:
            case RATE_ALERT_EVENT_FALLING:
                return R.drawable.alert_dropping;
            case PREDICTIVE_ALERT_EVENT_RISING:
            case RATE_ALERT_EVENT_RISING:
                return R.drawable.alert_rising;
            case NOTIFICATION_EVENT_RED:
            case NOTIFICATION_EVENT_YELLOW:
            case NOTIFICATION_EVENT_BLUE:
                return Utils.getNotificationIcon(eventPoint
                        .getNotificationEventType());
            default:
                return -1;
        }
    }

    public static int getNotificationIcon(
            TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {
            case CalibrationRequiredAlarm:
                return R.drawable.icon_graph_glucose;

            case LowBatteryAlarm:
                return R.drawable.battery_low_blue_icon;

            case InvalidSensorAlarm:
            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case InvalidClockAlarm:
            case EDRAlarm2: /** #3920 */
            case EDRAlarm3:
                return R.drawable.blue_icon_minus;

            case LowGlucoseAlert:
            case HighGlucoseAlert:
                return R.drawable.alert_icon_yellow;

            case PredictiveLowAlarm:
            case RateFallingAlarm:
                return R.drawable.alert_dropping;

            case PredictiveHighAlarm:
            case RateRisingAlarm:
                return R.drawable.alert_rising;

            case VeryLowBatteryAlarm:
                return R.drawable.battery_low_yellow_icon;

            case SensorRetiredAlarm:
            case CriticalFaultAlarm:
            case SensorErrorAlarm:
            case SensorTemperatureAlarm:
            case SensorLowTemperatureAlarm:
            case ReaderTemperatureAlarm:
            case HighAmbientLightAlarm:
            case SensorStablity:
            case SensorAwolAlarm:
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorRetiringSoon7Alarm:
            case MEPAlarm:
            case EDRAlarm0: /** #3920 */
            case EDRAlarm1:
//                return R.drawable.red_icon_minus;
                return R.drawable.yellow_icon_minus; /** #3214 */

            case SensorOnHoldAlarm:
                return R.drawable.yellow_icon_minus;

            case SeriouslyLowAlarm:
            case SeriouslyHighAlarm:
            case LowGlucoseAlarm:
            case HighGlucoseAlarm:
//                return R.drawable.alarm_icon_red;
                return R.drawable.alert_icon_yellow; /** #3214 */

            case CalibrationGracePeriodAlarm:
            case CalibrationExpiredAlarm:
//                return R.drawable.icon_graph_glucose_red;
                return R.drawable.icon_graph_glucose_yellow; /** #3214 */

            case EmptyBatteryAlarm:
//                return R.drawable.battery_low_red_icon;
                return R.drawable.battery_low_yellow_no_bar_icon; /** #3214 #3389 */

            case EDRAlarm4: /** #3920 */
                return R.drawable.icon_edr_alert;

            default:
//                return R.drawable.red_icon_minus;
                return R.drawable.disruption_icon;
        }
    }

    public static int getNotificationWhiteIcon(
            TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {
            case CalibrationRequiredAlarm:
                return R.drawable.ic_calibration_alert_white;

            case LowBatteryAlarm:
                return R.drawable.ic_battery_low_notification_white;

            case InvalidSensorAlarm:
            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case InvalidClockAlarm:
            case EDRAlarm2: /** #3920 */
            case EDRAlarm3:
                return R.drawable.ic_icon_minus_white;

            case LowGlucoseAlert:
            case HighGlucoseAlert:
                return R.drawable.ic_alert_icon_white;

            case PredictiveLowAlarm:
            case RateFallingAlarm:
                return R.drawable.ic_alert_dropping_white;

            case PredictiveHighAlarm:
            case RateRisingAlarm:
                return R.drawable.ic_alert_rising_white;

            case VeryLowBatteryAlarm:
                return R.drawable.ic_battery_low_alert_white;

            case SensorRetiredAlarm:
            case CriticalFaultAlarm:
            case SensorErrorAlarm:
            case SensorTemperatureAlarm:
            case SensorLowTemperatureAlarm:
            case ReaderTemperatureAlarm:
            case HighAmbientLightAlarm:
            case SensorStablity:
            case SensorAwolAlarm:
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorRetiringSoon7Alarm:
            case MEPAlarm:
            case EDRAlarm0: /** #3920 */
            case EDRAlarm1:
//                return R.drawable.red_icon_minus;
                return R.drawable.ic_icon_minus_white; /** #3214 */

            case SensorOnHoldAlarm:
                return R.drawable.ic_icon_minus_white;

            case SeriouslyLowAlarm:
            case SeriouslyHighAlarm:
            case LowGlucoseAlarm:
            case HighGlucoseAlarm:
//                return R.drawable.alarm_icon_red;
                return R.drawable.ic_alert_icon_white; /** #3214 */

            case CalibrationGracePeriodAlarm:
            case CalibrationExpiredAlarm:
//                return R.drawable.icon_graph_glucose_red;
                return R.drawable.ic_calibration_alert_white; /** #3214 */

            case EmptyBatteryAlarm:
//                return R.drawable.battery_low_red_icon;
                return R.drawable.ic_battery_empty_alert_white; /** #3214 #3389 */

            case EDRAlarm4: /** #3920 */
                return R.drawable.ic_icon_edr_white;

            default:
//                return R.drawable.red_icon_minus;
                return R.drawable.ic_icon_disruption_white;
        }
    }

    public static int getNotificationDialogMessageSubTitleStringId(
            Utils.TransmitterMessageCode notificationEventType) {
        int subTitleId = -1;

        switch (notificationEventType) {

            // alarms with which no glucose values can be displayed.
            case CalibrationGracePeriodAlarm:
            case SensorStablity:
            case CalibrationExpiredAlarm:
            case SeriouslyHighAlarm:
            case SeriouslyLowAlarm:
            case ReaderTemperatureAlarm:
            case HighAmbientLightAlarm:
            case SensorLowTemperatureAlarm:
            case SensorTemperatureAlarm:
            case SensorRetiredAlarm:
            case EmptyBatteryAlarm:
            case InvalidSensorAlarm:
            case CriticalFaultAlarm:
            case SensorRetiringSoon7Alarm:
            case SensorOnHoldAlarm:
            case MEPAlarm:
            {
                subTitleId = R.string.no_glucose_display;
                break;
            }

            // alarms with no subtitle.
            case HighGlucoseAlarm:
            case LowGlucoseAlarm:
            {
                subTitleId = -1;
                break;
            }

            // alerts with no subtitle.
            case CalibrationRequiredAlarm:
            case PredictiveLowAlarm:
            case PredictiveHighAlarm:
            case RateRisingAlarm:
            case RateFallingAlarm:
            case VeryLowBatteryAlarm:
            case LowBatteryAlarm:
                // case CalibrationPhaseChangeAlert:
            case HighGlucoseAlert:
            case LowGlucoseAlert:
            case SensorRetiringSoon1Alarm:
            case EDRAlarm0: /** #3224 #3920 */
            case EDRAlarm1: /** #3224 */
            case EDRAlarm4: /** #3920 */
            {
                subTitleId = -1;
                break;
            }

            // notifications with no subtitle.
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case EDRAlarm2: /** #3224 */
            case EDRAlarm3:
            {
                subTitleId = -1;
                break;
            }

            // unknown
            case SensorErrorAlarm:
            case SensorAwolAlarm:
            case InvalidClockAlarm: {
                subTitleId = -1;
                break;
            }

            default: {
                subTitleId = -1;
                break;
            }
        }

        return subTitleId;
    }

    public static int getNotificationDialogIcon(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {

            case CalibrationRequiredAlarm:
            case InvalidSensorAlarm:
            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case LowBatteryAlarm:
            case InvalidClockAlarm:
            case EDRAlarm2: /** #3224 */
            case EDRAlarm3:
                return R.drawable.blue_bg;

            case LowGlucoseAlert:
            case HighGlucoseAlert:
            case PredictiveLowAlarm:
            case PredictiveHighAlarm:
            case RateFallingAlarm:
            case RateRisingAlarm:
            case VeryLowBatteryAlarm:
            case SensorOnHoldAlarm:
            case EDRAlarm0: /** #3224 #3920 */
            case EDRAlarm1: /** #3224 */
            case EDRAlarm4: /** #3920 */
                return R.drawable.yellow_bg;

            case CriticalFaultAlarm:
            case SensorRetiredAlarm:
            case EmptyBatteryAlarm:
            case SensorTemperatureAlarm:
            case SensorLowTemperatureAlarm:
            case ReaderTemperatureAlarm:
            case SensorAwolAlarm:
            case SensorErrorAlarm:
            case HighAmbientLightAlarm:
            case SeriouslyLowAlarm:
            case SeriouslyHighAlarm:
            case LowGlucoseAlarm:
            case HighGlucoseAlarm:
            case CalibrationGracePeriodAlarm:
            case CalibrationExpiredAlarm:
            case SensorStablity:
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorRetiringSoon7Alarm:
            case MEPAlarm:
//                return R.drawable.red_bg;
                return R.drawable.yellow_bg; /** #3214 */

            default:
                return R.drawable.blue_bg;
        }
    }

    public static int getNotificationDialogMessageTitleStringId(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {

            case CriticalFaultAlarm:
                return R.string.transmitter_error_alarm_title;

            case SensorRetiredAlarm:
            case MEPAlarm:
                return R.string.sensor_retired_alarm_title;

            case EmptyBatteryAlarm:
                return R.string.empty_battery_alarm_title;

            case SensorTemperatureAlarm:
                return R.string.sensor_high_temperature_alarm_title;

            case SensorLowTemperatureAlarm:
                return R.string.sensor_low_temperature_alarm_title;

            case ReaderTemperatureAlarm:
                return R.string.transmitter_high_temperature_alarm_title;

            case SensorAwolAlarm:
                return R.string.no_sensor_detected_alarm_title;

            case SensorErrorAlarm:
                return R.string.sensor_hardware_error_alarm_title;

            case InvalidSensorAlarm:
                return R.string.new_sensor_detected_notification_title;

            case HighAmbientLightAlarm:
                return R.string.high_ambient_light_alarm_title;

            case CalibrationRequiredAlarm:
                return R.string.calibrate_now_notification_title;

            case SeriouslyLowAlarm:
                return R.string.out_of_range_low_glucose_alarm_title;

            case SeriouslyHighAlarm:
                return R.string.out_of_range_high_glucose_alarm_title;

            case LowGlucoseAlarm:
                return R.string.low_glucose_alarm_title;

            case HighGlucoseAlarm:
                return R.string.high_glucose_alarm_title;

            case LowGlucoseAlert:
                return R.string.low_glucose_alert_title;

            case HighGlucoseAlert:
                return R.string.high_glucose_alert_title;

            case PredictiveLowAlarm:
                return R.string.predicted_low_glucose_alert_title;

            case PredictiveHighAlarm:
                return R.string.predicted_high_glucose_alert_title;

            case RateFallingAlarm:
                return R.string.rate_falling_alert_title;

            case RateRisingAlarm:
                return R.string.rate_rising_alert_title;

            case CalibrationGracePeriodAlarm:
                return R.string.calibration_grace_alert_title;

            case CalibrationExpiredAlarm:
                return R.string.calibration_expired_alarm_title;

            case SensorRetiringSoon1Alarm:
                return R.string.sensor_retirement_1_day_alarm_title;

            case SensorRetiringSoon2Alarm:
                return R.string.sensor_retirement_2_days_alarm_title;

            case SensorRetiringSoon3Alarm:
                return R.string.sensor_retirement_3_days_alert_title;

            case SensorRetiringSoon4Alarm:
            case SensorAgedOutAlarm:
                return R.string.sensor_retirement_7_days_alert_title;

            case SensorRetiringSoon5Alarm:
                return R.string.sensor_retirement_14_days_notification_title;

            case SensorRetiringSoon6Alarm:
                return R.string.sensor_retirement_30_days_notification_title;

            case SensorRetiringSoon7Alarm:
                return R.string.sensor_retired_prematurely_alarm_title;

            case VeryLowBatteryAlarm:
                return R.string.very_low_battery_alert_title;

            case LowBatteryAlarm:
                return R.string.low_battery_notification_title;

            case InvalidClockAlarm:
                return R.string.power_failure_alarm_title;

            case SensorStablity:
                return R.string.sensor_instability_alarm_title;

            case TransmitterDisconnected:
                return R.string.transmitter_disconnected_notification_title;
            case VibrationCurrentAlarm:
                return R.string.vibration_motor_alarm_title;

            case SensorOnHoldAlarm:
                return R.string.sensor_on_hold_alarm_title;

            case EDRAlarm0: /** #3224 #3920 */
            case EDRAlarm1:
            case EDRAlarm2:
            case EDRAlarm3:
                return R.string.sensor_status_alarm_title;

            case EDRAlarm4: /** #3920 */
                return R.string.estimated_days_remaining_alarm_title;

            default:
                return R.string.unknown_error_alert_title;
        }
    }

    public static String getNotificationDialogMessageTitleStringNoTranslated(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {

            case CriticalFaultAlarm:
                return "Transmitter Error";

            case SensorRetiredAlarm:
            case MEPAlarm:
                return "Sensor Replacement";

            case EmptyBatteryAlarm:
                return "Battery Empty";

            case SensorTemperatureAlarm:
                return "High Sensor Temperature";

            case SensorLowTemperatureAlarm:
                return "Low Sensor Temperature";

            case ReaderTemperatureAlarm:
                return "High Transmitter Temperature";

            case SensorAwolAlarm:
                return "No Sensor Detected";

            case SensorErrorAlarm:
                return "Sensor Hardware Error";

            case InvalidSensorAlarm:
                return "New Sensor Detected";

            case HighAmbientLightAlarm:
                return "High Ambient Light";

            case CalibrationRequiredAlarm:
                return "Calibrate Now";

            case SeriouslyLowAlarm:
                return "Out of Range Low Glucose";

            case SeriouslyHighAlarm:
                return "Out of Range High Glucose";

            case LowGlucoseAlarm:
                return "Low Glucose";

            case HighGlucoseAlarm:
                return "High Glucose";

            case LowGlucoseAlert:
                return "Low Glucose";

            case HighGlucoseAlert:
                return "High Glucose";

            case PredictiveLowAlarm:
                return "Predicted Low Glucose";

            case PredictiveHighAlarm:
                return "Predicted High Glucose";

            case RateFallingAlarm:
                return "Rate Falling";

            case RateRisingAlarm:
                return "Rate Rising";

            case CalibrationGracePeriodAlarm:
                return "Calibration Past Due";

            case CalibrationExpiredAlarm:
                return "Calibration Expired";

            case SensorRetiringSoon1Alarm:
                return "Sensor Replacement";

            case SensorRetiringSoon2Alarm:
                return "Sensor Replacement";

            case SensorRetiringSoon3Alarm:
                return "Sensor Replacement";

            case SensorRetiringSoon4Alarm:
            case SensorAgedOutAlarm:
                return "Sensor Replacement";

            case SensorRetiringSoon5Alarm:
                return "Sensor Replacement";

            case SensorRetiringSoon6Alarm:
                return "Sensor Replacement";

            case SensorRetiringSoon7Alarm:
                return "Sensor Replacement";

            case VeryLowBatteryAlarm:
                return "Charge Transmitter";

            case LowBatteryAlarm:
                return "Charge Transmitter";

            case InvalidClockAlarm:
                return "Invalid Transmitter Time";

            case SensorStablity:
                return "Sensor Check";

            case TransmitterDisconnected:
                return "Transmitter Disconnected";

            case VibrationCurrentAlarm:
                return "Vibration Motor";

            case SensorOnHoldAlarm:
                return "Sensor Suspend";

            case EDRAlarm0: /** #3224 #3920 */
            case EDRAlarm1:
            case EDRAlarm2:
            case EDRAlarm3:
                return "Sensor Status";

            case EDRAlarm4: /** #3920 */
                return "Estimated Days Remaining";

            default:
                return "Unknown Code: %d";
        }
    }

    public static String getEnumIndexTransmitterMessageCode(TransmitterMessageCode transmitterMessageCode) {
        return "EC #" + TransmitterMessageCode.valueOf(transmitterMessageCode.toString()).ordinal();
    }

    public static int getNotificationDialogTypeStringId(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {

            case InvalidSensorAlarm:
            case CalibrationRequiredAlarm:
            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case LowBatteryAlarm:
            case InvalidClockAlarm:
            case EDRAlarm2: /** #3224 */
            case EDRAlarm3:
                return R.string.notification;

            case LowGlucoseAlert:
            case HighGlucoseAlert:
            case PredictiveLowAlarm:
            case PredictiveHighAlarm:
            case RateFallingAlarm:
            case RateRisingAlarm:
            case VeryLowBatteryAlarm:
            case SensorOnHoldAlarm:
            case EDRAlarm0: /** #3224 #3920 */
            case EDRAlarm1: /** #3224 */
            case EDRAlarm4: /** #3920 */
                return R.string.alert;

            case CriticalFaultAlarm:
            case SensorRetiredAlarm:
            case EmptyBatteryAlarm:
            case SensorTemperatureAlarm:
            case SensorLowTemperatureAlarm:
            case ReaderTemperatureAlarm:
            case SensorAwolAlarm:
            case SensorErrorAlarm:
            case HighAmbientLightAlarm:
            case SeriouslyLowAlarm:
            case SeriouslyHighAlarm:
            case LowGlucoseAlarm:
            case HighGlucoseAlarm:
            case CalibrationGracePeriodAlarm:
            case CalibrationExpiredAlarm:
            case SensorStablity:
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorRetiringSoon7Alarm:
            case MEPAlarm:
//                return R.string.alarm;
                return R.string.alert; /** #3214 */

            default:
                return R.string.unknown;
        }
    }

    public static int getNotificationDialogTextStringId(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {
            case CriticalFaultAlarm:
                return R.string.transmitter_error_alarm_message_2;

            case SensorRetiredAlarm:
            case MEPAlarm:
                return R.string.sensor_retired_alarm_message;

            case EmptyBatteryAlarm:
                return R.string.empty_battery_alarm_message;

            case SensorTemperatureAlarm:
                return R.string.sensor_high_temperature_alarm_message;

            case SensorLowTemperatureAlarm:
                return R.string.sensor_low_temperature_alarm_message;

            case ReaderTemperatureAlarm:
                return R.string.transmitter_high_temperature_alarm_message_2;

            case SensorAwolAlarm:
                return R.string.no_sensor_detected_alarm_message;

            case SensorErrorAlarm:
                return R.string.sensor_hardware_error_alarm_message;

            case InvalidSensorAlarm:
                return R.string.new_sensor_detected_notification_message;

            case HighAmbientLightAlarm:
                return R.string.high_ambient_light_alarm_message_2;

            case CalibrationRequiredAlarm:
                return R.string.calibrate_now_notification_message;

            case SeriouslyLowAlarm:
                return R.string.out_of_range_low_glucose_alarm_message;

            case SeriouslyHighAlarm:
                return R.string.out_of_range_high_glucose_alarm_message;

            case LowGlucoseAlarm:
                return R.string.low_glucose_alarm_message_2; /** #3214 */

            case HighGlucoseAlarm:
                return R.string.high_glucose_alarm_message_2; /** #3214 */

            case LowGlucoseAlert:
                return R.string.low_glucose_alert_message;

            case HighGlucoseAlert:
                return R.string.high_glucose_alert_message;

            case PredictiveLowAlarm:
                return R.string.predicted_low_glucose_alert_message_2; /** #3214 */

            case PredictiveHighAlarm:
                return R.string.predicted_high_glucose_alert_message_3; /** #3214 */

            case RateFallingAlarm:
                return R.string.rate_falling_alert_mg_message_2;

            case RateRisingAlarm:
                return R.string.rate_rising_alert_mg_message_2;

            case CalibrationGracePeriodAlarm:
                return R.string.calibration_grace_alert_message;

            case CalibrationExpiredAlarm:
                return R.string.calibration_expired_alarm_message;

            case SensorRetiringSoon1Alarm:
                return R.string.sensor_retirement_1_day_alarm_message;

            case SensorRetiringSoon2Alarm:
                return R.string.sensor_retirement_2_days_alarm_message_2;

            case SensorRetiringSoon3Alarm:
                return R.string.sensor_retirement_3_days_alert_message_2;

            case SensorRetiringSoon4Alarm:
                return R.string.sensor_retirement_7_days_alert_message_2;

            case SensorAgedOutAlarm:
                return R.string.sensor_retirement_agedout_alarm_message;

            case SensorRetiringSoon5Alarm:
                return R.string.sensor_retirement_14_days_notification_message_2;

            case SensorRetiringSoon6Alarm:
                return R.string.sensor_retirement_30_days_notification_message;

            case SensorRetiringSoon7Alarm:
                return R.string.sensor_retired_prematurely_alarm_message;

            case VeryLowBatteryAlarm:
                return R.string.very_low_battery_alert_message;

            case LowBatteryAlarm:
                return R.string.low_battery_notification_message;

            case InvalidClockAlarm:
                return R.string.power_failure_alarm_message;

            case SensorStablity:
                return R.string.sensor_instability_alarm_message;

            case TransmitterDisconnected:
                return R.string.transmitter_disconnected_notification_message;

            case VibrationCurrentAlarm:
                return R.string.vibration_motor_alarm_message;

            case SensorOnHoldAlarm:
                return R.string.sensor_on_hold_alarm_message;

            case EDRAlarm0: /** #3224 */
                return R.string.sensor_status_alarm_message_0;

            case EDRAlarm1:
                return R.string.sensor_status_alarm_message_1;

            case EDRAlarm2:
                return R.string.sensor_status_alarm_message_2;

            case EDRAlarm3:
                return R.string.sensor_status_alarm_message_3;

            case EDRAlarm4:
                return R.string.estimated_days_remaining_alarm_message;

            default:
                return R.string.unknown_error_alert_message;
        }
    }

    public static int getNotificationDialogHelpTextStringId(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {
            case CriticalFaultAlarm:
                return R.string.transmitter_error_alarm_help_message;

            case SensorRetiredAlarm:
            case MEPAlarm:
                return R.string.sensor_retired_alarm_help_message;

            case EmptyBatteryAlarm:
                return R.string.empty_battery_alarm_help_message;

            case SensorTemperatureAlarm:
                return R.string.sensor_low_high_temperature_alarm_help_message;

            case SensorLowTemperatureAlarm:
                return R.string.sensor_low_high_temperature_alarm_help_message;

            case ReaderTemperatureAlarm:
                return R.string.transmitter_high_temperature_alarm_help_message;

            case SensorAwolAlarm:
                return R.string.no_sensor_detected_alarm_help_message;

            case SensorErrorAlarm:
                return R.string.sensor_hardware_error_alarm_help_message;

            case InvalidSensorAlarm:
                return R.string.new_sensor_detected_notification_help_message;

            case HighAmbientLightAlarm:
                return R.string.high_ambient_light_alarm_help_message;

            case CalibrationRequiredAlarm:
                return R.string.calibrate_now_notification_help_message;

            case SeriouslyLowAlarm:
                return R.string.out_of_range_low_glucose_alarm_help_message;

            case SeriouslyHighAlarm:
                return R.string.out_of_range_high_glucose_alarm_help_message;

            case LowGlucoseAlarm:
                return R.string.low_glucose_alarm_help_message_2; /** #3214 */

            case HighGlucoseAlarm:
                return R.string.high_glucose_alarm_help_message_2; /** #3214 */

            case LowGlucoseAlert:
                return R.string.low_glucose_alert_help_message;

            case HighGlucoseAlert:
                return R.string.high_glucose_alert_help_message;

            case PredictiveLowAlarm:
                return R.string.predicted_low_glucose_alert_help_message_2; /** #3214 */

            case PredictiveHighAlarm:
                return R.string.predicted_high_glucose_alert_help_message_2; /** #3214 */

            case RateFallingAlarm:
                return R.string.rate_falling_alert_mg_mmol_help_message;

            case RateRisingAlarm:
                return R.string.rate_rising_alert_mg_mmol_help_message;

            case CalibrationGracePeriodAlarm:
                return R.string.calibration_grace_alert_help_message;

            case CalibrationExpiredAlarm:
                return R.string.calibration_expired_alarm_help_message;

            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
                return R.string.sensor_retirement_1_7_day_alarm_help_message;

            case SensorRetiringSoon7Alarm:
                return R.string.sensor_retired_prematurely_help_message;

            case SensorAgedOutAlarm:
                return R.string.sensor_retirement_agedout_help_message;

            case VeryLowBatteryAlarm:
                return R.string.very_low_battery_alert_help_message;

            case LowBatteryAlarm:
                return R.string.low_battery_notification_help_message;

            case InvalidClockAlarm:
                return R.string.power_failure_alarm_help_message;

            case SensorStablity:
                return R.string.sensor_instability_alarm_help_message;

            case TransmitterDisconnected:
                return R.string.transmitter_disconnected_notification_message;

            case VibrationCurrentAlarm:
                return R.string.vibration_motor_alarm_help_message;

            case SensorOnHoldAlarm:
                return R.string.sensor_on_hold_alarm_help_message;

            case EDRAlarm0: /** #3224 */
                return R.string.sensor_status_alarm_message_0;

            case EDRAlarm1:
                return R.string.sensor_status_alarm_message_1;

            case EDRAlarm2:
                return R.string.sensor_status_alarm_message_2;

            case EDRAlarm3:
                return R.string.sensor_status_alarm_message_3;

            case EDRAlarm4:
                return R.string.days_remaining_alarm_help_message_1;

            default:
                return R.string.unknown_help_message;
        }
    }

    public static int getRightButtonTextId(
            Utils.TransmitterMessageCode notificationEventType) {
        switch (notificationEventType) {
            case SensorStablity:
                return R.string.calibrate;

            case InvalidSensorAlarm:
                return R.string.link_sensor;

            case CriticalFaultAlarm:
            case SensorErrorAlarm:
                return R.string.contact;

            case SensorRetiredAlarm:
            case EmptyBatteryAlarm:
            case SensorTemperatureAlarm:
            case SensorLowTemperatureAlarm:
            case ReaderTemperatureAlarm:
            case SensorAwolAlarm:
            case HighAmbientLightAlarm:

            case CalibrationRequiredAlarm:
            case SeriouslyLowAlarm:
            case SeriouslyHighAlarm:
            case LowGlucoseAlarm:
            case HighGlucoseAlarm:
            case LowGlucoseAlert:
            case HighGlucoseAlert:
            case PredictiveLowAlarm:
            case PredictiveHighAlarm:

            case RateFallingAlarm:
            case RateRisingAlarm:
            case CalibrationGracePeriodAlarm:
            case CalibrationExpiredAlarm:
            case SensorRetiringSoon1Alarm:
            case SensorRetiringSoon2Alarm:
            case SensorRetiringSoon3Alarm:
            case SensorRetiringSoon4Alarm:
            case SensorRetiringSoon5Alarm:
            case SensorRetiringSoon6Alarm:
            case SensorRetiringSoon7Alarm:

            case VeryLowBatteryAlarm:
            case LowBatteryAlarm:
            case InvalidClockAlarm:
            case TransmitterDisconnected:
            case VibrationCurrentAlarm:
            case SensorAgedOutAlarm:
            case SensorOnHoldAlarm:
            case MEPAlarm:
            case EDRAlarm0: /** #3224 */
            case EDRAlarm1:
            case EDRAlarm2:
            case EDRAlarm3:
            case EDRAlarm4: /** #3920 */
                return -1;

            default:
                return -1;
        }
    }

    public static boolean isCriticalAlarm(TransmitterMessageCode code) {
        boolean isCritical = false;

        if ((code == TransmitterMessageCode.CriticalFaultAlarm)
                || (code == TransmitterMessageCode.SensorRetiredAlarm)
                || (code == TransmitterMessageCode.EmptyBatteryAlarm)
                || (code == TransmitterMessageCode.SensorTemperatureAlarm)
                || (code == TransmitterMessageCode.SensorLowTemperatureAlarm)
                || (code == TransmitterMessageCode.ReaderTemperatureAlarm)
                || (code == TransmitterMessageCode.SeriouslyLowAlarm)
                || (code == TransmitterMessageCode.SeriouslyHighAlarm)
                || (code == TransmitterMessageCode.LowGlucoseAlarm)
                || (code == TransmitterMessageCode.HighGlucoseAlarm)
                || (code == TransmitterMessageCode.VibrationCurrentAlarm)
                || (code == TransmitterMessageCode.SensorAwolAlarm) // this is a special case on the transmitter which always vibrates
                )
        {
            isCritical = true;
        }

        return isCritical;
    }

    public enum ALERT {
        HIGH_THRESHOLD, LOW_THRESHOLD, PREDICTIVE, HIGHT_TARGET
    }

    public static String getGlucoseUnitString(Context context) {
        return getGlucoseUnitString(context, Utils.currentGlucoseUnit);
    }

    public static String getGlucoseUnitString(Context context,
                                              GLUCOSE_UNIT glucoseUnit) {

        if (glucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return context.getString(R.string.mg_Dl);
        else
            return context.getString(R.string.mmol_L);
    }

    public static String getGlucoseLevelValue(int glucoseLevel) {

        if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return String.valueOf(glucoseLevel);
        else {
            float glucoseMmol = Convert.MLConvertMgToMmol(glucoseLevel);
            return String.format(Locale.US, "%.1f", glucoseMmol);
        }
    }


    public static String getGlucoseLevelValue(float glucoseLevelAvg) {

        if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return String.valueOf(String.format(Locale.US, "%.1f", glucoseLevelAvg));
        else {
            float glucoseMmol = Convert.MLConvertMgToMmol(glucoseLevelAvg);
            return String.format(Locale.US, "%.1f", glucoseMmol);
        }
    }

    public static String getGlucoseLevelValueNoDecs(float glucoseLevelAvg) {

        if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return String.valueOf(String.format(Locale.US, "%.0f", glucoseLevelAvg));
        else {
            float glucoseMmol = Convert.MLConvertMgToMmol(glucoseLevelAvg);
            return String.format(Locale.US, "%.1f", glucoseMmol);
        }
    }


    public static float getGlucoseLevelFloatValue(int glucoseLevel) {

        if (Utils.currentGlucoseUnit == GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            return glucoseLevel;
        else {
            float glucoseMmol = Convert.MLConvertMgToMmol(glucoseLevel);
            return glucoseMmol;
        }
    }

    public static String getGlucoseLevelString(Context context, int glucoseLevel) {
        String value;
        String unitString = Utils.getGlucoseUnitString(context,
                Utils.currentGlucoseUnit);
        String currentFormat = getGlucoseLevelValue(glucoseLevel);
        value = currentFormat + " " + unitString;
        return value;
    }

    public static String getAlertName(Context context, ALERT alert) {

        switch (alert) {
            case HIGH_THRESHOLD:
                return context.getString(R.string.high_threshold);
            case LOW_THRESHOLD:
                return context.getString(R.string.low_treshold);
            case PREDICTIVE:
                return context.getString(R.string.predictive);
            case HIGHT_TARGET:
                return context.getString(R.string.hight_target);
            default:
                return " ";
        }
    }

    public static int getImageForSignalStrength(SIGNAL_STRENGTH signalStrength) {

        switch (signalStrength) {
            case EXCELLENT:
                return R.drawable.signal_strength_excellent;
            case GOOD:
                return R.drawable.signal_strength_good;
            case LOW:
                return R.drawable.signal_strength_low;
            case VERY_LOW:
                return R.drawable.signal_strength_very_low;
            case POOR:
                return R.drawable.signal_strength_poor;
            case NO_SIGNAL:
                return R.drawable.signal_strength_none;
            default:
                return -1;
        }
    }

    public static int getImageForBatteryLevel(
            BATTERY_LEVEL batteryLevel) {
        int imageId = -1;

        switch (batteryLevel) {
            case UNKNOWN_NEG_1:
                imageId = R.drawable.icon_battery_0;
                break;
            case BL_0:
                imageId = R.drawable.icon_battery_low;
                break;
            case BL_5:
                imageId = R.drawable.icon_battery_5;
                break;
            case BL_10:
                imageId = R.drawable.icon_battery_10;
                break;
            case BL_25:
                imageId = R.drawable.icon_battery_25;
                break;
            case BL_35:
                imageId = R.drawable.icon_battery_35;
                break;
            case BL_45:
                imageId = R.drawable.icon_battery_45;
                break;
            case BL_55:
                imageId = R.drawable.icon_battery_55;
                break;
            case BL_65:
                imageId = R.drawable.icon_battery_65;
                break;
            case BL_75:
                imageId = R.drawable.icon_battery_75;
                break;
            case BL_85:
                imageId = R.drawable.icon_battery_85;
                break;
            case BL_95:
                imageId = R.drawable.icon_battery_95;
                break;
            case BL_100:
                imageId = R.drawable.icon_battery_100;
                break;

        }
        return imageId;
    }

    public static String getBatteryPercentStringForLevel(
            BATTERY_LEVEL batteryLevel) {
        String batteryPercent = Utils.NotAvailable;

        switch (batteryLevel) {
            case UNKNOWN_NEG_1:
                batteryPercent = Utils.NotAvailable;
                break;
            case BL_0:
                batteryPercent = "0%";
                break;
            case BL_5:
                batteryPercent = "5%";
                break;
            case BL_10:
                batteryPercent = "10%";
                break;
            case BL_25:
                batteryPercent = "25%";
                break;
            case BL_35:
                batteryPercent = "35%";
                break;
            case BL_45:
                batteryPercent = "45%";
                break;
            case BL_55:
                batteryPercent = "55%";
                break;
            case BL_65:
                batteryPercent = "65%";
                break;
            case BL_75:
                batteryPercent = "75%";
                break;
            case BL_85:
                batteryPercent = "85%";
                break;
            case BL_95:
                batteryPercent = "95%";
                break;
            case BL_100:
                batteryPercent = "100%";
                break;

        }

        return batteryPercent;
    }

    public static String getAlertEventText(Context context,
                                           Utils.ALERT_TYPE alertType,
                                           int glucoseHighThreshold,
                                           int glucoseLowThreshold) {
        switch (alertType) {
            case LOW_GLUCOSE:
                return context.getString(R.string.low_glucose_alert_message)
                        .replace("%d", Utils.getGlucoseLevelString(
                                context,
                                glucoseLowThreshold));

            case HIGH_GLUCOSE:
                return context.getString(R.string.high_glucose_alert_message)
                        .replace("%d", Utils.getGlucoseLevelString(
                                context,
                                glucoseHighThreshold));
            default:
                return "";
        }
    }

    public static String getAlarmEventText(Context context,
                                           Utils.ALERT_TYPE alertType,
                                           int glucoseHighThreshold,
                                           int glucoseLowThreshold) {
        switch (alertType) {
            case LOW_GLUCOSE:
                return context.getString(R.string.low_glucose_alarm_message_2) /** #3214 */
                        .replace("%d", Utils.getGlucoseLevelString(
                                context,
                                glucoseLowThreshold));
            case HIGH_GLUCOSE:
                return context.getString(R.string.high_glucose_alarm_message_2) /** #3214 */
                        .replace("%d", Utils.getGlucoseLevelString(
                                context,
                                glucoseHighThreshold));
            default:
                return "";
        }
    }

    public static String getAlarmEventTitle(Context context, ALERT_TYPE type) {
        switch (type) {
            case HIGH_GLUCOSE:
                return context.getResources().getString(
                        R.string.high_glucose_alarm_title);

            case LOW_GLUCOSE:
                return context.getString(R.string.low_glucose_alarm_title);
        }
        return " ";
    }

    public static String getAlarmEventTitleNotTranslated(Context context, ALERT_TYPE type) {
        switch (type) {
            case HIGH_GLUCOSE:
                return "High Glucose";

            case LOW_GLUCOSE:
                return "Low Glucose";
        }
        return " ";
    }


    public static String getAlertEventTitle(Context context, ALERT_TYPE type) {
        switch (type) {
            case LOW_GLUCOSE:
                return context.getString(R.string.low_glucose_alert_title);

            case HIGH_GLUCOSE:
                return context.getResources().getString(
                        R.string.high_glucose_alert_title);
        }
        return " ";
    }


    public static String getGlucoseTypeString(Context context, GLUCOSE_TYPE type) {
        switch (type) {
            case BLOOD_GLUCOSE:
                return context.getString(R.string.blood_glucose);

            case SENSOR_GLUCOSE:
                return context.getString(R.string.sensor_glucose);
        }
        return " ";
    }

    public static String getRateAlertTitle(Context context, EVENT_TYPE eventType) {
        switch (eventType) {
            case RATE_ALERT_EVENT_FALLING:
                return context.getString(R.string.rate_falling_alert_title);

            case RATE_ALERT_EVENT_RISING:
                return context.getString(R.string.rate_rising_alert_title);

            default:
                return " ";
        }
    }

    public static String getPredictiveAlertTitle(Context context,
                                                 EVENT_TYPE eventType) {
        switch (eventType) {
            case PREDICTIVE_ALERT_EVENT_FALLING:
                return context
                        .getString(R.string.predicted_low_glucose_alert_title);

            case PREDICTIVE_ALERT_EVENT_RISING:
                return context
                        .getString(R.string.predicted_high_glucose_alert_title);

            default:
                return " ";
        }
    }

    public static String getPredictiveAlertText(Context context,
                                                Utils.EVENT_TYPE eventType, int predictiveMinutes, String transmitterName) {
        switch (eventType) {
            case PREDICTIVE_ALERT_EVENT_FALLING:
                return Utils.replaceTransmitterNameFromString(
                        context.getString(
                                R.string.predicted_low_glucose_alert_message_2) /** #3214 */
                                .replace("%d", predictiveMinutes + ""),
                        transmitterName);

            case PREDICTIVE_ALERT_EVENT_RISING:
                return Utils.replaceTransmitterNameFromString(
                        context.getString(
                                R.string.predicted_high_glucose_alert_message_3) /** #3214 */
                                .replace("%d", predictiveMinutes + ""),
                        transmitterName);

            default:
                return " ";
        }
    }

    public static String getRateAlertText(Context context,
                                          Utils.EVENT_TYPE eventType, float rateValue, String transmitterName) {
        switch (eventType) {
            case RATE_ALERT_EVENT_FALLING:
                if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
                    return Utils
                            .replaceTransmitterNameFromString(
                                    context.getString(R.string.rate_falling_alert_mg_message_2),
                                    transmitterName)
                            .replace("%.1f", String.valueOf(rateValue))
                            .replace("%@", context.getString(R.string.mg_dl_min));
                } else if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L) {
                    return Utils
                            .replaceTransmitterNameFromString(
                                    context.getString(R.string.rate_falling_alert_mmol_message_2),
                                    transmitterName)
                            .replace(
                                    "%.2f",
                                    String.format(Locale.US, "%.2f",
                                            Convert.MLConvertMgToMmol(rateValue)))
                            .replace("%@", context.getString(R.string.mmol_l_min));
                }

            case RATE_ALERT_EVENT_RISING:
                if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
                    return Utils
                            .replaceTransmitterNameFromString(
                                    context.getString(R.string.rate_rising_alert_mg_message_2),
                                    transmitterName)
                            .replace("%.1f", String.valueOf(rateValue))
                            .replace("%@", context.getString(R.string.mg_dl_min));
                } else if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L) {
                    return Utils
                            .replaceTransmitterNameFromString(
                                    context.getString(R.string.rate_rising_alert_mmol_message_2),
                                    transmitterName)
                            .replace(
                                    "%.2f",
                                    String.format(Locale.US, "%.2f",
                                            Convert.MLConvertMgToMmol(rateValue)))
                            .replace("%@", context.getString(R.string.mmol_l_min));
                }

            default:
                return " ";
        }
    }

    public static int getTitleIdForCalibrationUseFlagForEventActivity(int calUseFlag) {
        int textIdTitle;
        switch (CALIBRATION_USE_FLAG.values()[calUseFlag]) {
            case NOT_ENTERED_FOR_CALIBRATION:
                textIdTitle = R.string.event_cal_not_entered_title;
                break;
            case ACTUALLY_USED_FOR_CALIBRATION:
            case THIS_ONE_USED_PREVIOUS_ONE_DELETED: /** #3209 */
                textIdTitle = R.string.event_cal_accepted_title;
                break;
            case MARKED_SUSPICIOUS:
                textIdTitle = R.string.event_cal_rejected_too_different_title;
                break;
            case GLUCOSE_TOO_LOW_TO_READ:
                textIdTitle = R.string.event_cal_rejected_too_low_title;
                break;
            case GLUCOSE_TOO_HIGH_TO_READ:
                textIdTitle = R.string.event_cal_rejected_too_high_title;
                break;
            case GLUCOSE_RAPID_CHANGE:
                textIdTitle = R.string.event_cal_rejected_rate_title;
                break;
            case INVALID_TIME:
                textIdTitle = R.string.event_cal_rejected_not_ready_title;
                break;
            case INSUFFICIENT_DATA:
                textIdTitle = R.string.event_cal_rejected_data_title;
                break;
            case SENSOR_EOL:
                textIdTitle = R.string.event_cal_rejected_replacement_title;
                break;
            case DROPOUT_PHASE:
                textIdTitle = R.string.event_cal_rejected_blinded_title;
                break;
            case AUTOLINK_MODE_ACTIVE:
                textIdTitle = R.string.event_cal_rejected_auto_link_title;
                break;
            case SENSOR_LED_DISCONNECT:
                textIdTitle = R.string.event_cal_rejected_replacement_title;
                break;
            case OTHER_FAILURE:
                textIdTitle = R.string.event_cal_rejected_other_title;
                break;
            default:
                textIdTitle = R.string.event_cal_not_entered_title;
                break;
        }
        return textIdTitle;
    }

    public static int getTitleIdForCalibrationUseFlag(int calUseFlag) {
        int textIdTitle;
        switch (CALIBRATION_USE_FLAG.values()[calUseFlag]) {
            case NOT_ENTERED_FOR_CALIBRATION:
                textIdTitle = R.string.cal_not_entered_title;
                break;
            case ACTUALLY_USED_FOR_CALIBRATION:
            case THIS_ONE_USED_PREVIOUS_ONE_DELETED: /** #3209 */
                textIdTitle = R.string.cal_accepted_title;
                break;
            case MARKED_SUSPICIOUS:
                textIdTitle = R.string.cal_rejected_too_different_title;
                break;
            case GLUCOSE_TOO_LOW_TO_READ:
                textIdTitle = R.string.cal_rejected_too_low_title;
                break;
            case GLUCOSE_TOO_HIGH_TO_READ:
                textIdTitle = R.string.cal_rejected_too_high_title;
                break;
            case GLUCOSE_RAPID_CHANGE:
                textIdTitle = R.string.cal_rejected_rate_title;
                break;
            case INVALID_TIME:
                textIdTitle = R.string.cal_rejected_not_ready_title;
                break;
            case INSUFFICIENT_DATA:
                textIdTitle = R.string.cal_rejected_data_title;
                break;
            case SENSOR_EOL:
                textIdTitle = R.string.cal_rejected_replacement_title;
                break;
            case DROPOUT_PHASE:
                textIdTitle = R.string.cal_rejected_blinded_title;
                break;
            case AUTOLINK_MODE_ACTIVE:
                textIdTitle = R.string.cal_rejected_auto_link_title;
                break;
            case SENSOR_LED_DISCONNECT:
                textIdTitle = R.string.cal_rejected_replacement_title;
                break;
            case OTHER_FAILURE:
                textIdTitle = R.string.cal_rejected_other_title;
                break;
            default:
                textIdTitle = R.string.cal_rejected_unknown_title;
                break;
        }
        return textIdTitle;
    }


    public static String getStatisticsString(Context context,
                                             MealTimeDataHandler.MealType type) {
        switch (type) {
            case BREAKFAST:
                return context.getString(R.string.breakfast);
            case LUNCH:
                return context.getString(R.string.lunch);
            case SNACK:
                return context.getString(R.string.snack);
            case DINNER:
                return context.getString(R.string.dinner);
            case SLEEP:
                return context.getString(R.string.sleep);
            case ALL:
                return context.getString(R.string.all).toString().toUpperCase();
            default:
                return " ";
        }
    }

    public static String getStatistics2String(Context context,
                                              STATISTIC_TYPE2 type) {
        switch (type) {

            case ABOVE_TARGET_LEVEL:
                return context.getString(R.string.above_target_level);
            case BELOW_TARGET_LEVEL:
                return context.getString(R.string.below_target_level);
            case WITHIN_TARGET_LEVELS:
                return context.getString(R.string.within_target_levels);
            default:
                return " ";
        }
    }

    public static boolean areArraysEqual(int[] a, int[] b) {

        if (a.length != b.length)
            return false;
        else
            for (int i = 0; i < b.length; i++)
                if (a[i] != b[i])
                    return false;
        return true;
    }


    // show event details
    public static void showEventDetails(Fragment fragment, EventPoint eventPoint) {

        EVENT_TYPE eventType = eventPoint.getEventType();
        Intent intent = null;

        switch (eventType) {
            case CALIBRATION:
                intent = new Intent(fragment.getActivity(), CalibrationEventActivity.class);
                break;
            case GLUCOSE_EVENT:
                intent = new Intent(fragment.getActivity(), GlucoseEventActivity.class);
                break;
            case EXERCISE_EVENT:
                intent = new Intent(fragment.getActivity(), ExerciseEventActivity.class);
                break;
            case MEAL_EVENT:
                intent = new Intent(fragment.getActivity(), MealEventActivity.class);
                break;
            case INSULIN_EVENT:
                intent = new Intent(fragment.getActivity(), InsulinEventActivity.class);
                break;
            case HEALTH_EVENT:
                intent = new Intent(fragment.getActivity(), HealthEventActivity.class);
                break;
            case ALERT_EVENT:
            case ALARM_EVENT:
            case PREDICTIVE_ALERT_EVENT_FALLING:
            case PREDICTIVE_ALERT_EVENT_RISING:
                intent = new Intent(fragment.getActivity(), AlertEventActivity.class);
                break;

            case RATE_ALERT_EVENT_FALLING:
            case RATE_ALERT_EVENT_RISING:
            case CALIBRATE_NOW_EVENT:
            case CALIBRATE_GRACE_EVENT:
            case CALIBRATE_EXPIRED_EVENT:
                intent = new Intent(fragment.getActivity(), NotificationEventActivity.class);
                break;
            case NOTIFICATION_EVENT_RED:
            case NOTIFICATION_EVENT_YELLOW:
            case NOTIFICATION_EVENT_BLUE:
                intent = new Intent(fragment.getActivity(), NotificationEventActivity.class);
                break;
            default:
                break;
        }

        if (intent != null) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("edit", true);
            bundle.putSerializable("eventPoint", eventPoint);

            // Same as the one in AddEventMenuCreator
            Calendar startDateLocal = Calendar.getInstance();
            startDateLocal.add(Calendar.DATE, -Utils.ADD_EDIT_EVENT_MAX_DAYS_AGO);
            bundle.putSerializable("startdate", startDateLocal);

            bundle.putSerializable("enddate", Utils.sanitizeDate(Calendar.getInstance()));
            intent.putExtras(bundle);
            fragment.getActivity().startActivity(intent);
        }
    }

    public static int getItemPosition(ArrayList<Item> items, int value) {
        for (int i = 0; i < items.size(); ++i) {
            String s = items.get(i).getValue();
            if (!Utils.isFloat(s))
                if (Integer.valueOf(items.get(i).getValue()) == value)
                    return i;
        }
        return -1;
    }

    public static int getItemPosition(ArrayList<Item> items, String value) {
        for (int i = 0; i < items.size(); ++i) {
            if (items.get(i).getValue().equals(value))
                return i;
        }
        return -1;
    }

    public static int getItemPosition(ArrayList<Item> items, float value) {
        for (int i = 0; i < items.size(); ++i) {
            String s = items.get(i).getValue();
            if (Utils.isFloat(s))
                if ((int) (Float.valueOf(items.get(i).getValue()) * 10) == (int) (value * 10)) // *10
                    // to
                    // convert
                    // to
                    // int
                    // and
                    // compare
                    return i;
        }
        return -1;
    }

    public static void saveSettings(Context context, String key, int value) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static int getSettingsForDefault(Context context, String key, int defaultInt) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getInt(key, defaultInt);
    }

    public static int getSettings(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getInt(key, -1);
    }

    public static String getSettingsForString(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getString(key, "");
    }

    public static String getSettingsForStringWithDefault(Context context, String key, String defValue) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getString(key, defValue);
    }

    public static void saveSettings(Context context, String key, boolean value) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static boolean getSettingsBoolean(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getBoolean(key, false);
    }

    public static void saveSettings(Context context, String key, float value) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putFloat(key, value);
        editor.commit();
    }

    public static float getSettingsFloatValueForKey(Context context, String key, float defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getFloat(key, defaultValue);
    }

    public static int getSettingsIntValueForKey(Context context, String key, int defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
        return prefs.getInt(key, defaultValue);
    }

    public static void saveSettings(Context context, String key, long value) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(key, value);
        editor.commit();
    }

    public static long getSettingsForLong(Context context, String key) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(
                    Utils.SHARED_PREF, Context.MODE_PRIVATE);
            return prefs.getLong(key, 0L);
        }
        catch (Exception ex) {
            return 0L;
        }
    }

    public static void saveSettings(Context context, String key, String value) {
        SharedPreferences prefs = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static void updateCellTextColorBasedOnConnection(Context activity,
                                                            TextView textview) {
        if (BluetoothUtils.mConnected) {
            textview.setTextColor(activity.getResources().getColor(
                    R.color.black));
        } else {
            textview.setTextColor(activity.getResources().getColor(
                    R.color.gray_medium));
        }
    }

    public static Dialog showCalibrationConfirmationPage(Context context,
                                                       int title, Spanned confirm_body,
                                                       final OnClickListener submitOnClickListener) {

        final Dialog dialog = new Dialog(context, R.style.PickerDialog);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_confirm_calibration, null);

        // Dialog title
        TextView titleTextView = (TextView) view.findViewById(R.id.title);
        titleTextView.setText(title);

        // Dialog body
        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(confirm_body);

        // Dialog buttons
        TextView cancelText = (TextView) view.findViewById(R.id.cancel);
        cancelText.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        TextView okText = (TextView) view.findViewById(R.id.ok);
        okText.setText(context.getString(R.string.submit));
        okText.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                submitOnClickListener.onClick(v);
                dialog.dismiss();
            }
        });

        dialog.setContentView(view);
        dialog.show();

        return dialog;
    }

    public static String replaceTransmitterNameFromString(String string_in,
                                                          String transmitterName) {
        if (transmitterName == null)
            return string_in.replace("(%@)", "(" + Utils.NotAvailable + ")");
        return string_in.replace("(%@)", "(" + transmitterName + ")");
    }

    public static String replaceGlucoseSettingLevelFromString(String string_in,
                                                              int glucoseSettingLevel) {

        return String.format(string_in, glucoseSettingLevel);
    }

    public static String replaceCalibrateButtonStringFromString(
            String string_in, Context context) {
        return string_in.replace("\'%@\'",
                "\'" + context.getString(R.string.calibrate) + "\'");
    }

    public static String replaceOutOfRangeThresholdString(Context context,
                                                          String string_in, int stringID) {
        String str_out = "";

        if (stringID == R.string.out_of_range_low_glucose_alarm_message) {
            str_out = string_in.replace("%@",
                    getGlucoseLevelString(context, GLUCOSE_VALID_MIN));
        } else {
            str_out = string_in.replace("%@",
                    getGlucoseLevelString(context, GLUCOSE_VALID_MAX));
        }

        return str_out;
    }

    public static String replaceUnknownErrorCodeString(Context context,
                                                       String string_in, int unknownCode) {
        String str_out = "";

        str_out = string_in.replace("%d", String.valueOf(unknownCode));

        return str_out;
    }

    public static void makeToast(Context c, String msg) {
        if (showToast) {
            Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
        }
    }

    public static void makeAlwaysShownToast(Context c, String msg) {
        Toast.makeText(c, msg, Toast.LENGTH_LONG).show();
    }

    public static void turnOffClinicalModeIfNeeded(Context context, BluetoothServiceCommandClient bluetoothServiceCommandClient) {
        if (BluetoothUtils.mConnected) {
            SharedPreferences prefs = context.getSharedPreferences(
                    Utils.SHARED_PREF, Context.MODE_PRIVATE);

            if (prefs.contains(Utils.prefClinicalModeStartTime)
                    && prefs.contains(Utils.prefClinicalModeDuration)
                    && prefs.contains(Utils.prefClinicalMode)) {
                boolean lastSavedClinicalMode = prefs.getBoolean(
                        Utils.prefClinicalMode, false);

                if (lastSavedClinicalMode == true) {

                    // Get the last saved start time
                    long lastSavedStartTimeMillis = prefs.getLong(
                            Utils.prefClinicalModeStartTime, -1);
                    Calendar calendar = Calendar.getInstance();
                    long timezoneOffset = Utils.getTimeZoneOffset(calendar);
                    lastSavedStartTimeMillis += timezoneOffset;

                    // Get the last saved clinical mode duration
                    long lastSavedDuration = prefs.getLong(
                            Utils.prefClinicalModeDuration, -1);

                    long durationExpiredMillis = lastSavedStartTimeMillis
                            + lastSavedDuration;
                    long nowMillis = calendar.getTimeInMillis();

                    Log.d("Clinical", "last saved start: "
                            + lastSavedStartTimeMillis
                            + " ; last saved duration: " + lastSavedDuration
                            + " | duration expired at: "
                            + durationExpiredMillis + " ; NOW: " + nowMillis);

                    if (durationExpiredMillis <= nowMillis) {
                        bluetoothServiceCommandClient.postWriteClinicalModeRequest(false);
                        Log.d("Clinical", "Should TURN OFF");
                    } else {
                        Log.d("Clinical", "Still ON: " +
                                (durationExpiredMillis - nowMillis)
                                + " left");
                    }
                }
            }
        }
    }

    public static int getNotificationIconForGlucose(int glucoseLevel) {

        if (glucoseLevel < Utils.GLUCOSE_ALARM_LEVEL_LOW || glucoseLevel > Utils.GLUCOSE_ALARM_LEVEL_HIGH)
//            return R.drawable.alarm_icon_red;
            return R.drawable.alert_icon_yellow; /** #3214 */
        else if (glucoseLevel < Utils.GLUCOSE_TARGET_LOW || glucoseLevel > Utils.GLUCOSE_TARGET_HIGH)
            return R.drawable.alert_icon_yellow;
        else
            return R.drawable.within_targets_icon_green;
    }

    public static int getTextColorForGlucose(int glucoseLevel) {

        if (glucoseLevel < Utils.GLUCOSE_ALARM_LEVEL_LOW || glucoseLevel > Utils.GLUCOSE_ALARM_LEVEL_HIGH)
            return R.color.graph_white;
        else
            return R.color.graph_line_black;

    }

    public static int getBackgroundColorForGlucose(int glucoseLevel) {

        if (glucoseLevel < Utils.GLUCOSE_ALARM_LEVEL_LOW || glucoseLevel > Utils.GLUCOSE_ALARM_LEVEL_HIGH)
            return R.color.graph_red;
        else if (glucoseLevel < Utils.GLUCOSE_TARGET_LOW || glucoseLevel > Utils.GLUCOSE_TARGET_HIGH)
            return R.color.graph_yellow;
        else
            return R.color.graph_green;

    }

    public static int getGlucoseLevelAlertText(int glucoseLevel) {

        if (glucoseLevel > Utils.GLUCOSE_ALARM_LEVEL_HIGH) {
            return R.string.glucose_above_high_alert_level; /** #3214 */
        } else if (glucoseLevel < Utils.GLUCOSE_ALARM_LEVEL_LOW) {
            return R.string.glucose_below_low_alert_level; /** #3214 */
        } else if (glucoseLevel > Utils.GLUCOSE_TARGET_HIGH
                && glucoseLevel <= Utils.GLUCOSE_ALARM_LEVEL_HIGH) {
            return R.string.glucose_above_high_target_level;
        } else if (glucoseLevel >= Utils.GLUCOSE_ALARM_LEVEL_LOW
                && glucoseLevel < Utils.GLUCOSE_TARGET_LOW) {
            return R.string.glucose_below_low_target_level;
        } else if (glucoseLevel <= Utils.GLUCOSE_TARGET_HIGH
                && glucoseLevel >= Utils.GLUCOSE_TARGET_LOW) {
            return R.string.glucose_within_target_levels;
        }

        return -1;
    }

    public static void printLongLog(String TAG, String veryLongString) {
        int maxLogSize = 1000;
        for (int i = 0; i <= veryLongString.length() / maxLogSize; i++) {
            int start = i * maxLogSize;
            int end = (i + 1) * maxLogSize;
            end = end > veryLongString.length() ? veryLongString.length() : end;
            Log.d(TAG, veryLongString.substring(start, end));
        }
    }

    public static int getSensorGlucoseAlertRecordTypeID(EVENT_TYPE eType, int customField,
                                                        int customField2, int unknownErrorCode) {
        int badID = -1;

        if ((eType == EVENT_TYPE.ALARM_EVENT) || (eType == EVENT_TYPE.ALERT_EVENT)) {
            if (customField2 == 0 || customField2 == 1) {
                ALERT_TYPE aType = ALERT_TYPE.values()[customField2];

                if ((eType == EVENT_TYPE.ALARM_EVENT) && (aType == ALERT_TYPE.LOW_GLUCOSE)) {
                    // Low Gluocse Alarm Asserted
                    return 0x00;
                }

                if ((eType == EVENT_TYPE.ALARM_EVENT) && (aType == ALERT_TYPE.HIGH_GLUCOSE)) {
                    // High Gluocse Alarm Asserted
                    return 0x01;
                }

                if ((eType == EVENT_TYPE.ALERT_EVENT) && (aType == ALERT_TYPE.LOW_GLUCOSE)) {
                    // Low Gluocse Alert Asserted
                    return 0x02;
                }

                if ((eType == EVENT_TYPE.ALERT_EVENT) && (aType == ALERT_TYPE.HIGH_GLUCOSE)) {
                    // High Gluocse Alert Asserted
                    return 0x03;
                }
            } else {
                return badID;
            }
        }

        if (eType == EVENT_TYPE.RATE_ALERT_EVENT_FALLING) {
            // Falling Rate Alert Asserted
            return 0x04;
        }

        if (eType == EVENT_TYPE.RATE_ALERT_EVENT_RISING) {
            // Rising Rate Alert Alert Asserted
            return 0x05;
        }

        if (eType == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING) {
            // Predictive Low Glucose Alert Asserted
            return 0x06;
        }

        if (eType == EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING) {
            // Predictive High Glucose Alert Asserted
            return 0x07;
        }

        if (eType == EVENT_TYPE.CALIBRATE_NOW_EVENT) {
            // Calibration Notification Asserted
            return 0x09;
        }

        if (eType == EVENT_TYPE.CALIBRATE_GRACE_EVENT) {
            // Calibration Grace Period Alert Asserted
            return 0x0A;
        }

        if (eType == EVENT_TYPE.CALIBRATE_EXPIRED_EVENT) {
            // Calibration Expired Alarm Asserted
            return 0x0B;
        }

        if (eType == EVENT_TYPE.NOTIFICATION_EVENT_RED) {
            if (unknownErrorCode != -1) { // Unknow Error Code
                return badID;
            } else {

                TransmitterMessageCode TMC = TransmitterMessageCode.values()[customField];

                if ((eType == EVENT_TYPE.NOTIFICATION_EVENT_RED)
                        && (TMC == TransmitterMessageCode.SeriouslyLowAlarm)) {
                    // Out of Range Low Glucose Asserted
                    return 0x0C;
                }

                if ((eType == EVENT_TYPE.NOTIFICATION_EVENT_RED)
                        && (TMC == TransmitterMessageCode.SeriouslyHighAlarm)) {
                    // Out of Range High Glucose Asserted
                    return 0x0D;
                }
            }
        }

        return badID;
    }

    public static int countOccurrancesInString(String str, String findStr) {
        int lastIndex = 0;
        int count = 0;

        while (lastIndex != -1) {

            lastIndex = str.indexOf(findStr, lastIndex);

            if (lastIndex != -1) {
                count++;
                lastIndex += findStr.length();
            }
        }

        return count;
    }

    public static void setScreenWidthandHeight(Activity activity) {
        if (activity == null) {
            return;
        }

        if (Utils.screenHeight != 0 && Utils.screenWidth != 0) {
            return;
        }

        // Get the device screen size
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        Utils.screenWidth = metrics.widthPixels;
        Utils.screenHeight = metrics.heightPixels;
    }

    public static void CopyAssetsFile(String filename, String folderName,Context context) {

        System.out.println("File name => " + filename);
        InputStream in = null;
        OutputStream out = null;
        try {
            if(folderName.length() >0)
                in = context.getAssets().open(folderName+ "/" + filename);   // if files resides inside the "Files" directory itself
            else
                in = context.getAssets().open(filename);   // if files resides inside the "Files" directory itself
            out = new FileOutputStream(context.getFilesDir().toString() +"/" + filename);
            copyFile(in, out);
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
        } catch(Exception e) {
            Log.e("tag", e.getMessage());
        }
    }

    private static void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
    }

    public static String getLatestFile(String fileName, String URL, Context context) {

        String result = null;
        try {

            DefaultHttpClient client = new DefaultHttpClient();
            // register ntlm auth scheme
            client.getAuthSchemes().register("ntlm", new NTLMSchemeFactory());
            client.getCredentialsProvider().setCredentials(
                    // Limit the credentials only to the specified domain and port
                    new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
                    // Specify credentials, most of the time only user/pass is needed
                    new NTCredentials(Utils.INTRANET_UN, Utils.INTRANET_PW, "", "")
            );

            HttpGet httpget = new HttpGet(URL+fileName);

            HttpResponse response;

            MLCheckResult checkResult = null;
            try {
                response = client.execute(httpget);
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    // A Simple JSON Response Read
                    InputStream instream = entity.getContent();
                    OutputStream out = null;
                    if(fileName.toLowerCase().contains("pdf")) {
                        out = new FileOutputStream(Environment.getExternalStorageDirectory().toString() + "/Senseonics/" + fileName);
                    }else
                    {
                        out = new FileOutputStream(context.getFilesDir().toString() + "/" + fileName);
                    }


                    Log.i("Files Dir", "Download:" + context.getFilesDir().toString() +"/" + fileName);
                    copyFile(instream, out);
                    result= convertStreamToString(instream);
                    instream.close();
                }
                return result;
            } catch (ClientProtocolException e) {
            } catch (SocketTimeoutException e) {
                checkResult = MLCheckResult.Timeout;
            } catch (ConnectTimeoutException e) {
                checkResult = MLCheckResult.Timeout;
            } catch (IOException e) {
                checkResult = MLCheckResult.ServerError;
                e.printStackTrace();
            }
            if (checkResult != MLCheckResult.None){
                return "-1";
            }

        } catch (Exception e) {
            return "-1";
        }

        return result;
    }


    public static String convertStreamToString(InputStream is) {
	    /*
	     * To convert the InputStream to String we use the BufferedReader.readLine()
	     * method. We iterate until the BufferedReader return null which means
	     * there's no more data to read. Each line will appended to a StringBuilder
	     * and returned as String.
	     */
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public static boolean checkIfFirstRun(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
        if (prefs.contains(Utils.prefFirstRun)) {
            return false;
        }
        return true;
    }

    public static void saveFirstRunForEULA(Context context) {
        Utils.saveSettings(context, Utils.prefFirstRunForEULA, false);
    }

    public static boolean checkIfFirstRunForEULA(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
        if (prefs.contains(Utils.prefFirstRunForEULA)) {
            return false;
        }
        return true;
    }

    public static boolean checkIfLoggedIn(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);
        if (!prefs.contains(Utils.prefAccountIsLoggedIn)) {
            return false;
        }
        else {
            return prefs.getBoolean(Utils.prefAccountIsLoggedIn, false);
        }
    }

    public static int[] convertHourFromGMTtoLocal(int hour, int minute)
    {
        // Get in GMT time
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
        long timeMillis = calendar.getTimeInMillis();

        // Set to local Time
        calendar.setTimeZone(TimeZone.getDefault());
        calendar.setTimeInMillis(timeMillis);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);

        return new int[]{hour, minute};
    }

    public static int[] convertHourFromLocaltoGMT(int hour, int minute)
    {
        // Get in Local time
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.setTimeZone(TimeZone.getDefault());
        long timeMillis = calendar.getTimeInMillis();

        // Set to GMT Time
        calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
        calendar.setTimeInMillis(timeMillis);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);

        return new int[]{hour, minute};
    }

    public static boolean isValidSensorID(long fullSensorID)
    {
        return (fullSensorID != Utils.unlinkedSensorValue) && (fullSensorID != 0);
    }
}
