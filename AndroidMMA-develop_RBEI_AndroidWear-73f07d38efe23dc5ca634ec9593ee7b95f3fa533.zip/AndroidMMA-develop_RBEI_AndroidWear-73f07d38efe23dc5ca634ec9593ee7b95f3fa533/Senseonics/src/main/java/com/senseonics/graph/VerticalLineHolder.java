package com.senseonics.graph;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.support.v4.view.GestureDetectorCompat;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import com.senseonics.graph.GraphView.LineScrollManager;

public class VerticalLineHolder extends View {

    private final boolean shouldHandleTouch;
    private Rect verticalLineRect;
    private boolean showVerticalLine;
    private float verticalLinePositionX;
    private Paint verticalLinePaint;
    private LineScrollManager scrollManager;
    private GestureDetectorCompat gestureDetector;
    private VerticalLineManager verticalLineManager;

    public VerticalLineHolder(Context context, int width, int height) {
        this(context, width, height, width / 5);
    }

    public VerticalLineHolder(Context context, int width, int height, int padding) {
        super(context);

        verticalLinePaint = new Paint();
        verticalLinePaint.setColor(Color.BLACK);
        verticalLinePaint.setStyle(Style.STROKE);
        verticalLinePaint.setStrokeWidth(3);

        verticalLineRect = new Rect(padding, 0, width - padding, height);
        showVerticalLine = false;

        verticalLineManager = new VerticalLineManager() {
            @Override
            public void drawVerticalLine(float positionX) {
                VerticalLineHolder.this.drawVerticalLine(positionX);
            }

            @Override
            public void hideVerticalLine() {
                VerticalLineHolder.this.hideVerticalLine();
            }

            @Override
            public boolean verticalLineIsVisible() {
                return VerticalLineHolder.this.verticalLineIsVisible();
            }
        };

        shouldHandleTouch = padding == 0;
        gestureDetector = new GestureDetectorCompat(context, new GestureDetector.SimpleOnGestureListener() {

            @Override
            public void onLongPress(MotionEvent e) {
                drawVerticalLine(e.getX());
            }
        });
    }


    @Override
    protected void onDraw(Canvas canvas) {
        if (showVerticalLine) {
            canvas.drawLine(verticalLinePositionX, verticalLineRect.top,
                    verticalLinePositionX, verticalLineRect.bottom,
                    verticalLinePaint);
        }
        super.onDraw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (shouldHandleTouch) {

            gestureDetector.onTouchEvent(event);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    hideVerticalLine();
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (verticalLineIsVisible()) {
                        drawVerticalLine(event.getX());
                    }
                    break;

            }
            return true;
        }

        return super.onTouchEvent(event);
    }

    public boolean verticalLineIsVisible() {
        return showVerticalLine;
    }

    public void drawVerticalLine(float positionX) {

        if (positionX >= verticalLineRect.left
                && positionX <= verticalLineRect.right) {
            verticalLinePositionX = positionX;
            showVerticalLine = true;
            scrollManager.stopScroll();
            invalidate();

        } else {

            if (positionX < verticalLineRect.left) {
                verticalLinePositionX = verticalLineRect.left;
                scrollManager.scrollLeft();
            }

            if (positionX > verticalLineRect.right) {
                verticalLinePositionX = verticalLineRect.right;
                scrollManager.scrollRight();
            }

            showVerticalLine = true;
            invalidate();
        }
        scrollManager.positionChanged(verticalLinePositionX);
    }

    public void hideVerticalLine() {
        scrollManager.stopScroll();
        showVerticalLine = false;
        scrollManager.actionCancelled();
        invalidate();
    }

    public void setScrollManager(LineScrollManager scrollManager) {
        this.scrollManager = scrollManager;
    }

    public VerticalLineManager getVerticalLineManager() {
        return verticalLineManager;
    }
}
