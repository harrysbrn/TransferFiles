package com.senseonics.gen12androidapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;

import com.senseonics.bluetoothle.BluetoothService;

import javax.inject.Inject;

public class BluetoothServiceClient {
  private BluetoothServiceConnection bluetoothServiceConnection;

  private boolean isBound = false;

  @Inject BluetoothServiceClient(BluetoothServiceConnection bluetoothServiceConnection) {
    this.bluetoothServiceConnection = bluetoothServiceConnection;
  }

  public void bind(Activity activity) {
    Intent intent = new Intent(activity, BluetoothService.class);
    isBound = activity.bindService(intent, bluetoothServiceConnection, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT);
  }

  public void unbind(Activity activity) {
    if (bluetoothServiceConnection.isConnected() && isBound) {
      activity.unbindService(bluetoothServiceConnection);
      isBound = false;
    }
  }

  @Nullable public BluetoothService getService() {
    return bluetoothServiceConnection.getBluetoothService();
  }
}
