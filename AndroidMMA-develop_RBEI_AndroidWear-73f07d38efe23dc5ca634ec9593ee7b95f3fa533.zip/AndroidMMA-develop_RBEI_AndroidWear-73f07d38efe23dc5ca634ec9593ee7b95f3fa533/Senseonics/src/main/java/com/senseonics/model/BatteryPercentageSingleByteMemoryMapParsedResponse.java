package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class BatteryPercentageSingleByteMemoryMapParsedResponse implements  SingleByteMemoryMapParsedResponse {

    @Inject
    public BatteryPercentageSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.batteryPercentageAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {

        model.setBatteryLevel(BATTERY_LEVEL.fromStrength(data));

    }


}
