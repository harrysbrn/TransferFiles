package com.senseonics.bluetoothle;

import java.util.List;

public interface DiscoverCallback {

    void onDevice(List<Transmitter> discoveredTransmitters);
    void onDiscoveryTimeout();
}
