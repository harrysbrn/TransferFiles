package com.senseonics.model.StateModelUpload;

public class DMSStateModelSensorInfo {
    private String SensorID; // *
    private String LinkedSensorID; // same as SensorID
    private String UnlinkedSensorID;
    private String SensorInsertionDate;
    private DMSStateModelUserInfo UserInfo;
    private String MEP;
    private String MSP;
    private boolean SensorActive;

    public DMSStateModelSensorInfo(
            String sensorID,
            String linkedSensorID,
            String unlinkedSensorID,
            String sensorInsertionDate,
            DMSStateModelUserInfo userInfo,
            String MEP,
            String MSP,
            boolean sensorActive
    ) {
        LinkedSensorID = linkedSensorID;
        this.MEP = MEP;
        this.MSP = MSP;
        SensorActive = sensorActive;
        SensorID = sensorID;
        SensorInsertionDate = sensorInsertionDate;
        UnlinkedSensorID = unlinkedSensorID;
        UserInfo = userInfo;
    }

    public String getLinkedSensorID() {
        return LinkedSensorID;
    }

    public String getMEP() {
        return MEP;
    }

    public String getMSP() {
        return MSP;
    }

    public boolean isSensorActive() {
        return SensorActive;
    }

    public String getSensorID() {
        return SensorID;
    }

    public String getSensorInsertionDate() {
        return SensorInsertionDate;
    }

    public String getUnlinkedSensorID() {
        return UnlinkedSensorID;
    }

    public DMSStateModelUserInfo getUserInfo() {
        return UserInfo;
    }
}
