package com.senseonics.events;

import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;

public class GlucoseEventPoint extends EventPoint  {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private int calibrationFlag = 0;

    public GlucoseEventPoint(Calendar calendar, int glucoseLevel, int calibrationFlag) {
        super(calendar, glucoseLevel);
        setEventType(EVENT_TYPE.GLUCOSE_EVENT);
        setCalibrationFlag(calibrationFlag);
    }

    public GlucoseEventPoint(Calendar calendar, int glucoseLevel, int calibrationFlag, String notes) {
        super(calendar, glucoseLevel);
        setEventType(EVENT_TYPE.GLUCOSE_EVENT);
        setCalibrationFlag(calibrationFlag);
        setNotes(notes);
    }

    public GlucoseEventPoint(int databaseId, Calendar calendar, int glucoseLevel, int calibrationFlag) {
        super(databaseId, calendar, glucoseLevel);
        setEventType(EVENT_TYPE.GLUCOSE_EVENT);
        setCalibrationFlag(calibrationFlag);
    }

    public GlucoseEventPoint(int databaseId, Calendar calendar, int glucoseLevel, int calibrationFlag, String notes) {
        super(databaseId, calendar, glucoseLevel);
        setEventType(EVENT_TYPE.GLUCOSE_EVENT);
        setCalibrationFlag(calibrationFlag);
        setNotes(notes);
    }

    public int getCalibrationFlag() {
        return calibrationFlag;
    }

    public void setCalibrationFlag(int calibrationFlag) {
        this.calibrationFlag = calibrationFlag;
    }

}
