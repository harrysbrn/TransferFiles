package com.senseonics.bluetoothle;

import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

import javax.inject.Inject;
import javax.inject.Provider;

public class CommandRequestTimer {
    static final int DELAY_FOR_FIRST_COMMAND_AS_TAKEN_FROM_ORIGINAL_CODE = 1000;
    public static final int SIGNAL_STRENGTH_REQUEST_PERIOD = 60 * 1000;
    public static final int SIGNAL_STRENGTH_REQUEST_DELAY = 0;
    public static final int BATTERY_LEVEL_REQUEST_DELAY = 0;
    public static final int BATTERY_LEVEL_REQUEST_PERIOD = 60 * 1000;
    public static final int GLUCOSE_ALERT_REQUEST_PERIOD = 60 * 1000;
    public static final int GLUCOSE_DATA_REQUEST_PERIOD = 60 * 1000;
    public static final int CALIBRATION_PHASE_REQUEST_PERIOD = 60 * 1000;

    private Timer timer;
    private RequestBlockingSet requestBlockingSet;
    private boolean haveReceivedE9 = false;
    private Provider<Timer> timerProvider;

    @Inject
    public CommandRequestTimer(Provider<Timer> timerProvider, RequestBlockingSet requestBlockingSet) {
        this.timerProvider = timerProvider;
        this.requestBlockingSet = requestBlockingSet;
    }

    public void setupTaskSchedule() {
        haveReceivedE9 = false;
        Log.i(CommandRequestTimer.class.getSimpleName(), "setupTaskSchedule");
        timer = timerProvider.get();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(!haveReceivedE9) {
                    Log.i(CommandRequestTimer.class.getSimpleName(), "going to send 0x69");
                    Log.d("Bluetooth", "----- CommRequestTimer going to send 0x69 | queue size:" + requestBlockingSet.size());
                    requestBlockingSet.put(Request.saveBondingInformation());
                }

            }
        }, DELAY_FOR_FIRST_COMMAND_AS_TAKEN_FROM_ORIGINAL_CODE);
    }

    public void scheduleIntervalCommands() {
        Log.i(CommandRequestTimer.class.getSimpleName(), "scheduleIntervalCommands");
        timer = timerProvider.get();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.d(CommandRequestTimer.class.getSimpleName(), "task for signal strength");
                requestBlockingSet.put(Request.readSignalStrengthRequest());
            }
        }, SIGNAL_STRENGTH_REQUEST_DELAY, SIGNAL_STRENGTH_REQUEST_PERIOD);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.d(CommandRequestTimer.class.getSimpleName(), "task for battery level");
                requestBlockingSet.put(Request.readBatteryLevelRequest());
            }
        }, BATTERY_LEVEL_REQUEST_DELAY, BATTERY_LEVEL_REQUEST_PERIOD);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.d(CommandRequestTimer.class.getSimpleName(), "task for phase info.");
                requestBlockingSet.put(Request.currentCalibrationPhase());
                requestBlockingSet.put(Request.completedCalibrationsCount());
            }
        }, 0, CALIBRATION_PHASE_REQUEST_PERIOD);


        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.d(CommandRequestTimer.class.getSimpleName(), "task for glucose alert");
                requestBlockingSet.put(Request.readGlucoseAlertsAndStatus());
            }
        }, 0, GLUCOSE_ALERT_REQUEST_PERIOD);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.d(CommandRequestTimer.class.getSimpleName(), "task for glucose data");

                /** #3194 */
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_1));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_2));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_3));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_4));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_5));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_6));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_7));
                requestBlockingSet.put(Request.readRawDataValue(MemoryMap.RAW_DATA_INDEX.RAW_DATA_INDEX_8));

                requestBlockingSet.put(Request.readGlucoseData());
            }
        }, 0, GLUCOSE_DATA_REQUEST_PERIOD);
    }

    public void setupForAutoReconnect() {
        cancel();
        requestBlockingSet.clear();
        requestBlockingSet.put(Request.saveBondingInformation());
    }

    public void receivedE9() {
        this.haveReceivedE9 = true;
    }

    public boolean haveReceivedE9() {
        return this.haveReceivedE9;
    }

    public void notReceivedE9() {
        this.haveReceivedE9 = false;
    }

    public void cancel() {
        if (timer != null) {
            timer.cancel();
            timer.purge();
        }
    }
}
