package com.senseonics.events;

public class RefreshGraphEvent { /** #3224 */
    public RefreshGraphEvent() { }
}
