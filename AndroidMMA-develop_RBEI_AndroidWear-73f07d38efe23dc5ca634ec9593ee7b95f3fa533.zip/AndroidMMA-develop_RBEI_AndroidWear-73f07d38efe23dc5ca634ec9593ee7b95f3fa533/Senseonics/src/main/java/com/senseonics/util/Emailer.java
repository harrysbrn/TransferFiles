package com.senseonics.util;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import com.senseonics.gen12androidapp.BitmapSenderActivity;

import javax.inject.Inject;

public class Emailer {

    public static final String EMAIL_TITLE = "EMAIL_TITLE";
    public static final String EMAIL_BODY = "EMAIL_BODY";
    public static final String EMAIL_BITMAP_PATH = "EMAIL_BITMAP_PATH";
    private Activity activity;
    private BitmapFileUtil bitmapFileUtil;

    @Inject
    public Emailer(Activity activity, BitmapFileUtil bitmapFileUtil) {
        this.activity = activity;
        this.bitmapFileUtil = bitmapFileUtil;
    }

    public void formShareEmail(final String emailTitle, final String emailBody, final View contentLayout) {
        Log.i("Bitmap", "Title:" + emailTitle + ", Body:" + emailBody);

        if (bitmapFileUtil.saveBitmapOfView(contentLayout, getInternalScreenshotPath())) {
            activity.startActivity(
                    new Intent(activity, BitmapSenderActivity.class) {{
                        putExtra(EMAIL_TITLE, emailTitle);
                        putExtra(EMAIL_BODY, emailBody);
                        putExtra(EMAIL_BITMAP_PATH, getInternalScreenshotPath());
                    }}
            );
        }
    }

    private String getInternalScreenshotPath() {
        return activity.getFilesDir() + "/screenshot.png";
    }
}
