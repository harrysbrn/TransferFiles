package com.senseonics.gen12androidapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.senseonics.fragments.GlucoseUnitFragment;
import com.senseonics.util.Utils;

public class GlucoseUnitActivity extends BaseActivity {

	private GlucoseUnitFragment glucoseUnitFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_simple_fragment, null),
				parms_content);

        // Configure the status header
        statusBarDrawerButton.setVisibility(View.GONE);

		// Configure the navigation bar
		naviBarTitle.setVisibility(View.GONE);
        naviBarTitleImageView.setVisibility(View.VISIBLE);
        naviBarTitleImageView.setImageResource(R.drawable.setup_04);
        naviBarLayout.setVisibility(View.VISIBLE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);
        naviBarRightItemTextView.setVisibility(View.VISIBLE);
        naviBarRightItemTextView.setText(getResources().getString(R.string.finish));

        naviBarRightItemTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
				if (glucoseUnitFragment != null) {
					if (glucoseUnitFragment.radioMgDLType != null && glucoseUnitFragment.radioMmolType != null) {
						/** Save the unit upon pressing Finish button */
						if (glucoseUnitFragment.radioMgDLType.isChecked()) {
							Utils.currentGlucoseUnit = Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL;
							Utils.saveSettings(GlucoseUnitActivity.this, Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal());
						}
						else {
							Utils.currentGlucoseUnit = Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L;
							Utils.saveSettings(GlucoseUnitActivity.this, Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L.ordinal());
						}
					}
				}

				startActivityForResult(new Intent(GlucoseUnitActivity.this,
						MainActivity.class), Utils.WELCOME_UNIT_SELECTION_RESULT);
            }
        });

        glucoseUnitFragment = new GlucoseUnitFragment();

		getFragmentManager().beginTransaction()
				.replace(R.id.fragment, glucoseUnitFragment)
				.commitAllowingStateLoss();

		if (!Utils.checkIfFirstRun(this)) {
			setResult(Utils.WELCOME_UNIT_SELECTION_RESULT);
			finish();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Result coming back from the unit selection page when the Finish button is pressed
		if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
			setResult(resultCode);
			finish();
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

}
