package com.senseonics.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;

import java.util.ArrayList;

public class StatisticsAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<Statistics> items;
	private LayoutInflater inflater;
	private int whiteColor, grayColor;

	public StatisticsAdapter(Context context, ArrayList<Statistics> items) {
		this.context = context;
		inflater = LayoutInflater.from(context);
		this.items = items;

		grayColor = context.getResources().getColor(R.color.divider_color);
		whiteColor = context.getResources().getColor(android.R.color.transparent);
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {

		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;

		if (convertView == null) {

			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.statistics_list_item,
					parent, false);
			holder.startTextView = (TextView) convertView
					.findViewById(R.id.start);
			holder.avgTextView = (TextView) convertView.findViewById(R.id.avg);
			holder.lowTextView = (TextView) convertView.findViewById(R.id.low);
			holder.highTextView = (TextView) convertView
					.findViewById(R.id.high);
			holder.countTextView = (TextView) convertView
					.findViewById(R.id.count);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		if (position % 2 == 0) {
			convertView.setBackgroundColor(whiteColor);
		} else {
			convertView.setBackgroundColor(grayColor);
		}

		Statistics statistics = items.get(position);
		holder.startTextView.setText(Utils.getStatisticsString(context,
				statistics.getMealType()));
		int avarage = statistics.getAverage();

		if (avarage != -1) {
			String avarageString = Utils.getGlucoseLevelValue(avarage);
			holder.avgTextView.setText(avarageString);
		} else
			holder.avgTextView.setText(Utils.unknownString);

		int low = statistics.getLow();
		if (low != -1){
			String lowString = Utils.getGlucoseLevelValue(low);
			holder.lowTextView.setText(lowString);
		}else
			holder.lowTextView.setText(Utils.unknownString);

		int high = statistics.getHigh();
		if (high != -1){
			String highString = Utils.getGlucoseLevelValue(high);
			holder.highTextView.setText(highString);
		}else
			holder.highTextView.setText(Utils.unknownString);

		double count = statistics.getCount();
		if (count != -1){
			holder.countTextView.setText(Utils.getGlucoseLevelValue((float)count));
		}else
			holder.countTextView.setText(Utils.unknownString);

		return convertView;
	}

	private class ViewHolder {
		public TextView startTextView, avgTextView, lowTextView, highTextView, countTextView;
	}

}
