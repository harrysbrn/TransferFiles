package com.senseonics.gen12androidapp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.common.base.Objects;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.ModelChangedLinkedSensorIdEvent;
import com.senseonics.events.ModelChangedSensorInsertDateTimeEvent;
import com.senseonics.events.ModelChangedUnLinkedSensorIdEvent;
import com.senseonics.util.Utils;

import java.util.TimeZone;

public class MySensorActivity extends BaseActivity {

    private LinearLayout parentLayout;
    private TextView serialNumberTextView, insertionDateTextView, insertionTimeTextView,detectedserialNumberTextView, serialNumberTitleView, insertionDateTitleView, insertionTimeTitleView,detectedserialNumberTitleView;

    private ProgressDialog progressDialog;
    private boolean sensorLinkedSensorArrived = false;
    private boolean sensorUnLinkedSensorArrived = false;
    private boolean sensorInsertionDateAndTimeArrived = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.activity_mysensor, null),
                parms_content);

        // Configure the navigation bar
        naviBarTitle.setText(R.string.my_sensor);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        parentLayout = (LinearLayout) findViewById(R.id.layout);
        serialNumberTextView = (TextView) findViewById(R.id.serialNumber);
        insertionDateTextView = (TextView) findViewById(R.id.insertionDate);
        insertionTimeTextView = (TextView) findViewById(R.id.insertionTime);
        detectedserialNumberTextView= (TextView) findViewById(R.id.detectedSerialNumber);

        serialNumberTitleView = (TextView) findViewById(R.id.serialNumberText);
        insertionDateTitleView = (TextView) findViewById(R.id.insertionDateText);
        insertionTimeTitleView = (TextView) findViewById(R.id.insertionTimeText);
        detectedserialNumberTitleView= (TextView) findViewById(R.id.detectedSerialNumberText);


        progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(true);
    }

    @Override
    protected void onResume() {
        Log.d(MySensorActivity.class.getSimpleName(), "onResume");
        refreshSensorInfo();
        super.onResume();
    }

    private void refreshSensorInfo() {
        progressDialog.show();

        sensorLinkedSensorArrived =false;
        sensorInsertionDateAndTimeArrived = false;
        sensorUnLinkedSensorArrived =false;
        loadDataFromTransmitter();
    }

    public void loadDataFromTransmitter() {
        updateViews();

        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            BluetoothUtils.initMySensorRequests(getService(), sensorLinkedSensorArrived, sensorInsertionDateAndTimeArrived,sensorUnLinkedSensorArrived);
        }
        else {
            progressDialog.dismiss();
        }
    }

    private void updateViews() {
        showSerialNumber();
        showInsertionDate();
        showInsertionTime();
        showDetectedSerialNumber();
    }

    public void updateDisplay() {
        if (checkIfAllDataLoaded() ) {
            updateViews();
            progressDialog.dismiss();
        }
    }

    private void showSerialNumber() {
        serialNumberTextView.setText(Objects.firstNonNull(transmitterStateModel.getLinkedSensorId(), Utils.unknownString));

        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                serialNumberTextView);
        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                serialNumberTitleView);
    }

    private void showInsertionDate() {
        if (transmitterStateModel.getSensorInsertionDateAndTime() != null) {
            insertionDateTextView.setText(Utils.formatDateOnlyForTimeZone(transmitterStateModel.getSensorInsertionDateAndTime(),
                    TimeZone.getDefault()));
        }else {
            insertionDateTextView.setText(Utils.unknownString);
        }

        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                insertionDateTextView);
        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                insertionDateTitleView);
    }

    private void showInsertionTime() {
        if (transmitterStateModel.getSensorInsertionDateAndTime() != null) {
            insertionTimeTextView.setText(Utils.getTime24HrFormat(transmitterStateModel.getSensorInsertionDateAndTime(),
                    TimeZone.getDefault(), MySensorActivity.this));
        }else {
            insertionTimeTextView.setText(Utils.unknownString);
        }

        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                insertionTimeTextView);
        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                insertionTimeTitleView);
    }

    private void showDetectedSerialNumber() {
        if (transmitterStateModel.getUnLinkedSensorId() != null) {
            detectedserialNumberTextView.setText(transmitterStateModel.getUnLinkedSensorId());
        } else {
            detectedserialNumberTextView.setText(Utils.unknownString);
        }

        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                detectedserialNumberTextView);
        Utils.updateCellTextColorBasedOnConnection(MySensorActivity.this,
                detectedserialNumberTitleView);
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        refreshSensorInfo();
        super.onEventMainThread(event);
    }

    public void onEventMainThread(ModelChangedLinkedSensorIdEvent event) {
        sensorLinkedSensorArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedUnLinkedSensorIdEvent event) {
        sensorUnLinkedSensorArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedSensorInsertDateTimeEvent event) {
        sensorInsertionDateAndTimeArrived = true;
        updateDisplay();
    }

    private boolean checkIfAllDataLoaded() {
        boolean result = false;

        if(sensorInsertionDateAndTimeArrived && sensorLinkedSensorArrived && sensorUnLinkedSensorArrived) {
            result = true;
        }

        return result;
    }
}
