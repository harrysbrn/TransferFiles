package com.senseonics.gen12androidapp;

import android.app.IntentService;

import com.senseonics.bluetoothle.ServiceModule;

import java.util.ArrayList;
import java.util.List;

import dagger.ObjectGraph;

public abstract class BaseInjectedIntentService extends IntentService {
  public BaseInjectedIntentService(String name) {
    super(name);
  }

  @Override public void onCreate() {
    super.onCreate();
    ObjectGraph objectGraph =
        ((SenseonicsApplication) getApplication()).plus(getModules().toArray());
    objectGraph.inject(this);
  }

  protected List<Object> getModules() {
    List<Object> result = new ArrayList<Object>();
    result.add(new ServiceModule(this));
    return result;
  }
}
