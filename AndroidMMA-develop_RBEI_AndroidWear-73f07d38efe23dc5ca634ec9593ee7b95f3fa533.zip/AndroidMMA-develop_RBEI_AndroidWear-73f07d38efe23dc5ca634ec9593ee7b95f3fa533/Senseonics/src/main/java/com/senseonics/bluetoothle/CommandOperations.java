package com.senseonics.bluetoothle;

import android.util.Log;

public class CommandOperations {

    // ---------------------------------------------------
    // OPERATIONS TO ESTABLISH LINK AND CONTROL TRASMITTER
    // ---------------------------------------------------

    // 0x01
    public static int[] operationToPingTransmitter() {

        int[] command = new int[] { CommandAndResponseIDs.PingCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x76
    public static int[] operationToEnterDiagnosticMode() {

        int[] command = new int[] { CommandAndResponseIDs.EnterDiagnosticModeCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x77
    public static int[] operationToExitDiagnosticMode() {

        int[] command = new int[] { CommandAndResponseIDs.ExitDiagnosticModeCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x02
    public static int[] operationToLinkTransmitterWithSensor(int[] sensorID) {

        if (sensorID.length != 4) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[5];

        command[0] = CommandAndResponseIDs.LinkTransmitterWithSensorCommandID;
        int j = 1;

        for (int i = sensorID.length - 1; i >= 0; i--) {
            command[j] = sensorID[i];
            j++;
        }

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x03
    public static int[] operationToResetTransmitter() {

        int[] command = new int[] { CommandAndResponseIDs.ResetTransmitterCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x04
    public static int[] operationToClearErrorFlags() {

        int[] command = new int[] { CommandAndResponseIDs.ClearErrorFlagsCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x05
    public static int[] operationToStartSelfTestSequence() {

        int[] command = new int[] { CommandAndResponseIDs.StartSelfTestSequenceCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x06 - FUTURE
    public static int[] operationToReadAllAvailableSensorIDs() {

        int[] command = new int[] { CommandAndResponseIDs.ReadAllAvailableSensorsCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x07
    public static int[] operationToSetTransmitterDateAndTime(int[] DateGMT,
                                                             int[] TimeGMT, int[] TimeZoneOffset, int TimeZoneOffsetSign) {

        if (DateGMT.length != 2 || TimeGMT.length != 2
                || TimeZoneOffset.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[8];
        command[0] = CommandAndResponseIDs.SetCurrentTrasmitterDateAndTimeCommandID;
        command[1] = DateGMT[0];
        command[2] = DateGMT[1];
        command[3] = TimeGMT[0];
        command[4] = TimeGMT[1];
        command[5] = TimeZoneOffset[0];
        command[6] = TimeZoneOffset[1];
        command[7] = TimeZoneOffsetSign;

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x19
    public static int[] operationToReadCurrentTransmitterDateAndTime() {

        int[] command = new int[] { CommandAndResponseIDs.ReadCurrentTrasmitterDateAndTimeCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x69
    public static int[] operationToSaveBLEBondingInformation() {

        int[] command = new int[] { CommandAndResponseIDs.SaveBLEBondingInformationCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x74
    public static int[] operationToDisconnectBLESavingBondingInformation() {

        int[] command = new int[] { CommandAndResponseIDs.DisconnectBLESavingBondingInformationCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x75
    public static int[] operationToChangeTimingParameters(int TimingMode) {

        int[] command = new int[] {
                CommandAndResponseIDs.ChangeTimingParametersCommandID,
                TimingMode };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0])
                + " " + Integer.toHexString(command[1]);

        int[] commandToSend = new int[crcArray.length + 2];
        commandToSend[0] = command[0];
        commandToSend[1] = command[1];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 2] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 2]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ SENSOR GLUCOSE VALUES
    // ---------------------------------------------------

    // 0x08
    public static int[] operationToReadMostRecentGlucoseData() {

        int[] command = new int[] { CommandAndResponseIDs.ReadSensorGlucoseCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x09
    public static int[] operationToReadSingleSensorGlucoseDataValue(
            int[] RecordNumber) {

        if (RecordNumber.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadSingleSensorGlucoseDataRecordCommandID;
        command[1] = RecordNumber[0];
        command[2] = RecordNumber[1];
        command[3] = RecordNumber[2];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x70
    public static int[] operationToReadAllSensorGlucoseDataInSpecifiedRange(
            int[] startNumber, int[] endNumber) {

        if (startNumber.length != 3 || endNumber.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[7];
        command[0] = CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeCommandID;
        command[1] = startNumber[0];
        command[2] = startNumber[1];
        command[3] = startNumber[2];
        command[4] = endNumber[0];
        command[5] = endNumber[1];
        command[6] = endNumber[2];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("Sync_Process", logString);
        return commandToSend;
    }

    // 0x0E
    public static int[] operationToReadFirstAndLastSensorGlucoseRecordNumbers() {

        int[] command = new int[] { CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseRecordNumbersCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ SENSOR GLUCOSE ALERTS AND ALARMS
    // ---------------------------------------------------

    // 0x10
    public static int[] operationToReadSensorGlucoseAlertsAndStatus() {

        int[] command = new int[] { CommandAndResponseIDs.ReadSensorGlucoseAlertsAndStatusCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x11
    public static int[] operationToReadSingleSensorGlucoseAlertRecord(
            int[] RecordNumber) {

        if (RecordNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[3];
        command[0] = CommandAndResponseIDs.ReadSingleSensorGlucoseAlertRecordCommandID;
        command[1] = RecordNumber[1];
        command[2] = RecordNumber[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x12
    public static int[] operationToReadFirstAndLastSensorGlucoseAlertRecordNumbers() {

        int[] command = new int[] { CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseAlertRecordNumbersCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x71
    public static int[] operationToReadSensorGlucoseAlertLogInSpecifiedRange(
            int[] startNumber, int[] endNumber) {

        if (startNumber.length != 2 || endNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[5];
        command[0] = CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeCommandID;
        command[1] = startNumber[0];
        command[2] = startNumber[1];
        command[3] = endNumber[0];
        command[4] = endNumber[1];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x14
    public static int[] operationToAssertSnoozeAgainstAlarm(int SnoozeAlarmType) {

        int[] command = new int[] {
                CommandAndResponseIDs.AssertSnoozeAgainsAlarmCommandID,
                SnoozeAlarmType };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0])
                + Integer.toHexString(command[1]);

        int[] commandToSend = new int[crcArray.length + 2];
        commandToSend[0] = command[0];
        commandToSend[1] = command[1];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 2] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 2]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ AND WRITE BLOOD GLUCOSE DATA LOG
    // ---------------------------------------------------

    // 0x15
    public static int[] operationToSendBloodGlucoseValueToTransmitter(
            int[] date, int[] time, int[] value, int units, int[] meter,
            boolean forCalibration) {

        if (date.length != 2 || time.length != 2 || value.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[11];
        command[0] = CommandAndResponseIDs.SendBloodGlucoseDataCommandID;
        command[1] = date[0];
        command[2] = date[1];
        command[3] = time[0];
        command[4] = time[1];
        command[5] = value[0];
        command[6] = value[1];
        command[7] = units;
        command[8] = meter[1];
        command[9] = meter[0];

        if (forCalibration)
            command[10] = 0x55;
        else
            command[10] = 0x00;

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x16
    public static int[] operationToReadSingleBloodGlucoseDataRecord(
            int[] RecordNumber) {

        if (RecordNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[3];
        command[0] = CommandAndResponseIDs.ReadSingleBloodGlucoseDataRecordCommandID;
        command[1] = RecordNumber[1];
        command[2] = RecordNumber[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x17
    public static int[] operationToReadFirstAndLastBloodGlucoseDataRecordNumbers() {

        int[] command = new int[] { CommandAndResponseIDs.ReadFirstAndLastBloodGlucoseDataRecordNumbersCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x72
    public static int[] operationToReadLogOfBloodGlucoseDataInSpecifiedRange(
            int[] startNumber, int[] endNumber) {

        if (startNumber.length != 2 || endNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[5];
        command[0] = CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeCommandID;
        command[1] = startNumber[0];
        command[2] = startNumber[1];
        command[3] = endNumber[0];
        command[4] = endNumber[1];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ AND WRITE PATIENT EVENTS
    // ---------------------------------------------------

    // 0x1A
    public static int[] operationToWritePatientEvent(int[] date, int[] time,
                                                     int eventTypeID, int subtype, int quantity) {

        if (date.length != 2 || time.length != 2 ) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] eventSubtypeID = BinaryOperations
                .data16BitsFromIntLSByteFirst(subtype);
        int[] quantityID = BinaryOperations
                .data16BitsFromIntLSByteFirst(quantity);

        int[] command = new int[11];
        command[0] = CommandAndResponseIDs.WritePatientEventCommandID;
        command[1] = date[0];
        command[2] = date[1];
        command[3] = time[0];
        command[4] = time[1];
        command[5] = eventTypeID;
        command[6] = eventSubtypeID[0];
        command[7] = eventSubtypeID[1];
        command[8] = quantityID[0];
        command[9] = quantityID[1];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x1B
    public static int[] operationToReadSinglePatientEvent(int[] RecordNumber) {

        if (RecordNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[3];
        command[0] = CommandAndResponseIDs.ReadSinglePatientEventCommandID;
        command[1] = RecordNumber[1];
        command[2] = RecordNumber[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x1C
    // 0x1D
    public static int[] operationToMarkPatientEventRecordAsDeleted(
            int[] RecordNumber) {

        if (RecordNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[3];
        command[0] = CommandAndResponseIDs.MarkPatientEventRecordAsDeletedCommandID;
        command[1] = RecordNumber[1];
        command[2] = RecordNumber[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ AND WRITE MISCELLANEOUS EVENT LOG
    // ---------------------------------------------------

    // 0x22
    public static int[] operationToReadSingleMiscEventLog(int[] RecordNumber) {

        if (RecordNumber.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[3];
        command[0] = CommandAndResponseIDs.ReadSingleMiscEventLogCommandID;
        command[1] = RecordNumber[1];
        command[2] = RecordNumber[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x23
    public static int[] operationToReadFirstAndLastMiscEventLogRecordNumbers() {

        int[] command = new int[] { CommandAndResponseIDs.ReadFirstAndLastMiscEventLogRecordNumbersCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x24
    public static int[] operationToWriteSingleMiscEventLogRecord(int[] date,
                                                                 int[] time, int[] eventTypeID, int[] additionalInfo) {

        if (date.length != 2 || time.length != 2 || eventTypeID.length != 2
                || additionalInfo.length != 8) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[15];
        command[0] = CommandAndResponseIDs.WriteSingleMiscEventLogRecordCommandID;
        command[1] = date[1];
        command[2] = date[0];
        command[3] = time[1];
        command[4] = time[0];
        command[5] = eventTypeID[1];
        command[6] = eventTypeID[0];

        int j = 7;
        for (int i = additionalInfo.length - 1; i >= 0; i--) {
            command[j] = additionalInfo[i];
            j++;
        }

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ ERROR LOG
    // ---------------------------------------------------

    // 0x26
    public static int[] operationToReadFirstAndLastErrorLogRecordNumbers() {

        int[] command = new int[] { CommandAndResponseIDs.ReadFirstAndLastErrorLogRecordNumbersCommandID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // ---------------------------------------------------
    // OPERATIONS TO READ AND WRITE DATA MEMORY DIRECTLY
    // ---------------------------------------------------

    // 0x2A
    public static int[] operationToReadSingleByteSerialFlashRegister(
            int[] registerAddress) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadSingleByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x2B
    public static int[] operationToWriteSingleByteSerialFlashRegister(
            int[] registerAddress, int value) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[5];
        command[0] = CommandAndResponseIDs.WriteSingleByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];
        command[4] = value;

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x2C
    public static int[] operationToReadTwoByteSerialFlashRegister(
            int[] registerAddress) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadTwoByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x2D
    public static int[] operationToWriteTwoByteSerialFlashRegister(
            int[] registerAddress, int[] value) {

        if (registerAddress.length != 3 || value.length != 2) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[6];
        command[0] = CommandAndResponseIDs.WriteTwoByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];
        command[4] = value[0];
        command[5] = value[1];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x2E
    public static int[] operationToReadFourByteSerialFlashRegister(
            int[] registerAddress) {

        if (registerAddress.length != 3) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[4];
        command[0] = CommandAndResponseIDs.ReadFourByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x2F
    public static int[] operationToWriteFourByteSerialFlashRegister(
            int[] registerAddress, int[] value) {

        if (registerAddress.length != 3 || value.length != 4) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[8];
        command[0] = CommandAndResponseIDs.WriteFourByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];
        command[4] = value[0];
        command[5] = value[1];
        command[6] = value[2];
        command[7] = value[3];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x30
    public static int[] operationToReadNByteSerialFlashRegister(
            int[] registerAddress, int N) {

        if (registerAddress.length != 3 || N < 4 || N > 65536) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[6];
        command[0] = CommandAndResponseIDs.ReadNByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int[] NArray = BinaryOperations.data16BitsFromIntLSByteFirst(N);

        command[4] = NArray[0];
        command[5] = NArray[1];

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x31
    public static int[] operationToWriteNByteSerialFlashRegister(
            int[] registerAddress, int N, int[] values) {

        if (registerAddress.length != 3 || N < 4 || N > 65536
                || values.length != N) {
            Log.d("COMMAND", "Parameter length error!");
            return null;
        }

        int[] command = new int[6 + N];
        command[0] = CommandAndResponseIDs.WriteNByteSerialFlashRegisterCommandID;
        command[1] = registerAddress[2];
        command[2] = registerAddress[1];
        command[3] = registerAddress[0];

        int[] NArray = BinaryOperations.data16BitsFromIntLSByteFirst(N);

        command[4] = NArray[0];
        command[5] = NArray[1];

        int j = 6;
        for (int i = 0; i < N; ++i) {
            command[j] = values[i];
            j++;
        }

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command =";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // TRM initiated commands
    // 0x01
    public static int[] operationRespondToKeepAlive() {

        int[] command = new int[] { CommandAndResponseIDs.KeepAliveResponseID };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = " + Integer.toHexString(command[0]);

        int[] commandToSend = new int[crcArray.length + 1];
        commandToSend[0] = command[0];

        for (int i = 0; i < crcArray.length; i++) {
            commandToSend[i + 1] = crcArray[i];
            logString = logString + " "
                    + Integer.toHexString(commandToSend[i + 1]);
        }

        Log.d("COMMAND", logString);
        return commandToSend;
    }

    // 0x60 + 0x18
    public static int[] operationToForceGlucoseMeasurement() {

        int[] command = new int[] { CommandAndResponseIDs.TestCommandID, CommandAndResponseIDs.TestCommandForceGlucoseMeasurement };

        int crc = BinaryOperations.GenerateChecksumCRC16(command);
        int[] crcArray = BinaryOperations.data16BitsFromIntLSByteFirst(crc);

        String logString = new String();
        logString = "Calculated Command = ";

        int[] commandToSend = new int[crcArray.length + command.length];

        for (int i = 0; i < commandToSend.length; i++) {
            if (i < command.length)
                commandToSend[i] = command[i];
            else
                commandToSend[i] = crcArray[i - command.length];

            logString = logString + " " + Integer.toHexString(commandToSend[i]);
        }

        Log.d("Linking", "ForceGlucoseMeasurement:" + logString);
        Log.d("COMMAND", logString);
        return commandToSend;
    }
}
