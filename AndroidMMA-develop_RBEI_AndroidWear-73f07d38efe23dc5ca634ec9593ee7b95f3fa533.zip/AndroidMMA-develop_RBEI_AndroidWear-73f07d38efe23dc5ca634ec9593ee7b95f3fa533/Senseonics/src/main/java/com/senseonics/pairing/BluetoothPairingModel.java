package com.senseonics.pairing;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.DiscoverCallback;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.pairing.events.model.BeginDiscoveryEvent;
import com.senseonics.pairing.events.model.DiscoveryEvent;
import com.senseonics.pairing.events.model.TimeoutEvent;
import com.senseonics.pairing.events.model.TransmittersChangedEvent;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

import static com.senseonics.bluetoothle.Transmitter.CONNECTION_STATE.DISCONNECTED;

@Singleton public class BluetoothPairingModel {
  private EventBus eventBus;
  private BluetoothEnabler enabler;
  private Provider<BluetoothService> service;
  private List<Transmitter> transmitters;
  private boolean bDiscoverOnce;

  @Inject public BluetoothPairingModel(EventBus eventBus, BluetoothEnabler enabler,
      Provider<BluetoothService> service) {
    this.eventBus = eventBus;
    this.enabler = enabler;
    this.service = service;
  }

  public void transmitterPressed(Transmitter transmitter) {
    if (transmitter.getConnectionState() == DISCONNECTED) {
      service.get().connect(transmitter, true);
    } else {
      service.get().disconnect(transmitter);
    }
  }

  public void refreshConnectionState(Transmitter refreshedTransmitter) {
    if (transmitters != null) {
      for (Transmitter transmitter : transmitters) {
        if (refreshedTransmitter.equals(transmitter)) {
          transmitter.setConnectionState(refreshedTransmitter.getConnectionState());
        }
      }
      eventBus.post(new TransmittersChangedEvent(transmitters));
    }
  }

  public void initiateInitialDiscovery() {
    if (isServiceBound() && !bDiscoverOnce && enabler.isEnabled()) {
      discover();
      bDiscoverOnce = true;
    }
  }

  public void discover() {
    eventBus.post(new BeginDiscoveryEvent());
    service.get().startDiscovery(new DiscoverCallback() {
      @Override public void onDevice(List<Transmitter> discoveredTransmitters) {
        transmitters = discoveredTransmitters;
        eventBus.post(new TransmittersChangedEvent(transmitters));
        eventBus.post(new DiscoveryEvent());
      }

      @Override public void onDiscoveryTimeout() {
        eventBus.post(new TimeoutEvent());
      }
    });
  }

  public void triggerBluetoothEnabled(boolean enabled) {
    if (!enabled) {
      if (transmitters != null) {
        transmitters.clear();
        eventBus.post(new TransmittersChangedEvent(transmitters));
      }
    }
  }

  public boolean isServiceBound() {
    return service.get() != null;
  }
}
