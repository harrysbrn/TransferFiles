package com.senseonics.model;

public interface TwoByteMemoryMapParsedResponse {

    int[] getMemoryAddress();
    void apply(int dataOne, int dataTwo, TransmitterStateModel model);
}
