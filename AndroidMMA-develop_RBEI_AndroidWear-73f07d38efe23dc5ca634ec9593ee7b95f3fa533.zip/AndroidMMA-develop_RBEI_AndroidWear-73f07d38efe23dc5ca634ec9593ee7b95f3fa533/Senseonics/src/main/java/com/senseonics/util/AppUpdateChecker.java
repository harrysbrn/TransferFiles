package com.senseonics.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.util.Log;

import com.senseonics.bluetoothle.DialogUtils;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.util.Calendar;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class AppUpdateChecker { /** #3272 Prompt to the user if there is a newer version of the app in the app store and direct to the App Store if the user confirms. */
    private final String RELEASE_ONLINE_VERSIONS_STAGING = "https://intranet.senseonics.com/SE/Releases/AndroidMMAAppStoreVersion_Staging.txt";
    private final String RELEASE_ONLINE_VERSIONS = "https://intranet.senseonics.com/SE/Releases/AndroidMMAAppStoreVersion.txt";
    private final int CHECK_INTERVAL = 24 * 60; // 1 day

    private final String TAG = "AppUpdate";

    private DialogUtils dialogUtils;
    private SharedPreferences sharedPreferences;
    private CheckProcessState processState;

    private enum MLCheckResult {
        Timeout(1),
        NotConnectedToWifi(2),
        ServerError(3),
        None(4),
        Unknown(5);

        private final int id;
        MLCheckResult(int id) {this.id = id;}
        public int getValue() {return id;}

        public static MLCheckResult fromValue(int id) {
            for (MLCheckResult err: values()) {
                if (err.getValue() == id) {
                    return err;
                }
            }
            return null;
        }
    }

    private enum MLVersionCompare {
        FIND_NEWER,
        FIND_OLDER,
        FIND_SAME
    }

    private enum CheckProcessState {
        STARTED,
        ENDED
    }

    @Inject
    public AppUpdateChecker(DialogUtils dialogUtils, SharedPreferences sharedPreferences) {
        this.dialogUtils = dialogUtils;
        this.sharedPreferences = sharedPreferences;

        processState = CheckProcessState.ENDED;
    }

    private void resetAppUpdateLastCheckedInPreference(Context context) {
        Utils.saveSettings(context, Utils.prefAppUpdateLastCheckedDateTime, Calendar.getInstance().getTimeInMillis());
    }

    private void setCurrentDateTimeToAppUpdateLastCheckedInPreference(Context context) {
        long timeInMillis = Calendar.getInstance().getTimeInMillis();
        Utils.saveSettings(context, Utils.prefAppUpdateLastCheckedDateTime, timeInMillis);
    }

    private long getAppUpdateLastCheckedDateTimeFromPreference(Context context) {
        long timeInMills = Utils.getSettingsForLong(context, Utils.prefAppUpdateLastCheckedDateTime);
        return timeInMills;
    }

    private boolean isItTimeToCheck(Context context) {
        // reset last check time if it does not exist in preference
        if (!sharedPreferences.contains(Utils.prefAppUpdateLastCheckedDateTime)) {
            resetAppUpdateLastCheckedInPreference(context);
        }

        long lastCheckTimeInMillis = getAppUpdateLastCheckedDateTimeFromPreference(context);
        long currentTimeInMills = Calendar.getInstance().getTimeInMillis();
        long diffTimeInMills = currentTimeInMills - lastCheckTimeInMillis;

        Log.d(TAG, "currentTimeInMills:" + currentTimeInMills + "|lastCheckTimeInMillis:" + lastCheckTimeInMillis + "|diff:"+diffTimeInMills);

        if (diffTimeInMills < 0) {
            Log.d(TAG, "invalid time");
            resetAppUpdateLastCheckedInPreference(context);
            return false;
        }

        if (diffTimeInMills < (CHECK_INTERVAL * 60L * 1000L)) {
            Log.d(TAG, "Less than (" + CHECK_INTERVAL + " minutes)");
            return false;
        }

        return true;
    }

    public void checkForSoftwareUpdate(Context context) {
        /** Check if it's time */
        if (!isItTimeToCheck(context)) {
            Log.d(TAG, "PANIC: it is not the time");
            return;
        }

        if (processState == CheckProcessState.STARTED) {
            Log.d(TAG, "PANIC: processed alreay started!");
            return;
        }

        processState = CheckProcessState.STARTED;

        if (Utils.haveNetworkConnection(context) == false) {
            Log.d(TAG, "PANIC: No Internet");
            processState = CheckProcessState.ENDED;
            return;
        }

        new getLastestAppAsynctask().execute(context);
    }

    private class getLastestAppAsynctask extends AsyncTask<Context, Void, Void> {
        private String response;
        private Context context;

        @Override
        protected Void doInBackground(Context... params) {
            context = params[0];
            response = getVersionFile();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Log.d(TAG, "response:"+response);

            if (response != null && !response.equals("-1")) {
                decodeVersionFile(response, context);

                /** timestamp this check for update */
                setCurrentDateTimeToAppUpdateLastCheckedInPreference(context);
            }

            processState = CheckProcessState.ENDED;
        }
    }

    private String getVersionFile() {
        try {
            DefaultHttpClient client = new DefaultHttpClient();
            // register ntlm auth scheme
            client.getAuthSchemes().register("ntlm", new NTLMSchemeFactory());
            client.getCredentialsProvider().setCredentials(
                    // Limit the credentials only to the specified domain and port
                    new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
                    // Specify credentials, most of the time only user/pass is needed
                    new NTCredentials(Utils.INTRANET_UN, Utils.INTRANET_PW, "", "")
            );

            String url = (AccountConstants.server == AccountConstants.Server.DMS_Staging) ? RELEASE_ONLINE_VERSIONS_STAGING : RELEASE_ONLINE_VERSIONS;
            HttpGet httpget = new HttpGet(url);

            HttpResponse response;
            MLCheckResult checkResult = null;
            try {
                response = client.execute(httpget);
                HttpEntity entity = response.getEntity();

                String result = null;
                if (entity != null) {
                    // A Simple JSON Response Read
                    InputStream instream = entity.getContent();
                    result = Utils.convertStreamToString(instream);
                    // now you have the string representation of the HTML request
                    instream.close();
                }

                return result;
            } catch (ClientProtocolException e) {
                Log.d(TAG, "Client Protocol Exception");
            } catch (SocketTimeoutException e) {
                checkResult = MLCheckResult.Timeout;
                Log.d(TAG, "Socket timeout");
            } catch (ConnectTimeoutException e) {
                checkResult = MLCheckResult.Timeout;
                Log.d(TAG, "Connect timeout");
            } catch (IOException e) {
                checkResult = MLCheckResult.ServerError;
                Log.d(TAG, "IO Exception");
                e.printStackTrace();
            }
            if (checkResult != MLCheckResult.None){
                return "-1";
            }

        } catch (Exception e) {
            Log.d(TAG, "Might be keystore exception");
            return "-1";
        }

        return null;
    }

    private void decodeVersionFile(String fileContent, Context context) {
        // Remove carriage returns
        fileContent = fileContent.replaceAll("\r", "");
        fileContent = fileContent.replaceAll("\n", "");

        Log.d(TAG, "FirstLine:" + fileContent);

        try {
            if (!fileContent.isEmpty()) {
                String[] firLineChunks = fileContent.split(" ");
                String fetched_app_version = firLineChunks[0];
                String otherInfo = firLineChunks[1];

                Log.d(TAG, "otherInfo:" + otherInfo);

                // Compare the version
                PackageInfo pInfo = context.getPackageManager().getPackageInfo(
                        context.getPackageName(), 0);
                String current_app_version = String.valueOf(pInfo.versionName);

                Log.d(TAG, "server app version:" + fetched_app_version);
                Log.d(TAG, "my version:" + current_app_version);

                MLVersionCompare compareResult = compareVersion(current_app_version, fetched_app_version);
                Log.d(TAG, "compare result: " + compareResult);

                if (compareResult == MLVersionCompare.FIND_NEWER) {
                    /** new version detected */
                    dialogUtils.fireUpdateAppPopup(context, fetched_app_version);
                }

            }
        } catch (PackageManager.NameNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    private boolean checkIfValidVersionString(String versionString) {
        String[] versionSplit = versionString.split("\\.");

        int count = versionSplit.length;
        if (count != 3) {
            return false;
        }

        for (String thisString: versionSplit) {
            try {
                Integer.parseInt(thisString);
            }
            catch (NumberFormatException ex) {
                return false;
            }
        }

        return true;
    }

    private MLVersionCompare compareVersion(String localVersion, String serverVersion) {
        localVersion = localVersion.replaceAll("\"", "");
        localVersion = localVersion.replaceAll(" ", "");

        serverVersion = serverVersion.replaceAll("\"", "");
        serverVersion = serverVersion.replaceAll(" ", "");

        if (serverVersion == null || serverVersion.equals("")) { // invalid server version: should NOT happen
            return MLVersionCompare.FIND_OLDER;
        }

        if (!checkIfValidVersionString(serverVersion)) { // if the server has an invalid version
            return MLVersionCompare.FIND_OLDER;
        }

        if (localVersion == null || localVersion.equals("")) { // empty local version: should NOT happen
            return MLVersionCompare.FIND_NEWER;
        }

        // always return find newer version if either version is not in X.Y.Z format
        if (!checkIfValidVersionString(localVersion)) { // always happen if it's DEVELOPER version
            return MLVersionCompare.FIND_NEWER;
        }

        String[] localVersionSplit = localVersion.split("\\."); // split into X, Y, Z components

        int local_x = Integer.parseInt(localVersionSplit[0]);
        int local_y = Integer.parseInt(localVersionSplit[1]);
        int local_z = Integer.parseInt(localVersionSplit[2]);


        String[] serverVersionSplit = serverVersion.split("\\."); // split into X, Y, Z components

        int server_x = Integer.parseInt(serverVersionSplit[0]);
        int server_y = Integer.parseInt(serverVersionSplit[1]);
        int server_z = Integer.parseInt(serverVersionSplit[2]);

        // Check x first
        if (server_x > local_x)
        {
            return MLVersionCompare.FIND_NEWER;
        }
        else if (server_x < local_x)
        {
            return MLVersionCompare.FIND_OLDER;
        }
        else // same x
        {
            // Check y secondly
            if (server_y > local_y)
            {
                return MLVersionCompare.FIND_NEWER;
            }
            else if (server_y < local_y)
            {
                return MLVersionCompare.FIND_OLDER;
            }
            else // same y
            {
                // Check z thirdly
                if (server_z > local_z)
                {
                    return MLVersionCompare.FIND_NEWER;
                }
                else if (server_z < local_z)
                {
                    return MLVersionCompare.FIND_OLDER;
                }
                else // same z
                {
                    return MLVersionCompare.FIND_SAME;
                }
            }
        }
    }

}
