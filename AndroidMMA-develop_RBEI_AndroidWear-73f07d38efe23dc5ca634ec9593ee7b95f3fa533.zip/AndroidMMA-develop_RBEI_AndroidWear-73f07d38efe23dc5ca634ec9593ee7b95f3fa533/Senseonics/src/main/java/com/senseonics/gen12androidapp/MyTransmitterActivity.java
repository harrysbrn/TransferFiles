package com.senseonics.gen12androidapp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.bluetoothle.event.TransmitterRSSIEvent;
import com.senseonics.events.ModelChangedBatteryLevelEvent;
import com.senseonics.events.ModelChangedCalibrationsMadeInThisPhaseEvent;
import com.senseonics.events.ModelChangedCurrentCalibrationPhaseEvent;
import com.senseonics.events.ModelChangedLastCalibrationDateTimeEvent;
import com.senseonics.events.ModelChangedStartPhaseCalibrationDateTimeEvent;
import com.senseonics.events.ModelChangedTransmitterFirmwareVersionEvent;
import com.senseonics.events.ModelChangedTransmitterModelNoEvent;
import com.senseonics.events.ModelChangedTransmitterSerialNumberEvent;
import com.senseonics.model.BATTERY_LEVEL;
import com.senseonics.util.Utils;

import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

public class MyTransmitterActivity extends BaseActivity {

    private LinearLayout parentLayout, content;
    private LayoutInflater inflater;
    private ProgressDialog progressDialog;
    private Timer rssiTimer;
    private View rssiView;
    private TextView rssiTextView;
    private TextView rssiValueTextView;

    private TextView transmitterNameTextView,transmitterNameTitleView ;
    private TextView transmitterSerialNumberTextView,transmitterSerialNumberTitleView;
    private TextView transmitterModelNumberTextView,transmitterModelNumberTitleView;
    private TextView transmitterFirmwareVersionTextView,transmitterFirmwareVersionTitleView;
    private TextView transmitterLastCalTextView,transmitterLastCalTitleView;
    private TextView transmitterPhaseStartTextView,transmitterPhaseStartTitleView;
    private TextView transmitterCompletedCalsTextView,transmitterCompletedCalsTitleView;
    private TextView transmitterCurrentPhaseTextView,transmitterCurrentPhaseTitleView ;
    private TextView transmtiterRSSILevelTextView,transmtiterRSSILevelTitleView;
    private TextView transmitterBatteryLevelTextView,transmitterBatteryLevelTitleView;

    //event arrivals
    private boolean transmitterSerialNumberArrived = false;
    private boolean transmitterModelNoArrived = false;
    private boolean transmitterFirmwareVersionArrived = false;
    private boolean transmitterLastCalibrationDateAndTimeArrived = false;
    private boolean transmitterPhaseStartDateAndTimeArrived= false;
    private boolean transmitterBatteryLevelArrived = false;
    private boolean transmitterCalibrationsMadeInThisPhaseArrived = false;
    private boolean transmitterCurrentCalibrationPhaseArrived = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(layoutInflater.inflate(R.layout.activity_mytransmitter, null), parms_content);

        // Configure the navigation bar
        naviBarTitle.setText(R.string.my_transmitter);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        content = (LinearLayout) findViewById(R.id.content);
        parentLayout = (LinearLayout) findViewById(R.id.layout);
        inflater = LayoutInflater.from(this);
        transmitterNameTextView = (TextView) findViewById(R.id.myTx_transmitterName);
        transmitterSerialNumberTextView = (TextView) findViewById(R.id.myTx_transmitterSerialNo);
        transmitterModelNumberTextView = (TextView) findViewById(R.id.myTx_transmitterModelNo);
        transmitterFirmwareVersionTextView = (TextView) findViewById(R.id.myTx_transmitterFWVersion);
        transmitterLastCalTextView = (TextView) findViewById(R.id.myTx_transmitterLastCal);
        transmitterPhaseStartTextView = (TextView) findViewById(R.id.myTx_transmitterPhaseStart);
        transmitterCompletedCalsTextView = (TextView) findViewById(R.id.myTx_transmitterCompletedCals);
        transmitterCurrentPhaseTextView = (TextView) findViewById(R.id.myTx_transmitterCurrentPhase);
        transmtiterRSSILevelTextView = (TextView) findViewById(R.id.myTx_transmitterRSSI);
        transmitterBatteryLevelTextView = (TextView) findViewById(R.id.myTx_transmitterBatteryLevel);

        transmitterNameTitleView = (TextView) findViewById(R.id.myTx_transmitterNameText);
        transmitterSerialNumberTitleView = (TextView) findViewById(R.id.myTx_transmitterSerialNoText);
        transmitterModelNumberTitleView = (TextView) findViewById(R.id.myTx_transmitterModelNoText);
        transmitterFirmwareVersionTitleView = (TextView) findViewById(R.id.myTx_transmitterFWVersionText);
        transmitterLastCalTitleView = (TextView) findViewById(R.id.myTx_transmitterLastCalText);
        transmitterPhaseStartTitleView = (TextView) findViewById(R.id.myTx_transmitterPhaseStartText);
        transmitterCompletedCalsTitleView = (TextView) findViewById(R.id.myTx_transmitterCompletedCalsText);
        transmitterCurrentPhaseTitleView = (TextView) findViewById(R.id.myTx_transmitterCurrentPhaseText);
        transmtiterRSSILevelTitleView = (TextView) findViewById(R.id.myTx_transmitterRSSIText);
        transmitterBatteryLevelTitleView = (TextView) findViewById(R.id.myTx_transmitterBatteryLevelText);


        progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(true);
    }

    @Override
    protected void onResume() {

        refreshTransmitterInfo();

        super.onResume();
    }

    private void refreshTransmitterInfo() {
        progressDialog.show();

        transmitterSerialNumberArrived = false;
        transmitterModelNoArrived = false;
        transmitterFirmwareVersionArrived = false;
        transmitterLastCalibrationDateAndTimeArrived = false;
        transmitterPhaseStartDateAndTimeArrived = false;
        transmitterBatteryLevelArrived = false;
        transmitterCalibrationsMadeInThisPhaseArrived = false;
        transmitterCurrentCalibrationPhaseArrived = false;

        loadDataFromTransmitter();

        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            startRssiTimer();
        } else {
            updateTransmitterRSSILevel(0);
        }
    }

    public void loadDataFromTransmitter() {
        updateViews();
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            initMyTransmitterRequests(getService());
        }
        else{
            progressDialog.dismiss();
        }
    }

    public void updateDisplay() {
        if (checkIfAllDataLoaded() ) {
            updateViews();
            progressDialog.dismiss();
        }
    }
    @Override
    protected void onPause() {
        stopRssiTimer();

        super.onPause();
    }

    private void stopRssiTimer() {
        if (rssiTimer != null) {
            rssiTimer.cancel();
            rssiTimer = null;
        }
    }

    private void startRssiTimer() {

        if (rssiTimer == null) {
            rssiTimer = new Timer();
        }

        rssiTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                    getService().readRemoteRSSI();
                }
            }
        }, 1, 1000);
    }

//    public void highPriorityRequestFinished() {
//        loadDataFromTransmitter();
//    }

    public void updateViews() {

        showTransmitterName();
        showTransmitterSerialNumber();
        showTransmitterModelNumber();
        showTransmitterFWVersion();
        showTransmitterLastCal();
        showTransmitterPhaseStart();
        showTransmitterCompletedCal();
        showTransmitterCurrentPhase();
        showTransmitterBatteryLevel();
    }

    private void showTransmitterName() {
        // add transmitter name
        if (transmitterStateModel.getTransmitterName() != null) {
            transmitterNameTextView.setText(transmitterStateModel.getTransmitterName());
        } else {
            transmitterNameTextView.setText(Utils.unknownString);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterNameTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterNameTitleView);
    }

    private void showTransmitterSerialNumber() {
        // add serial number
        if (transmitterStateModel.getTransmitterSerialNumber() != null) {
            transmitterSerialNumberTextView.setText(transmitterStateModel.getTransmitterSerialNumber());
        } else {
            transmitterSerialNumberTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterSerialNumberTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterSerialNumberTitleView);
    }

    private void showTransmitterModelNumber() {
        // add model number
        if (transmitterStateModel.getTransmitterModelNumber() != null) {
            transmitterModelNumberTextView.setText(transmitterStateModel.getTransmitterModelNumber());
        } else {
            transmitterModelNumberTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterModelNumberTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterModelNumberTitleView);
    }

    private void showTransmitterFWVersion() {
        // add version number
        if (transmitterStateModel.getFormattedTransmitterVersionNumber() != null) {
            transmitterFirmwareVersionTextView.setText(transmitterStateModel.getFormattedTransmitterVersionNumber());
        } else {
            transmitterFirmwareVersionTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterFirmwareVersionTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterFirmwareVersionTitleView);
    }

    private void showTransmitterLastCal() {
        // add last cal date
        if (transmitterStateModel.getlastCalibrationDateAndTime() != null) {
            transmitterLastCalTextView.setText(Utils.formatDateSimple(transmitterStateModel.getlastCalibrationDateAndTime(),
                    TimeZone.getDefault(), MyTransmitterActivity.this));
        } else {
            transmitterLastCalTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterLastCalTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterLastCalTitleView);
    }

    private void showTransmitterPhaseStart() {
        // add calibration phase date
        if (transmitterStateModel.getStartCalibrationPhaseDateAndTime() != null) {
            transmitterPhaseStartTextView.setText(Utils.formatDateSimple(transmitterStateModel.getStartCalibrationPhaseDateAndTime(),
                    TimeZone.getDefault(), MyTransmitterActivity.this));
        } else {
            transmitterPhaseStartTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterPhaseStartTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterPhaseStartTitleView);
    }

    private void showTransmitterCompletedCal() {
        // add number of calibrations
        if (transmitterStateModel.getCalibrationsMadeInThisPhase() >= 0) {
            transmitterCompletedCalsTextView.setText(String.valueOf(transmitterStateModel.getCalibrationsMadeInThisPhase()));
        } else {
            transmitterCompletedCalsTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterCompletedCalsTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterCompletedCalsTitleView);
    }

    private void showTransmitterCurrentPhase() {
        // add current phase
        if (transmitterStateModel.getCurrentCalibrationPhase() != Utils.CAL_PHASE.UNDERTERMINED) {
            transmitterCurrentPhaseTextView.setText(transmitterStateModel.getCurrentPhase());
        } else {
            transmitterCurrentPhaseTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterCurrentPhaseTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterCurrentPhaseTitleView);
    }

    private void updateTransmitterRSSILevel(final int rssiValue) {
        // add RSSI level
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            transmtiterRSSILevelTextView.setText(rssiValue + "");
        } else {
            transmtiterRSSILevelTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmtiterRSSILevelTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmtiterRSSILevelTitleView);
    }

    private void showTransmitterBatteryLevel() {
        // add battery life
        if (transmitterStateModel.getBatteryLevel() != BATTERY_LEVEL.UNKNOWN_NEG_1) {
            transmitterBatteryLevelTextView.setText(transmitterStateModel.getBatteryLife());
        } else {
            transmitterBatteryLevelTextView.setText(Utils.NotAvailable);
        }

        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterBatteryLevelTextView);
        Utils.updateCellTextColorBasedOnConnection(MyTransmitterActivity.this,
                transmitterBatteryLevelTitleView);
    }

    public void onEventMainThread(TransmitterRSSIEvent event) {
        updateTransmitterRSSILevel(event.getRSSIValue());
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        refreshTransmitterInfo();
        super.onEventMainThread(event);
    }

    public void onEventMainThread(ModelChangedTransmitterSerialNumberEvent event) {
        transmitterSerialNumberArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedTransmitterModelNoEvent event) {
        transmitterModelNoArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedTransmitterFirmwareVersionEvent event) {
        transmitterFirmwareVersionArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedLastCalibrationDateTimeEvent event) {
        transmitterLastCalibrationDateAndTimeArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedStartPhaseCalibrationDateTimeEvent event) {
        transmitterPhaseStartDateAndTimeArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedBatteryLevelEvent event) {
        transmitterBatteryLevelArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedCalibrationsMadeInThisPhaseEvent event) {
        transmitterCalibrationsMadeInThisPhaseArrived = true;
        updateDisplay();
    }

    public void onEventMainThread(ModelChangedCurrentCalibrationPhaseEvent event) {
        transmitterCurrentCalibrationPhaseArrived = true;
        updateDisplay();
    }

    private boolean checkIfAllDataLoaded() {
        boolean result = false;
        if(transmitterSerialNumberArrived
                && transmitterModelNoArrived
                && transmitterFirmwareVersionArrived
                && transmitterLastCalibrationDateAndTimeArrived
                && transmitterPhaseStartDateAndTimeArrived
                && transmitterCurrentCalibrationPhaseArrived
                && transmitterBatteryLevelArrived
                && transmitterCalibrationsMadeInThisPhaseArrived) {
            result = true;
        }

        Log.i(MyTransmitterActivity.class.getSimpleName(), "checkIfAllDataLoaded:" + result);

        return result;
    }

    private void initMyTransmitterRequests(BluetoothService service) {
        if (transmitterStateModel.getTransmitterName() == null
                || !transmitterSerialNumberArrived) {
            service.postPingRequest();
        }

        // model number
        if (!transmitterModelNoArrived) {
            service.postGetModelRequest();
        }

        // version number
        if (!transmitterFirmwareVersionArrived) {
            service.postVersionNumberRequest();
        }

        // last cal
        if (!transmitterLastCalibrationDateAndTimeArrived) {
            service.postLastCalibrationDateTimeRequest();
        }

        // phase start date and time
        if (!transmitterPhaseStartDateAndTimeArrived) {
            service.postPhaseStartDateTimeRequest();
        }

        // total calibration
        if (!transmitterCalibrationsMadeInThisPhaseArrived) {
            service.postCompletedCalibrationsCountRequest();
        }

        // current phase
        if (!transmitterCurrentCalibrationPhaseArrived) {
            service.postCurrentCalibrationPhaseRequest();
        }

        // battery life
        if (!transmitterBatteryLevelArrived) {
            service.postBatteryLifeRequest();
        }
    }

}
