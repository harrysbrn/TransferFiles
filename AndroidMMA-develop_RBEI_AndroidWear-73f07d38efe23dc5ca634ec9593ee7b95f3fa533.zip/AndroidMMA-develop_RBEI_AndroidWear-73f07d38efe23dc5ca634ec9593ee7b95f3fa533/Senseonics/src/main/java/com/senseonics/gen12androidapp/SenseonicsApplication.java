package com.senseonics.gen12androidapp;

import android.app.Application;
import android.content.Context;
import android.content.Intent;

import com.senseonics.bluetoothle.ApplicationForegroundState;
import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.db.DatabaseManager;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import dagger.Lazy;
import dagger.ObjectGraph;
import de.greenrobot.event.EventBus;

public class SenseonicsApplication extends Application implements ObjectGraphApplication {
  private ObjectGraph objectGraph;
  @Inject Lazy<DatabaseManager> databaseManagerLazy;
  @Inject BluetoothServiceClient bluetoothServiceClient;
  @Inject ApplicationForegroundState applicationForegroundState;

  @Override protected void attachBaseContext(Context base) {
    objectGraph = ObjectGraph.create(getModules().toArray());
    objectGraph.inject(this);
    super.attachBaseContext(base);
  }

  @Override public void onCreate() {
    super.onCreate();
    registerActivityLifecycleCallbacks(applicationForegroundState);
    startService(new Intent(this, BluetoothService.class));
    EventBus.getDefault().register(this);
  }

  @Override public void onTerminate() {
    databaseManagerLazy.get().close();
    super.onTerminate();
  }

  public BluetoothServiceClient getBluetoothServiceClient() {
    return bluetoothServiceClient;
  }

  protected List<Object> getModules() {
    return Arrays.asList(new AndroidModule(this), new ApplicationModule());
  }

  public void onEventMainThread(TransmitterConnectionEvent event) {
    BluetoothUtils.mConnected = false;

    // only change the mConnected to true when the state is CONNECTED, others belong to false
    if (event.getTransmitter().getConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
      BluetoothUtils.mConnected = true;
    }
  }

  @Override public ObjectGraph plus(Object... objects) {
    return objectGraph.plus(objects);
  }

  @Override public void inject(Object object) {
    objectGraph.inject(object);
  }
}
