package com.senseonics.gen12androidapp;

import android.app.AlarmManager;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;

import com.senseonics.bluetoothle.BluetoothAdapterWrapper;
import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.events.AlertEventActivity;
import com.senseonics.events.CalibrationEventActivity;
import com.senseonics.events.EventActivity;
import com.senseonics.events.ExerciseEventActivity;
import com.senseonics.events.GlucoseEventActivity;
import com.senseonics.events.HealthEventActivity;
import com.senseonics.events.InsulinEventActivity;
import com.senseonics.events.MealEventActivity;
import com.senseonics.events.NotificationEventActivity;
import com.senseonics.fragments.AboutFragment;
import com.senseonics.fragments.CalibrateFragment;
import com.senseonics.fragments.DailyCalibrationFragment;
import com.senseonics.fragments.EventLogFragment;
import com.senseonics.fragments.GraphFragment;
import com.senseonics.fragments.MealTimesFragment;
import com.senseonics.fragments.MealTimesStartEndTimePickerFragment;
import com.senseonics.fragments.NotificationsFragment;
import com.senseonics.fragments.PlacementGuideFragment;
import com.senseonics.fragments.SettingsFragment;
import com.senseonics.fragments.SoundSettingsSimplifiedFragment;
import com.senseonics.fragments.TempGlucoseProfileFragment;
import com.senseonics.model.AlgorithmParameterFormatVersionTwoByteMemoryMapParsedResponse;
import com.senseonics.model.BatteryPercentageSingleByteMemoryMapParsedResponse;
import com.senseonics.model.CalibrationPhaseStartDateTwoByteMemoryMapParsedResponse;
import com.senseonics.model.CalibrationPhaseStartTimeTwoByteMemoryMapParsedResponse;
import com.senseonics.model.CalibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse;
import com.senseonics.model.DefaultedHashMap;
import com.senseonics.model.FourByteMemoryMapParsedResponse;
import com.senseonics.model.GlucoseLevelParsedResponse;
import com.senseonics.model.HysteresisPercentageSingleByteMemoryMapParsedResponse;
import com.senseonics.model.HysteresisPredictivePercentageSingleByteMemoryMapParsedResponse;
import com.senseonics.model.HysteresisPredictiveValueSingleByteMemoryMapParsedResponse;
import com.senseonics.model.HysteresisValueSingleByteMemoryMapParsedResponse;
import com.senseonics.model.LastCalibrationDateTwoByteMemoryMapParsedResponse;
import com.senseonics.model.LastCalibrationTimeTwoByteMemoryMapParsedResponse;
import com.senseonics.model.LinkedSensorIdAddressFourByteMemoryMapParsedResponse;
import com.senseonics.model.NoOpParsedResponse;
import com.senseonics.model.ParsedResponse;
import com.senseonics.model.PingParsedResponse;
import com.senseonics.model.ReadClinicalModeSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadCurrentCalibrationPhaseSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadCurrentTransmitterDateAndTimeParsedResponse;
import com.senseonics.model.ReadDayStartTimeTwoByteMemoryParsedResponse;
import com.senseonics.model.ReadDoNotDisturbModeSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadEEP24MSPTwoByteMemoryParsedResponse;
import com.senseonics.model.ReadFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse;
import com.senseonics.model.ReadFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse;
import com.senseonics.model.ReadFirstAndLastSensorGlucoseRecordNumbersParsedResponse;
import com.senseonics.model.ReadFourByteSerialFlashRegisterParsedResponse;
import com.senseonics.model.ReadMEPSavedDriftMetricFourByteMemoryParsedResponse;
import com.senseonics.model.ReadMEPSavedLowRefMetricFourByteMemoryParsedResponse;
import com.senseonics.model.ReadMEPSavedRefChannelMetricFourByteMemoryParsedResponse;
import com.senseonics.model.ReadMEPSavedSpikeFourByteMemoryParsedResponse;
import com.senseonics.model.ReadMEPSavedValueFourByteMemoryParsedResponse;
import com.senseonics.model.ReadNightStartTimeTwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue1TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue2TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue3TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue4TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue5TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue6TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue7TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadRawValuesResponses.ReadRawDataValue8TwoByteMemoryParsedResponse;
import com.senseonics.model.ReadSensorGlucoseAlertAndStatusParsedResponse;
import com.senseonics.model.ReadSingleByteSerialFlashRegisterParsedResponse;
import com.senseonics.model.ReadTwoByteSerialFlashRegisterParsedResponse;
import com.senseonics.model.ReadVibrateModeSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse;
import com.senseonics.model.ReadWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse;
import com.senseonics.model.ReadWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse;
import com.senseonics.model.ReadWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse;
import com.senseonics.model.ReadWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse;
import com.senseonics.model.ReadWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse;
import com.senseonics.model.SensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse;
import com.senseonics.model.SensorInsertionDateTwoByteMemoryMapParsedResponse;
import com.senseonics.model.SensorInsertionTimeTwoByteMemoryMapParsedResponse;
import com.senseonics.model.SignalStrengthTwoByteMemoryMapParsedResponse;
import com.senseonics.model.SingleByteMemoryMapParsedResponse;
import com.senseonics.model.SyncingParsedResponse;
import com.senseonics.model.TransmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse;
import com.senseonics.model.TransmitterFirmwareVersionFourByteMemoryMapParsedResponse;
import com.senseonics.model.TransmitterModelNoFourByteMemoryMapParsedResponse;
import com.senseonics.model.TwoByteMemoryMapParsedResponse;
import com.senseonics.model.UnLinkedSensorIdAddressFourByteMemoryMapParsedResponse;
import com.senseonics.model.WriteClinicalModeSingleByteMemoryMapParsedResponse;
import com.senseonics.model.WriteSingleByteSerialFlashRegisterParsedResponse;
import com.senseonics.model.WriteTwoByteSerialFlashRegisterParsedResponse;
import com.senseonics.util.AlarmReceiver;
import com.senseonics.util.TimeChangedReceiver;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Timer;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module(
        addsTo = AndroidModule.class,
        library = true,
        injects = {AboutActivity.class,
                AlertEventActivity.class,
                CalibrateActivity.class,
                CalibrationEventActivity.class,
                DailyCalibrationActivity.class,
                MealTimesActivity.class,
                MealTimesStartEndTimePickerActivity.class,
                SoundSettingsSimplifiedActivity.class,
                SoundSelectionActivity.class,
                TempGlucoseProfileActivity.class,
                EulaScreenActivity.class,
                DeviceCompatibiityActivity.class,
                EventActivity.class,
                ExerciseEventActivity.class,
                GlucoseEventActivity.class,
                GlucoseSettingsActivity.class,
                HealthEventActivity.class,
                InsulinEventActivity.class,
                MealEventActivity.class,
                MyProductInfoActivity.class,
                MyReportsActivity.class,
                MySensorActivity.class,
                MyTransmitterActivity.class,
                NotificationEventActivity.class,
                NotificationsActivity.class,
                SensorListActivity.class,
                GlucoseUnitActivity.class,
                SplashActivity.class,
                SystemSettingsActivity.class,
                UserAccountBaseActivity.class,
                UserAccountActivity.class,
                UserAccountLoginActivity.class,
                WebviewActivity.class,
                WelcomeScreenActivity.class,
                InitialBluetoothPairingActivity.class,
                InitialDailyCalibrationActivity.class,
                CalibrateFragment.class,
                EventLogFragment.class,
                GraphFragment.class,
                PlacementGuideFragment.class,
                AboutFragment.class,
                DailyCalibrationFragment.class,
                MealTimesFragment.class,
                MealTimesStartEndTimePickerFragment.class,
                SoundSettingsSimplifiedFragment.class,
                TempGlucoseProfileFragment.class,
                NotificationsFragment.class,
                SettingsFragment.class,
                TimeChangedReceiver.class,
                AlarmReceiver.class,
                BitmapSenderActivity.class
        }
)
public class ApplicationModule {

    @Provides
    protected DefaultedHashMap<Integer, ParsedResponse> provideDefaultHashMapofIntegerToParsedResponse(PingParsedResponse pingParsedResponse,
                                                                                                       GlucoseLevelParsedResponse glucoseLevelParsedResponse,
                                                                                                       ReadSensorGlucoseAlertAndStatusParsedResponse readSensorGlucoseAlertAndStatusParsedResponse,
                                                                                                       ReadSingleByteSerialFlashRegisterParsedResponse readSingleByteSerialFlashRegisterParsedResponse,
                                                                                                       WriteSingleByteSerialFlashRegisterParsedResponse writeSingleByteSerialFlashRegisterParsedResponse,
                                                                                                       ReadTwoByteSerialFlashRegisterParsedResponse readTwoByteSerialFlashRegisterParsedResponse,
                                                                                                       WriteTwoByteSerialFlashRegisterParsedResponse writeTwoByteSerialFlashRegisterParsedResponse,
                                                                                                       ReadFourByteSerialFlashRegisterParsedResponse readFourByteSerialFlashRegisterParsedResponse,
                                                                                                       WritePatientEventParsedResponse writePatientEventParsedResponse,
                                                                                                       SyncingParsedResponse syncingParsedResponse,
                                                                                                       ReadFirstAndLastSensorGlucoseRecordNumbersParsedResponse readFirstAndLastSensorGlucoseRecordNumbersParsedResponse,
                                                                                                       ReadFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse readFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse,
                                                                                                       ReadFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse readFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse, ReadCurrentTransmitterDateAndTimeParsedResponse readCurrentTransmitterDateAndTimeParsedResponse) {
        DefaultedHashMap defaultedHashMap = new DefaultedHashMap(new NoOpParsedResponse());
        defaultedHashMap.put(pingParsedResponse.getExpectedResponseId(), pingParsedResponse);
        defaultedHashMap.put(glucoseLevelParsedResponse.getExpectedResponseId(), glucoseLevelParsedResponse);
        defaultedHashMap.put(readSensorGlucoseAlertAndStatusParsedResponse.getExpectedResponseId(), readSensorGlucoseAlertAndStatusParsedResponse);
        defaultedHashMap.put(readSingleByteSerialFlashRegisterParsedResponse.getExpectedResponseId(), readSingleByteSerialFlashRegisterParsedResponse);
        defaultedHashMap.put(writeSingleByteSerialFlashRegisterParsedResponse.getExpectedResponseId(), writeSingleByteSerialFlashRegisterParsedResponse);
        defaultedHashMap.put(readTwoByteSerialFlashRegisterParsedResponse.getExpectedResponseId(), readTwoByteSerialFlashRegisterParsedResponse);
        defaultedHashMap.put(writeTwoByteSerialFlashRegisterParsedResponse.getExpectedResponseId(), writeTwoByteSerialFlashRegisterParsedResponse);
        defaultedHashMap.put(readFourByteSerialFlashRegisterParsedResponse.getExpectedResponseId(), readFourByteSerialFlashRegisterParsedResponse);
        defaultedHashMap.put(writePatientEventParsedResponse.getExpectedResponseId(), writePatientEventParsedResponse);

        defaultedHashMap.put(CommandAndResponseIDs.ReadAllSensorGlucoseDataInSpecifiedRangeResponseID, syncingParsedResponse);
        defaultedHashMap.put(CommandAndResponseIDs.ReadAllSensorGlucoseAlertsInSpecifiedRangeResponseID, syncingParsedResponse);
        defaultedHashMap.put(CommandAndResponseIDs.ReadLogOfBloodGlucoseDataInSpecifiedRangeResponseID, syncingParsedResponse);

        defaultedHashMap.put(readFirstAndLastSensorGlucoseRecordNumbersParsedResponse.getExpectedResponseId(), readFirstAndLastSensorGlucoseRecordNumbersParsedResponse);
        defaultedHashMap.put(readFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse.getExpectedResponseId(), readFirstAndLastSensorGlucoseAlertRecordNumbersParsedResponse);
        defaultedHashMap.put(readFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse.getExpectedResponseId(), readFirstAndLastBloodGlucoseDataRecordNumbersParsedResponse);

        defaultedHashMap.put(readCurrentTransmitterDateAndTimeParsedResponse.getExpectedResponseId(), readCurrentTransmitterDateAndTimeParsedResponse);

        return defaultedHashMap;
    }

    @Provides
    @Named("readsinglebyteregisters")
    protected Map<int[], SingleByteMemoryMapParsedResponse> provideMapOfInArrayToSingleByteMemoryMapParsedresponse(ReadClinicalModeSingleByteMemoryMapParsedResponse clinicalModeMemoryMapParsedResponse,
                                                                                                                   ReadCurrentCalibrationPhaseSingleByteMemoryMapParsedResponse currentCalibrationPhaseMemoryMapParsedResponse,
                                                                                                                   ReadVibrateModeSingleByteMemoryMapParsedResponse readVibrateModeSingleByteMemoryMapParsedResponse,
                                                                                                                   ReadDoNotDisturbModeSingleByteMemoryMapParsedResponse readDoNotDisturbModeSingleByteMemoryMapParsedResponse,
                                                                                                                   ReadWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse,
                                                                                                                   ReadWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse,
                                                                                                                   ReadWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse,
                                                                                                                   ReadWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse,
                                                                                                                   BatteryPercentageSingleByteMemoryMapParsedResponse batteryPercentageSingleByteMemoryMapParsedResponse, HysteresisPercentageSingleByteMemoryMapParsedResponse hysteresisPercentageSingleByteMemoryMapParsedResponse,
                                                                                                                   HysteresisValueSingleByteMemoryMapParsedResponse hysteresisValueSingleByteMemoryMapParsedResponse,
                                                                                                                   HysteresisPredictivePercentageSingleByteMemoryMapParsedResponse hysteresisPredictivePercentageSingleByteMemoryMapParsedResponse,
                                                                                                                   HysteresisPredictiveValueSingleByteMemoryMapParsedResponse hysteresisPredictiveValueSingleByteMemoryMapParsedResponse, ReadWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse, ReadWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse, ReadWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse, ReadWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse) {
        Map mapMemoryMapParsedResponse = new LinkedHashMap();
        mapMemoryMapParsedResponse.put(clinicalModeMemoryMapParsedResponse.getMemoryAddress(), clinicalModeMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(currentCalibrationPhaseMemoryMapParsedResponse.getMemoryAddress(), currentCalibrationPhaseMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readVibrateModeSingleByteMemoryMapParsedResponse.getMemoryAddress(), readVibrateModeSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readDoNotDisturbModeSingleByteMemoryMapParsedResponse.getMemoryAddress(), readDoNotDisturbModeSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(batteryPercentageSingleByteMemoryMapParsedResponse.getMemoryAddress(), batteryPercentageSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(hysteresisPercentageSingleByteMemoryMapParsedResponse.getMemoryAddress(), hysteresisPercentageSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(hysteresisValueSingleByteMemoryMapParsedResponse.getMemoryAddress(), hysteresisValueSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(hysteresisPredictivePercentageSingleByteMemoryMapParsedResponse.getMemoryAddress(), hysteresisPredictivePercentageSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(hysteresisPredictiveValueSingleByteMemoryMapParsedResponse.getMemoryAddress(), hysteresisPredictiveValueSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse);
        return mapMemoryMapParsedResponse;
    }

    @Provides
    @Named("readtwobyteregisters")
    protected Map<int[], TwoByteMemoryMapParsedResponse> provideMapOfInArrayToTwoByteMemoryMapParsedresponse(CalibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse calibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse,
                                                                                                             SensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse sensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse,
                                                                                                             SensorInsertionDateTwoByteMemoryMapParsedResponse sensorInsertionDateTwoByteMemoryMapParsedResponse,
                                                                                                             SensorInsertionTimeTwoByteMemoryMapParsedResponse sensorInsertionTimeTwoByteMemoryMapParsedResponse,
                                                                                                             LastCalibrationDateTwoByteMemoryMapParsedResponse lastCalibrationDateTwoByteMemoryMapParsedResponse,
                                                                                                             LastCalibrationTimeTwoByteMemoryMapParsedResponse lastCalibrationTimeTwoByteMemoryMapParsedResponse,
                                                                                                             CalibrationPhaseStartDateTwoByteMemoryMapParsedResponse calibrationPhaseStartDateTwoByteMemoryMapParsedResponse,
                                                                                                             CalibrationPhaseStartTimeTwoByteMemoryMapParsedResponse calibrationPhaseStartTimeTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse,
                                                                                                             ReadWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse,
                                                                                                             SignalStrengthTwoByteMemoryMapParsedResponse signalStrengthTwoByteMemoryMapParsedResponse,
                                                                                                             AlgorithmParameterFormatVersionTwoByteMemoryMapParsedResponse algorithmParameterFormatVersionTwoByteMemoryMapParsedResponse, ReadEEP24MSPTwoByteMemoryParsedResponse readEEP24MSPTwoByteMemoryParsedResponse, ReadDayStartTimeTwoByteMemoryParsedResponse readDayStartTimeTwoByteMemoryParsedResponse, ReadNightStartTimeTwoByteMemoryParsedResponse readNightStartTimeTwoByteMemoryParsedResponse, ReadRawDataValue1TwoByteMemoryParsedResponse readRawDataValue1TwoByteMemoryParsedResponse, ReadRawDataValue2TwoByteMemoryParsedResponse readRawDataValue2TwoByteMemoryParsedResponse, ReadRawDataValue3TwoByteMemoryParsedResponse readRawDataValue3TwoByteMemoryParsedResponse, ReadRawDataValue4TwoByteMemoryParsedResponse readRawDataValue4TwoByteMemoryParsedResponse, ReadRawDataValue5TwoByteMemoryParsedResponse readRawDataValue5TwoByteMemoryParsedResponse, ReadRawDataValue6TwoByteMemoryParsedResponse readRawDataValue6TwoByteMemoryParsedResponse, ReadRawDataValue7TwoByteMemoryParsedResponse readRawDataValue7TwoByteMemoryParsedResponse, ReadRawDataValue8TwoByteMemoryParsedResponse readRawDataValue8TwoByteMemoryParsedResponse)

    {
        Map mapMemoryMapParsedResponse = new LinkedHashMap();
        mapMemoryMapParsedResponse.put(calibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse.getMemoryAddress(), calibrationsMadeInThisPhaseTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(sensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse.getMemoryAddress(), sensorGlucoseSamplingIntervalTwoByteMemoryMappedParsedResponse);
        mapMemoryMapParsedResponse.put(sensorInsertionDateTwoByteMemoryMapParsedResponse.getMemoryAddress(), sensorInsertionDateTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(sensorInsertionTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), sensorInsertionTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(lastCalibrationDateTwoByteMemoryMapParsedResponse.getMemoryAddress(), lastCalibrationDateTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(lastCalibrationTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), lastCalibrationTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(calibrationPhaseStartDateTwoByteMemoryMapParsedResponse.getMemoryAddress(), calibrationPhaseStartDateTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(calibrationPhaseStartTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), calibrationPhaseStartTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(signalStrengthTwoByteMemoryMapParsedResponse.getMemoryAddress(), signalStrengthTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(algorithmParameterFormatVersionTwoByteMemoryMapParsedResponse.getMemoryAddress(), algorithmParameterFormatVersionTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readEEP24MSPTwoByteMemoryParsedResponse.getMemoryAddress(), readEEP24MSPTwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readDayStartTimeTwoByteMemoryParsedResponse.getMemoryAddress(), readDayStartTimeTwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readNightStartTimeTwoByteMemoryParsedResponse.getMemoryAddress(), readNightStartTimeTwoByteMemoryParsedResponse);

        /** #3194 */
        mapMemoryMapParsedResponse.put(readRawDataValue1TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue1TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue2TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue2TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue3TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue3TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue4TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue4TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue5TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue5TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue6TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue6TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue7TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue7TwoByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readRawDataValue8TwoByteMemoryParsedResponse.getMemoryAddress(), readRawDataValue8TwoByteMemoryParsedResponse);

        return mapMemoryMapParsedResponse;
    }

    @Provides
    @Named("writetwobyteregisters")
    public Map<int[], TwoByteMemoryMapParsedResponse> provideMapOfInArrayToWriteTwoByteMemoryMapParsedresponse(ReadWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse,
                                                                                                               ReadWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse,
                                                                                                               ReadWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse,
                                                                                                               ReadWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse,
                                                                                                               ReadWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse,
                                                                                                               ReadWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse) {
        Map mapMemoryMapParsedResponse = new LinkedHashMap();
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteHighGlucoseTargetTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteLowGlucoseTargetTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteMorningCalibrationTimeTwoByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse.getMemoryAddress(), readWriteEveningCalibrationTimeTwoByteMemoryMapParsedResponse);
        return mapMemoryMapParsedResponse;
    }

    @Provides
    @Named("readfourbyteregisters")
    protected Map<int[], FourByteMemoryMapParsedResponse> provideMapOfInArrayToFourByteMemoryMapParsedResponse(LinkedSensorIdAddressFourByteMemoryMapParsedResponse linkedSensorIdAddressFourByteMemoryMapParsedResponse,
                                                                                                               UnLinkedSensorIdAddressFourByteMemoryMapParsedResponse unLinkedSensorIdAddressFourByteMemoryMapParsedResponse,
                                                                                                               TransmitterModelNoFourByteMemoryMapParsedResponse transmitterModelNoFourByteMemoryMapParsedResponse,
                                                                                                               TransmitterFirmwareVersionFourByteMemoryMapParsedResponse transmitterFirmwareVersionFourByteMemoryMapParsedResponse,
                                                                                                               TransmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse transmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse, ReadMEPSavedValueFourByteMemoryParsedResponse readMEPSavedValueFourByteMemoryParsedResponse, ReadMEPSavedRefChannelMetricFourByteMemoryParsedResponse readMEPSavedRefChannelMetricFourByteMemoryParsedResponse, ReadMEPSavedDriftMetricFourByteMemoryParsedResponse readMEPSavedDriftMetricFourByteMemoryParsedResponse, ReadMEPSavedLowRefMetricFourByteMemoryParsedResponse readMEPSavedLowRefMetricFourByteMemoryParsedResponse, ReadMEPSavedSpikeFourByteMemoryParsedResponse readMEPSavedSpikeFourByteMemoryParsedResponse) {
        Map mapMemoryMapParsedResponse = new LinkedHashMap();
        mapMemoryMapParsedResponse.put(linkedSensorIdAddressFourByteMemoryMapParsedResponse.getMemoryAddress(), linkedSensorIdAddressFourByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(unLinkedSensorIdAddressFourByteMemoryMapParsedResponse.getMemoryAddress(), unLinkedSensorIdAddressFourByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(transmitterModelNoFourByteMemoryMapParsedResponse.getMemoryAddress(), transmitterModelNoFourByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(transmitterFirmwareVersionFourByteMemoryMapParsedResponse.getMemoryAddress(), transmitterFirmwareVersionFourByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(transmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse.getMemoryAddress(), transmitterFirmwareVersionExtensionFourByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readMEPSavedValueFourByteMemoryParsedResponse.getMemoryAddress(), readMEPSavedValueFourByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readMEPSavedRefChannelMetricFourByteMemoryParsedResponse.getMemoryAddress(), readMEPSavedRefChannelMetricFourByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readMEPSavedDriftMetricFourByteMemoryParsedResponse.getMemoryAddress(), readMEPSavedDriftMetricFourByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readMEPSavedLowRefMetricFourByteMemoryParsedResponse.getMemoryAddress(), readMEPSavedLowRefMetricFourByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readMEPSavedSpikeFourByteMemoryParsedResponse.getMemoryAddress(), readMEPSavedSpikeFourByteMemoryParsedResponse);

        return mapMemoryMapParsedResponse;
    }


    @Provides
    @Named("writesinglebyteregisters")
    protected Map<int[], SingleByteMemoryMapParsedResponse> provideMapOfInArrayToMemoryMapParsedResponseForWrite(WriteClinicalModeSingleByteMemoryMapParsedResponse writeClinicalModeMemoryMapParsedResponse,
                                                                                                                 ReadWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse,
                                                                                                                 ReadWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse,
                                                                                                                 ReadWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse,
                                                                                                                 ReadWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse, ReadWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse, ReadWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse, ReadWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse, ReadWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse) {
        Map mapMemoryMapParsedResponse = new LinkedHashMap();
        mapMemoryMapParsedResponse.put(writeClinicalModeMemoryMapParsedResponse.getMemoryAddress(), writeClinicalModeMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWritePredictiveAlertsActivatedSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWritePredictiveFallingRateAlertMinuteIntervalSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWriteRateAlertFallingThresholdSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse.getMemoryAddress(), readWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteLowGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse);
        mapMemoryMapParsedResponse.put(readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse.getMemoryAddress(), readWriteHighGlucoseAlarmRepeatIntervalNightTimeSingleByteMemoryParsedResponse);
        return mapMemoryMapParsedResponse;
    }

    @Provides
    @Singleton
    protected BluetoothServiceCommandClient provideBluetoothServiceCommandClient(Context context) {
        return new BluetoothServiceCommandClient(context);
    }

    @Provides
    protected Timer provideTimer() {
        return new Timer();
    }

    @Provides
    @Singleton
    protected BluetoothAdapterWrapper providesBluetoothAdapter() {
        return new BluetoothAdapterWrapper(BluetoothAdapter.getDefaultAdapter());
    }

    @Provides
    protected AlarmManager providesAlarmManager(Context context) {
        return (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    }
}

