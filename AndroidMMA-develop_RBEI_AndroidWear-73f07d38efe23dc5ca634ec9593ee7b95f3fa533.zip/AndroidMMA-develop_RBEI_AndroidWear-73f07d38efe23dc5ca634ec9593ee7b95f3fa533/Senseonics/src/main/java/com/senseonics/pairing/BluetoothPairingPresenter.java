package com.senseonics.pairing;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;

import com.senseonics.bluetoothle.BluetoothConnectionEvent;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.BluetoothServiceBoundEvent;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.pairing.events.model.BeginDiscoveryEvent;
import com.senseonics.pairing.events.model.DiscoveryEvent;
import com.senseonics.pairing.events.model.TimeoutEvent;
import com.senseonics.pairing.events.model.TransmittersChangedEvent;
import com.senseonics.pairing.events.view.RefreshTransmittersPressed;
import com.senseonics.pairing.events.view.TransmitterPressed;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class BluetoothPairingPresenter {
    private BluetoothPairingModel model;
    private BluetoothPairingView view;
    private EventBus bus;
    private final BluetoothEnabler enabler;
    private BluetoothAdapter adapter;
    private final Activity activity;

    @Inject
    public BluetoothPairingPresenter(EventBus bus, BluetoothPairingModel model,
                                     BluetoothPairingView view, BluetoothEnabler enabler, BluetoothAdapter adapter,
                                     Activity activity) {
        this.model = model;
        this.view = view;
        this.bus = bus;
        this.enabler = enabler;
        this.adapter = adapter;
        this.activity = activity;
    }

    public void resume() {
        refresh();
    }

    public void start() {
        bus.registerSticky(this);
    }

    public void stop() {
        bus.unregister(this);
    }

    public void onEvent(BluetoothServiceBoundEvent event) {
        refresh();
    }

    private void refresh() {
        if (activity instanceof MainActivity) {
            ((MainActivity) activity).selectItem(7);
            ((MainActivity) activity).refreshAfterFragmentChanged();
        }
        view.refreshList();
        model.initiateInitialDiscovery();
    }

    public void onEvent(RefreshTransmittersPressed event) {
        if (enabler.isEnabled()) {
            model.discover();
        }
    }

    public void onEvent(TransmitterPressed event) {
        model.transmitterPressed(event.transmitter);
    }

    public void onEvent(BeginDiscoveryEvent event) {
        view.beginRefreshButtonAnimation();
    }

    public void onEvent(TransmitterConnectionEvent event) {
        model.refreshConnectionState(event.getTransmitter());
    }

    public void onEvent(BluetoothConnectionEvent event) {
        boolean isEnabled = event.isBluetoothEnabled();
        model.triggerBluetoothEnabled(isEnabled);

        //TODO: should discover there? More test needed
//    if (isEnabled) {
//      model.discover();
//    }
    }

    public void onEvent(TransmittersChangedEvent event) {
        view.setDevices(event.transmitters);
    }

    public void onEvent(DiscoveryEvent event) {
        view.stopRefreshButtonAnimation();
    }

    public void onEvent(TimeoutEvent event) {
        view.stopRefreshButtonAnimation();
    }
}
