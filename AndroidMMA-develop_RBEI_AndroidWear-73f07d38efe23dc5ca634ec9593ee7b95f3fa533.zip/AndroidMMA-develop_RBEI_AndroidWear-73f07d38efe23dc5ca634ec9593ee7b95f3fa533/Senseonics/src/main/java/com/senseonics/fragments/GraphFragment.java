package com.senseonics.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.DialogUtils.DateDialogManager;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.events.EventPoint;
import com.senseonics.events.ModelChangedRefreshGraphEvent;
import com.senseonics.events.RefreshGraphEvent;
import com.senseonics.events.TempProfileTurnedOffEvent;
import com.senseonics.gen12androidapp.LandscapeGraphViewActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.graph.GraphManagerView;
import com.senseonics.graph.LazyLoadGraphModel;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.model.BATTERY_LEVEL;
import com.senseonics.model.ModelChangedEvent;
import com.senseonics.model.SIGNAL_STRENGTH;
import com.senseonics.util.AddEventMenuCreator;
import com.senseonics.util.Destroyer;
import com.senseonics.util.TypefaceFetcher;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.ARROW_TYPE;
import com.senseonics.util.Utils.TransmitterMessageCode;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class GraphFragment extends BaseFragment {
    @Inject
    LazyLoadGraphModel lazyLoadGraphModel;

    // private ScrollView scrollView;
    private RelativeLayout layout, topLayout;
    private GraphManagerView graphManagerView;
    private int topLayoutHeight, currentTopLayoutHeight, popUpEventHeight, arrowSize;

    //    private RelativeLayout popUpEventView;
    private LayoutInflater inflater;
    private View glucoseValueDisplay, alertView;
    private RelativeLayout parentLayout;

    private ImageView signalStrengthImageView, batteryStrengthImageView, arrowImageView, tempProfileImageView;
    private TextView glucoseValueTextView, glucoseUnitTextView, transmitterNameTextView;

    private int graphHeight, graphPaddingTop, alertInfoHeight;
    private Dialog dialog;
    private ImageButton expandImageButton;
    private PopupGraphManagerView popupGraphManagerView;

    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        Log.i(GraphFragment.class.getSimpleName(), "in onCreateView");

        View view = inflater.inflate(R.layout.fragment_graph, null);
        init(view, getActivity());
        GraphUtils.listPopUpIsVisible = false;
        alertInfoHeight = topLayoutHeight / 4;

        expandImageButton = (ImageButton) view.findViewById(R.id.expandImageButton);
        expandImageButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LandscapeGraphViewActivity.class);
                getActivity().startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i(GraphFragment.class.getSimpleName(), "in onResume");

        EventBus.getDefault().registerSticky(this);

        /** Show progress dialog */
        createProgressDialogIfNeeded();
        showProgressDialogIfNeeded();

        /** Create a new GraphManagerView upon onResume() */
        if (graphManagerView == null) {
            addGraphManagerView(
                    getActivity()); /** refreshGraphWithExistingStartEndDates() is done inside */
        } else {
            refreshGraph();
        }

        refreshGlucosePanel();
        layout.bringChildToFront(expandImageButton);

        /** #3664 */
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).refreshAfterFragmentChanged();
        }
    }

    @Override
    public void onPause() {
        EventBus.getDefault().unregister(this);

        dismissProgressDialogIfNeeded();

        /** Nullify the GraphManagerView upon onPause() */
        graphManagerView = null;

        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Destroyer.destroy(graphManagerView);
    }

    private void createProgressDialogIfNeeded() {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
            progressDialog.setCancelable(false);
        }
    }

    private void showProgressDialogIfNeeded() {
        if ((progressDialog != null) && (getActivity() != null)) {
            if (!progressDialog.isShowing()) {
                progressDialog.show();
            }
        }
    }

    private void dismissProgressDialogIfNeeded() {
        if ((progressDialog != null) && (getActivity() != null)) {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }

    // Tint the image with a specified color
    private Drawable imageColorTint(int drawableInt, String colorString) {
        int tint = Color.parseColor(colorString);
        PorterDuff.Mode mode = PorterDuff.Mode.SRC_ATOP;
        Drawable icon = getResources().getDrawable(drawableInt);
        icon.setColorFilter(tint, mode);
        return icon;
    }

    private void refreshGlucosePanel() {
        // Update the graph components
        Log.i(GraphFragment.class.getSimpleName(), "in refreshGlucosePanel");

        setGlucoseLevel();
        setGlucoseUnit();
        setSignalStrength();
        setBatteryLevel();
        setTransmitterName();
        setTempProfileIcon(); /** #3160 */
    }

    /**
     * #3640
     */
    public void onEventMainThread(ModelChangedRefreshGraphEvent event) {
        refreshGraph();
    }

    public void onEventMainThread(ModelChangedEvent event) {
        refreshGlucosePanel();
        /** #3640 Refresh graph in ModelChangedRefreshGraphEvent
         * refreshGraph(); */
    }

    /** #3640
     public void onEventMainThread(SyncingProgressUpdateEvent event) {
     refreshGraph();
     }*/

    /**
     * #3160
     */
    public void onEventMainThread(TempProfileTurnedOffEvent event) {
        refreshGlucosePanel();
    }

    /**
     * #3224
     */
    public void onEventMainThread(RefreshGraphEvent event) {
        refreshGraph();
    }

    private void setSignalStrength() {
        if (signalStrengthImageView != null) {
            int resId = Utils.getImageForSignalStrength(transmitterStateModel.getSignalStrength());

            if ((transmitterStateModel.getSignalStrength() == SIGNAL_STRENGTH.NO_SIGNAL)
                    || (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.SensorAwolAlarm)
                    || (transmitterStateModel.getTransmitterConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED)) {
                resId = R.drawable.signal_strength_none;
            }

            if (resId != -1) {
                if (resId == R.drawable.signal_strength_none) {
                    // Change the color to Red if signal strength is NONE
                    if (getActivity() != null) {
                        signalStrengthImageView.setImageDrawable(imageColorTint(resId, "#cf3a3a"));
                    }
                } else {
                    signalStrengthImageView.setImageResource(resId);
                }
            }
        }
    }


    private void setBatteryLevel() {
        if (batteryStrengthImageView == null && getView() != null)
            batteryStrengthImageView = (ImageView) getView().findViewById(
                    R.id.batteryStrengthImageView);

        if (batteryStrengthImageView != null) {
            int resId = Utils.getImageForBatteryLevel(transmitterStateModel.getBatteryLevel());

            if ((transmitterStateModel.getTransmitterConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED)
                    || (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.CriticalFaultAlarm)) {
                resId = R.drawable.icon_battery_0;
            } else if ((transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.EmptyBatteryAlarm)
                    || (transmitterStateModel.getBatteryLevel() == BATTERY_LEVEL.BL_0)) {
                resId = R.drawable.icon_battery_low;
            }

            if (resId != -1) {
                batteryStrengthImageView.setImageResource(resId);
            }
        }
    }

    private void setGlucoseLevel() {
        if (glucoseValueTextView == null && getView() != null)
            glucoseValueTextView = (TextView) getView().findViewById(
                    R.id.glucoseValue);

        if (glucoseValueTextView != null) {
            Boolean shouldDisplayGlucose = true;

            if ((transmitterStateModel.getTransmitterConnectionState() != Transmitter.CONNECTION_STATE.CONNECTED)
                    || (transmitterStateModel.getSignalStrength() == SIGNAL_STRENGTH.NO_SIGNAL)
                    || (transmitterStateModel.getCurrentMessageCode() == Utils.TransmitterMessageCode.SensorAwolAlarm)) {
                shouldDisplayGlucose = false;
            } else {
                shouldDisplayGlucose = true;
            }
            // draw the arrow
            setArrowType(shouldDisplayGlucose);

            String glucoseLevel = null;

            if (shouldDisplayGlucose == false) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
            } else if (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.SeriouslyLowAlarm) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_OUT_OF_RANGE_LOW_STRING;
            } else if (transmitterStateModel.getCurrentMessageCode() == TransmitterMessageCode.SeriouslyHighAlarm) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_OUT_OF_RANGE_HIGH_STRING;
            } else if (transmitterStateModel.isGlucoseLevelWithinRange() == false) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
            } else if (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(transmitterStateModel.getCurrentMessageCode())) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
            } else if (transmitterStateModel.checkIfNonGlucoseShowingPhase()) {
                glucoseLevel = Utils.GLUCOSE_LEVEL_UNKNOWN_STRING;
            } else {
                glucoseLevel = Utils.getGlucoseLevelValue(transmitterStateModel.getGlucoseLevel());
            }

            int textColorId;
            if (shouldDisplayGlucose == true) {
                textColorId = getResources().getColor(R.color.black);
            } else {
                textColorId = getResources().getColor(R.color.gray_text_glucose);
            }
            glucoseValueTextView.setText(glucoseLevel);
            glucoseValueTextView.setTextColor(textColorId);
            if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
                glucoseValueTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.glucose_value_size_mg_dl));
            } else {
                glucoseValueTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.glucose_value_size_mmol_l));
            }
            setDashTextBold(glucoseValueTextView);
        }
    }

    private void setArrowType(Boolean shouldDisplayGlucose) {
        int resId = transmitterStateModel.getGlucoseTrendDirection().getImageId();
        if (arrowImageView != null) {
            int alpha;
            // Set the alpha of the arrow image: see iOS implementation
            if (((transmitterStateModel.getGlucoseTrendDirection() == ARROW_TYPE.STALE)
                    || (shouldDisplayGlucose == false)
                    || (blindedGlucoseCauseIdentifier.messageCodeCanBeReasonForBlindedGlucose(transmitterStateModel.getCurrentMessageCode()))
                    || (transmitterStateModel.isGlucoseLevelWithinRange() == false))
                    || (transmitterStateModel.checkIfNonGlucoseShowingPhase())) {
                alpha = 102; // 0.4/1
            } else {
                alpha = 255; // 1/1
            }
            arrowImageView.setImageResource(resId);
            arrowImageView.setImageAlpha(alpha);
        }
    }

    private void setGlucoseUnit() {
        if (glucoseUnitTextView != null) {
            String glucoseUnit = Utils.getGlucoseUnitString(getActivity());
            glucoseUnitTextView.setText(glucoseUnit);
            // #2067 Glucose Unit label should be updated based on Connection State
            if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                glucoseUnitTextView.setTextColor(getResources()
                        .getColor(R.color.black));
            } else {
                glucoseUnitTextView.setTextColor(getResources()
                        .getColor(R.color.gray_text_glucose));
            }
        }
    }

    private void setTransmitterName() {
        String name = null;
        name = transmitterStateModel.getTransmitterName();
        transmitterNameTextView.setText(name == null ? "" : name);

        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            transmitterNameTextView.setTextColor(getResources().getColor(R.color.black));
        } else {
            transmitterNameTextView.setTextColor(getResources().getColor(R.color.gray_medium));
        }
    }

    /**
     * #3160
     */
    private void setTempProfileIcon() {
        Boolean shouldDisplay = false;
        // connected, draw
        if (transmitterStateModel.isTransmitterConnected()) {
            if (tempProfileManager.getTempProfileEnabled()) {
                shouldDisplay = true;
            }
        }

        if (tempProfileImageView != null) {
            if (shouldDisplay) {
                tempProfileImageView.setVisibility(View.VISIBLE);
            } else {
                tempProfileImageView.setVisibility(View.INVISIBLE);
            }
        }
    }

    private int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height",
                "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private void init(View content, Context context) {

        inflater = LayoutInflater.from(context);

        layout = (RelativeLayout) content.findViewById(R.id.graph_parent);

        int titleBarHeight = getStatusBarHeight();

        TypedValue tv = new TypedValue();
        context.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv,
                true);
        int actionBarHeight = getResources().getDimensionPixelSize(
                tv.resourceId);

        // -----above graph------------------------------
        topLayoutHeight = Utils.screenHeight * 25 / 100;
        currentTopLayoutHeight = topLayoutHeight;
        topLayout = new RelativeLayout(context);
        RelativeLayout.LayoutParams paramsTop = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, topLayoutHeight);
        topLayout.setLayoutParams(paramsTop);
        topLayout.setId(R.id.top_layout);
        topLayout.setBackgroundColor(getResources().getColor(
                R.color.graph_white));
        layout.addView(topLayout);

        glucoseValueDisplay = inflater.inflate(R.layout.glucose_value_display,
                null);
        glucoseValueDisplay.setId(R.id.glucose_value_display);

        RelativeLayout.LayoutParams paramsCenter = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, topLayoutHeight);
        glucoseValueDisplay.setLayoutParams(paramsCenter);

        topLayout.addView(glucoseValueDisplay);

        signalStrengthImageView = (ImageView) glucoseValueDisplay.findViewById(R.id.signalStrengthImageView);
        batteryStrengthImageView = (ImageView) glucoseValueDisplay.findViewById(R.id.batteryStrengthImageView);
        glucoseValueTextView = (TextView) glucoseValueDisplay.findViewById(R.id.glucoseValue);
        glucoseUnitTextView = (TextView) glucoseValueDisplay.findViewById(R.id.glucoseUnit);
        arrowImageView = (ImageView) glucoseValueDisplay.findViewById(R.id.arrow);
        transmitterNameTextView = (TextView) glucoseValueDisplay.findViewById(R.id.transmitterName);
        tempProfileImageView = (ImageView) glucoseValueDisplay.findViewById(R.id.tempProfileImageView);
        // ----------------------------------------------

        graphHeight = Utils.screenHeight - titleBarHeight - actionBarHeight
                - topLayoutHeight;

        if (Utils.screenWidth > 350) {
            graphPaddingTop = Utils.screenWidth / 10;
        } else {
            graphPaddingTop = Utils.screenWidth / 5;
        }


        // #2068 Tapping on the glucose arrow field should move the graph to NOW
        glucoseValueDisplay.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (graphManagerView != null) {
                    graphManagerView.setCurrentVisibleDate(Utils.currentDate);
                    graphManagerView.invalidate();
                }
            }
        });

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, graphHeight);
        params.addRule(RelativeLayout.BELOW, R.id.top_layout);
        parentLayout = new RelativeLayout(context);
        parentLayout.setLayoutParams(params);
        layout.addView(parentLayout);

        arrowSize = topLayoutHeight / 5;

        addPopUpView();

        alertView = createAlertView();
        addAlertViewToTopLayout(alertView);
    }

    private void showHideAlertInfo(int visibility) {
        currentTopLayoutHeight = topLayoutHeight;
        RelativeLayout.LayoutParams paramsCenter = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                currentTopLayoutHeight);
        glucoseValueDisplay.setLayoutParams(paramsCenter);
        alertView.setVisibility(visibility);// View.INVISIBLE);
    }

    private View createAlertView() {

        if (inflater == null)
            inflater = LayoutInflater.from(getActivity());

        View view = inflater.inflate(R.layout.notification_bar, null);
        view.setBackgroundColor(Color.CYAN);
        return view;
    }

    private void addAlertViewToTopLayout(View view) {

        RelativeLayout.LayoutParams paramsAlert = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, alertInfoHeight);
        paramsAlert.addRule(RelativeLayout.BELOW, R.id.glucose_value_display);
        view.setLayoutParams(paramsAlert);
        topLayout.addView(view);
    }

    public void removeAlertView() {
        topLayout.removeView(alertView);

        RelativeLayout.LayoutParams paramsTop = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, topLayoutHeight);
        topLayout.setLayoutParams(paramsTop);
    }

    public void refreshGraph() {
        if (lazyLoadGraphModel != null) {
            lazyLoadGraphModel.refreshGraphWithExistingStartEndDates();
        }
    }

    public void validateGraph() {
        if (lazyLoadGraphModel != null) {
            lazyLoadGraphModel.refreshGraphWithNewStartEndDates();
        }
    }

    private void addGraphManagerView(Activity activity) {

        graphManagerView = new GraphManagerView(activity, Utils.screenWidth,
                graphHeight, graphPaddingTop, Utils.daysCount,
                Utils.currentDate);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, graphHeight);
        graphManagerView.setLayoutParams(params);
        graphManagerView.setId(R.id.graph_manager_view);
        graphManagerView.setGraphManagerViewListener(
                new GraphManagerView.GraphManagerViewListener() {
                    @Override
                    public void onDateChanged(Date date) {
                        lazyLoadGraphModel.refreshWithDate(date);
                    }

                    @Override
                    public void onGlucoseValuesRefreshed() {
                        lazyLoadGraphModel.refreshGraphWithExistingStartEndDates();
                    }
                });

        activity.runOnUiThread(new Runnable() {

            @Override
            public void run() {

                parentLayout.removeAllViews();
                parentLayout.addView(graphManagerView);

                graphManagerView.setOnDateClickListener(onDateClickListener);
                graphManagerView.setManager(graphManager);

                lazyLoadGraphModel.refreshGraphWithExistingStartEndDates();
            }
        });

    }

    private void addPopUpView() {

        popupGraphManagerView = new PopupGraphManagerView(getActivity(), topLayoutHeight);

        popupGraphManagerView.setVisibility(View.GONE);
        layout.addView(popupGraphManagerView);

    }

    private void setDashTextBold(TextView tv) {
        if (tv.getText().equals(Utils.GLUCOSE_LEVEL_UNKNOWN_STRING))
            tv.setTypeface(TypefaceFetcher.get(getActivity(), "Fonts/Roboto-Bold.ttf"));
        else
            tv.setTypeface(TypefaceFetcher.get(getActivity(), "Fonts/Roboto-Regular.ttf"));
    }

    private void createPickerViewDialog(Calendar calendar) {
        if (calendar != null) {
            final DateDialogManager dialogManager = new DateDialogManager() {
                @Override
                public void onDateSelected(Calendar calendar) {
                    if (graphManagerView != null) {
                        graphManagerView.setCurrentVisibleDate(calendar);
                    }
                }
            };

            if (calendar.getTimeInMillis() < Utils.startDate.getTimeInMillis()) {
                calendar = Utils.startDate;
            }
            if (calendar.getTimeInMillis() > Utils.currentDate.getTimeInMillis())
                calendar = Utils.currentDate;

            if (dialog != null && dialog.isShowing())
                dialog.dismiss();

            dialog = dialogUtils.createDatePickerDialog(getActivity(), calendar, Utils.startDate,
                    Utils.currentDate, dialogManager);
            dialog.show();
        }
    }

    OnClickListener onDateClickListener = new OnClickListener() {

        @Override
        public void onClick(View v) {
            Calendar currentVisibleDay = null;
            if (graphManagerView != null)
                currentVisibleDay = graphManagerView.getCurrentVisibleDate();
            if (currentVisibleDay == null)
                currentVisibleDay = Calendar.getInstance();

            createPickerViewDialog(currentVisibleDay);
        }
    };

    GraphManagerView.GraphManager graphManager = new GraphManagerView.GraphManager() {

        @Override
        public void showEventPopUp(float x, EventPoint eventPoint) {
            popupGraphManagerView.putEventPopUp(x, eventPoint, currentTopLayoutHeight, alertInfoHeight);
        }

        @Override
        public void showGlucosePopUp(float x, Glucose glucose) {
            popupGraphManagerView.putGlucosePopUp(x, glucose, currentTopLayoutHeight, alertInfoHeight);
        }

        @Override
        public void showNoGlucoseReadingPopUp(float x) {
            popupGraphManagerView.putNoSensorGlucosePopUp(x, currentTopLayoutHeight, alertInfoHeight);
        }

        @Override
        public void hideEventGlucosePopUp() {
            popupGraphManagerView.setVisibility(View.INVISIBLE);
        }

        @Override
        public void onEventSelected(EventPoint eventPoint) {
            Utils.showEventDetails(GraphFragment.this, eventPoint);
        }

        @Override
        public void tapAddNewEvent(Calendar calendar) {
            Log.i("Tap Test", "GraphFragment: tapAddNewEvent->calendar:" + Utils.formatDate_TimeZone(calendar, TimeZone.getDefault()));
            if (getActivity() != null) {
                AddEventMenuCreator.createLogEventMenuDialog(getActivity(), calendar);
            }
        }

        @Override
        public void dismissProgressDialog() {
            dismissProgressDialogIfNeeded();
        }

    };

}
