package com.senseonics.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.MealTimeDataHandler;
import com.senseonics.gen12androidapp.MealTimesStartEndTimePickerActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.TimeZone;


public class MealTimesFragment extends BaseFragment {

	private TextView mealTimeTextTextView,breakfastTextView,lunchTextView,snackTextView,dinnerTextView,sleepTextView;

	private MealTimesManager mealTimesManager;
	private MealTimeDataHandler.MealType mealType;
	private RelativeLayout breakfastPicker, lunchPicker, snackPicker,dinnerPicker, sleepPicker;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater,container, savedInstanceState);

		View view = inflater.inflate(R.layout.fragment_mealtimes, container, false);

		mealTimeTextTextView = (TextView) view.findViewById(R.id.mealTimeText);

		mealType = MealTimeDataHandler.MealType.BREAKFAST;
		breakfastPicker = (RelativeLayout) view.findViewById(R.id.breakfastPicker);
		lunchPicker = (RelativeLayout) view.findViewById(R.id.lunchPicker);
		snackPicker = (RelativeLayout) view.findViewById(R.id.snackPicker);
		dinnerPicker = (RelativeLayout) view.findViewById(R.id.dinnerPicker);
		sleepPicker = (RelativeLayout) view.findViewById(R.id.sleepPicker);

		breakfastTextView = (TextView) view.findViewById(R.id.breakfastTime);
		lunchTextView = (TextView) view.findViewById(R.id.lunchTime);
		snackTextView = (TextView) view.findViewById(R.id.snackTime);
		dinnerTextView = (TextView) view.findViewById(R.id.dinnerTime);
		sleepTextView = (TextView) view.findViewById(R.id.sleepTime);

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();
		updateView();
	}

	private void updateView() {
		//Set Text
		MealTimeDataHandler mealTimeDataHandler;
		mealTimeDataHandler = new MealTimeDataHandler(getActivity());
		setTimeTextView(breakfastTextView,mealTimeDataHandler.getBreakfastStartHour(), mealTimeDataHandler.getBreakfastStartMinute(),
				mealTimeDataHandler.getBreakfastEndHour(), mealTimeDataHandler.getBreakfastEndMinute());

		setTimeTextView(lunchTextView,mealTimeDataHandler.getLunchStartHour(), mealTimeDataHandler.getLunchStartMinute(),
				mealTimeDataHandler.getLunchEndHour(), mealTimeDataHandler.getLunchEndMinute());

		setTimeTextView(snackTextView,mealTimeDataHandler.getSnackStartHour(), mealTimeDataHandler.getSnackStartMinute(),
				mealTimeDataHandler.getSnackEndHour(), mealTimeDataHandler.getSnackEndMinute());

		setTimeTextView(dinnerTextView, mealTimeDataHandler.getDinnerStartHour(), mealTimeDataHandler.getDinnerStartMinute(),
				mealTimeDataHandler.getDinnerEndHour(), mealTimeDataHandler.getDinnerEndMinute());

		setTimeTextView(sleepTextView, mealTimeDataHandler.getSleepStartHour(), mealTimeDataHandler.getSleepStartMinute(),
				mealTimeDataHandler.getSleepEndHour(), mealTimeDataHandler.getSleepEndtMinute());

		//Click Events

		breakfastPicker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MealTimesStartEndTimePickerActivity.class);
				Bundle b = new Bundle();
				b.putInt(MealTimeDataHandler.PASS_VALUE, mealType.BREAKFAST.ordinal());
				intent.putExtras(b);
				getActivity().startActivity(intent);
			}
		});

		lunchPicker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MealTimesStartEndTimePickerActivity.class);
				Bundle b = new Bundle();
				b.putInt(MealTimeDataHandler.PASS_VALUE, mealType.LUNCH.ordinal());
				intent.putExtras(b);
				getActivity().startActivity(intent);
			}
		});


		snackPicker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MealTimesStartEndTimePickerActivity.class);
				Bundle b = new Bundle();
				b.putInt(MealTimeDataHandler.PASS_VALUE, mealType.SNACK.ordinal());
				intent.putExtras(b);
				getActivity().startActivity(intent);
			}
		});


		dinnerPicker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MealTimesStartEndTimePickerActivity.class);
				Bundle b = new Bundle();
				b.putInt(MealTimeDataHandler.PASS_VALUE, mealType.DINNER.ordinal());
				intent.putExtras(b);
				getActivity().startActivity(intent);
			}
		});

		sleepPicker.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), MealTimesStartEndTimePickerActivity.class);
				Bundle b = new Bundle();
				b.putInt(MealTimeDataHandler.PASS_VALUE, mealType.SLEEP.ordinal());
				intent.putExtras(b);
				getActivity().startActivity(intent);
			}
		});



	}

	private void setTimeTextView(TextView tv, int stHour, int stMinute, int endHour, int endMinute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, stHour);
		calendar.set(Calendar.MINUTE, stMinute);
		String strStartTime = Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getActivity());
		calendar.set(Calendar.HOUR_OF_DAY, endHour);
		calendar.set(Calendar.MINUTE, endMinute);
		String strEndTime = Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getActivity());

		if (tv != null)
		{
			tv.setText(strStartTime + "-" + strEndTime);
		}
	}


	public interface MealTimesManager {

	}

	public void setMealTimesManager(MealTimesManager manager) {
		this.mealTimesManager = manager;
	}




}
