package com.senseonics.model;

import com.senseonics.bluetoothle.CommandAndResponseIDs;
import com.senseonics.bluetoothle.ResponseOperations;
import com.senseonics.util.Range;

import javax.inject.Inject;

public class ReadFirstAndLastSensorGlucoseRecordNumbersParsedResponse implements ParsedResponse{

    @Inject
    public ReadFirstAndLastSensorGlucoseRecordNumbersParsedResponse() {
    }

    @Override
    public int getExpectedResponseId() {
        return CommandAndResponseIDs.ReadFirstAndLastSensorGlucoseRecordNumbersResponseID;
    }

    @Override
    public boolean check(int[] data) {
        return ResponseOperations.isReadFirstAndLastSensorGlucoseRecordNumbersResponseCorrect(data);
    }

    @Override
    public void apply(int[] data, TransmitterStateModel model) {
        int firstRecordNr = data[1] | (data[2] << 8) | (data[3] << 16);
        int lastRecordNr = data[4] | (data[5] << 8) | (data[6] << 16);

        model.setSensorGlucoseRecordRange(new Range(firstRecordNr, lastRecordNr));
    }
}
