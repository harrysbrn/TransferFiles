package com.senseonics.bluetoothle;

public class MemoryMap {

	/** #3194 */
	public enum RAW_DATA_INDEX {
		RAW_DATA_INDEX_1(MemoryMap.RawDataValue1Address),
		RAW_DATA_INDEX_2(MemoryMap.RawDataValue2Address),
		RAW_DATA_INDEX_3(MemoryMap.RawDataValue3Address),
		RAW_DATA_INDEX_4(MemoryMap.RawDataValue4Address),
		RAW_DATA_INDEX_5(MemoryMap.RawDataValue5Address),
		RAW_DATA_INDEX_6(MemoryMap.RawDataValue6Address),
		RAW_DATA_INDEX_7(MemoryMap.RawDataValue7Address),
		RAW_DATA_INDEX_8(MemoryMap.RawDataValue8Address);

		private int[] MemoryAddress;

		private RAW_DATA_INDEX(int[] MemoryAddress) {
			this.MemoryAddress = MemoryAddress;
		}

		public int[] getMemoryAddress() {
			return this.MemoryAddress;
		}
	}

	public static final int[] sensorFieldCurrentAddress			= new int[]{0x00,0x04,0x08};
	public static final int[] batteryPercentageAddress  		= new int[]{0x00,0x04,0x06};
	public static final int[] readyForCalibrationAddress		= new int[]{0x00,0x04,0x0A};
    public static final int[] calibrationsMadeInThisPhaseAddress= new int[]{0x00,0x08,0xA1};
    public static final int[] mostRecentCalibrationDateAddress	= new int[]{0x00,0x08,0xA3};
	public static final int[] mostRecentCalibrationTimeAddress	= new int[]{0x00,0x08,0xA5};
	public static final int[] transmitterNameAddress			= new int[]{0x00,0x08,0xA7};
	public static final int[] transmitterSerialNumberAddress	= new int[]{0x00,0x00,0x02};
	public static final int[] transmitterModelNumberAddress		= new int[]{0x00,0x00,0x06};
	public static final int[] transmitterSoftwareVersionAddress	= new int[]{0x00,0x00,0x0A};
    public static final int[] transmitterSoftwareVersionExtAddress	= new int[]{0x00,0x00,0xA2};

	// #2936
	public static final int[] mepSavedValueAddress 				= new int[]{0x00,0x00,0xB3};
	public static final int[] mepSavedRefChannelMetricAddress	= new int[]{0x00,0x00,0xB7};
	public static final int[] mepSavedDriftMetricAddress		= new int[]{0x00,0x00,0xBB};
	public static final int[] mepSavedLowRefMetricAddress		= new int[]{0x00,0x00,0xBF};
	public static final int[] mepSavedSpikeAddress 				= new int[]{0x00,0x00,0xC3};

    public static final int[] startDateOfCalibrationPhaseAddress= new int[]{0x00,0x08,0x9D};
	public static final int[] startTimeOfCalibrationPhaseAddress= new int[]{0x00,0x08,0x9F};
	public static final int[] currentCalibrationPhaseAddress	= new int[]{0x00,0x08,0x9C};
	public static final int[] linkedSensorIDAddress				= new int[]{0x00,0x08,0x8C};
	public static final int[] unlinkedSensorIDAddress			= new int[]{0x00,0x04,0x16};
	public static final int[] sensorInsertionDateAddress		= new int[]{0x00,0x08,0x90};
	public static final int[] sensorInsertionTimeAddress		= new int[]{0x00,0x08,0x92};
	public static final int[] sensorLifeAddress					= new int[]{0x00,0x08,0xB0};
	public static final int[] sensorGlucoseSamplingInterval		= new int[]{0x00,0x00,0x12};

	//Hysteresis Values
	public static final int[] hysteresisPercentageAddress  		= new int[]{0x00,0x00,0x93};
	public static final int[] hysteresisValueAddress	  		= new int[]{0x00,0x00,0x94};

	//Hysteresis Values for Predictive Alert
	public static final int[] hysteresisPredictivePercentageAddress		= new int[]{0x00,0x00,0x95};
	public static final int[] hysteresisPredictiveValueAddress	  		= new int[]{0x00,0x00,0x96};

	//Min and Max Calibration Tresholds
    public static final int[] minCalibrationTreshold            = new int[]{0x00,0x09,0x12};	//2byte
    public static final int[] maxCalibrationTreshold			= new int[]{0x00,0x09,0x14};	//2byte

	// #2936 MSP is only the MSB of the address value
	public static final int[] eep24MSPAddress					= new int[]{0x00,0x0A,0x20};

    public static final int[] lowGlucoseTarget					= new int[]{0x00,0x11,0x02};	//2byte
	public static final int[] highGlucoseTarget					= new int[]{0x00,0x11,0x04};	//2byte

	public static final int[] lowGlucoseAlarmTreshold			= new int[]{0x00,0x11,0x0A};	//2byte
	public static final int[] highGlucoseAlarmTreshold			= new int[]{0x00,0x11,0x0C};	//2byte
	
	public static final int[] predictiveAlert					= new int[]{0x00,0x10,0x20};	//1byte
	public static final int[] predictiveFallingRateAlertTimeInterval = new int[]{0x00,0x10,0x21};//1byte
	public static final int[] predictiveRisingRateAlertTimeInterval  = new int[]{0x00,0x10,0x22};//1byte
	
	public static final int[] rateAlert							= new int[]{0x00,0x10,0x10};	//1byte
	public static final int[] rateAlertFallingTreshold			= new int[]{0x00,0x10,0x11};	//1byte
	public static final int[] rateAlertRisingTreshold			= new int[]{0x00,0x10,0x12};	//1byte

	// #2379
	public static final int[] lowGlucoseAlarmRepeatIntervalDayTimeAddress	= new int[]{0x00,0x10,0x32};
	public static final int[] highGlucoseAlarmRepeatIntervalDayTimeAddress	= new int[]{0x00,0x10,0x33};
	public static final int[] lowGlucoseAlarmRepeatIntervalNightTimeAddress	= new int[]{0x00,0x11,0x0E};
	public static final int[] highGlucoseAlarmRepeatIntervalNightTimeAddress= new int[]{0x00,0x11,0x0F};
	public static final int[] dayStartTimeAddress							= new int[]{0x00,0x11,0x10};
	public static final int[] nightStartTimeAddress							= new int[]{0x00,0x11,0x12};
	
	public static final int[] nextCalibrationDate				= new int[]{0x00,0x04,0x70};	//2byte
	public static final int[] nextCalibrationTime				= new int[]{0x00,0x04,0x72};	//2byte
	public static final int[] minsBeforeNextCalibrationTime		= new int[]{0x00,0x04,0x74};	//2byte
	public static final int[] minsAfterNextCalibrationTime		= new int[]{0x00,0x04,0x76};	//2byte

	public static final int[] minutesRemainingUntilCalibrationAllowed = new int[]{0x00,0x04,0x78};	//2byte

	public static final int[] algorithmParameterFormatVersion	= new int[]{0x00,0x04,0x80}; 	//2byte
	
	public static final int[] morningCalibrationTime			= new int[]{0x00,0x08,0x98};	//2byte
	public static final int[] eveningCalibrationTime			= new int[]{0x00,0x08,0x9A};	//2byte
	
	public static final int[] transmitterNameFirst4Byte			= new int[]{0x00,0x08,0xA7};	//4byte
	public static final int[] transmitterNameLast4Byte			= new int[]{0x00,0x08,0xAB};	//4byte
	
	public static final int[] clinicalMode						= new int[]{0x00,0x0B,0x49};	//1byte
	public static final int[] clinicalModeDuration				= new int[]{0x00,0x00,0x98};	//2byte

	public static final int[] vibrateMode						= new int[]{0x00,0x09,0x02};	//1byte
	public static final int[] doNotDisturbMode					= new int[]{0x00,0x0B,0x4A};	//1byte

	public static final int[] appVersionAddress					= new int[]{0x00,0x0B,0x4B};	//4bytes

	public static final int[] EEPROMParameterStartAddress 		= new int[]{0x00,0x0A,0x24};   
    public static final int[] ATCCALParameterStartAddress 		= new int[]{0x00,0x12,0x00};

	/** #3194 */
	public static final int[] RawDataValue1Address 				= new int[]{0x00,0x04,0x1A}; 	//2bytes
	public static final int[] RawDataValue2Address 				= new int[]{0x00,0x04,0x1C}; 	//2bytes
	public static final int[] RawDataValue3Address 				= new int[]{0x00,0x04,0x1E}; 	//2bytes
	public static final int[] RawDataValue4Address 				= new int[]{0x00,0x04,0x20}; 	//2bytes
	public static final int[] RawDataValue5Address 				= new int[]{0x00,0x04,0x22}; 	//2bytes
	public static final int[] RawDataValue6Address 				= new int[]{0x00,0x04,0x24}; 	//2bytes
	public static final int[] RawDataValue7Address 				= new int[]{0x00,0x04,0x26}; 	//2bytes
	public static final int[] RawDataValue8Address 				= new int[]{0x00,0x04,0x28}; 	//2bytes

}
