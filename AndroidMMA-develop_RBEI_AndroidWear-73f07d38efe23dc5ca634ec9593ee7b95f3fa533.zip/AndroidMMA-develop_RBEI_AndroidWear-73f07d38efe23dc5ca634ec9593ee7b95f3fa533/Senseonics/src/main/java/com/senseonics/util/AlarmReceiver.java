package com.senseonics.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.senseonics.bluetoothle.AlarmFiredEvent;
import com.senseonics.gen12androidapp.SenseonicsApplication;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;


public class AlarmReceiver extends BroadcastReceiver {

    @Inject
    protected EventBus bus;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (bus == null) {
            ((SenseonicsApplication) context.getApplicationContext()).inject(this);
        }

        bus.post(new AlarmFiredEvent());
    }
}
