package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadDayStartTimeTwoByteMemoryParsedResponse implements TwoByteMemoryMapParsedResponse{
    @Inject
    public ReadDayStartTimeTwoByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.dayStartTimeAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] data = {dataOne, dataTwo};
        int[] time = BinaryOperations.calculateTimeFromBytes(data);

        model.setDayStartTimeHour(time[0]);
        model.setDayStartTimeMinute(time[1]);
    }
}
