package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public ReadWriteHighGlucoseAlarmThresholdTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.highGlucoseAlarmTreshold;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {

        int highGlucoseAlarmThreshold = BinaryOperations.dataIntFrom16BitsLSByteFirst(dataOne, dataTwo);
        Log.i("Glucose thresholds","high alarm: " + highGlucoseAlarmThreshold);
        model.setHighGlucoseAlarmThreshold(highGlucoseAlarmThreshold);

    }
}
