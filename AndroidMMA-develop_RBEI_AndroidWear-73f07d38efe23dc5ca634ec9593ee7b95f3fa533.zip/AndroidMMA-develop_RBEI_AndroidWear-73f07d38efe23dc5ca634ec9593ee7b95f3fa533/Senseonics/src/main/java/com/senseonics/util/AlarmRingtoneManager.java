package com.senseonics.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Log;

import com.senseonics.gen12androidapp.R;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class AlarmRingtoneManager {
    private final String PACKAGE_NAME = "android.resource://com.senseonics.gen12androidapp/";
    public final int DEFAULT_INDEX = 0;
    private final String TAG = "SoundSettingMgr";
    private final String DayLowAlarmSoundPref = "prefDayLowAlarmSound";
    private final String DayHighAlarmSoundPref = "prefDayHighAlarmSound";

    private Context context;
    private SharedPreferences sharedPreferences;
    private ArrayList<String> RingtoneList;

    @Inject
    public AlarmRingtoneManager(Context context, SharedPreferences sharedPreferences) {
        this.context = context;
        this.sharedPreferences = sharedPreferences;
        initRingtoneList();
    }

    private void initRingtoneList() {
        this.RingtoneList = new ArrayList<>();
        this.RingtoneList.add("Default");
        this.RingtoneList.add("Apex");
        this.RingtoneList.add("Beacon");
        this.RingtoneList.add("Bulletin");
        this.RingtoneList.add("By The Seaside");
        this.RingtoneList.add("Chimes");
        this.RingtoneList.add("Circuit");
        this.RingtoneList.add("Constellation");
        this.RingtoneList.add("Cosmic");
        this.RingtoneList.add("Crystals");
        this.RingtoneList.add("Hillside");
        this.RingtoneList.add("Illuminate");
        this.RingtoneList.add("Night Owl");
        this.RingtoneList.add("Opening");
        this.RingtoneList.add("Playtime");
        this.RingtoneList.add("Presto");
        this.RingtoneList.add("Radar");
        this.RingtoneList.add("Radiate");
        this.RingtoneList.add("Ripples");
        this.RingtoneList.add("Sencha");
        this.RingtoneList.add("Signal");
        this.RingtoneList.add("Silk");
        this.RingtoneList.add("Slow Rise");
        this.RingtoneList.add("Stargaze");
        this.RingtoneList.add("Summit");
        this.RingtoneList.add("Twinkle");
        this.RingtoneList.add("Uplift");
        this.RingtoneList.add("Waves");
    }

    public ArrayList<String> getRingtoneList() {
        return this.RingtoneList;
    }

    public Uri getUriforRingtone(String ringTone) {
        if (ringTone.equals(this.RingtoneList.get(DEFAULT_INDEX))) {
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        else {
            return Uri.parse(PACKAGE_NAME + getResIdForRingtone(ringTone));
        }
    }

    public Uri getUriforRingtone(int index) {
        if (index == DEFAULT_INDEX) {
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        else {
            return Uri.parse(PACKAGE_NAME + getResIdForRingtone(index));
        }
    }

    private int getResIdForRingtone(String ringTone) {
        int index = getRingtoneIndex(ringTone);
        return getResIdForRingtone(index);
    }

    private int getResIdForRingtone(int index) {
        if (index == 1) {
            return R.raw.apex;
        }
        else if (index == 2) {
            return R.raw.beacon;
        }
        else if (index == 3) {
            return R.raw.bulletin;
        }
        else if (index == 4) {
            return R.raw.by_the_seaside;
        }
        else if (index == 5) {
            return R.raw.chimes;
        }
        else if (index == 6) {
            return R.raw.circuit;
        }
        else if (index == 7) {
            return R.raw.constellation;
        }
        else if (index == 8) {
            return R.raw.cosmic;
        }
        else if (index == 9) {
            return R.raw.crystals;
        }
        else if (index == 10) {
            return R.raw.hillside;
        }
        else if (index == 11) {
            return R.raw.illuminate;
        }
        else if (index == 12) {
            return R.raw.night_owl;
        }
        else if (index == 13) {
            return R.raw.opening;
        }
        else if (index == 14) {
            return R.raw.playtime;
        }
        else if (index == 15) {
            return R.raw.presto;
        }
        else if (index == 16) {
            return R.raw.radar;
        }
        else if (index == 17) {
            return R.raw.radiate;
        }
        else if (index == 18) {
            return R.raw.ripples;
        }
        else if (index == 19) {
            return R.raw.sencha;
        }
        else if (index == 20) {
            return R.raw.signal;
        }
        else if (index == 21) {
            return R.raw.silk;
        }
        else if (index == 22) {
            return R.raw.slow_rise;
        }
        else if (index == 23) {
            return R.raw.stargaze;
        }
        else if (index == 24) {
            return R.raw.summit;
        }
        else if (index == 25) {
            return R.raw.twinkle;
        }
        else if (index == 26) {
            return R.raw.uplift;
        }
        else if (index == 27) {
            return R.raw.waves;
        }
        else {
            return R.raw.apex;
        }
    }

    private String getDefaultRingtone() {
        return this.RingtoneList.get(DEFAULT_INDEX);
    }

    public int getRingtoneIndex(String name) {
        int index = this.RingtoneList.indexOf(name);
        Log.d(TAG, "GeT index of " + name + ":" + index);
        return index;
    }

    public String ringtoneAtIndex(int index) {
        String ringtone = this.RingtoneList.get(index);
        Log.d(TAG, "Get ringtone at " + index + ":" + ringtone);
        return ringtone;
    }

    public void setAlarmSoundsToDefaults() {
        if (!sharedPreferences.contains(DayLowAlarmSoundPref)) {
            setDayLowAlarmSound(getDefaultRingtone());
        }

        if (!sharedPreferences.contains(DayHighAlarmSoundPref)) {
            setDayHighAlarmSound(getDefaultRingtone());
        }
    }

    public String getDayLowAlarmSound() {
        String val = Utils.getSettingsForStringWithDefault(context, DayLowAlarmSoundPref, getDefaultRingtone());
        Log.d(TAG, "GeT Day Low:" + val);
        return val;
    }

    public void setDayLowAlarmSound(String dayLowAlarmSound) {
        Log.d(TAG, "SeT Day Low:" + dayLowAlarmSound);
        Utils.saveSettings(context, DayLowAlarmSoundPref, dayLowAlarmSound);
    }

    public String getDayHighAlarmSound() {
        String val = Utils.getSettingsForStringWithDefault(context, DayHighAlarmSoundPref, getDefaultRingtone());
        Log.d(TAG, "GeT Day High:" + val);
        return val;
    }

    public void setDayHighAlarmSound(String dayHighAlarmSound) {
        Log.d(TAG, "SeT Day High:" + dayHighAlarmSound);
        Utils.saveSettings(context, DayHighAlarmSoundPref, dayHighAlarmSound);
    }

}
