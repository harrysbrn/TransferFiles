package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class HysteresisPredictivePercentageSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {
    @Inject
    public HysteresisPredictivePercentageSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {return MemoryMap.hysteresisPredictivePercentageAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        model.setHysteresisHighPredictiveGlocosePercent(data);
    }
}
