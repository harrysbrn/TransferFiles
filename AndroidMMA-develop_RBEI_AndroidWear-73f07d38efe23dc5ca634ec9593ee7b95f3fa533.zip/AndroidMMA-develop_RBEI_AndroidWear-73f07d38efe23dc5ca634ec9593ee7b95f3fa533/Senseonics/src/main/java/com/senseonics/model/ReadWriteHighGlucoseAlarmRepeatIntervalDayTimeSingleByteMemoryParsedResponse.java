package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse implements SingleByteMemoryMapParsedResponse{
    @Inject
    public ReadWriteHighGlucoseAlarmRepeatIntervalDayTimeSingleByteMemoryParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.highGlucoseAlarmRepeatIntervalDayTimeAddress;
    }

    @Override
    public void apply(int dataOne, TransmitterStateModel model) {
        model.setHighGlucoseAlarmRepeatIntervalDayTime(dataOne);
    }
}
