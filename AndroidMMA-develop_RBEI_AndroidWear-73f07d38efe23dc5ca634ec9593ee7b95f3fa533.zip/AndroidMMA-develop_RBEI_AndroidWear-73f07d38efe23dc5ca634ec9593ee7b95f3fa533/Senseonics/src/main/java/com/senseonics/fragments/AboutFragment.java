package com.senseonics.fragments;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.senseonics.gen12androidapp.EulaScreenActivity;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.MyProductInfoActivity;
import com.senseonics.gen12androidapp.MySensorActivity;
import com.senseonics.gen12androidapp.MyTransmitterActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.WebviewActivity;
import com.senseonics.bluetoothle.DialogUtils;
import com.senseonics.model.BATTERY_LEVEL;
import com.senseonics.util.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class AboutFragment extends BaseFragment {
	private LinearLayout feedback,eula, privacystatement;
	private LinearLayout myTransmitter, mySensor,myProductInfo;
	private LinearLayout help;
	private View aboutView;

	private String FEEDBACK_EMAIL_ADDRESS = "Feedback.app@senseonics.com";
	private String SENSEONICS_WEBSITE = "http://www.senseonics.com";
	private String SENSEONICS_PHONE_NUMBER = "tel:301-515-7260";
    private Dialog dialog;
	private ProgressDialog progressDialog;
	private String folderName = "/Senseonics";
	private String fileName = "";

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
        super.onCreateView(inflater,container, savedInstanceState);
        aboutView = inflater.inflate(R.layout.fragment_about, null);
		progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
		progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
		progressDialog.setCancelable(false);

		myTransmitter = (LinearLayout) aboutView
				.findViewById(R.id.myTransmitter);
		mySensor = (LinearLayout) aboutView.findViewById(R.id.mySensor);
        myProductInfo = (LinearLayout) aboutView.findViewById(R.id.myProductionInformation);
        eula = (LinearLayout) aboutView.findViewById(R.id.eula);
        privacystatement = (LinearLayout) aboutView.findViewById(R.id.privacystatement);
		feedback = (LinearLayout) aboutView.findViewById(R.id.feedback);

		/** #3620 */
		help = (LinearLayout) aboutView.findViewById(R.id.help);

		File folder = new File(Environment.getExternalStorageDirectory()
				+ folderName);

		if (!folder.exists()) {
			if (!folder.mkdir()) {
			}
		}


		initViews();
		return aboutView;
	}

	@Override
	public void onResume() {
		super.onResume();

		/** #3664 */
		if (getActivity() instanceof MainActivity) {
			((MainActivity) getActivity()).refreshAfterFragmentChanged();
		}
	}

	public void hideProgressDialog() {
		progressDialog.dismiss();
	}


    private void copyFile(InputStream in, OutputStream out) throws IOException
    {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1)
        {
            out.write(buffer, 0, read);
        }
    }

	private File getAssetsFile(String fileName) throws IOException
	{
		AssetManager assetManager = getActivity().getAssets();
		InputStream in = null;
		OutputStream out = null;

		File file = new File(Environment.getExternalStorageDirectory()
				+ folderName, fileName);
		try
		{
			in = assetManager.open("IFU/"+fileName);
			//I wil change this using FileProvider and ContentProvider
			out = new FileOutputStream(Environment.getExternalStorageDirectory()+ folderName+"/" + fileName);
			//out = getActivity().openFileOutput(file.getAbsolutePath(), Context.MODE_WORLD_READABLE);
			copyFile(in, out);
			in.close();
			in = null;
			out.flush();
			out.close();
			out = null;
		} catch (Exception e)
		{

		}
		return file;
	}

    public void initViews() {

		// Setup click events for four cells
		
		myTransmitter.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(new Intent(getActivity(),
						MyTransmitterActivity.class));				
			}
		});

		myProductInfo.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().startActivity(new Intent(getActivity(), MyProductInfoActivity.class));
			}
		});

        mySensor.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
				getActivity().startActivity(new Intent(getActivity(), MySensorActivity.class));
            }
        });

        eula.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), EulaScreenActivity.class);
				intent.putExtra("eula_init", "false");
				getActivity().startActivity(intent);
			}
		});

        privacystatement.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), WebviewActivity.class);
				intent.putExtra("screen_type", "privacy");
				getActivity().startActivity(intent);
			}
        });


        feedback.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startMailClientIfExists();
			}
		});

		help.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				OpenHelpLink(getActivity());
			}
		});
	}

	/** #3620 */
	private void OpenHelpLink(Context ctx) {
		Intent i = new Intent(Intent.ACTION_VIEW);
		i.setData(Uri.parse("http://ous.eversensediabetes.com/distributors/"));
		try {
			ctx.startActivity(i);
		}
		catch (ActivityNotFoundException e) {
			Utils.makeAlwaysShownToast(ctx, ctx.getResources().getString(R.string.no_browser_found_2));
		}
	}

	class DownloadFileFromURL extends AsyncTask<String,String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		private String response;
		@Override
		protected String doInBackground(String... f_url) {
			response = Utils.getLatestFile(f_url[0], f_url[1], getActivity());
			return response;
		}

		@Override
		protected void onPostExecute(String result) {
			progressDialog.dismiss();

			if (response != null && !response.equals("-1")) {
				displayPDF();
			} else {
				if (response == null) {
					displayCheckingResult(Utils.MLCheckResult.NotConnectedToWifi);
				}
				else {
					displayCheckingResult(Utils.MLCheckResult.ServerError);
				}
			}

			super.onPostExecute(result);
		}
	}

	private void displayPDF () {
		Intent intent= new Intent(Intent.ACTION_VIEW);
		File file = new File(Environment.getExternalStorageDirectory()
				+ folderName, fileName);
		intent.setDataAndType(Uri.fromFile(file),"application/pdf");
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		try {
			getActivity().getApplicationContext().startActivity(intent);
		}catch(ActivityNotFoundException e){
			if (dialog != null && dialog.isShowing())
				dialog.dismiss();
			dialog = dialogUtils.createWarningDialog(getActivity(), new DialogUtils.WarningDialogInfo(-1,
					getResources().getString(R.string.app_name), getResources().getString(R.string.no_pdf_reader)));
			dialog.show();
		}
	}

	public void displayCheckingResult(Utils.MLCheckResult error) {
		String title = "", message = "";
		switch (error) {
			case Timeout:
				title = getString(R.string.request_timeout);
				message = getString(R.string.invalid_error_text);
				break;
			case NotConnectedToWifi:
				title = getString(R.string.wi_fi_disconnected);
				message = getString(R.string.wi_fi_disconnected_text);
				break;
			case ServerError:
				title = getString(R.string.server_error);
				message = getString(R.string.invalid_error_text);
				break;
			case None:
				title = getString(R.string.file_corrupted);
				message = getString(R.string.invalid_error_text);
				break;
			case Unknown:
			default:
				title = getString(R.string.unknown_error);
				message = getString(R.string.invalid_error_text);
				break;
		}

		if (dialog != null && dialog.isShowing())
			dialog.dismiss();

		final DialogUtils.WarningDialogInfo warningDialogInfo = new DialogUtils.WarningDialogInfo(-1,
				title, message);
		dialog = dialogUtils.createWarningDialog(getActivity(), warningDialogInfo, new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
				dialogUtils.removeDialogFromCustomDialogs(warningDialogInfo);
				displayPDF();
			}
		});
		dialog.show();
	}

	public void startMailClientIfExists() {
		final List<Intent> targetedShareIntents = new ArrayList<Intent>();

		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType("text/plain");

		List<ResolveInfo> resInfo = getActivity().getPackageManager()
				.queryIntentActivities(intent, 0);
		String versionName = "";

		if (getActivity() != null) {
			try {
				versionName = getActivity().getPackageManager().getPackageInfo(
						getActivity().getPackageName(), 0).versionName;
			} catch (NameNotFoundException e) {
				e.printStackTrace();
			}
		}

		String subject = getString(R.string.contact_us_mail_subject);
		String body = getString(R.string.contact_us_mail_body) + "\n\n\n\n\n\n\n";

		body += "-------------------------------------------\n";
		body += "*" + getString(R.string.transmitter_details) + ":\n";

		// Transmitter name
		String nameText = getString(R.string.name) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getTransmitterName() != null) ? transmitterStateModel.getTransmitterName() : Utils.NotAvailable);
		body += nameText;

		// Transmitter serial number
		nameText = getString(R.string.serial_number) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getTransmitterSerialNumber() != null) ? transmitterStateModel.getTransmitterSerialNumber() : Utils.NotAvailable);
		body += nameText;

		// Transmitter model number
		nameText = getString(R.string.model_number) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getTransmitterModelNumber() != null) ? transmitterStateModel.getTransmitterModelNumber() : Utils.NotAvailable);
		body += nameText;

		// Transmitter version number
		nameText = getString(R.string.version_number) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getFormattedTransmitterVersionNumber() != null) ? transmitterStateModel.getFormattedTransmitterVersionNumber() : Utils.NotAvailable);
		body += nameText;

        // Transmitter Last Cal
		nameText = getString(R.string.last_cal) + ": %% \n";
        nameText = nameText.replace("%%", (transmitterStateModel.getlastCalibrationDateAndTime() != null) ? Utils.formatDateSimple(transmitterStateModel.getlastCalibrationDateAndTime(), TimeZone.getDefault(), getActivity()) : Utils.NotAvailable);
        body += nameText;

        // Transmitter phase start
		nameText = getString(R.string.phase_start) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getStartCalibrationPhaseDateAndTime() != null) ? Utils.formatDateSimple(transmitterStateModel.getStartCalibrationPhaseDateAndTime(), TimeZone.getDefault(), getActivity()) : Utils.NotAvailable);
		body += nameText;

		// Transmitter completed cals
		nameText = getString(R.string.completed_cals) + ": " + ((transmitterStateModel.getCalibrationsMadeInThisPhase() >= 0) ? transmitterStateModel.getCalibrationsMadeInThisPhase() : Utils.NotAvailable) + "\n";
		body += nameText;

		// Transmitter current phase
		nameText = getString(R.string.current_phase) + ": " + ((transmitterStateModel.getCurrentCalibrationPhase() != Utils.CAL_PHASE.UNDERTERMINED) ? transmitterStateModel.getCurrentPhase() : Utils.NotAvailable) + "\n";
		body += nameText;
		
		// Transmitter battery life
		nameText = getString(R.string.battery_level) + ": %% \n";
        nameText = nameText.replace("%%", (transmitterStateModel.getBatteryLevel() != BATTERY_LEVEL.UNKNOWN_NEG_1) ? (transmitterStateModel.getBatteryLife() + "") : Utils.NotAvailable);
        body += nameText;

		body += "\n";
		body += "*" + getString(R.string.sensor_details) + ":\n";

		// Sensor serial number
		nameText = getString(R.string.serial_number_sensor) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getLinkedSensorId() != null) ? transmitterStateModel.getLinkedSensorId() : Utils.NotAvailable);
		body += nameText;

		// Sensor insertion date
		nameText = getString(R.string.insertion_date) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getSensorInsertionDateAndTime() != null) ? Utils.formatDateOnlyForTimeZone(transmitterStateModel.getSensorInsertionDateAndTime(), TimeZone.getDefault()) : Utils.NotAvailable);
		body += nameText;

		// Sensor insertion time
		nameText = getString(R.string.insertion_time) + ": %% \n";
		nameText = nameText.replace("%%", (transmitterStateModel.getSensorInsertionDateAndTime() != null) ? Utils.getTime24HrFormat(transmitterStateModel.getSensorInsertionDateAndTime(), TimeZone.getDefault(), getActivity()) : Utils.NotAvailable);
		body += nameText;

        // Sensor unlinked serial number
		nameText = getString(R.string.detected_serialnumber) + ": %% \n";
        nameText = nameText.replace("%%", (transmitterStateModel.getUnLinkedSensorId() != null) ? transmitterStateModel.getUnLinkedSensorId() : Utils.NotAvailable);
        body += nameText;

		if (getActivity() != null) {

			body += "\n";
			body += "*" + getString(R.string.android_device_info) + ":\n";

			String deviceName = android.os.Build.BRAND;
			String deviceModel = android.os.Build.MODEL;
			String androidVersion = android.os.Build.VERSION.RELEASE;

			// App version name
			nameText = getString(R.string.details_version) + ": %% \n";
			nameText = nameText.replace("%%", (!versionName.equals("")) ? versionName : Utils.NotAvailable);
			body += nameText;

			// Machine name
			nameText = getString(R.string.machine) + ": %% \n";
			nameText = nameText.replace("%%", (deviceName != null) ? deviceName : Utils.NotAvailable);
			body += nameText;

			// Model name
			nameText = getString(R.string.model) + ": %% \n";
			nameText = nameText.replace("%%", (deviceModel != null) ? deviceModel : Utils.NotAvailable);
			body += nameText;

			// Android version
			nameText = getString(R.string.android_version) + ": %% \n";
			nameText = nameText.replace("%%", (androidVersion != null) ? androidVersion : Utils.NotAvailable);
			body += nameText;
		}

		body += "-------------------------------------------\n";

		if (!resInfo.isEmpty()) {
			for (ResolveInfo info : resInfo) {
				Intent targetedShare = new Intent(
						android.content.Intent.ACTION_VIEW);
				targetedShare.setType("text/plain");

				if (info.activityInfo.packageName.toLowerCase(Locale.US)
						.contains("mail")
						|| info.activityInfo.name.toLowerCase(Locale.US)
								.contains("mail")) {
					Uri data = Uri
							.parse("mailto:?subject=" + subject + "&body="
									+ body);

					targetedShare.setData(data);
					targetedShare.setPackage(info.activityInfo.packageName);
					targetedShareIntents.add(targetedShare);
				}
			}
		}

		if (targetedShareIntents.size() == 0) {
			Toast.makeText(getActivity(),
					"There are no email clients installed.", Toast.LENGTH_SHORT)
					.show();
		} else {
			Intent chooserIntent = Intent.createChooser(
					targetedShareIntents.remove(0), getString(R.string.contact_us));
			chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
					targetedShareIntents.toArray(new Parcelable[] {}));
			getActivity().startActivity(chooserIntent);
		}
	}

}
