package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadWriteRateAlertsActivatedSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.rateAlert;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setRateAlertsActivated(false);
                break;
            case 0x55:
                model.setRateAlertsActivated(true);
                break;
        }
    }
}
