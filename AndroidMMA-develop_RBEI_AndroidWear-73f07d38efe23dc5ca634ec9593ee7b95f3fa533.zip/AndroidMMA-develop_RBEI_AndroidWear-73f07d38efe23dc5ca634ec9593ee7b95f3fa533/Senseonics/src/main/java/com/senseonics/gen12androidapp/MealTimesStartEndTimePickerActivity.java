package com.senseonics.gen12androidapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import com.senseonics.fragments.MealTimesStartEndTimePickerFragment.MealTimesStartEndTimePickerManager;
import com.senseonics.fragments.MealTimesStartEndTimePickerFragment;
import com.senseonics.model.ModelChangedEvent;

public class MealTimesStartEndTimePickerActivity extends BaseActivity {

	protected MealTimesStartEndTimePickerFragment mealTimesStartEndTimePickerFragment;
	protected MealTimeDataHandler.MealType mealType = MealTimeDataHandler.MealType.BREAKFAST;
    protected MealTimesStartEndTimePickerManager mealTimesStartEndTimePickerManager = new MealTimesStartEndTimePickerManager() {

	};

	@Override
	public void connectionStateChanged() {
		if(mealTimesStartEndTimePickerManager!=null)
		{
			mealTimesStartEndTimePickerFragment.updateViews();
		}
		
		super.connectionStateChanged();
	}

	@Override
	public void highPriorityRequestFinished() {

		
		super.highPriorityRequestFinished();
	}

	public void onEventMainThread(ModelChangedEvent event) {

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Add the content view
		LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
		LayoutInflater layoutInflater = getLayoutInflater();
		LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);
		rl.addView(
				layoutInflater.inflate(R.layout.activity_simple_fragment, null),
				parms_content);

		Bundle b = getIntent().getExtras();

		// Configure the navigation bar
		mealType = MealTimeDataHandler.MealType.values()[b.getInt(MealTimeDataHandler.PASS_VALUE)];
		naviBarTitle.setText(getTitleString(mealType));
		naviBarRightItemTextView.setVisibility(View.GONE);
		naviBarRightItemAddEventImageview.setVisibility(View.GONE);
		mealTimesStartEndTimePickerFragment = new MealTimesStartEndTimePickerFragment();

		mealTimesStartEndTimePickerFragment.setMealTimesManager(mealTimesStartEndTimePickerManager);
		Bundle args = new Bundle();
		args.putInt(MealTimeDataHandler.PASS_VALUE, mealType.ordinal());
		mealTimesStartEndTimePickerFragment.setArguments(args);
		getFragmentManager().beginTransaction()
				.replace(R.id.fragment, mealTimesStartEndTimePickerFragment)
				.commitAllowingStateLoss();
		
	}

	private String getTitleString(MealTimeDataHandler.MealType ord)
	{
		switch(ord) {
			case BREAKFAST:
				return getString(R.string.breakfast);
			case LUNCH:
				return getString(R.string.lunch);
			case SNACK:
				return getString(R.string.snack);
			case DINNER:
				return getString(R.string.dinner);
			case SLEEP:
				return getString(R.string.sleep);
			default:
				return "";

		}
	}


	@Override
	protected void onResume() {
		getService().postReadMorningCalibrationTime();
		getService().postReadEveningCalibrationTime();
		super.onResume();
	}
}
