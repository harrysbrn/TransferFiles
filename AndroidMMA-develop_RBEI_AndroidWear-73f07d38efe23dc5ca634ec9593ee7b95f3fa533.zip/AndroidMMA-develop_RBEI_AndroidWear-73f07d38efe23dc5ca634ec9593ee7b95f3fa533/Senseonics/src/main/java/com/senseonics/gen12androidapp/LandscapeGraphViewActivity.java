package com.senseonics.gen12androidapp;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.jjoe64.graphview.LineGraphView;
import com.senseonics.events.EventPoint;
import com.senseonics.fragments.PopupGraphManagerView;
import com.senseonics.graph.GraphView;
import com.senseonics.graph.VerticalLineHolder;
import com.senseonics.graph.events.GraphCacheEvent;
import com.senseonics.graph.util.Glucose;
import com.senseonics.util.Emailer;
import com.senseonics.util.IntentUtils;
import com.senseonics.util.Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LandscapeGraphViewActivity extends BaseActivity {
  @Inject Emailer emailer;
  @Inject IntentUtils intentUtils;
  @BindView(R.id.title) TextView title;
  @BindView(R.id.spinner) Spinner spinner;
  @BindView(R.id.shareImageButton) ImageButton shareImageButton;
  @BindView(R.id.progressBar) ProgressBar progressBar;

  private LineGraphView graphView;
  private Calendar startDate;
  private Calendar endDate;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.landscape_graph_activity);
    ButterKnife.bind(this);

    ((Toolbar)findViewById(R.id.toolbar)).setNavigationOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        finish();
      }
    });

    shareImageButton.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        final String currentSpinnerText = spinner.getSelectedItem().toString();
        emailer.formShareEmail(getString(R.string.email_subject_graph),
            getString(R.string.email_body_graph, currentSpinnerText),
            findViewById(android.R.id.content));
      }
    });

    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
      @Override
      public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        putDataInGraph();
        setDateInTitle();
      }

      @Override public void onNothingSelected(AdapterView<?> parent) {

      }
    });
    addGraph();
  }

  @Override protected void onResume() {
    super.onResume();
    putDataInGraph();
    setDateInTitle();
  }

  @Override protected void onPause() {
    super.onPause();
  }

  @Override protected void onDestroy() {
    super.onDestroy();
  }

  private void setDateInTitle() {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM d, yyyy");
    String formattedEndDate = simpleDateFormat.format(endDate.getTime());
    String formattedStartDate = simpleDateFormat.format(startDate.getTime());
    title.setText(formattedStartDate + " - " + formattedEndDate);
  }

  private void addGraph() {
    updateStartAndEndDates();
    int width = Utils.screenWidth - getStatusBarHeight() - getActionBarHeight();
    int height = Utils.screenHeight;

    this.graphView =
        new LineGraphView(this, "", startDate, endDate, height, width, height, 50, false, false);
    RelativeLayout.LayoutParams layoutParams =
        new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,
            RelativeLayout.LayoutParams.MATCH_PARENT);
    this.graphView.setLayoutParams(layoutParams);
    this.graphView.setScalable(false);
    this.graphView.setScrollable(false);
    this.graphView.setIsLandscape(true);
    this.graphView.setDisableTouch(true);
    this.graphView.setDrawBackground(true);

    ViewGroup graphParent = (ViewGroup) findViewById(R.id.graph_parent);
    graphParent.addView(this.graphView);

    final VerticalLineHolder verticalLineHolder = new VerticalLineHolder(this, height, width, 0);
    verticalLineHolder.setLayoutParams(new RelativeLayout.LayoutParams(height, width));

    graphParent.addView(verticalLineHolder);

    final PopupGraphManagerView popupGraphManagerView =
        new PopupGraphManagerView(this, oneThirdMyHeight());
    popupGraphManagerView.setVisibility(View.GONE);
    ((ViewGroup) findViewById(R.id.popup)).addView(popupGraphManagerView);

    verticalLineHolder.setScrollManager(new LandscapeLineScrollManager(popupGraphManagerView));
  }

  private int oneThirdMyHeight() {
    return findViewById(android.R.id.content).getHeight() / 3;
  }

  private void updateStartAndEndDates() {
    startDate = Calendar.getInstance();
    endDate = Calendar.getInstance();
    int selectedDays = getSelectedDays();
    startDate.add(Calendar.DAY_OF_WEEK, -1 * selectedDays);
  }

  private int getSelectedDays() {
    return Integer.parseInt(spinner.getSelectedItem().toString().split("\\s+")[0]);
  }

  private void putDataInGraph() {
    updateStartAndEndDates();
    intentUtils.refreshGraphFromCache(startDate, endDate, true);
    progressBar.setVisibility(View.VISIBLE);
  }

  public void onEventMainThread(GraphCacheEvent event) {
    progressBar.setVisibility(View.GONE);
    graphView.removeAllSeries();
    graphView.setEventPoints(Collections.<EventPoint>emptyList(), startDate, endDate);
    graphView.setStartDate(startDate);
    graphView.setEndDate(endDate);
    graphView.removeAllSeries();
    graphView.addSeries(event.glucoseValues);
    if (getSelectedDays() <= 7) {
      graphView.setEventPoints(event.events, startDate, endDate);
    }
  }

  //http://stackoverflow.com/questions/3407256/height-of-status-bar-in-android
  private int getStatusBarHeight() {
    int result = 0;
    int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
    if (resourceId > 0) {
      result = getResources().getDimensionPixelSize(resourceId);
    }
    return result;
  }

  //http://stackoverflow.com/questions/12301510/how-to-get-the-actionbar-height
  private int getActionBarHeight() {
    TypedValue tv = new TypedValue();
    if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
      return TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
    }
    return 0;
  }

  private class LandscapeLineScrollManager implements GraphView.LineScrollManager {
    private PopupGraphManagerView popupGraphManagerView;

    public LandscapeLineScrollManager(PopupGraphManagerView popupGraphManagerView) {
      this.popupGraphManagerView = popupGraphManagerView;
    }

    @Override public void scrollRight() {

    }

    @Override public void scrollLeft() {

    }

    @Override public void stopScroll() {

    }

    @Override public void positionChanged(float x) {
      EventPoint eventPoint = graphView.ifEventAtPosition(x);
      Glucose glucose = graphView.ifGlucoseAtPosition(x);

      int currentHeight = oneThirdMyHeight();
      int alertInfoHeight = currentHeight / 4;

      if (eventPoint != null) {
        popupGraphManagerView.putEventPopUp(x, eventPoint, currentHeight, alertInfoHeight);
      } else if (glucose != null) {
        popupGraphManagerView.putGlucosePopUp(x, glucose, currentHeight, alertInfoHeight);
      } else {
        popupGraphManagerView.putNoSensorGlucosePopUp(x, currentHeight, alertInfoHeight);
      }
    }

    @Override public void actionCancelled() {
      popupGraphManagerView.setVisibility(View.GONE);
    }
  }
}
