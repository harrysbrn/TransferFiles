package com.senseonics.graph;

import android.content.Intent;
import com.senseonics.gen12androidapp.BaseInjectedIntentService;
import com.senseonics.gen12androidapp.Constants;
import java.util.Calendar;
import javax.inject.Inject;

public class GraphCacheIntentService extends BaseInjectedIntentService {
  @Inject GraphCache graphCache;

  public GraphCacheIntentService() {
    super("GraphCacheIntentService");
  }

  @Override protected void onHandleIntent(Intent intent) {
    Boolean newStartEndDates = intent.getBooleanExtra(Constants.NEW_START_END_DATES, false);
    Calendar startDate = (Calendar) intent.getSerializableExtra(Constants.START_DATE);
    Calendar endDate = (Calendar) intent.getSerializableExtra(Constants.END_DATE);
    graphCache.refresh(startDate, endDate, newStartEndDates);
  }
}
