package com.senseonics.gen12androidapp;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.LinearLayout;
import android.widget.ListView;

public class SoundSelectionActivity extends BaseActivity{
    public enum ALARM_SOUND_TYPE {
        ALARM_SOUND_TYPE_LOW_DAY,
        ALARM_SOUND_TYPE_HIGH_DAY
    }

    private final String TAG = "SoundSettingSelect";
    private ListView soundListView;
    private ALARM_SOUND_TYPE soundType;
    private Ringtone ringTone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(layoutInflater.inflate(R.layout.activity_soundselection, null), parms_content);

        // Configure the navigation bar
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        soundListView = (ListView) findViewById(R.id.soundList);
        soundListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        soundListView.setAdapter(new ArrayAdapter<String>(this, R.layout.simple_list_item_multiple_choice_customized, alarmRingtoneManager.getRingtoneList()));

        int index = 0;
        Bundle extras = getIntent().getExtras();
        if (extras.containsKey("LowAlarmDay")) {
            Log.d(TAG, "Is Low Alarm Day");
            soundType = ALARM_SOUND_TYPE.ALARM_SOUND_TYPE_LOW_DAY;
        }
        else if (extras.containsKey("HighAlarmDay")) {
            Log.d(TAG, "Is High Alarm Day");
            soundType = ALARM_SOUND_TYPE.ALARM_SOUND_TYPE_HIGH_DAY;
        }

        switch (soundType) {
            case ALARM_SOUND_TYPE_LOW_DAY:
                naviBarTitle.setText(R.string.sound_low_glucose_alarm_2); /** #3214 */
                index = alarmRingtoneManager.getRingtoneIndex(alarmRingtoneManager.getDayLowAlarmSound());
                break;
            case ALARM_SOUND_TYPE_HIGH_DAY:
                naviBarTitle.setText(R.string.sound_high_glucose_alarm_2); /** #3214 */
                index = alarmRingtoneManager.getRingtoneIndex(alarmRingtoneManager.getDayHighAlarmSound());
                break;
            default:
                break;
        }

        soundListView.setItemChecked(index, true);
        soundListView.setSelection(index); // direct scroll to position

        soundListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CheckedTextView tv = (CheckedTextView)view;
                if (tv.isChecked()) {
                    Log.d(TAG, "Checked:" + position);

                    try {
                        nullifyRingtone();
                        Uri notifUri = alarmRingtoneManager.getUriforRingtone(position);
                        Log.d(TAG, "PLAY: " + notifUri);
                        ringTone = RingtoneManager.getRingtone(getApplicationContext(), notifUri);
                        ringTone.play();
                    }
                    catch (Exception ex) {
                        Log.d(TAG, ex.getMessage());
                    }

                    switch (soundType) {
                        case ALARM_SOUND_TYPE_LOW_DAY:
                            alarmRingtoneManager.setDayLowAlarmSound(alarmRingtoneManager.ringtoneAtIndex(position));
                            break;
                        case ALARM_SOUND_TYPE_HIGH_DAY:
                            alarmRingtoneManager.setDayHighAlarmSound(alarmRingtoneManager.ringtoneAtIndex(position));
                            break;
                        default:
                            break;
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        nullifyRingtone();
    }

    private void nullifyRingtone() {
        if (ringTone != null) {
            ringTone.stop();
            ringTone = null;
        }
    }

}
