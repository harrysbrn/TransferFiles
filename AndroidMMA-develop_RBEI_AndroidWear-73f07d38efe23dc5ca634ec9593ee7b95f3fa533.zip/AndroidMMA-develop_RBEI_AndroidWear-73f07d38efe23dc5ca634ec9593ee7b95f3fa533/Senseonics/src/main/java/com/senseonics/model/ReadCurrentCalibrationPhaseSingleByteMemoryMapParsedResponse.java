package com.senseonics.model;

import com.senseonics.bluetoothle.MemoryMap;
import com.senseonics.util.Utils;

import javax.inject.Inject;

public class ReadCurrentCalibrationPhaseSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadCurrentCalibrationPhaseSingleByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.currentCalibrationPhaseAddress;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        Utils.CAL_PHASE calPhase = Utils.CAL_PHASE.values()[data];
        model.setCurrentCalibrationPhase(calPhase);
    }
}
