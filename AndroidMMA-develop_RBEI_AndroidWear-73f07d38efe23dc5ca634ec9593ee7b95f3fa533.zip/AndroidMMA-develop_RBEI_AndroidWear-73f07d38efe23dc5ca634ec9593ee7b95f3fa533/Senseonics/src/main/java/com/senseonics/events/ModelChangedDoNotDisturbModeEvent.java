package com.senseonics.events;

public class ModelChangedDoNotDisturbModeEvent {

    private boolean newValue;

    public ModelChangedDoNotDisturbModeEvent(boolean newValue){
        this.newValue = newValue;
    }

    public boolean isNewValue() {
        return newValue;
    }
}
