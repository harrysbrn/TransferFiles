package com.senseonics.gen12androidapp;

import android.content.Context;
import android.content.SharedPreferences;

import com.senseonics.util.Utils;

/**
 * Created by sureshaddaguduru on 5/13/2015.
 */
public class MealTimeDataHandler {

    public static String PASS_VALUE = "Type";
    public enum MealType {
        BREAKFAST,
        LUNCH,
        SNACK,
        DINNER,
        SLEEP,
        ALL
    }

    private int breakfastStartHour = 6, breakfastStartMinute = 0,
            breakfastEndHour = 10, breakfastEndMinute = 0,
            lunchStartHour = 10, lunchStartMinute = 0,
            lunchEndHour = 14, lunchEndMinute = 0,
            snackStartHour = 14, snackStartMinute = 0,
            snackEndHour = 18, snackEndMinute = 0,
            dinnerStartHour = 18, dinnerStartMinute = 0,
            dinnerEndtHour = 22, dinnerEndMinute = 0,
            sleepStartHour = 22, sleepStartMinute = 0,
            sleepEndHour = 6, sleepEndtMinute = 0;

    private SharedPreferences sharedPreferences;

    public MealTimeDataHandler(Context context)
    {
        sharedPreferences = context.getSharedPreferences(Utils.SHARED_PREF, Context.MODE_PRIVATE);

        breakfastStartHour = sharedPreferences.getInt("breakfastStartHour", breakfastStartHour);
        breakfastStartMinute = sharedPreferences.getInt("breakfastStartMinute", breakfastStartMinute);
        breakfastEndHour = sharedPreferences.getInt("breakfastEndHour", breakfastEndHour);
        breakfastEndMinute = sharedPreferences.getInt("breakfastEndMinute", breakfastEndMinute);

        lunchStartHour = sharedPreferences.getInt("lunchStartHour", lunchStartHour);
        lunchStartMinute = sharedPreferences.getInt("lunchStartMinute", lunchStartMinute);
        lunchEndHour = sharedPreferences.getInt("lunchEndHour", lunchEndHour);
        lunchEndMinute = sharedPreferences.getInt("lunchEndMinute",lunchEndMinute);


        snackStartHour = sharedPreferences.getInt("snackStartHour", snackStartHour);
        snackStartMinute = sharedPreferences.getInt("snackStartMinute", snackStartMinute);
        snackEndHour = sharedPreferences.getInt("snackEndHour", snackEndHour);
        snackEndMinute = sharedPreferences.getInt("snackEndMinute",snackEndMinute);

        dinnerStartHour = sharedPreferences.getInt("dinnerStartHour", dinnerStartHour);
        dinnerStartMinute = sharedPreferences.getInt("dinnerStartMinute", dinnerStartMinute);
        dinnerEndtHour = sharedPreferences.getInt("dinnerEndtHour", dinnerEndtHour);
        dinnerEndMinute = sharedPreferences.getInt("dinnerEndMinute",dinnerEndMinute);

        sleepStartHour = sharedPreferences.getInt("sleepStartHour", sleepStartHour);
        sleepStartMinute = sharedPreferences.getInt("sleepStartMinute", sleepStartMinute);
        sleepEndHour = sharedPreferences.getInt("sleepEndHour", sleepEndHour);
        sleepEndtMinute = sharedPreferences.getInt("sleepEndtMinute",sleepEndtMinute);


    }

    public int  getBreakfastStartHour() {
        return breakfastStartHour;
    }
    public int  getBreakfastStartMinute() {
        return breakfastStartMinute;
    }

    public int  getBreakfastEndHour() {
        return breakfastEndHour;
    }
    public int  getBreakfastEndMinute() {
        return breakfastEndMinute;
    }

    public int  getLunchStartHour() {
        return lunchStartHour;
    }
    public int  getLunchStartMinute() {
        return lunchStartMinute;
    }

    public int  getLunchEndHour() {
        return lunchEndHour;
    }
    public int  getLunchEndMinute() {
        return lunchEndMinute;
    }

    public int  getSnackStartHour() {
        return snackStartHour;
    }
    public int  getSnackStartMinute() {
        return snackStartMinute;
    }

    public int  getSnackEndHour() {
        return snackEndHour;
    }
    public int  getSnackEndMinute() {
        return snackEndMinute;
    }

    public int  getDinnerStartHour() {
        return dinnerStartHour;
    }
    public int  getDinnerStartMinute() {
        return dinnerStartMinute;
    }

    public int  getDinnerEndHour() {
        return dinnerEndtHour;
    }
    public int  getDinnerEndMinute() {
        return dinnerEndMinute;
    }


    public int  getSleepStartHour() {
        return sleepStartHour;
    }
    public int  getSleepStartMinute() {
        return sleepStartMinute;
    }

    public int  getSleepEndHour() {
        return sleepEndHour;
    }
    public int  getSleepEndtMinute() {
        return sleepEndtMinute;
    }


    public void setBreakfastStartTime(int startHourIn, int startMiniuteIn) {
        this.breakfastStartHour = startHourIn;
        this.breakfastStartMinute = startMiniuteIn;
        sharedPreferences.edit().putInt("breakfastStartHour", startHourIn).apply();
        sharedPreferences.edit().putInt("breakfastStartMinute",startMiniuteIn).apply();

    }
    public void setBreakfastEndTime(int endHourIn,  int endMinitueIn) {
        this.breakfastEndHour = endHourIn;
        this.breakfastEndMinute = endMinitueIn;
        sharedPreferences.edit().putInt("breakfastEndHour",endHourIn).apply();
        sharedPreferences.edit().putInt("breakfastEndMinute",endMinitueIn).apply();
    }
    public void setLunchStartTime(int startHourIn, int startMiniuteIn) {
        this.lunchStartHour = startHourIn;
        this.lunchStartMinute = startMiniuteIn;
        sharedPreferences.edit().putInt("lunchStartHour", startHourIn).apply();
        sharedPreferences.edit().putInt("lunchStartMinute",startMiniuteIn).apply();;
    }
    public void setLunchEndTime(int endHourIn,  int endMinitueIn) {
        this.lunchEndHour = endHourIn;
        this.lunchEndMinute = endMinitueIn;
        sharedPreferences.edit().putInt("lunchEndHour", endHourIn).apply();
        sharedPreferences.edit().putInt("lunchEndMinute",endMinitueIn).apply();;
    }


    public void setSnackStartTime(int startHourIn, int startMiniuteIn) {
        this.snackStartHour = startHourIn;
        this.snackStartMinute = startMiniuteIn;
        sharedPreferences.edit().putInt("snackStartHour", startHourIn).apply();
        sharedPreferences.edit().putInt("snackStartMinute",startMiniuteIn).apply();;
    }

    public void setSnackEndTime(int endHourIn,  int endMinitueIn) {
        this.snackEndHour = endHourIn;
        this.snackEndMinute = endMinitueIn;
        sharedPreferences.edit().putInt("snackEndHour", endHourIn).apply();
        sharedPreferences.edit().putInt("snackEndMinute",endMinitueIn).apply();;
    }
    public void setDinnerStartTime(int startHourIn, int startMiniuteIn) {
        this.dinnerStartHour = startHourIn;
        this.dinnerStartMinute= startMiniuteIn;
        sharedPreferences.edit().putInt("dinnerStartHour", startHourIn).apply();
        sharedPreferences.edit().putInt("dinnerStartMinute",startMiniuteIn).apply();;
    }
    public void setDinnerEndTime(int endHourIn,  int endMinitueIn) {
        this.dinnerEndtHour = endHourIn;
        this.dinnerEndMinute = endMinitueIn;
        sharedPreferences.edit().putInt("dinnerEndtHour", endHourIn).apply();
        sharedPreferences.edit().putInt("dinnerEndMinute",endMinitueIn).apply();;
    }
    public void setSleepStartTime(int startHourIn, int startMiniuteIn) {
        this.sleepStartHour = startHourIn;
        this.sleepStartMinute = startMiniuteIn;
        sharedPreferences.edit().putInt("sleepStartHour", startHourIn).apply();
        sharedPreferences.edit().putInt("sleepStartMinute",startMiniuteIn).apply();;
    }
    public void setSleepEndTime(int endHourIn,  int endMinitueIn) {
        this.sleepEndHour = endHourIn;
        this.sleepEndtMinute = endMinitueIn;
        sharedPreferences.edit().putInt("sleepEndHour", endHourIn).apply();
        sharedPreferences.edit().putInt("sleepEndtMinute",endMinitueIn).apply();;
    }


}


