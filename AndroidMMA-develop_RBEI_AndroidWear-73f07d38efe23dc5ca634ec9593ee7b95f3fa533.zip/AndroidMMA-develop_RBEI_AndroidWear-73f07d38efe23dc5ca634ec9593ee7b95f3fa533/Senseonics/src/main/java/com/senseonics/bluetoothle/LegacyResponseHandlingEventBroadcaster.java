package com.senseonics.bluetoothle;

import android.util.Log;

import com.senseonics.bluetoothle.event.LegacyResponseHandlingEvent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.inject.Inject;
import javax.inject.Singleton;

import de.greenrobot.event.EventBus;

@Singleton
public class LegacyResponseHandlingEventBroadcaster implements Runnable {

    private BlockingQueue<LegacyResponseHandlingEvent> queue;
    private EventBus eventBus;

    @Inject
    public LegacyResponseHandlingEventBroadcaster(EventBus eventBus) {
        this(eventBus, new LinkedBlockingQueue<LegacyResponseHandlingEvent>());
    }

    protected LegacyResponseHandlingEventBroadcaster(EventBus eventBus, LinkedBlockingQueue<LegacyResponseHandlingEvent> arrayBlockingQueue) {
        this.eventBus = eventBus;
        queue = arrayBlockingQueue;

        new Thread(this, LegacyResponseHandlingEventBroadcaster.class.getSimpleName() + "-Thread").start();
    }

    public void broadcast(LegacyResponseHandlingEvent event) {
        try {
            queue.put(event);
            Log.v(LegacyResponseHandlingEventBroadcaster.class.getSimpleName(), "put " + event + " depth now: " + queue.size());
        } catch (InterruptedException e) {
            Log.w(LegacyResponseHandlingEventBroadcaster.class.getSimpleName(), "skipping event because our queue is full (should never happen)");
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                LegacyResponseHandlingEvent event = queue.take();
                Log.v(LegacyResponseHandlingEventBroadcaster.class.getSimpleName(), "take " + event + " from " + queue.getClass().getName());
                eventBus.post(event);
            } catch (InterruptedException e) {
                Log.w(LegacyResponseHandlingEventBroadcaster.class.getSimpleName(), "leaving run method due to interruption");
                return;
            }
        }
    }


}
