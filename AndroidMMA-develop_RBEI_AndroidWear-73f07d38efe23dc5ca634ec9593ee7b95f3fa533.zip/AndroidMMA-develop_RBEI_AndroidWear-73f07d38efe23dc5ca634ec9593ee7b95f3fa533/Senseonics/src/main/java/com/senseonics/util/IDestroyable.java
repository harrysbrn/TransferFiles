package com.senseonics.util;

public interface IDestroyable {
  void destroy();
}
