package com.senseonics.gen12androidapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.senseonics.util.Utils;

public class InitialDailyCalibrationActivity extends DailyCalibrationActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configure the status header
        statusBarDrawerButton.setVisibility(View.GONE);

        naviBarTitle.setVisibility(View.GONE);
        naviBarTitleImageView.setVisibility(View.VISIBLE);
        naviBarTitleImageView.setImageResource(R.drawable.setup_03);
        naviBarRightItemTextView.setText(getResources().getString(R.string.next));
    }

    public void goToUnitSelection() {
        startActivityForResult(new Intent(InitialDailyCalibrationActivity.this,
                GlucoseUnitActivity.class), Utils.WELCOME_UNIT_SELECTION_RESULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // Result coming back from the unit selection page when the Finish button is pressed
        if (resultCode == Utils.WELCOME_UNIT_SELECTION_RESULT) {
            setResult(resultCode);
            finish();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}
