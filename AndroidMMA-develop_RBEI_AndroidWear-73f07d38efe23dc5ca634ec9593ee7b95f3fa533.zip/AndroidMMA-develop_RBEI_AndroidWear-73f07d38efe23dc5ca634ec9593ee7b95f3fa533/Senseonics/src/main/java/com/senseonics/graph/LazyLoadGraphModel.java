package com.senseonics.graph;

import android.util.Log;
import com.senseonics.db.DatabaseManager;
import com.senseonics.util.IntentUtils;
import com.senseonics.util.TimeProvider;
import com.senseonics.util.Utils;
import java.util.Calendar;
import java.util.Date;
import javax.inject.Inject;

import static java.util.Calendar.DAY_OF_YEAR;

public class LazyLoadGraphModel {
  private String TAG = getClass().toString();
  private Date startDate = new Date(Long.MAX_VALUE);
  private IntentUtils intentUtils;
  private DatabaseManager databaseManager;
  private TimeProvider timeProvider;

  @Inject public LazyLoadGraphModel(IntentUtils intentUtils, DatabaseManager databaseManager,
      TimeProvider timeProvider) {
    Log.i(TAG, "New instance");
    this.databaseManager = databaseManager;
    this.intentUtils = intentUtils;
    this.timeProvider = timeProvider;
    reset();
  }

  public void refreshWithDate(Date newDate) {
    if (possiblyRetreatStartDate(newDate)) {
      refreshGraphWithExistingStartEndDates();
    }
  }

  public void refreshGraphWithExistingStartEndDates() {
    Log.i(TAG, "refreshGraphWithExistingStartEndDates to: " + startDate);
    Utils.endDateFinished = timeProvider.getCurrentTime();
    intentUtils.refreshGraphFromCache(getStartTimeAsCalendar(), Utils.endDateFinished, false);
  }

  public void refreshGraphWithNewStartEndDates() {
    Log.i(TAG, "refreshGraphWithNewStartEndDates to: " + startDate);
    Utils.endDateFinished = timeProvider.getCurrentTime();
    intentUtils.refreshGraphFromCache(getStartTimeAsCalendar(), Utils.endDateFinished, true);
  }

  private void reset() {
    if (Utils.threeDaysAgo == null) {
      Utils.initDates(databaseManager.getEarliestEventDate());
    }
    startDate = Utils.threeDaysAgo.getTime();
  }

  private boolean possiblyRetreatStartDate(Date newDate) {
    if (newDate.before(startDate)) {
      Calendar newStartDate = Calendar.getInstance();
      newStartDate.setTime(newDate);
      newStartDate.add(DAY_OF_YEAR, -3);
      startDate = newStartDate.getTime();
      return true;
    }
    return false;
  }

  private Calendar getStartTimeAsCalendar() {
    Calendar startCalendar = Calendar.getInstance();
    startCalendar.setTime(startDate);
    return startCalendar;
  }
}
