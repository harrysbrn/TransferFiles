package com.senseonics.graph.util;

public class WeeklyStatValue {
	public final static int INVALID_AVG = 0;
	public final static int INVALID_MIN = 0;
	public final static int INVALID_MAX = 0;
	private int avg;
	private int min;
	private int max;


	public WeeklyStatValue(int avg, int min, int max) {
		super();
		this.avg = avg;
		this.min = min;
		this.max = max;
	}



	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}




	public int getAvg() {
		return avg;
	}

	public void setAvg(int avg) {
		this.avg = avg;
	}
}
