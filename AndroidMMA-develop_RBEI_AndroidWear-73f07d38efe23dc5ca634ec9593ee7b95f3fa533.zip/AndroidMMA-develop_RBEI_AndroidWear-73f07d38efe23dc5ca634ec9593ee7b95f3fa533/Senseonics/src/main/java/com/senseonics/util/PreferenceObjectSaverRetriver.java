package com.senseonics.util;

import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.senseonics.model.TempProfileModel.GlucoseProfile;

import javax.inject.Inject;

public class PreferenceObjectSaverRetriver { /** #3160 */
    private SharedPreferences sharedPreferences;

    @Inject
    public PreferenceObjectSaverRetriver(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    public void saveGlucoseProfileIntoPreference(String key, GlucoseProfile object) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(object);
        editor.putString(key, json);
        editor.apply();
    }

    public GlucoseProfile retrieveGlucoseProfileFromPreference(String key) {
        boolean exists = sharedPreferences.contains(key);

        if (!exists) {
            return null;
        }

        String json = sharedPreferences.getString(key, "");
        Gson gson = new Gson();
        GlucoseProfile obj = gson.fromJson(json, GlucoseProfile.class);

        return obj;
    }
}
