package com.senseonics.events;

public class ActivityOnResumeEvent {
    public ActivityOnResumeEvent() { }
}
