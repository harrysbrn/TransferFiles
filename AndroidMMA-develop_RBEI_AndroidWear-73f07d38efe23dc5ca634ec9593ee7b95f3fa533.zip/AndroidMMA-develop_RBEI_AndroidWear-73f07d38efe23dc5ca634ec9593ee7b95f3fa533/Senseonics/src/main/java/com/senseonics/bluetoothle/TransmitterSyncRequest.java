package com.senseonics.bluetoothle;

import com.google.common.base.Objects;

public class TransmitterSyncRequest implements Comparable<TransmitterSyncRequest> {
    private int expectedResponseId;
    private int[] data;
    private int highestExpectedRecordNumber;
    private int expectResponseCount;

    public TransmitterSyncRequest(int expectedResponseId, int[] data, int highestExpectedRecordNumber, int expectResponseCount) {
        this.expectedResponseId = expectedResponseId;
        this.data = data;
        this.highestExpectedRecordNumber = highestExpectedRecordNumber;
        this.expectResponseCount = expectResponseCount;
    }

    public int[] getData() {
        return data;
    }

    public int getExpectedResponseId() {
        return expectedResponseId;
    }

    public int getHighestExpectedRecordNumber() {
        return highestExpectedRecordNumber;
    }

    public int getExpectResponseCount() {
        return expectResponseCount;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("expectedResponseId", Integer.toHexString(expectedResponseId))
                .add("highestExpectedRecordNumber", highestExpectedRecordNumber)
                .add("expectResponseCount", expectResponseCount)
                .add("data", HexHelper.intArrayToString(data))
                .toString();
    }

    @Override
    public int compareTo(TransmitterSyncRequest another) {

        int compareByResponse = Integer.compare(expectedResponseId, another.getExpectedResponseId());
        if (compareByResponse == 0) {
            return Integer.compare(highestExpectedRecordNumber, another.getHighestExpectedRecordNumber());
        }
        return compareByResponse;
    }
}
