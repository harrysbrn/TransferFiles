package com.senseonics.model;

public class ModelChangedEvent {
    private TransmitterStateModel transmitterStateModel;

    public ModelChangedEvent(TransmitterStateModel transmitterStateModel) {
        this.transmitterStateModel = transmitterStateModel;
    }

    public TransmitterStateModel getModel() {
        return transmitterStateModel;
    }
}
