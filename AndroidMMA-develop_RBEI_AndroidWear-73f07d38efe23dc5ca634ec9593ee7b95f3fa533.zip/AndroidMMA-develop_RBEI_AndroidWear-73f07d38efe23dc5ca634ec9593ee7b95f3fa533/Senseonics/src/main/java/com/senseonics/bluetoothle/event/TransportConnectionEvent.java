package com.senseonics.bluetoothle.event;

import com.senseonics.bluetoothle.Transmitter;

public class TransportConnectionEvent {
    private final Transmitter transmitter;

    public TransportConnectionEvent(Transmitter transmitter) {
        this.transmitter = transmitter;
    }

    public Transmitter getTransmitter() {
        return transmitter;
    }
}
