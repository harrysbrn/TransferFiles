package com.senseonics.fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.gen12androidapp.ServiceActivity;
import com.senseonics.gen12androidapp.SoundSelectionActivity;
import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.EventUtils;
import com.senseonics.events.ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent;
import com.senseonics.events.ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent;
import com.senseonics.events.ModelChangedVibrateModeEvent;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;

import java.util.ArrayList;

import de.greenrobot.event.EventBus;

public class SoundSettingsSimplifiedFragment extends BaseFragment{
    private final String TAG = "SoundSetting";

    private final int LOW_SNOOZE_MIN = 5;
    private final int LOW_SNOOZE_MAX = 30;
    private final int HIGH_SNOOZE_MIN = 15;
    private final int HIGH_SNOOZE_MAX = 180;

    private RelativeLayout lowAlarmLayout;
    private TextView lowAlarmLeftText;
    private TextView lowAlarmRightText;

    private RelativeLayout lowSnoozeLayout;
    private TextView lowSnoozeLeftText;
    private TextView lowSnoozeRightText;

    private RelativeLayout highAlarmLayout;
    private TextView highAlarmLeftText;
    private TextView highAlarmRightText;

    private RelativeLayout highSnoozeLayout;
    private TextView highSnoozeLeftText;
    private TextView highSnoozeRightText;

    private RelativeLayout doNotDisturbLayout;
    private Switch doNotDisturbSwitch;
    private TextView doNotDisturbTextView;

    private ProgressDialog progressDialog;
    private boolean doNotDisturbModeArrived = false;
    private boolean lowSnoozeDayArrived = false;
    private boolean highSnoozeDayArrived = false;

    private Dialog dialog;
    private ArrayList<Item> values;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_soundsettingssimplified, container, false);

        /** Find all the views */
        lowAlarmLayout = (RelativeLayout) view.findViewById(R.id.lowAlarmLayout);
        lowAlarmLeftText = (TextView) view.findViewById(R.id.lowAlarmLeftText);
        lowAlarmRightText = (TextView) view.findViewById(R.id.lowAlarmRightText);
        initLowAlarmLayout();

        lowSnoozeLayout = (RelativeLayout) view.findViewById(R.id.lowSnoozeLayout);
        lowSnoozeLeftText = (TextView) view.findViewById(R.id.lowSnoozeLeftText);
        lowSnoozeRightText = (TextView) view.findViewById(R.id.lowSnoozeRightText);
        initLowSnoozeLayout();

        highAlarmLayout = (RelativeLayout) view.findViewById(R.id.highAlarmLayout);
        highAlarmLeftText = (TextView) view.findViewById(R.id.highAlarmLeftText);
        highAlarmRightText = (TextView) view.findViewById(R.id.highAlarmRightText);
        initHighAlarmLayout();

        highSnoozeLayout = (RelativeLayout) view.findViewById(R.id.highSnoozeLayout);
        highSnoozeLeftText = (TextView) view.findViewById(R.id.highSnoozeLeftText);
        highSnoozeRightText = (TextView) view.findViewById(R.id.highSnoozeRightText);
        initHighSnoozeLayout();

        // Find and Configure Do Not Distrub
        doNotDisturbLayout = (RelativeLayout) view.findViewById(R.id.layoutDoNotDisturb);
        doNotDisturbSwitch = (Switch) view.findViewById(R.id.switcher);
        doNotDisturbTextView = (TextView) view.findViewById(R.id.doNotDisturbName);
        doNotDisturbSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                InputMethodManager imm = (InputMethodManager) getActivity()
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(
                        buttonView.getApplicationWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);

                if (transmitterStateModel.isVibrateMode() != !isChecked) {
                    if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                        transmitterStateModel.setVibrateMode(!isChecked);
                        BluetoothService bluetoothService = ((ServiceActivity) getActivity()).getService();
                        bluetoothService.postWriteVibrateModelRequest(!isChecked);
                    }
                }
            }
        });

        progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(true);

        return view;
    }

    @Override
    public void onStop() {
        progressDialog.dismiss();
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
        updateViews();
        loadData();
    }

    @Override
    public void onPause() {
        EventBus.getDefault().unregister(this);
        super.onPause();
    }

    private void loadData() {
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            progressDialog.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    progressDialog.dismiss();
                }
            }, GraphUtils.MINUTE / 6);

            BluetoothService bluetoothService = ((ServiceActivity) getActivity()).getService();
            bluetoothService.postGlucoseAlarmRepeatIntervalAndStartTime();
            bluetoothService.postReadVibrateModeRequest();
        }
    }

    private void updateProgressDialog() {
        if (doNotDisturbModeArrived && lowSnoozeDayArrived && highSnoozeDayArrived) {
            updateViews();
            progressDialog.dismiss();
        }
    }

    public void onEventMainThread(ModelChangedVibrateModeEvent event) {
        doNotDisturbModeArrived = true;
        updateProgressDialog();
    }

    public void onEventMainThread(ModelChangedLowGlucoseAlarmRepeatIntervalDayTimeEvent event) {
        lowSnoozeDayArrived = true;
        updateProgressDialog();
    }

    public void onEventMainThread(ModelChangedHighGlucoseAlarmRepeatIntervalDayTimeEvent event) {
        highSnoozeDayArrived = true;
        updateProgressDialog();
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        updateViews();
    }

    private void updateViews() {
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            lowAlarmLayout.setClickable(true);
            lowAlarmLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            lowAlarmLeftText.setTextColor(getResources().getColor(R.color.black));
            lowAlarmRightText.setTextColor(getResources().getColor(R.color.black));

            lowSnoozeLayout.setClickable(true);
            lowSnoozeLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            lowSnoozeLeftText.setTextColor(getResources().getColor(R.color.black));
            lowSnoozeRightText.setTextColor(getResources().getColor(R.color.black));

            highAlarmLayout.setClickable(true);
            highAlarmLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            highAlarmLeftText.setTextColor(getResources().getColor(R.color.black));
            highAlarmRightText.setTextColor(getResources().getColor(R.color.black));

            highSnoozeLayout.setClickable(true);
            highSnoozeLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            highSnoozeLeftText.setTextColor(getResources().getColor(R.color.black));
            highSnoozeRightText.setTextColor(getResources().getColor(R.color.black));

            // Do Not Disturb
            doNotDisturbSwitch.setEnabled(true);
            doNotDisturbLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            doNotDisturbTextView.setTextColor(getResources().getColor(R.color.black));

        } else {
            lowAlarmLayout.setClickable(false);
            lowAlarmLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            lowAlarmLeftText.setTextColor(getResources().getColor(R.color.light_gray));
            lowAlarmRightText.setTextColor(getResources().getColor(R.color.light_gray));

            lowSnoozeLayout.setClickable(false);
            lowSnoozeLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            lowSnoozeLeftText.setTextColor(getResources().getColor(R.color.light_gray));
            lowSnoozeRightText.setTextColor(getResources().getColor(R.color.light_gray));

            highAlarmLayout.setClickable(false);
            highAlarmLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            highAlarmLeftText.setTextColor(getResources().getColor(R.color.light_gray));
            highAlarmRightText.setTextColor(getResources().getColor(R.color.light_gray));

            highSnoozeLayout.setClickable(false);
            highSnoozeLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            highSnoozeLeftText.setTextColor(getResources().getColor(R.color.light_gray));
            highSnoozeRightText.setTextColor(getResources().getColor(R.color.light_gray));

            // Do Not Disturb
            doNotDisturbSwitch.setEnabled(false);
            doNotDisturbLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            doNotDisturbTextView.setTextColor(getResources().getColor(R.color.light_gray));
        }

        lowAlarmRightText.setText(alarmRingtoneManager.getDayLowAlarmSound());
        lowSnoozeRightText.setText(String.valueOf(transmitterStateModel.getLowGlucoseAlarmRepeatIntervalDayTime()));
        highAlarmRightText.setText(alarmRingtoneManager.getDayHighAlarmSound());
        highSnoozeRightText.setText(String.valueOf(transmitterStateModel.getHighGlucoseAlarmRepeatIntervalDayTime()));
        doNotDisturbSwitch.setChecked(!transmitterStateModel.isVibrateMode());
    }

    private void showDialog(String title, ArrayList<Item> items,
                           final EventUtils.PickerManager pickerManager, int currentSelected) {
        if (items.size() > 1) {
            if (dialog != null && dialog.isShowing())
                dialog.hide();
            dialog = dialogUtils.createPickerDialog(getActivity(),
                    title, items, pickerManager, currentSelected);
            dialog.show();
        }
    }

    private void initLowAlarmLayout() {
        lowAlarmLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SoundSelectionActivity.class);
                intent.putExtra("LowAlarmDay", "1");
                getActivity().startActivity(intent);
            }
        });
    }

    private void initHighAlarmLayout() {
        highAlarmLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SoundSelectionActivity.class);
                intent.putExtra("HighAlarmDay", "1");
                getActivity().startActivity(intent);
            }
        });
    }

    private void initLowSnoozeLayout() {
        final EventUtils.PickerManager pickerManager = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                String value = values.get(id).getValue();
                if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                    BluetoothService bluetoothService = ((ServiceActivity) getActivity()).getService();
                    bluetoothService.postWriteLowGlucoseAlarmRepeatIntervalDayTime(Integer.valueOf(value));
                    // #2944 To make the app compatible with both FW 6.20 and 6.21 change the snooze settings
                    bluetoothService.postWriteLowGlucoseAlarmRepeatIntervalNightTime(Integer.valueOf(value));
                }
            }
        };

        lowSnoozeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.sound_low_snooze);
                values = dialogUtils.getNumbersBetween(LOW_SNOOZE_MIN, LOW_SNOOZE_MAX, 5);
                int position = Utils.getItemPosition(values, transmitterStateModel.getLowGlucoseAlarmRepeatIntervalDayTime());
                showDialog(dialogTitle, values, pickerManager, position);
            }
        });
    }

    private void initHighSnoozeLayout() {
        final EventUtils.PickerManager pickerManager = new EventUtils.PickerManager() {
            @Override
            public void selected(int id) {
                String value = values.get(id).getValue();
                if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
                    BluetoothService bluetoothService = ((ServiceActivity) getActivity()).getService();
                    bluetoothService.postWriteHighGlucoseAlarmRepeatIntervalDayTime(Integer.valueOf(value));
                    // #2944 To make the app compatible with both FW 6.20 and 6.21 change the snooze settings
                    bluetoothService.postWriteHighGlucoseAlarmRepeatIntervalNightTime(Integer.valueOf(value));
                }
            }
        };

        highSnoozeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dialogTitle = getResources().getString(
                        R.string.sound_high_snooze);
                values = dialogUtils.getNumbersBetween(HIGH_SNOOZE_MIN, HIGH_SNOOZE_MAX, 15);
                int position = Utils.getItemPosition(values, transmitterStateModel.getHighGlucoseAlarmRepeatIntervalDayTime());
                showDialog(dialogTitle, values, pickerManager, position);
            }
        });
    }

}
