package com.senseonics.events;

public class ModelChangedLinkedSensorIdEvent {

    private String sensorId;

    public ModelChangedLinkedSensorIdEvent(String sensorId){
        this.sensorId = sensorId;
    }

    public String getSensorId() {
        return sensorId;
    }
}
