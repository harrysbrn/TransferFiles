package com.senseonics.model;

public enum BATTERY_LEVEL {
    UNKNOWN_NEG_1(-1), BL_0(0), BL_5(1), BL_10(2), BL_25(3), BL_35(4), BL_45(5), BL_55(6), BL_65(7), BL_75(8), BL_85(9), BL_95(10), BL_100(11);

    private int strength;

    BATTERY_LEVEL(int strength) {
        this.strength = strength;
    }

    public static BATTERY_LEVEL fromStrength(int fromStrength) {
        for(BATTERY_LEVEL level : BATTERY_LEVEL.values()) {
            if (fromStrength == level.strength) {
                return level;
            }
        }
        return UNKNOWN_NEG_1;
    }
}
