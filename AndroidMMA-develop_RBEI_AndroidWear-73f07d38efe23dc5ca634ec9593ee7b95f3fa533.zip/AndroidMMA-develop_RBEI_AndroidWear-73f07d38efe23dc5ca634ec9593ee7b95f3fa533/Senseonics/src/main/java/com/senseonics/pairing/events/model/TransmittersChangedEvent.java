package com.senseonics.pairing.events.model;

import com.senseonics.bluetoothle.Transmitter;
import java.util.List;

public class TransmittersChangedEvent {
  public List<Transmitter> transmitters;

  public TransmittersChangedEvent(List<Transmitter> discoveredTransmitters) {
    this.transmitters = discoveredTransmitters;
  }
}
