package com.senseonics.events;

public class ModelChangedCalibrationsMadeInThisPhaseEvent {
    private int calibrationsMadeInThisPhase;

    public ModelChangedCalibrationsMadeInThisPhaseEvent(int calibrationsMadeInThisPhase){
        this.calibrationsMadeInThisPhase = calibrationsMadeInThisPhase;
    }

    public int getCalibrationsMadeInThisPhase() {
        return calibrationsMadeInThisPhase;
    }
}
