package com.senseonics.bluetoothle;

import android.content.Context;
import android.content.SharedPreferences;

import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import com.senseonics.util.Utils;

import java.util.Locale;

public class BluetoothUtils {

    public static boolean mConnected = false;
    public static boolean linkingRequestsInitialized = false;
    public static int linkingPacketsNumber = 0;

    public static void loadSettings(Context context) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(
                Utils.SHARED_PREF, Context.MODE_PRIVATE);

        boolean hasInvalidUnit = false;
        // Unit
        if (sharedPreferences.contains(Utils.prefGlucoseUnit)) {
            Utils.GLUCOSE_UNIT storedUnit = Utils.GLUCOSE_UNIT.values()[sharedPreferences
                    .getInt(Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal())];
            if ((storedUnit != Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
                    && (storedUnit != Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L)) {
                hasInvalidUnit = true;
            }
            else {
                Utils.currentGlucoseUnit = storedUnit;
            }
        }
        else {
            hasInvalidUnit = true;
        }

//        Log.d(BluetoothUtils.class.getSimpleName() + "#3743", "hasInvalidUnit?" + hasInvalidUnit + "|unit:" + Utils.currentGlucoseUnit);

        if (hasInvalidUnit) {
            /** ! Should Never Happen ! */
            String localeString = Locale.getDefault().toString();
            if (localeString.equals("en_US") ||
                    localeString.equals("de_DE") ||
                    localeString.equals("it_IT")) {
                Utils.currentGlucoseUnit = Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL;
                Utils.saveSettings(context, Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL.ordinal());
            }
            else {
                Utils.currentGlucoseUnit = Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L;
                Utils.saveSettings(context, Utils.prefGlucoseUnit, Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L.ordinal());
            }

            Answers.getInstance().logCustom(new CustomEvent("Unit")
                    .putCustomAttribute("Reason", "Not Found in Preference"));
        }

        // Target
        if (sharedPreferences.contains(Utils.prefTargetHigh))
            Utils.GLUCOSE_TARGET_HIGH = sharedPreferences.getInt(
                    Utils.prefTargetHigh, Utils.GLUCOSE_TARGET_HIGH);
        if (sharedPreferences.contains(Utils.prefTargetLow))
            Utils.GLUCOSE_TARGET_LOW = sharedPreferences.getInt(
                    Utils.prefTargetLow, Utils.GLUCOSE_TARGET_LOW);

        // Alarm
        if (sharedPreferences.contains(Utils.prefAlarmHigh))
            Utils.GLUCOSE_ALARM_LEVEL_HIGH = sharedPreferences.getInt(
                    Utils.prefAlarmHigh, Utils.GLUCOSE_ALARM_LEVEL_HIGH);
        if (sharedPreferences.contains(Utils.prefAlarmLow))
            Utils.GLUCOSE_ALARM_LEVEL_LOW = sharedPreferences.getInt(
                    Utils.prefAlarmLow, Utils.GLUCOSE_ALARM_LEVEL_LOW);
        // Predictive alert
        if (sharedPreferences.contains(Utils.prefPredictiveAlertsActivated))
            Utils.predictiveAlertsActivated = sharedPreferences.getBoolean(
                    Utils.prefPredictiveAlertsActivated,
                    Utils.predictiveAlertsActivated);
        if (sharedPreferences.contains(Utils.prefPredictiveMinutes))
            Utils.PREDICTIVE_MINUTES = sharedPreferences.getInt(
                    Utils.prefPredictiveMinutes, Utils.PREDICTIVE_MINUTES);
        // Rate alert
        if (sharedPreferences.contains(Utils.prefRateAlertsActivated))
            Utils.rateAlertsActivated = sharedPreferences.getBoolean(
                    Utils.prefRateAlertsActivated, Utils.rateAlertsActivated);
        if (sharedPreferences.contains(Utils.prefRateValue))
            Utils.RATE_VALUE = sharedPreferences.getFloat(Utils.prefRateValue,
                    Utils.RATE_VALUE);
    }

    public static void initMySensorRequests(BluetoothService service, boolean linkedSensorIdArrived, boolean sensorInsertionDateAndTimeArrived, boolean unLinkedSensorIdArrived) {
        if (BluetoothUtils.mConnected) {
            // linked sensor id
            if (!linkedSensorIdArrived) {
                service.postLinkedSensorId();
            }

            if (!sensorInsertionDateAndTimeArrived) {
                // insertion date
                service.postSensorInsertionDate();
                // insertion time
                service.postSensorInsertionTime();
            }

            // detected sensor id
            if (!unLinkedSensorIdArrived) {
                service.postDetectedSensorId();
            }
        }
    }

}
