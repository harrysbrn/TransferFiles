package com.senseonics.events;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.senseonics.gen12androidapp.R;
import com.senseonics.util.Item;

import net.simonvt.numberpicker.NumberPicker;

import java.util.ArrayList;

public class EventUtils {
	public static final int eventTypeInsulin = 0x01, eventTypeMeal = 0x02,
			eventTypeExercise = 0x04, eventTypeHealth = 0x08;

	public enum MEAL_TYPE {
		BREAKFAST, LUNCH, DINNER, SNACK
	}

	public enum INSULIN_TYPE {
		RAPID_ACTING, SHORT_ACTING, INTERMEDIATE_ACTING, LONG_ACTING, MIXED_70_30, MIXED_50_50, MIXED_75_25, OTHER
	}

	public enum HEALTH_CONDITION {
		NORMAL, COUGH_COLD, SORE_THROAT, TIRED, STRESS, FEVER, FLU, MENSTRUAL_PERIOD, NAUSEA_VOMITING, DIARRHEA, ALLERGY, EARACHE, INFECTION, DIZZY, ALCOHOL, LOW_SYMPTOMS, HIGH_SYMPTOMS, OTHER
	}

	public enum HEALTH_SEVERITY {
		LOW(0x0000), MEDIUM(0x0001), HIGH(0x0002);

		private int subType;

		HEALTH_SEVERITY(int subType) {
			this.subType = subType;
		}

		public int getSubType() {
			return subType;
		}

		public static HEALTH_SEVERITY valueBySubtype(int subtypeId) {
			for(HEALTH_SEVERITY intensity : HEALTH_SEVERITY.values()) {
				if (subtypeId == intensity.getSubType()) {
					return intensity;
				}
			}
			return null;
		}	}

	public enum EXERCISE_INTENSITY {
		LOW(0x0000), MEDIUM(0x0001), HIGH(0x0002);

		private int subType;

		EXERCISE_INTENSITY(int subType) {
			this.subType = subType;
		}

		public int getSubType() {
			return subType;
		}

		public static EXERCISE_INTENSITY valueBySubtype(int subtypeId) {
			for(EXERCISE_INTENSITY intensity : EXERCISE_INTENSITY.values()) {
				if (subtypeId == intensity.getSubType()) {
					return intensity;
				}
			}
			return null;
		}
	}

	public interface PickerManager {
		void selected(int id);
	}

	public static void createMealTypePicker(Context context, String title,
			PickerManager manager, int selectedId) {

		ArrayList<Item> items = new ArrayList<Item>();
		for (MEAL_TYPE mealType : MEAL_TYPE.values())
			items.add(new Item(mealType.ordinal(), getMealTypeName(context,
					mealType)));
		EventUtils.createPickerDialog(context, title, items, manager, selectedId);
	}

	public static void createInsulinTypePicker(Context context, String title,
			PickerManager manager, int selectedId) {

		ArrayList<Item> items = new ArrayList<Item>();
		for (INSULIN_TYPE insulinType : INSULIN_TYPE.values())
			items.add(new Item(insulinType.ordinal(), getInsulinTypeName(
					context, insulinType)));
		EventUtils.createPickerDialog(context, title, items, manager, selectedId);
	}

	public static void createHealthConditionPicker(Context context, String title,
			PickerManager manager, int selectedId) {

		ArrayList<Item> items = new ArrayList<Item>();
		for (HEALTH_CONDITION condition : HEALTH_CONDITION.values())
			items.add(new Item(condition.ordinal(), getHealthConditionName(
					context, condition)));
		EventUtils.createPickerDialog(context, title, items, manager, selectedId);
	}

	public static void createHealthSeverityPicker(Context context, String title,
			PickerManager manager, int selectedId) {

		ArrayList<Item> items = new ArrayList<Item>();
		for (HEALTH_SEVERITY severity : HEALTH_SEVERITY.values())
			items.add(new Item(severity.ordinal(), getHealthSeverityName(
					context, severity)));
		EventUtils.createPickerDialog(context, title, items, manager, selectedId);
	}

	public static void createExerciseIntensityPicker(Context context, String title,
			PickerManager manager, int selectedId) {

		ArrayList<Item> items = new ArrayList<Item>();
		for (EXERCISE_INTENSITY intensity : EXERCISE_INTENSITY.values())
			items.add(new Item(intensity.ordinal(), getExerciseIntensityName(
					context, intensity)));
		EventUtils.createPickerDialog(context, title, items, manager, selectedId);
	}

	public static void createPickerDialog(Context context, String title,
			ArrayList<Item> items, final PickerManager pickerManager,
			int currentSelected) {

		final Dialog dialog = new Dialog(context, R.style.PickerDialog);
		LayoutInflater inflater = LayoutInflater.from(context);
		View view = inflater.inflate(R.layout.picker, null);

		TextView titleTextView = (TextView) view.findViewById(R.id.title);
		titleTextView.setText(title);
		
		final NumberPicker picker = (NumberPicker) view
				.findViewById(R.id.picker);

		String[] array = new String[items.size()];
		for (int i = 0; i < items.size(); i++)
			array[i] = items.get(i).getValue();

		picker.setMinValue(0);
		picker.setMaxValue(items.size() - 1);
		picker.setDisplayedValues(array);
		picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
		picker.setWrapSelectorWheel(false);
		picker.setValue(currentSelected);

		TextView ok = (TextView) view.findViewById(R.id.ok);
		ok.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				pickerManager.selected(picker.getValue());
				dialog.dismiss();
			}
		});

		TextView cancel = (TextView) view.findViewById(R.id.cancel);
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		dialog.setContentView(view);
		dialog.show();
	}

	public static String getMealTypeName(Context context, MEAL_TYPE mealType) {

		switch (mealType) {
		case BREAKFAST:
			return context.getResources().getString(R.string.breakfast);
		case DINNER:
			return context.getResources().getString(R.string.dinner);
		case LUNCH:
			return context.getResources().getString(R.string.lunch);
		case SNACK:
			return context.getResources().getString(R.string.snack);
		default:
			return " ";
		}
	}

	public static String getInsulinTypeName(Context context,
			INSULIN_TYPE insulinType) {

		switch (insulinType) {
		case INTERMEDIATE_ACTING:
			return context.getResources().getString(
					R.string.intermediate_acting);
		case LONG_ACTING:
			return context.getResources().getString(R.string.long_acting);
		case MIXED_50_50:
			return context.getResources().getString(R.string.mixed_50_50);
		case MIXED_70_30:
			return context.getResources().getString(R.string.mixed_70_30);
		case MIXED_75_25:
			return context.getResources().getString(R.string.mixed_75_25);
		case OTHER:
			return context.getResources().getString(R.string.other);
		case RAPID_ACTING:
			return context.getResources().getString(R.string.rapid_acting);
		case SHORT_ACTING:
			return context.getResources().getString(R.string.short_acting);
		default:
			return " ";
		}
	}

	public static String getHealthConditionName(Context context,
			HEALTH_CONDITION condition) {

		switch (condition) {
		case ALCOHOL:
			return context.getResources().getString(R.string.alcohol);
		case ALLERGY:
			return context.getResources().getString(R.string.allergy);
		case COUGH_COLD:
			return context.getResources().getString(R.string.cough_cold);
		case DIARRHEA:
			return context.getResources().getString(R.string.diarrhea);
		case DIZZY:
			return context.getResources().getString(R.string.dizzy);
		case EARACHE:
			return context.getResources().getString(R.string.earache);
		case FEVER:
			return context.getResources().getString(R.string.fever);
		case FLU:
			return context.getResources().getString(R.string.flu);
		case HIGH_SYMPTOMS:
			return context.getResources().getString(R.string.high_symptoms);
		case INFECTION:
			return context.getResources().getString(R.string.infection);
		case LOW_SYMPTOMS:
			return context.getResources().getString(R.string.low_symptoms);
		case MENSTRUAL_PERIOD:
			return context.getResources().getString(R.string.menstrual_period);
		case NAUSEA_VOMITING:
			return context.getResources().getString(R.string.nausea_vomiting);
		case NORMAL:
			return context.getResources().getString(R.string.normal);
		case OTHER:
			return context.getResources().getString(R.string.other);
		case SORE_THROAT:
			return context.getResources().getString(R.string.sore_throat);
		case STRESS:
			return context.getResources().getString(R.string.stress);
		case TIRED:
			return context.getResources().getString(R.string.tired);
		default:
			return " ";
		}
	}

	public static String getHealthSeverityName(Context context,
			HEALTH_SEVERITY severity) {

		switch (severity) {
		case HIGH:
			return context.getResources().getString(R.string.high);
		case LOW:
			return context.getResources().getString(R.string.low);
		case MEDIUM:
			return context.getResources().getString(R.string.medium);
		default:
			return " ";

		}
	}

	public static String getExerciseIntensityName(Context context,
			EXERCISE_INTENSITY intensity) {

		switch (intensity) {
		case HIGH:
			return context.getResources().getString(R.string.high);
		case LOW:
			return context.getResources().getString(R.string.low);
		case MEDIUM:
			return context.getResources().getString(R.string.medium);
		default:
			return " ";

		}
	}
	
	
	

}