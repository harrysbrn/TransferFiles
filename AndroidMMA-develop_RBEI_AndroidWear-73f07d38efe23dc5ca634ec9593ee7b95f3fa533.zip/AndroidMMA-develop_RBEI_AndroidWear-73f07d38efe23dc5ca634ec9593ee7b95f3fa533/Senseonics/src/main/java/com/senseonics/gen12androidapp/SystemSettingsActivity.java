package com.senseonics.gen12androidapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.google.common.base.Objects;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.bluetoothle.TransmitterConnectionEvent;
import com.senseonics.events.EventUtils.PickerManager;
import com.senseonics.events.ModelChangedLinkedSensorIdEvent;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.util.CustomEditText;
import com.senseonics.util.CustomEditText.EditTextImeBackListener;
import com.senseonics.util.Item;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.GLUCOSE_UNIT;

import java.util.ArrayList;

public class SystemSettingsActivity extends BaseActivity {

    private LinearLayout content, transmitterNameLayout;
    private RelativeLayout linkedSensorLayout;
    private TextView transmitterNameTextView,
            linkedSensorTextView;
    private View glucoseView;
    private TextView glucoseTextView;
    private RelativeLayout glucoseLayout;
    private CustomEditText transmitterNameEditText;
    private TextView sensorIdTextView;
    private LayoutInflater inflater;
    private Dialog dialog;

    private ArrayList<Item> unitValues;

    private ProgressDialog progressDialog;

    private boolean linkedSerialNumberArrived = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add the content view
        LinearLayout rl = (LinearLayout) findViewById(R.id.base_activity_linear_layout);
        LayoutInflater layoutInflater = getLayoutInflater();
        LinearLayout.LayoutParams parms_content = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        rl.addView(
                layoutInflater.inflate(R.layout.layout_content, null),
                parms_content);

        // Configure the navigation bar
        naviBarTitle.setText(R.string.system);
        naviBarRightItemTextView.setVisibility(View.GONE);
        naviBarRightItemAddEventImageview.setVisibility(View.GONE);

        Utils.transmitterNameContainer = null;
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        progressDialog = new ProgressDialog(this, R.style.TransparentProgressDialogTheme);
        progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        progressDialog.setCancelable(true);

        content = (LinearLayout) findViewById(R.id.content);
        inflater = LayoutInflater.from(this);

        unitValues = new ArrayList<Item>();
        unitValues.add(new Item(0, Utils.getGlucoseUnitString(this,
                GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)));
        unitValues.add(new Item(1, Utils.getGlucoseUnitString(this,
                GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L)));

        RelativeLayout layout = (RelativeLayout) findViewById(R.id.parent);
        layout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) SystemSettingsActivity.this
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getApplicationWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
                if (transmitterStateModel.getTransmitterName() != null)
                    transmitterNameEditText.setText(transmitterStateModel.getTransmitterName());
            }
        });

        addViews();
    }

    public void onEventMainThread(TransmitterConnectionEvent event) {
        updateViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
            progressDialog.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    progressDialog.dismiss();
                }
            }, GraphUtils.MINUTE / 6);

            getService().postReadSensorIdRequest();
        }
    }

    private void addViews() {
        // ----------------- Glucose unit -------------------------
        addGlucoseUnitView();

        // ----------------- Transmitter name ---------------------
        addTransmitterNameView();

        // ----------------- Linked sensor ------------------------
        addSensorSerialNumberView(getResources().getString(R.string.linked_sensor));

        updateViews();
    }

    private void updateViews() {
        if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED) {
              // Transmitter name
            transmitterNameLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            transmitterNameTextView.setTextColor(getResources().getColor(R.color.black));
            transmitterNameEditText.setEnabled(true);
            transmitterNameEditText.setTextColor(getResources().getColor(R.color.black));
              // Linked sensor
            linkedSensorLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            linkedSensorLayout.setEnabled(true);
            linkedSensorTextView.setTextColor(getResources().getColor(R.color.black));
            sensorIdTextView.setTextColor(getResources().getColor(R.color.black));

        } else {
            // Transmitter name
            transmitterNameLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            transmitterNameTextView.setTextColor(getResources().getColor(R.color.light_gray));
            transmitterNameEditText.setTextColor(getResources().getColor(R.color.light_gray));
            transmitterNameEditText.setSelected(false);
            transmitterNameEditText.setFocusable(false);
            transmitterNameEditText.setEnabled(false);

            // Linked sensor
            linkedSensorLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            linkedSensorLayout.setEnabled(false);
            linkedSensorTextView.setTextColor(getResources().getColor(R.color.light_gray));
            sensorIdTextView.setTextColor(getResources().getColor(R.color.light_gray));
        }
    }

    public void onEventMainThread(ModelChangedLinkedSensorIdEvent event) {
        sensorIdTextView.setText(Objects.firstNonNull(event.getSensorId(), Utils.unknownString));
        linkedSerialNumberArrived = true;
        updateDisplay();
    }

    private void updateDisplay() {
        if (linkedSerialNumberArrived) {
            progressDialog.dismiss();
        }

        transmitterNameEditText.setText(Objects.firstNonNull(transmitterStateModel.getTransmitterName(), ""));

        updateViews();
    }

    private void setBoldTextView(TextView textView) {
        textView.setTypeface(Typeface.DEFAULT_BOLD);
    }

    private void addGlucoseUnitView() {

        glucoseView = inflater.inflate(R.layout.settings_system_item, null);

        glucoseTextView = (TextView) glucoseView.findViewById(R.id.name);
        final TextView rightTextView = (TextView) glucoseView.findViewById(R.id.rightTextView);
        glucoseTextView.setText(getResources().getString(R.string.glucose_unit));
        setBoldTextView(glucoseTextView);

        ImageView arrowImageView = (ImageView) glucoseView.findViewById(R.id.arrow);
        arrowImageView.setVisibility(View.INVISIBLE);

        glucoseLayout = (RelativeLayout) glucoseView.findViewById(R.id.layout);
        final PickerManager unitPickerManager = new PickerManager() {

            @Override
            public void selected(int id) {
                switch (id) {
                    case 0:
                        Utils.currentGlucoseUnit = GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL;
                        break;
                    case 1:
                        Utils.currentGlucoseUnit = GLUCOSE_UNIT.GLUCOSE_UNIT_MMOL_L;
                        break;
                }
                String unitString = Utils
                        .getGlucoseUnitString(SystemSettingsActivity.this);
                rightTextView.setText(unitString);
                Utils.saveSettings(SystemSettingsActivity.this,
                        Utils.prefGlucoseUnit,
                        Utils.currentGlucoseUnit.ordinal());
            }
        };

        glucoseLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                if (dialog != null && dialog.isShowing())
                    dialog.dismiss();
                int position = Utils.currentGlucoseUnit.ordinal();
                dialog = dialogUtils.createPickerDialog(SystemSettingsActivity.this,
                        getResources().getString(R.string.glucose_unit),
                        unitValues, unitPickerManager, position);
                dialog.show();
            }
        });

        unitPickerManager.selected(Utils.currentGlucoseUnit.ordinal());
        glucoseLayout.setBackgroundColor(getResources().getColor(R.color.transparent));

        if (Utils.enableGlucoseUnitPanel == false) {
            glucoseLayout.setBackgroundColor(getResources().getColor(R.color.inactive_gray));
            glucoseLayout.setEnabled(false);
            glucoseTextView.setTextColor(getResources().getColor(R.color.light_gray));
            rightTextView.setTextColor(getResources().getColor(R.color.light_gray));
        }
        else {
            glucoseLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
            glucoseLayout.setEnabled(true);
            glucoseTextView.setTextColor(getResources().getColor(R.color.black));
            rightTextView.setTextColor(getResources().getColor(R.color.black));
        }

        content.addView(glucoseView);
    }

    private void addTransmitterNameView() {

        View view = (View) inflater.inflate(
                R.layout.settings_system_item_with_edittext, null);
        transmitterNameLayout = (LinearLayout) view.findViewById(R.id.content);

        transmitterNameEditText = (CustomEditText) view
                .findViewById(R.id.rightEditText);
        transmitterNameTextView = (TextView) view.findViewById(R.id.name);
        transmitterNameTextView.setText(getString(R.string.name));
        setBoldTextView(transmitterNameTextView);

        transmitterNameEditText
                .setOnEditTextImeBackListener(new EditTextImeBackListener() {

                    @Override
                    public void onImeBack(CustomEditText ctrl, String text) {
                        if (transmitterStateModel.getTransmitterName() != null)
                            transmitterNameEditText
                                    .setText(transmitterStateModel.getTransmitterName());
                        else
                            transmitterNameEditText
                                    .setText(Utils.unknownString);
                        // transmitterNameEdited();
                    }
                });

        transmitterNameEditText
                .setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                        | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        if (transmitterStateModel.getTransmitterName() != null)
            transmitterNameEditText.setText(transmitterStateModel.getTransmitterName());
        else
            transmitterNameEditText.setText(Utils.unknownString);

        transmitterNameEditText
                .setOnEditorActionListener(new OnEditorActionListener() {

                    public boolean onEditorAction(TextView v, int actionId,
                                                  KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {

                            InputMethodManager imm = (InputMethodManager) SystemSettingsActivity.this
                                    .getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.hideSoftInputFromWindow(
                                    v.getApplicationWindowToken(),
                                    InputMethodManager.HIDE_NOT_ALWAYS);

                            transmitterNameEdited();
                            return true;
                        }
                        return false;
                    }
                });

        content.addView(view);
    }

    private void transmitterNameEdited() {
        if (transmitterNameEditText != null) {
            String name = transmitterNameEditText.getText().toString();
            if (transmitterStateModel.getTransmitterConnectionState() == Transmitter.CONNECTION_STATE.CONNECTED
                    && name.replaceAll(" ", "").length() > 0) {
                progressDialog.show();
                Utils.transmitterNameContainer = null;
                getService().postWriteTransmitterNameRequest(name);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        progressDialog.dismiss();
                    }
                }, GraphUtils.MINUTE / 6);
                // send the PING request to get the new Name from the Transmitter after the Write
                getService().postPingRequest();
                progressDialog.dismiss();
            } else {
                if (transmitterStateModel.getTransmitterName() != null)
                    transmitterNameEditText.setText(transmitterStateModel.getTransmitterName());
            }
        }
    }

    private void addSensorSerialNumberView(String name) {

        View view = inflater.inflate(R.layout.settings_system_item, null);
        linkedSensorLayout = (RelativeLayout) view.findViewById(R.id.layout);

        sensorIdTextView = (TextView) view.findViewById(R.id.rightTextView);
        sensorIdTextView.setText(Objects.firstNonNull(transmitterStateModel.getLinkedSensorId(), Utils.unknownString));

        ImageView arrowImageView = (ImageView) view.findViewById(R.id.arrow);
        arrowImageView.setVisibility(View.VISIBLE);

        if (BluetoothUtils.mConnected) {

            linkedSensorLayout.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SystemSettingsActivity.this, SensorListActivity.class));
                }
            });
        } else {
            linkedSensorLayout.setOnClickListener(null);
        }
        linkedSensorTextView = (TextView) view.findViewById(R.id.name);
        linkedSensorTextView.setText(name);
        setBoldTextView(linkedSensorTextView);
        content.addView(view);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}
