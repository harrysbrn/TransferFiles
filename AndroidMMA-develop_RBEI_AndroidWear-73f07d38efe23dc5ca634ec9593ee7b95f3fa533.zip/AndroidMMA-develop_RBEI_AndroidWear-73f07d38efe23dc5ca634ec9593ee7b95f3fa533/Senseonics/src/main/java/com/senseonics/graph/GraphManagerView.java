package com.senseonics.graph;

import android.content.Context;
import android.widget.RelativeLayout;

import com.senseonics.gen12androidapp.R;
import com.senseonics.db.DatabaseManager;
import com.senseonics.events.EventPoint;
import com.senseonics.graph.events.GraphCacheEvent;
import com.senseonics.graph.util.Glucose;
import com.senseonics.util.IDestroyable;

import java.util.Calendar;
import java.util.Date;

import de.greenrobot.event.EventBus;

public class GraphManagerView extends RelativeLayout implements IDestroyable {

  private GraphManagerViewListener graphManagerViewListener = new GraphManagerViewListener() {
    @Override public void onDateChanged(Date date) {
    }

    @Override public void onGlucoseValuesRefreshed() {
    }
  };

  public interface GraphManagerViewListener {
    void onDateChanged(Date date);

    void onGlucoseValuesRefreshed();
  }

  private DateView dateView;
  private GraphView graphView;

  private GraphManager manager;
  private DatabaseManager databaseManager;

  public GraphManagerView(Context context, int screenWidth, int graphHeight, int graphPaddingTop,
      int daysCount, Calendar currentDate) {
    super(context);

    databaseManager = new DatabaseManager(context);
    databaseManager.open();

    // adding date and time view
    dateView = new DateView(context, screenWidth, graphPaddingTop);

    RelativeLayout.LayoutParams params =
        new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, graphPaddingTop);
    dateView.setLayoutParams(params);
    addView(dateView);

    dateView.setId(R.id.date_and_time);
    dateView.setClickable(true);
    dateView.setFocusable(true);
    dateView.setBackgroundResource(R.drawable.dateviewbackground);

    // adding the graph view
    graphView = new GraphView(context, 0, screenWidth, graphHeight - graphPaddingTop, daysCount,
        currentDate);
    RelativeLayout.LayoutParams params2 =
        new RelativeLayout.LayoutParams(screenWidth * 2, graphHeight);
    params2.leftMargin = 0;
    params2.addRule(RelativeLayout.BELOW, dateView.getId());
    graphView.setLayoutParams(params2);
    addView(graphView);
    graphView.setId(R.id.graph);
    graphView.setScrollManager(scrollManager);

    EventBus bus = EventBus.getDefault();
    bus.register(this);
  }

  @Override public void destroy() {
    EventBus bus = EventBus.getDefault();
    bus.unregister(this);
  }

  public void setCurrentVisibleDate(Calendar calendar) {
    graphView.selectDay(calendar);
  }

  public Calendar getCurrentVisibleDate() {
    if (graphView != null) return graphView.getCurrentVisibleDate();
    return null;
  }

  public void onPause() {
    graphView.hidePopUp();
  }

  public void onEventMainThread(GraphCacheEvent event) {
    if (event.newStartEndDates) {
      graphView.redrawGraphWithNewStartEndDates(event.glucoseValues, event.events);
    } else {
      graphView.redrawGraphWithExistingStartEndDates(event.glucoseValues, event.events);
      manager.dismissProgressDialog();
    }
  }

  public void setOnDateClickListener(OnClickListener listener) {
    dateView.setListener(listener);
  }

  public void setGraphManagerViewListener(GraphManagerViewListener listener) {
    graphManagerViewListener = listener;
  }

  GraphView.ScrollManager scrollManager = new GraphView.ScrollManager() {

    @Override public void dayChanged(Date day) {
      graphManagerViewListener.onDateChanged(day);
      dateView.setDate(day);
    }

    @Override public void dayChanged(Date fromDay, Date toDay) {
      graphManagerViewListener.onDateChanged(fromDay);
      dateView.setDate(fromDay, toDay);
    }

    @Override public void showEventPopUpTop(float x, EventPoint eventPoint) {
      manager.showEventPopUp(x, eventPoint);
    }

    @Override public void showGlucosePopUpTop(float x, Glucose glucose) {
      manager.showGlucosePopUp(x, glucose);
    }

    @Override public void showNoGlucoseReadingPopUp(float x) {
      manager.showNoGlucoseReadingPopUp(x);
    }

    @Override public void hideEventGlucosePopUpTop() {
      manager.hideEventGlucosePopUp();
    }

    @Override public void onEventSelected(EventPoint eventPoint) {
      manager.onEventSelected(eventPoint);
    }

    @Override public void refreshGlucoseData() {
      graphManagerViewListener.onGlucoseValuesRefreshed();
    }

    @Override public void tapAddNewEvent(Calendar calendar) {
      manager.tapAddNewEvent(calendar);
    }
  };

  public interface GraphManager {
    void showEventPopUp(float x, EventPoint eventPoint);

    void showGlucosePopUp(float x, Glucose glucose);

    void showNoGlucoseReadingPopUp(float x);

    void hideEventGlucosePopUp();

    void onEventSelected(EventPoint eventPoint);

    void tapAddNewEvent(Calendar calendar);

    void dismissProgressDialog();
  }

  public void setManager(GraphManager manager) {
    this.manager = manager;
  }
}
