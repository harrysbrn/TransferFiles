package com.senseonics.events;

public class ModelChangedRefreshGraphEvent {
    public ModelChangedRefreshGraphEvent() { }
}
