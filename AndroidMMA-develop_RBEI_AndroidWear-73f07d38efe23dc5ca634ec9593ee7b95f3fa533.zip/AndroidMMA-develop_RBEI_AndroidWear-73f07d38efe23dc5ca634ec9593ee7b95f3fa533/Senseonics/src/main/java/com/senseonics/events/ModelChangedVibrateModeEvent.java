package com.senseonics.events;

public class ModelChangedVibrateModeEvent {

    private boolean vibrateMode;

    public ModelChangedVibrateModeEvent(boolean vibrateMode) {
        this.vibrateMode = vibrateMode;
    }

    public boolean isVibrateMode() {
        return vibrateMode;
    }
}
