package com.senseonics.gen12androidapp;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.events.BluetoothServiceBoundEvent;
import com.senseonics.events.BluetoothServiceUnboundEvent;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

class BluetoothServiceConnection implements ServiceConnection {
  private boolean isConnected;
  private BluetoothService bluetoothService;
  private Semaphore haveServiceSemaphore = new Semaphore(0);
  private EventBus eventBus;

  @Inject public BluetoothServiceConnection(EventBus eventBus) {
    this.eventBus = eventBus;
  }

  @Override public void onServiceConnected(ComponentName className, IBinder service) {
    isConnected = true;
    bluetoothService = ((BluetoothService.BluetoothServiceBinder) service).getService();
    haveServiceSemaphore.release();
    eventBus.post(new BluetoothServiceBoundEvent());
  }

  @Override public void onServiceDisconnected(ComponentName arg0) {
    isConnected = false;
    eventBus.post(new BluetoothServiceUnboundEvent());
  }

  public boolean isConnected() {
    return isConnected;
  }

  @Nullable public BluetoothService getBluetoothService() {
    try {
      boolean didAcquire = haveServiceSemaphore.tryAcquire(50, TimeUnit.MILLISECONDS);
      if (didAcquire) {
        haveServiceSemaphore.release();
      } else {
        Log.w(BluetoothServiceConnection.class.getSimpleName(), "service will be returned as null");
      }
    } catch (InterruptedException e) {
      Log.w(BluetoothServiceConnection.class.getSimpleName(),
          "interrupted, for good or bad, returning service: " + bluetoothService);
    }
    return bluetoothService;
  }
}
