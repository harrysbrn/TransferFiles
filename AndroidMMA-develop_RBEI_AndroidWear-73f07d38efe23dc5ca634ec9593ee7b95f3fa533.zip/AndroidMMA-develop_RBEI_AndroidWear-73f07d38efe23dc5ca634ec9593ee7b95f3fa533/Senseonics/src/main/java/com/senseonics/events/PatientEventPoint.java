package com.senseonics.events;

public interface PatientEventPoint {
    int eventTypeId();
    int eventSubTypeId();
    int quantity();
    long getTimestamp();
}
