package com.senseonics.model;

import android.util.Log;

import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class ReadVibrateModeSingleByteMemoryMapParsedResponse implements SingleByteMemoryMapParsedResponse {

    @Inject
    public ReadVibrateModeSingleByteMemoryMapParsedResponse(){}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.vibrateMode;
    }

    @Override
    public void apply(int data, TransmitterStateModel model) {
        switch (data) {
            case 0x00:
                model.setVibrateMode(false);
                break;
            case 0x55:
                model.setVibrateMode(true);
                break;
        }
    }
}
