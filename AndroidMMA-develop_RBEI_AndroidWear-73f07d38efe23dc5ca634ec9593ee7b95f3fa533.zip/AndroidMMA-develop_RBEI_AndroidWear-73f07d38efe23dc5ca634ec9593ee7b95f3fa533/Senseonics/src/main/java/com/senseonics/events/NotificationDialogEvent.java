package com.senseonics.events;

import com.google.common.base.Objects;
import com.senseonics.util.Utils;

public class NotificationDialogEvent {
    private final EventPoint ep;
    private final Utils.TransmitterMessageCode transmitterMessageCode;

    public NotificationDialogEvent(EventPoint epIn, Utils.TransmitterMessageCode transmitterMessageCode) {
        this.ep = epIn;
        this.transmitterMessageCode = transmitterMessageCode;
    }

    public EventPoint getEventPoint() {
        return ep;
    }

    public Utils.TransmitterMessageCode getTransmitterMessageCode() {
        return transmitterMessageCode;
    }

    public int getNotificationId() {
        return transmitterMessageCode.notificationId();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NotificationDialogEvent)) return false;
        NotificationDialogEvent that = (NotificationDialogEvent) o;
        return Objects.equal(ep.getEventType(), that.ep.getEventType()) &&
                Objects.equal(transmitterMessageCode, that.transmitterMessageCode);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ep.getEventType(), transmitterMessageCode);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("eventType", ep.getEventType())
                .add("transmitterMessageCode", transmitterMessageCode)
                .toString();
    }
}
