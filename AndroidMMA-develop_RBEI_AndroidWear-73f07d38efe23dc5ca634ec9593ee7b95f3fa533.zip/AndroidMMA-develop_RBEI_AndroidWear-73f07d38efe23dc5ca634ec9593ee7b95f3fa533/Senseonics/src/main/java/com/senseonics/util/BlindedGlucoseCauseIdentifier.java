package com.senseonics.util;

import javax.inject.Inject;

public class BlindedGlucoseCauseIdentifier {

    @Inject
    public BlindedGlucoseCauseIdentifier() {}

    public boolean messageCodeCanBeReasonForBlindedGlucose(Utils.TransmitterMessageCode msgCode) {
        boolean currentMessageCanCauseBlindedGlucose = false;

        if (msgCode == Utils.TransmitterMessageCode.CalibrationGracePeriodAlarm
                || msgCode == Utils.TransmitterMessageCode.CalibrationExpiredAlarm
                || msgCode == Utils.TransmitterMessageCode.CriticalFaultAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorRetiredAlarm
                || msgCode == Utils.TransmitterMessageCode.HighAmbientLightAlarm
                || msgCode == Utils.TransmitterMessageCode.ReaderTemperatureAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorTemperatureAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorLowTemperatureAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorAwolAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorStablity
                || msgCode == Utils.TransmitterMessageCode.SeriouslyHighAlarm
                || msgCode == Utils.TransmitterMessageCode.SeriouslyLowAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorErrorAlarm
                || msgCode == Utils.TransmitterMessageCode.InvalidSensorAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorRetiringSoon7Alarm
                || msgCode == Utils.TransmitterMessageCode.EmptyBatteryAlarm
                || msgCode == Utils.TransmitterMessageCode.SensorOnHoldAlarm
                || msgCode == Utils.TransmitterMessageCode.MEPAlarm
                ) {
            currentMessageCanCauseBlindedGlucose = true;
        }

        return currentMessageCanCauseBlindedGlucose;
    }
}
