package com.senseonics.fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.gen12androidapp.DailyCalibrationActivity;
import com.senseonics.gen12androidapp.InitialDailyCalibrationActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.bluetoothle.BluetoothUtils;
import com.senseonics.bluetoothle.DialogUtils.TimeDialogManager;
import com.senseonics.events.ModelChangedCalibrationTimeEvent;
import com.senseonics.util.Utils;

import java.util.Calendar;
import java.util.TimeZone;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

public class DailyCalibrationFragment extends BaseFragment {

	private TextView textView, morningText, morningTextView, eveningText,
			eveningTextView;
	private int morningHour = 8, morningMinute = 0, 
			eveningHour = 19, eveningMinute = 0, 
			minDiffHour = 10, maxDiffHour = 14;
	private boolean settingsOk = true;
	private CalibrationManager calibrationManager;
	private RelativeLayout morningPicker, eveningPicker;
	private Dialog dialog;

	@Inject
	protected EventBus eventBus;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater,container, savedInstanceState);

		View view = inflater.inflate(R.layout.fragment_dailycalibration, container, false);

		textView = (TextView) view.findViewById(R.id.text);
		morningText = (TextView) view.findViewById(R.id.morningText);
		morningTextView = (TextView) view.findViewById(R.id.morningTime);
		eveningText = (TextView) view.findViewById(R.id.eveningText);
		eveningTextView = (TextView) view.findViewById(R.id.eveningTime);
		morningPicker = (RelativeLayout) view.findViewById(R.id.morningPicker);
		eveningPicker = (RelativeLayout) view.findViewById(R.id.eveningPicker);

        // show the title if it's initial setup
        if (getActivity() instanceof InitialDailyCalibrationActivity) {
            // Setup the text
            TextView title = (TextView)view.findViewById(R.id.dailyCalibrationTitle);
            title.setVisibility(View.VISIBLE);
            title.setText(title.getText().toString().toUpperCase());
        }

        // Set the action bar item for SAVE
        if(getActivity() instanceof DailyCalibrationActivity) {
            DailyCalibrationActivity act = (DailyCalibrationActivity) getActivity();
            act.setNaviBarRightItemTextViewOnClick(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (settingsOk == true) {
						final ProgressDialog progressDialog;

						boolean isInitial = (getActivity() instanceof InitialDailyCalibrationActivity);

						// Convert hour from local back to GMT
						int[] hourMinuteMorning = Utils.convertHourFromLocaltoGMT(morningHour, morningMinute);
                        int hour = hourMinuteMorning[0];
						int minute = hourMinuteMorning[1];
                        calibrationManager.onMorningCalibrationSelected(hour, minute, isInitial);
                        // #979
						int[] hourMinuteEvening = Utils.convertHourFromLocaltoGMT(eveningHour, eveningMinute);
						hour = hourMinuteEvening[0];
						minute = hourMinuteEvening[1];
                        calibrationManager.onEveningCalibrationSelected(hour, minute, isInitial);

                        if (isInitial) {
                            InitialDailyCalibrationActivity actInitial = (InitialDailyCalibrationActivity) getActivity();
                            actInitial.goToUnitSelection();
                        }
						else {
							progressDialog = new ProgressDialog(getActivity(), R.style.TransparentProgressDialogTheme);
							progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
							progressDialog.setCancelable(false);
							progressDialog.show();
							Handler handler = new Handler();
							handler.postDelayed(new Runnable() {
								public void run() {
									getActivity().setResult(Utils.DAILY_CALIBRATION_SAVE_RESULT);
									progressDialog.dismiss();
									getActivity().finish();
								}
							}, 3000);
						}

                    }
                }
            });
        }

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();

		eventBus.register(this);
        setBothCalibrationTimeToCurrentModelValue();
        updateViews();
	}

	@Override
	public void onPause() {
		eventBus.unregister(this);
		super.onPause();
	}

	public void onEventMainThread(ModelChangedCalibrationTimeEvent event) {
		setBothCalibrationTimeToCurrentModelValue();
	}

	public void updateViews() {

		if (getActivity() != null) {

			setMorningTime(transmitterStateModel.getMorningCalibrationTimeHour(), transmitterStateModel.getMorningCalibrationTimeMinute());
			setEveningTime(transmitterStateModel.getEveningCalibrationTimeHour(), transmitterStateModel.getEveningCalibrationTimeMinute());

			if (BluetoothUtils.mConnected) {
                if(getActivity() instanceof DailyCalibrationActivity) {
                    DailyCalibrationActivity act = (DailyCalibrationActivity) getActivity();
                    act.enableSaveButton();
                }
				
				morningPicker.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (dialog != null && dialog.isShowing())
							dialog.dismiss();
						dialog = dialogUtils.createTimePickerDialog(getActivity(),
								morningHour, morningMinute,
								getResources().getString(R.string.morning_time),
								morningTimeManager);
						dialog.show();
					}
				});
				eveningPicker.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (dialog != null && dialog.isShowing())
							dialog.dismiss();
						dialog = dialogUtils.createTimePickerDialog(getActivity(),
								eveningHour, eveningMinute,
								getResources().getString(R.string.evening_time),
								eveningTimeManager);
						dialog.show();
					}
				});

				morningPicker.setBackgroundColor(getResources().getColor(
						android.R.color.white));
				morningText
						.setTextColor(getResources().getColor(R.color.black));
				morningTextView.setTextColor(getResources().getColor(
						R.color.black));
				eveningPicker.setBackgroundColor(getResources().getColor(
						android.R.color.white));
				eveningText
						.setTextColor(getResources().getColor(R.color.black));
				eveningTextView.setTextColor(getResources().getColor(
						R.color.black));
			} else {
                if(getActivity() instanceof DailyCalibrationActivity) {
                    DailyCalibrationActivity act = (DailyCalibrationActivity) getActivity();
                    act.disableSaveButton();
                }

				morningPicker.setOnClickListener(null);
				morningPicker.setBackgroundColor(getResources().getColor(
						R.color.inactive_gray));
				morningText.setTextColor(getResources().getColor(
						R.color.gray_darker));
				morningTextView.setTextColor(getResources().getColor(
						R.color.light_gray));
				eveningPicker.setOnClickListener(null);
				eveningPicker.setBackgroundColor(getResources().getColor(
						R.color.inactive_gray));
				eveningText.setTextColor(getResources().getColor(
						R.color.gray_darker));
				eveningTextView.setTextColor(getResources().getColor(
						R.color.light_gray));

			}
		}
	}

	public void setBothCalibrationTimeToCurrentModelValue() {
		setMorningTime(transmitterStateModel.getMorningCalibrationTimeHour(), transmitterStateModel.getMorningCalibrationTimeMinute());
		setEveningTime(transmitterStateModel.getEveningCalibrationTimeHour(), transmitterStateModel.getEveningCalibrationTimeMinute());
	}

	private boolean checkSettings(int morningHour, int eveningHour) {
		int hourDiff = eveningHour - morningHour;

		if (Math.abs(hourDiff) < minDiffHour
				|| Math.abs(hourDiff) > maxDiffHour)
			return false;
		return true;
	}

	private void updateText() {
		DailyCalibrationActivity act = (DailyCalibrationActivity) getActivity();

		if (settingsOk) {
			textView.setTextColor(getResources().getColor(R.color.black));
			textView.setText(getString(R.string.set_calibration_time_text));
			act.enableSaveButton();
		} else {
			textView.setTextColor(getResources().getColor(R.color.red_light));
			textView.setText(getString(R.string.modify_evening_time));
			act.disableSaveButton();
		}
	}

	private void setMorningTimeTextView(int hour, int minute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		if (morningTextView != null)
		{
			morningTextView.setText(Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getActivity()));
		}
	}

	private void setEveningTimeTextView(int hour, int minute) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);

		if (eveningTextView != null)
		{
			eveningTextView.setText(Utils.getTime24HrFormat(calendar, TimeZone.getDefault(), getActivity()));
		}
	}

	// the input hour is in GMT time
	private void setMorningTime(int hour, int minute) {
		if (hour >= 0 && minute >= 0) {
			// Convert hour from GMT back to local
			int[] hourMinute = Utils.convertHourFromGMTtoLocal(hour, minute);
			hour = hourMinute[0];
			minute = hourMinute[1];

			morningHour = hour;
			morningMinute = minute;
			setMorningTimeTextView(hour, minute);
		}
		else if (morningTextView != null)
		{
			morningTextView.setText(Utils.unknownTime);
		}
	}

	// the input hour is in GMT time
	private void setEveningTime(int hour, int minute) {
		if (hour >= 0 && minute >= 0) {
			// Convert hour from GMT back to local
			int[] hourMinute = Utils.convertHourFromGMTtoLocal(hour, minute);
			hour = hourMinute[0];
			minute = hourMinute[1];

			eveningHour = hour;
			eveningMinute = minute;
			setEveningTimeTextView(hour, minute);
		}
		else if (eveningTextView != null)
		{
			eveningTextView.setText(Utils.unknownTime);
		}
	}

	TimeDialogManager morningTimeManager = new TimeDialogManager() {

		@Override
		public void onTimeSelected(Integer hour, Integer minute) {
			settingsOk = checkSettings(hour, eveningHour);
			updateText();
			calibrationManager.settingsOk(settingsOk);

			// #979
			morningHour = hour;
			morningMinute = minute;
			setMorningTimeTextView(hour, minute);
		}
	};

	TimeDialogManager eveningTimeManager = new TimeDialogManager() {

		@Override
		public void onTimeSelected(Integer hour, Integer minute) {
			settingsOk = checkSettings(morningHour, hour);
			updateText();
			calibrationManager.settingsOk(settingsOk);

			// #979
			eveningHour = hour;
			eveningMinute = minute;
			setEveningTimeTextView(hour, minute);
		}
	};

	public interface CalibrationManager {
		void settingsOk(boolean value);

		void onMorningCalibrationSelected(int hour, int minute, boolean isInitial);

		void onEveningCalibrationSelected(int hour, int minute, boolean isInitial);
	}

	public void setCalibrationManager(CalibrationManager manager) {
		this.calibrationManager = manager;
	}

}
