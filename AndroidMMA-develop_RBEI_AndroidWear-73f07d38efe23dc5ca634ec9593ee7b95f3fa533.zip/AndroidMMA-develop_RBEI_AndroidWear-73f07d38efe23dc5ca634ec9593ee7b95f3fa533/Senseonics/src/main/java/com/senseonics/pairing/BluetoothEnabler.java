package com.senseonics.pairing;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton public class BluetoothEnabler {
  private Activity context;
  private BluetoothAdapter adapter;

  @Inject public BluetoothEnabler(Activity context, BluetoothAdapter adapter) {
    this.context = context;
    this.adapter = adapter;
  }

  public void requestToEnableIfDisabled() {
    if (adapter != null && !adapter.isEnabled()) {
      Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
      context.startActivityForResult(enableBtIntent, 2000);
    }
  }

  public boolean isEnabled() {
    boolean isEnabled = false;
    if (adapter != null && adapter.isEnabled()) {
      isEnabled = true;
    }
    return isEnabled;
  }
}
