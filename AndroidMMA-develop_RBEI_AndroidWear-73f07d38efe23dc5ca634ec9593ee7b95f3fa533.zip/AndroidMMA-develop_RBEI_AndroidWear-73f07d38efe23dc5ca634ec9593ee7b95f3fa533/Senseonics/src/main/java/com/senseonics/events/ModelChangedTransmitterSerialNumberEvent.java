package com.senseonics.events;

public class ModelChangedTransmitterSerialNumberEvent {
    private String transmitterSerialNo;

    public ModelChangedTransmitterSerialNumberEvent(String transmitterSerialNo){
        this.transmitterSerialNo = transmitterSerialNo;
    }

    public String getTransmitterSerialNo() {
        return transmitterSerialNo;
    }
}
