package com.senseonics.util;

import com.senseonics.bluetoothle.DialogUtils;

import java.util.ArrayList;
import java.util.Locale;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ThresholdsController {
    private final int incValue = 5;
    private final float incValueMmol = 0.1f;

    // #2964 Broaden Target/Alarm ranges based on the input provided (Android)
    /** mg/dL Ranges */
    private final int targetHighMin = 120;
    private final int targetHighMax = 350;
    private final int targetLowMin = 65;
    private final int targetLowMax = 120;
    private final int alarmHighMin = 125;
    private final int alarmHighMax = 350;
    private final int alarmLowMin = 60;
    private final int alarmLowMax = 115;

    /** mmol/L Ranges */
    private final float targetHighMinMMOL = 6.7f;
    private final float targetHighMaxMMOL = 19.4f;
    private final float targetLowMinMMOL = 3.6f;
    private final float targetLowMaxMMOL = 6.7f;
    private final float alarmHighMinMMOL = 6.9f;
    private final float alarmHighMaxMMOL = 19.4f;
    private final float alarmLowMinMMOL = 3.3f;
    private final float alarmLowMaxMMOL = 6.4f;

    private DialogUtils dialogUtils;

    @Inject
    public ThresholdsController(DialogUtils dialogUtils) {
        this.dialogUtils = dialogUtils;
    }

    public int getPosition(int glucoseValue, ArrayList<Item> values) {
        int position;
        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL)
            position = Utils.getItemPosition(values, glucoseValue);
        else
            position = Utils.getItemPosition(values,
                    String.format(Locale.US, "%.1f", Convert.MLConvertMgToMmol(glucoseValue)));
        return position;
    }

    public ArrayList<Item> getTargetHighValues(int lowTarget, int highAlarm) {
        ArrayList<Item> values;

        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            int lowerLimit = targetHighMin;
            if (lowTarget >= lowerLimit)
                lowerLimit = lowTarget + incValue;
            int higherLimit = targetHighMax;
            if (highAlarm <= higherLimit)
                higherLimit = highAlarm - incValue;
            values = dialogUtils.getNumbersBetween(lowerLimit, higherLimit,
                    incValue);
        }
        else
        {
            float glucoseAlarmLevelHigh = Convert.MLConvertMgToMmol(highAlarm);
            float glucoseTargetLow = Convert.MLConvertMgToMmol(lowTarget);
            glucoseAlarmLevelHigh = (float)Math.round(glucoseAlarmLevelHigh * 10) / 10;
            glucoseTargetLow = (float)Math.round(glucoseTargetLow * 10) / 10;

            float lowerLimitMMOL = targetHighMinMMOL;
            float higherLimitMMOL = targetHighMaxMMOL;

            if (glucoseTargetLow >= lowerLimitMMOL)
                lowerLimitMMOL = glucoseTargetLow + incValueMmol;
            if (glucoseAlarmLevelHigh <= higherLimitMMOL)
                higherLimitMMOL = glucoseAlarmLevelHigh - incValueMmol;
            values = dialogUtils.getGlucoseLevels(lowerLimitMMOL, higherLimitMMOL, incValueMmol);
        }

        return values;
    }

    public ArrayList<Item> getTargetLowValues(int highTarget, int lowAlarm) {
        ArrayList<Item> values;

        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            int lowerLimit = targetLowMin;
            if (lowAlarm >= lowerLimit)
                lowerLimit = lowAlarm + incValue;
            int higherLimit = targetLowMax;
            if (highTarget <= higherLimit)
                higherLimit = highTarget - incValue;
            values = dialogUtils.getNumbersBetween(lowerLimit, higherLimit,
                    incValue);
        }
        else
        {
            float glucoseAlarmLevelLow = Convert.MLConvertMgToMmol(lowAlarm);
            float glucoseTargetHigh = Convert.MLConvertMgToMmol(highTarget);
            glucoseAlarmLevelLow = (float)Math.round(glucoseAlarmLevelLow * 10) / 10;
            glucoseTargetHigh = (float)Math.round(glucoseTargetHigh * 10) / 10;

            float lowerLimitMMOL = targetLowMinMMOL;
            float higherLimitMMOL = targetLowMaxMMOL;
            if (glucoseAlarmLevelLow>= lowerLimitMMOL)
                lowerLimitMMOL = glucoseAlarmLevelLow + incValueMmol;
            if (glucoseTargetHigh <= higherLimitMMOL)
                higherLimitMMOL = glucoseTargetHigh - incValueMmol;
            values = dialogUtils.getGlucoseLevels(lowerLimitMMOL, higherLimitMMOL, incValueMmol);
        }

        return values;
    }

    public ArrayList<Item> getAlarmHighValues(int highTarget) {
        ArrayList<Item> values;

        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            int lowerLimit = alarmHighMin;
            if (highTarget >= lowerLimit)
                lowerLimit = highTarget + incValue;

            values = dialogUtils.getGlucoseLevels(lowerLimit, alarmHighMax,
                    incValue);
        }
        else
        {
            float glucoseTargetHigh = Convert.MLConvertMgToMmol(highTarget);
            glucoseTargetHigh = (float)Math.round(glucoseTargetHigh * 10) / 10;

            float lowerLimitMMOL = alarmHighMinMMOL;
            if (glucoseTargetHigh >= lowerLimitMMOL)
                lowerLimitMMOL = glucoseTargetHigh + incValueMmol;

            values = dialogUtils.getGlucoseLevels(lowerLimitMMOL, alarmHighMaxMMOL,
                    incValue);
        }

        return values;
    }

    public ArrayList<Item> getAlarmLowValues(int lowTarget) {
        ArrayList<Item> values;

        if (Utils.currentGlucoseUnit == Utils.GLUCOSE_UNIT.GLUCOSE_UNIT_MG_DL) {
            int higherLimit = alarmLowMax;
            if (lowTarget <= higherLimit)
                higherLimit = lowTarget - incValue;
            values = dialogUtils.getGlucoseLevels(alarmLowMin, higherLimit,
                    incValue);
        }
        else
        {
            float glucoseTargetLow = Convert.MLConvertMgToMmol(lowTarget);
            glucoseTargetLow = (float)Math.round(glucoseTargetLow * 10) / 10;

            float higherLimit = alarmLowMaxMMOL;

            if (glucoseTargetLow  <= higherLimit)
                higherLimit = glucoseTargetLow - 0.1f;
            values = dialogUtils.getGlucoseLevels(alarmLowMinMMOL, higherLimit,
                    0.1f);
        }

        return values;
    }

    /** #3789 */
    public int getTargetHighWithRangeChecked(int value) {
        return getGlucoseValueInRange(value, targetHighMin, targetHighMax);
    }

    public int getTargetLowWithRangeChecked(int value) {
        return getGlucoseValueInRange(value, targetLowMin, targetLowMax);
    }

    public int getAlarmHighWithRangeChecked(int value) {
        return getGlucoseValueInRange(value, alarmHighMin, alarmHighMax);
    }

    public int getAlarmLowWithRangeChecked(int value) {
        return getGlucoseValueInRange(value, alarmLowMin, alarmLowMax);
    }

    private int getGlucoseValueInRange(int value, int min, int max) {
        if (value < min) {
            value = min;
        } else if (value > max) {
            value = max;
        }

        return value;
    }

}
