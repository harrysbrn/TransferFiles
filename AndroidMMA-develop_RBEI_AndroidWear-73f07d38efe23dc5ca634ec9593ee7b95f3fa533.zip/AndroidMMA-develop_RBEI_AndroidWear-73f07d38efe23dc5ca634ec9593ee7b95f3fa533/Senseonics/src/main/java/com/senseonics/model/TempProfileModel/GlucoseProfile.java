package com.senseonics.model.TempProfileModel;

public class GlucoseProfile { /** #3160 */
    public static final int TEMP_PROFILE_THRESHOLD_INIT_VALUE = 0;

    private int TargetHigh;
    private int TargetLow;
    private int AlarmHigh;
    private int AlarmLow;

    private boolean UsedAtLeastOnce_TargetHigh;
    private boolean UsedAtLeastOnce_TargetLow;
    private boolean UsedAtLeastOnce_AlarmHigh;
    private boolean UsedAtLeastOnce_AlarmLow;

    public GlucoseProfile() {
        initAllThresholds();
    }

    public void initAllThresholds() {
        setTargetHigh(TEMP_PROFILE_THRESHOLD_INIT_VALUE);
        setTargetLow(TEMP_PROFILE_THRESHOLD_INIT_VALUE);
        setAlarmHigh(TEMP_PROFILE_THRESHOLD_INIT_VALUE);
        setAlarmLow(TEMP_PROFILE_THRESHOLD_INIT_VALUE);

        setUsedAtLeastOnce_TargetHigh(false);
        setUsedAtLeastOnce_TargetLow(false);
        setUsedAtLeastOnce_AlarmHigh(false);
        setUsedAtLeastOnce_AlarmLow(false);
    }

    public boolean hasInitialValues() {
        if ((TargetHigh == TEMP_PROFILE_THRESHOLD_INIT_VALUE) &&
                (TargetLow == TEMP_PROFILE_THRESHOLD_INIT_VALUE) &&
                (AlarmHigh == TEMP_PROFILE_THRESHOLD_INIT_VALUE) &&
                (AlarmLow == TEMP_PROFILE_THRESHOLD_INIT_VALUE))
        {
            return true;
        }

        return false;
    }

    @Override
    public String toString() {
        return "{ Target High:" + TargetHigh + " (" + UsedAtLeastOnce_TargetHigh +
                ") ; Target Low:" + TargetLow + " (" + UsedAtLeastOnce_TargetLow +
                ") ; Alarm High:" + AlarmHigh + " (" + UsedAtLeastOnce_AlarmHigh +
                ") ; Alarm Low:" + AlarmLow + " (" + UsedAtLeastOnce_AlarmLow + ") }";
    }

    public int getAlarmHigh() {
        return AlarmHigh;
    }

    public void setAlarmHigh(int alarmHigh) {
        AlarmHigh = alarmHigh;
    }

    public int getAlarmLow() {
        return AlarmLow;
    }

    public void setAlarmLow(int alarmLow) {
        AlarmLow = alarmLow;
    }

    public int getTargetHigh() {
        return TargetHigh;
    }

    public void setTargetHigh(int targetHigh) {
        TargetHigh = targetHigh;
    }

    public int getTargetLow() {
        return TargetLow;
    }

    public void setTargetLow(int targetLow) {
        TargetLow = targetLow;
    }

    public boolean isUsedAtLeastOnce_AlarmHigh() {
        return UsedAtLeastOnce_AlarmHigh;
    }

    public void setUsedAtLeastOnce_AlarmHigh(boolean usedAtLeastOnce_AlarmHigh) {
        UsedAtLeastOnce_AlarmHigh = usedAtLeastOnce_AlarmHigh;
    }

    public boolean isUsedAtLeastOnce_AlarmLow() {
        return UsedAtLeastOnce_AlarmLow;
    }

    public void setUsedAtLeastOnce_AlarmLow(boolean usedAtLeastOnce_AlarmLow) {
        UsedAtLeastOnce_AlarmLow = usedAtLeastOnce_AlarmLow;
    }

    public boolean isUsedAtLeastOnce_TargetHigh() {
        return UsedAtLeastOnce_TargetHigh;
    }

    public void setUsedAtLeastOnce_TargetHigh(boolean usedAtLeastOnce_TargetHigh) {
        UsedAtLeastOnce_TargetHigh = usedAtLeastOnce_TargetHigh;
    }

    public boolean isUsedAtLeastOnce_TargetLow() {
        return UsedAtLeastOnce_TargetLow;
    }

    public void setUsedAtLeastOnce_TargetLow(boolean usedAtLeastOnce_TargetLow) {
        UsedAtLeastOnce_TargetLow = usedAtLeastOnce_TargetLow;
    }
}
