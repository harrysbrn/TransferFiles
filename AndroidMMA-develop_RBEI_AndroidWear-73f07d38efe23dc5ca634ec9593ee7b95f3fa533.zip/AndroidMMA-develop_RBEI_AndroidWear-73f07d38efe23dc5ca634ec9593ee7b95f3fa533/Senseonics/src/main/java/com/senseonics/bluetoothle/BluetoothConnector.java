package com.senseonics.bluetoothle;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
class BluetoothConnector {
    BluetoothGatt gatt = null;
    String transmitterAddress;
    private final Handler handler;

    @Inject
    public BluetoothConnector(Handler handler) {
        this.handler = handler;
    }

    void beginConnection(final BluetoothDevice bluetoothDevice, final BluetoothGattCallback bluetoothGattCallback, final Context context) {
        if (gatt != null) {
            Log.d(BluetoothConnector.class.getSimpleName(), "&&&&& gatt:" + gatt);
            gatt.disconnect();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.d(BluetoothConnector.class.getSimpleName(), "&&&&& CLOSE gatt before beginConnection &&&&&");
                    gatt.close();
                    gatt = null;
                    bleDeviceConnectGatt(bluetoothDevice, bluetoothGattCallback, context);
                }
            });
        }
        else {
            bleDeviceConnectGatt(bluetoothDevice, bluetoothGattCallback, context);
        }
    }

    private void bleDeviceConnectGatt(BluetoothDevice bluetoothDevice, BluetoothGattCallback bluetoothGattCallback, Context context) {
        Log.i(BluetoothConnector.class.getSimpleName(), "calling connectGatt with bondstate " + bluetoothDevice.getBondState() + " on device named " + bluetoothDevice.getName() + " with context " + context.getPackageName() + " thread:" + Thread.currentThread().getName());
        gatt = bluetoothDevice.connectGatt(context, true, bluetoothGattCallback);
        transmitterAddress = bluetoothDevice.getAddress();
    }

    void onReceive(Context context, Intent intent) {
        int bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, Integer.MAX_VALUE);
        BluetoothDevice bondingDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        //if (gatt != null) {
        if (bondingDevice.getAddress().equals(transmitterAddress)) {
            Log.i(BluetoothConnector.class.getSimpleName(), "bond state changed " + bondState + " named " + bondingDevice.getName() + ":" + bondingDevice.getAddress());

            Log.d(BluetoothConnector.class.getSimpleName(), "****** SHOULD I DISCOVER SERVICE??? DO NOT ******");

//            if (bondState == BluetoothDevice.BOND_BONDED) {
//                handler.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        gatt.discoverServices();
//                    }
//                }, LET_BLUETOOTH_CATCH_ITS_BREATH_BETWEEN_CONNECT_AND_DISCOVER);
//            }
        } else {
            Log.i(BluetoothConnector.class.getSimpleName(), "no gatt, bond state changed " + bondState + " named " + bondingDevice.getName() + ":" + bondingDevice.getAddress());
        }
    }
}
