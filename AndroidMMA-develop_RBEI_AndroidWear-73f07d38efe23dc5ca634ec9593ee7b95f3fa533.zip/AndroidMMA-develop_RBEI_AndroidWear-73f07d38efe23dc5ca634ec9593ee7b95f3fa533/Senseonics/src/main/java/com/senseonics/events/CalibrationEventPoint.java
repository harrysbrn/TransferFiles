package com.senseonics.events;

import java.util.Calendar;
import com.senseonics.util.Utils.EVENT_TYPE;

public class CalibrationEventPoint extends EventPoint {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private boolean calibrationUsed=false;

	public CalibrationEventPoint(Calendar calendar, int glucoseLevel, boolean calibrationUsed) {
		super(calendar, glucoseLevel);
		setEventType(EVENT_TYPE.CALIBRATION);
		setCalibrationUsed(calibrationUsed);
	}

	public CalibrationEventPoint(Calendar calendar, int glucoseLevel, boolean calibrationUsed, String notes) {
		this(calendar, glucoseLevel, calibrationUsed);
		setNotes(notes); /** APPDEV-4032 */
	}

	public CalibrationEventPoint(int databaseId, Calendar calendar,
			int glucoseLevel, boolean calibrationUsed, String notes) {
		super(databaseId, calendar, glucoseLevel);
		setEventType(EVENT_TYPE.CALIBRATION);
		setCalibrationUsed(calibrationUsed);
		setNotes(notes); /** APPDEV-4032 */
	}

	public boolean isCalibrationUsed() {
		return calibrationUsed;
	}

	public void setCalibrationUsed(boolean calibrationUsed) {
		this.calibrationUsed = calibrationUsed;
	}
}
