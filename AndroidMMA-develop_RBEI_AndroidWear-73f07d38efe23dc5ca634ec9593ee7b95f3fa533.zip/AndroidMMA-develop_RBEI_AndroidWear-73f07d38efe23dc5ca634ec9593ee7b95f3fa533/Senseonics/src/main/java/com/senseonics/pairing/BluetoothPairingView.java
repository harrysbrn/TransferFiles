package com.senseonics.pairing;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.senseonics.bluetoothle.Transmitter;
import com.senseonics.gen12androidapp.BluetoothPairBaseActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.pairing.events.view.TransmitterPressed;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

import static com.senseonics.gen12androidapp.Constants.IS_FIRST_RUN;
import static com.senseonics.gen12androidapp.Constants.REFRESH_BUTTON;

@Singleton
public class BluetoothPairingView extends RelativeLayout {
    private final BluetoothTransmitterAdapter adapter;
    private final Activity activity;
    private Context context;
    private ImageButton refreshButton;
    @BindView(R.id.listView)
    ListView listView;
    @BindView(R.id.tips)
    LinearLayout connectLayout;
    @BindView(R.id.arrowTips)
    ImageView arrowConnect;
    @BindView(R.id.tipsText)
    TextView tipsTextView;
    @BindView(R.id.tipsTextLayout)
    LinearLayout connectTextViewLayout;
    @BindView(R.id.pairTitle)
    TextView pairTitleTextView;
    @BindString(R.string.tips_connect_html_text_initial)
    String connectHtmlInitialText;
    @BindString(R.string.tips_connect_html_text)
    String connectHtmlText;
    private EventBus bus;

    @Inject
    public BluetoothPairingView(Context context, final EventBus bus,
                                final BluetoothTransmitterAdapter adapter,
                                @Named(REFRESH_BUTTON) ImageButton refreshButton,
                                @Named(IS_FIRST_RUN) boolean isFirstRun, Activity activity) {
        super(context);
        this.activity = activity;
        inflate(context, R.layout.fragment_bluetoothpairing, this);
        ButterKnife.bind(this);

        this.context = context;
        this.bus = bus;
        this.adapter = adapter;
        this.refreshButton = refreshButton;

        checkPermissionsIfNeeded();

        refreshButton.setVisibility(VISIBLE);
        refreshButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionsIfNeeded();
            }
        });

        listView.setAdapter(adapter);
        listView.addFooterView(new View(context), null, false);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {
                bus.post(new TransmitterPressed((Transmitter) adapter.getItem(position)));
            }
        });

        initBottomLayout(isFirstRun);
    }

    private void checkPermissionsIfNeeded() {
        ((BluetoothPairBaseActivity) activity).checkPermissionsIfNeeded();
    }

    public void beginRefreshButtonAnimation() {
        Animation animation = AnimationUtils.loadAnimation(context, R.anim.rotate_infinitely);
        refreshButton.setVisibility(VISIBLE);
        refreshButton.startAnimation(animation);
        refreshButton.setEnabled(false);
    }

    public void stopRefreshButtonAnimation() {
        refreshButton.clearAnimation();
        refreshButton.setEnabled(true);
    }

    public void setDevices(List<Transmitter> devices) {
        adapter.setDevices(devices);
    }

    public void refreshList() {
        adapter.refreshList();
    }

    private void initBottomLayout(boolean isFirstRun) {
        String tipsText;
        if (isFirstRun) {
            pairTitleTextView.setVisibility(View.VISIBLE);
            tipsText = connectHtmlInitialText;
        } else {
            pairTitleTextView.setVisibility(View.GONE);
            tipsText = connectHtmlText;
        }
        tipsTextView.setText(tipsText);
        connectLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (connectTextViewLayout.getVisibility() == VISIBLE) {
                    arrowConnect.setImageResource(R.drawable.icon_tips_arrow);
                    connectTextViewLayout.setVisibility(View.GONE);
                } else {
                    arrowConnect.setImageResource(R.drawable.icon_tips_arrow_down);
                    connectTextViewLayout.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}
