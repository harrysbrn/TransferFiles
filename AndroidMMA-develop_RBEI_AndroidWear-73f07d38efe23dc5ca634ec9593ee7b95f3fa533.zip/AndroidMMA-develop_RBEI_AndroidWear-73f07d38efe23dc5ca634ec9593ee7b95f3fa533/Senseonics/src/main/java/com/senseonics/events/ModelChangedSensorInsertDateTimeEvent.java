package com.senseonics.events;

import java.util.Calendar;

public class ModelChangedSensorInsertDateTimeEvent {
    private Calendar sensorInsertionDateTime;

    public ModelChangedSensorInsertDateTimeEvent(Calendar sensorInsertionDateTime){
        this.sensorInsertionDateTime = sensorInsertionDateTime;
    }

    public Calendar getSensorInsertionDateTime() {
        return sensorInsertionDateTime;
    }
}
