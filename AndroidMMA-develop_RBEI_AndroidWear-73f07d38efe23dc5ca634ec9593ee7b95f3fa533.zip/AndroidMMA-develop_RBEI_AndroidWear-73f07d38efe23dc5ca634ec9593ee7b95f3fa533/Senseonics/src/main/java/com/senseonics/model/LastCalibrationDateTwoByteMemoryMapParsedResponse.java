package com.senseonics.model;

import com.senseonics.bluetoothle.BinaryOperations;
import com.senseonics.bluetoothle.MemoryMap;

import javax.inject.Inject;

public class LastCalibrationDateTwoByteMemoryMapParsedResponse implements TwoByteMemoryMapParsedResponse {
    @Inject
    public LastCalibrationDateTwoByteMemoryMapParsedResponse() {}

    @Override
    public int[] getMemoryAddress() {
        return MemoryMap.mostRecentCalibrationDateAddress;
    }

    @Override
    public void apply(int dataOne, int dataTwo, TransmitterStateModel model) {
        int[] date = BinaryOperations.calculateDateFromBytes(new int[]{dataOne, dataTwo});
        model.setlastCalibrationDateOnly(date);
    }
}
