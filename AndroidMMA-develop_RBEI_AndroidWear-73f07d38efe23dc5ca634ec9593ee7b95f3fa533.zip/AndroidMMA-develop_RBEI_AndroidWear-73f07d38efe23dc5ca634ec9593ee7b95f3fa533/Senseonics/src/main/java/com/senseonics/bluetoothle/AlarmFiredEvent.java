package com.senseonics.bluetoothle;

public class AlarmFiredEvent {
}
