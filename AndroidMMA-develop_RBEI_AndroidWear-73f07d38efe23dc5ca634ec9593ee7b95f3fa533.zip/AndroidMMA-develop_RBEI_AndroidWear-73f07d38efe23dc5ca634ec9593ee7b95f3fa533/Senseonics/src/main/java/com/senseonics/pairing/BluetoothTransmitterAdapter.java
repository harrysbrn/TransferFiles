package com.senseonics.pairing;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.senseonics.bluetoothle.Transmitter;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;

@Singleton public class BluetoothTransmitterAdapter extends BaseAdapter {
  private Provider<BluetoothTransmitterCell> deviceCellProvider;
  private List<Transmitter> devices = new ArrayList<>();

  @Inject public BluetoothTransmitterAdapter(Provider<BluetoothTransmitterCell> deviceCellProvider) {
    this.deviceCellProvider = deviceCellProvider;
  }

  public void setDevices(List<Transmitter> devices) {
    this.devices = devices;
    notifyDataSetChanged();
  }

  public void refreshList() {
    notifyDataSetChanged();
  }

  @Override public int getCount() {
    return devices.size();
  }

  @Override public Object getItem(int position) {
    return devices.get(position);
  }

  @Override public long getItemId(int position) {
    return position;
  }

  @Override public View getView(int position, View view, ViewGroup viewGroup) {
    BluetoothTransmitterCell cell;
    if (view == null) {
      cell = deviceCellProvider.get();
    } else {
      cell = (BluetoothTransmitterCell) view;
    }
    Transmitter transmitter = (Transmitter) getItem(position);
    cell.refresh(transmitter);
    return cell;
  }
}
