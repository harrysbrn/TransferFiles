package com.senseonics.gen12androidapp;

import android.content.Context;
import android.content.Intent;

import com.senseonics.bluetoothle.BluetoothService;
import com.senseonics.bluetoothle.CommandProcessor;
import com.senseonics.bluetoothle.TransmitterSyncRequest;
import com.senseonics.events.GlucoseEventPoint;
import com.senseonics.events.PatientEventPoint;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class BluetoothServiceCommandClient {
    private final Context context;

    @Inject
    public BluetoothServiceCommandClient(Context context) {
        this.context = context;
    }

    public void postReadClinicalModeDuration() {
        context.startService(gimmeAnIntent(CommandProcessor.COMMAND.READ_CLINCAL_MODE_DURATION));
    }

    public void postSnooze(int messageCode) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.SNOOZE);
        intent.putExtra(CommandProcessor.PUSH_NOTIFICATION_MESSAGE_CODE, messageCode);
        context.startService(intent);
    }

    public void postWriteGlucoseEvent(GlucoseEventPoint glucoseEventPoint) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_GLUCOSE_EVENT_POINT);
        intent.putExtra(CommandProcessor.MILLIS, glucoseEventPoint.getTimestamp());
        intent.putExtra(CommandProcessor.GLUCOSE_LEVEL, glucoseEventPoint.getGlucoseLevel());
        context.startService(intent);
    }

    public void postWritePatientEvent(PatientEventPoint patientEventPoint) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_PATIENT_EVENT_POINT);
        intent.putExtra(CommandProcessor.EVENT_QUANTITY, patientEventPoint.quantity());
        intent.putExtra(CommandProcessor.EVENT_SUB_TYPE_ID, patientEventPoint.eventSubTypeId());
        intent.putExtra(CommandProcessor.EVENT_TYPE_ID, patientEventPoint.eventTypeId());
        intent.putExtra(CommandProcessor.MILLIS, patientEventPoint.getTimestamp());
        context.startService(intent);
    }

    public void postWriteClinicalModeRequest(boolean isClinicalMode) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_CLINICAL_MODE);
        intent.putExtra(CommandProcessor.IS_CLINICAL_MODE, isClinicalMode);
        context.startService(intent);
    }

    public void postMarkPatientEventDeleted(long recordNumber) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.MARK_PATIENT_EVENT_RECORD_DELETED);
        intent.putExtra(CommandProcessor.RECORD_NUMBER, recordNumber);
        context.startService(intent);
    }

    public void postSync(TransmitterSyncRequest transmitterSyncRequest) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.SYNC);
        intent.putExtra(CommandProcessor.EXPECTED_RESPONSE_ID, transmitterSyncRequest.getExpectedResponseId());
        intent.putExtra(CommandProcessor.DATA, transmitterSyncRequest.getData());
        intent.putExtra(CommandProcessor.RECORD_NUMBER, transmitterSyncRequest.getHighestExpectedRecordNumber());
        intent.putExtra(CommandProcessor.EXPECTED_RESPONSE_COUNT, transmitterSyncRequest.getExpectResponseCount());
        context.startService(intent);

    }

    public void postReadGlucoseData() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_GLUCOSE_DATA);
        context.startService(intent);
    }

    /** #3194 */
    public void postReadRawDataValues() {
        postReadRawDataValue1();
        postReadRawDataValue2();
        postReadRawDataValue3();
        postReadRawDataValue4();
        postReadRawDataValue5();
        postReadRawDataValue6();
        postReadRawDataValue7();
        postReadRawDataValue8();
    }

    private void postReadRawDataValue1() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_1);
        context.startService(intent);
    }

    private void postReadRawDataValue2() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_2);
        context.startService(intent);
    }

    private void postReadRawDataValue3() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_3);
        context.startService(intent);
    }

    private void postReadRawDataValue4() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_4);
        context.startService(intent);
    }

    private void postReadRawDataValue5() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_5);
        context.startService(intent);
    }

    private void postReadRawDataValue6() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_6);
        context.startService(intent);
    }

    private void postReadRawDataValue7() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_7);
        context.startService(intent);
    }

    private void postReadRawDataValue8() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_RAW_VALUE_8);
        context.startService(intent);
    }

    public void postReadCurrentTransmitterDateAndTime() {
//        Log.d("#3734", Request.class.getSimpleName() + ": READ Time!!");
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_CURRENT_TRANSMITTER_DATE_TIME);
        context.startService(intent);
    }

    public void postSendCurrentDateAndTimeToTransmitter() {
//        Log.d("#3734", Request.class.getSimpleName() + ": WRITE Time!!");
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.SEND_CURRENT_DATE_TIME_TO_TRANSMITTER);
        context.startService(intent);
    }

    public void postReadMEPSavedValue() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_MEP_SAVED_VALUE);
        context.startService(intent);
    }

    public void postMEPSavedRefChannelMetric() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_MEP_SAVED_REF_CHANNEL_METRIC);
        context.startService(intent);
    }

    public void postMEPSavedDriftMetric() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_MEP_SAVED_DRIFT_METRIC);
        context.startService(intent);
    }

    public void postMEPSavedLowRefMetric() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_MEP_SAVED_LOW_REF_METRIC);
        context.startService(intent);
    }

    public void postMEPSavedSpike() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_MEP_SAVED_SPIKE);
        context.startService(intent);
    }

    public void postEEP24MSP() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_EEP24_MSP);
        context.startService(intent);
    }

    public void postMEPMSPInfo() {
        postReadMEPSavedValue();
        postMEPSavedRefChannelMetric();
        postMEPSavedDriftMetric();
        postMEPSavedLowRefMetric();
        postMEPSavedSpike();
        postEEP24MSP();
    }
	
	// Read sensor glucose record range 0x0E
    private void postSensorGlucoseRecordRange() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_SENSOR_GLUCOSE_RANGE);
        context.startService(intent);
    }

    // Read alert record range 0x12
    private void postSensorGlucoseAlertRecordRange() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_GLUCOSE_ALERT_RANGE);
        context.startService(intent);
    }

    // Read blood glucose record range 0x17
    private void postBloodGlucoseRecordRange() {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.READ_BLOOD_GLUCOSE_RANGE);
        context.startService(intent);
    }

    public void postGetRangesForSyncing() {
        postSensorGlucoseRecordRange();
        postSensorGlucoseAlertRecordRange();

        // this is put as the last step since in BluetoothPairBaseActivity.java
        // function parsedReadFirstAndLastBloodGlucoseDataRecordNumbersResponse()
        // the syncing is initialized after receiving the response for
        // glucose range fetching
        postBloodGlucoseRecordRange();
    }

    public void postWriteLowGlucoseTargetRequest(int value) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_LOW_TARGET);
        intent.putExtra(CommandProcessor.TARGET_LOW_VALUE, value);
        context.startService(intent);
    }

    public void postWriteHighGlucoseTarget(int value) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_HIGH_TARGET);
        intent.putExtra(CommandProcessor.TARGET_HIGH_VALUE, value);
        context.startService(intent);
    }

    public void postWriteLowGlucoseAlarmRequest(int value) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_LOW_ALARM);
        intent.putExtra(CommandProcessor.ALARM_LOW_VALUE, value);
        context.startService(intent);
    }

    public void postWriteHighGlucoseAlarmRequest(int value) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_HIGH_ALARM);
        intent.putExtra(CommandProcessor.ALARM_HIGH_VALUE, value);
        context.startService(intent);
    }

    /** #4080 */
    public void postWriteMorningCalibrationTime(int hour, int minutes) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_MORNING_CALIBRATION_TIME);
        intent.putExtra(CommandProcessor.CALIBRATION_HOUR, hour);
        intent.putExtra(CommandProcessor.CALIBRATION_MINUTE, minutes);
        context.startService(intent);
    }

    public void postWriteEveningCalibrationTime(int hour, int minutes) {
        Intent intent = gimmeAnIntent(CommandProcessor.COMMAND.WRITE_EVENING_CALIBRATION_TIME);
        intent.putExtra(CommandProcessor.CALIBRATION_HOUR, hour);
        intent.putExtra(CommandProcessor.CALIBRATION_MINUTE, minutes);
        context.startService(intent);
    }

    private Intent gimmeAnIntent(CommandProcessor.COMMAND command) {
        Intent intent = new Intent(context, BluetoothService.class);
        intent.setAction(command.name());
        return intent;
    }
}
