package com.senseonics.pairing.events.view;

import com.senseonics.bluetoothle.Transmitter;

public class TransmitterPressed {
  public Transmitter transmitter;

  public TransmitterPressed(Transmitter transmitter) {
    this.transmitter = transmitter;
  }
}
