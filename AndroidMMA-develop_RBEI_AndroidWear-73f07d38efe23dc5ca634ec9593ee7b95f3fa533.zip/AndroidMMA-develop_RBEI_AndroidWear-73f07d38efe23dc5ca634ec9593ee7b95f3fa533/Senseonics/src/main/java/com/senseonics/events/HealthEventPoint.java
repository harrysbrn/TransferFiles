package com.senseonics.events;

import com.senseonics.events.EventUtils.HEALTH_CONDITION;
import com.senseonics.events.EventUtils.HEALTH_SEVERITY;
import com.senseonics.util.Utils.EVENT_TYPE;

import java.util.Calendar;

public class HealthEventPoint extends EventPoint implements PatientEventPoint{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HEALTH_CONDITION healthCondition;
	private HEALTH_SEVERITY healthSeverity;

	public HealthEventPoint(Calendar calendar, int glucoseLevel,
			HEALTH_CONDITION condition, HEALTH_SEVERITY severity, String notes) {
		super(calendar, glucoseLevel);
		setHealthCondition(condition);
		setHealthSeverity(severity);
		setNotes(notes);
		setEventType(EVENT_TYPE.HEALTH_EVENT);
	}

	public HealthEventPoint(int databaseId, Calendar calendar,
			int glucoseLevel, HEALTH_CONDITION condition,
			HEALTH_SEVERITY severity, String notes) {
		super(databaseId, calendar, glucoseLevel);
		setHealthCondition(condition);
		setHealthSeverity(severity);
		setNotes(notes);
		setEventType(EVENT_TYPE.HEALTH_EVENT);
	}

	public HEALTH_CONDITION getHealthCondition() {
		return healthCondition;
	}

	public void setHealthCondition(HEALTH_CONDITION healthCondition) {
		this.healthCondition = healthCondition;
	}

	public HEALTH_SEVERITY getHealthSeverity() {
		return healthSeverity;
	}

	public void setHealthSeverity(HEALTH_SEVERITY healthSeverity) {
		this.healthSeverity = healthSeverity;
	}

	@Override
	public int eventTypeId() {
		return EventUtils.eventTypeHealth;
	}

	@Override
	public int eventSubTypeId() {
		return healthCondition.ordinal();
	}

	@Override
	public int quantity() {
		return healthSeverity.getSubType();
	}

}
