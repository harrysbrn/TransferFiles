/**
 * This file is part of GraphView.
 *
 * GraphView is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphView is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphView.  If not, see <http://www.gnu.org/licenses/lgpl.html>.
 *
 * Copyright Jonas Gehring
 */

package com.jjoe64.graphview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.Log;
import com.jjoe64.graphview.GraphViewSeries.GraphViewSeriesStyle;
import com.senseonics.gen12androidapp.MainActivity;
import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventPoint;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.graph.util.GraphUtils.COLOR;
import com.senseonics.util.Utils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Line Graph View. This draws a line chart.
 */
public class LineGraphView extends Graph {
	private final Paint paintBackground;
	private boolean drawBackground;
	private boolean drawDataPoints;
	private float dataPointsRadius = 10f;
	private Rect rect;
	private Paint graphLinePaint;
	private Calendar start, end;
	private int paddingTop;

	public LineGraphView(Context context, String title, Calendar start,
			Calendar end, int graphWidth, int height, int width,
			int paddingTop, boolean scrollableGraph, boolean shouldDrawVerticalLines) {
		super(context, title, start, end, height, graphWidth, paddingTop,
				scrollableGraph, shouldDrawVerticalLines);

		this.start = start;
		this.end = end;

		paintBackground = new Paint();
		paintBackground.setColor(getResources().getColor(
				GraphUtils.getColorId(COLOR.GREEN_MIN)));
		paintBackground.setStyle(Paint.Style.FILL);
		paintBackground.setStrokeWidth(1.0f);
		paintBackground.setAntiAlias(true);

		paint.setStyle(Paint.Style.STROKE);
		paint.setAntiAlias(true);
		paint.setStrokeWidth(4.0f);
		paint.setStrokeJoin(Paint.Join.ROUND);
		paint.setStrokeCap(Paint.Cap.ROUND);
		paint.setAlpha(150);
		paint.setColor(getResources().getColor(R.color.graph_line_black));

		graphLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		graphLinePaint.setStyle(Paint.Style.STROKE);
		graphLinePaint.setAntiAlias(true);
		graphLinePaint.setStrokeWidth(5.0f);
		graphLinePaint.setStrokeJoin(Paint.Join.ROUND);
		graphLinePaint.setStrokeCap(Paint.Cap.ROUND);
		graphLinePaint.setAlpha(150);
		graphLinePaint.setColor(getResources().getColor(
				R.color.graph_line_black));

		rect = new Rect(0, paddingTop, width, height);

		this.paddingTop = paddingTop;
	}

	public interface EventsManager {
		void onEventClick(float x, float y, EventGroup eventGroup);

		void onClick();

		void hidePopUpEvent();

		void tapAddNewEvent(Calendar calendar);
	}

	@Override
	public EventPoint ifEventAtPosition(float x) {

		double maxX = getMaxX(false);
		double minX = getMinX(false);
		double diffX = maxX - minX;

		for (EventGroup eventGroup : eventGroups) {
			float valX = (float) (eventGroup.x - minX);
			float ratX = (float) (valX / diffX);
			float xOnScreen = graphwidth * ratX;

			float disGroup = Math.abs(xOnScreen - x);
			if (disGroup < 5)
				for (EventPoint eventPoint : eventGroup.getEvents()) {
					Utils.EVENT_TYPE eventType = eventPoint.getEventType();

					/** No popups for the following events */
					if (eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_RED ||
							eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_YELLOW ||
							eventType == Utils.EVENT_TYPE.NOTIFICATION_EVENT_BLUE ||
							eventType == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_FALLING || /** #3745 */
							eventType == Utils.EVENT_TYPE.PREDICTIVE_ALERT_EVENT_RISING ||
							eventType == Utils.EVENT_TYPE.RATE_ALERT_EVENT_FALLING || /** look at Graph.java setUpEventGroups() */
							eventType == Utils.EVENT_TYPE.RATE_ALERT_EVENT_RISING ||
							eventType == Utils.EVENT_TYPE.ALARM_EVENT) /** look at Graph.java setUpEventGroups() */
					{
						continue;
					}

					float distanceX = Math.abs(eventPoint.getxOnScreen() - x);
					if (distanceX < 5)
						return eventPoint;
				}
		}
		return null;
	}
	
	@Override
    public Glucose ifGlucoseAtPosition(float x) {
 
        double maxX = getMaxX(false);
        double minX = getMinX(false);
        double diffX = maxX - minX;
        float minDisGroup = 0xFFFF; // set to a big number at init since we need a min value
        Glucose pointForReturn = null;

		for (List<Glucose> arrayList : glucosePoints) {
			for (int i = 0; i < arrayList.size(); ++i) {
                Glucose currentPoint = arrayList.get(i);
                float valX = (float) (currentPoint.getX() - minX);
                float ratX = (float) (valX / diffX);
                float xOnScreen = graphwidth * ratX;

                float disGroup = Math.abs(xOnScreen - x);

                // Find the gluocse point which is nearest to the touch x
                if (disGroup < minDisGroup)
                {
                    minDisGroup = disGroup;
                    pointForReturn = currentPoint;
                }
            }
        }

        // #2039 Glucose info would not show if it's a single point on the graph
        if (minDisGroup < 15) { // left and right touch range
            return pointForReturn;
        }

        return null;
    }

	@Override
	public boolean ifEventClick(float x, float y) {
		y += paddingTop;
		for (EventGroup eventGroup : eventGroups) {
			float pX = eventGroup.xOnScreen;
			float pY = rect.bottom - eventGroup.yOnScreen;
			float distanceX = Math.abs(pX - x);
			float distanceY = Math.abs(pY - y + rect.top);

			Log.i("Tap Test","ifEventClick: true| dx:" + distanceX + "|dy:"+distanceY + "|bms:"+GraphUtils.eventBitmapSize);

			if (distanceX <= GraphUtils.eventBitmapSize*1.5
					&& distanceY <= GraphUtils.eventBitmapSize*1.5) {
				return true;
			}
		}

		if (eventsManager != null) {
			Log.i("Tap Test","ifEventClick: onClick");
			eventsManager.onClick();
		}

		return false;
	}

	public void clickEvent(float x, float y) {

		Log.d("position clickEvent", " ---- " + eventGroups.size() + " " + x
				+ " " + y);
		if (eventGroups.size() > 0 && x >= 0 && y >= 0) {
		
			int[] distances = new int[eventGroups.size()];
			int value = GraphUtils.eventBitmapSize * 2;
			for (int i = 0; i < eventGroups.size(); ++i) {

				EventGroup eventGroup = eventGroups.get(i);

				float distanceX = Math.abs(eventGroup.xOnScreen - x);
				float posY = rect.bottom - eventGroup.yOnScreen
						- bottomPositionY;
				float distanceY = Math.abs(posY - y);

				if (distanceX <= value && distanceY <= value)
					distances[i] = (int) (distanceX + distanceY);
				else {
					distances[i] = 10000;
				}
			}

			int maxPosition = 0;
			for (int i = 1; i < distances.length; ++i) {
				if (distances[i] < distances[maxPosition]
						&& distances[i] != 10000)
					maxPosition = i;
			}

			if (distances[maxPosition] != 10000) {
				
				EventGroup eventGroup = eventGroups.get(maxPosition);
				float posY = rect.bottom - eventGroup.yOnScreen
						+ bottomPositionY;

				if (eventsManager != null){
					eventsManager.onEventClick(eventGroup.xOnScreen, posY,
							eventGroup);
				}else{
					Log.d("position eventsmanager null", " -----");
				}
			}
		}
	}

	public void hideEvent() {
		if (eventsManager != null)
			eventsManager.hidePopUpEvent();
	}

	public void drawSeries(Canvas canvas, ArrayList<GlucoseSection> sections,
			float graphwidth, float graphheight, float border, double minX,
			double minY, double diffX, double diffY, float horstart,
			GraphViewSeriesStyle style, boolean lastSectionBOOL) {

		// draw graph
		Path linePath = new Path();
		for (int j = 0; j < sections.size(); ++j) {
			GraphViewDataInterface[] values = sections.get(j)
					.getGlucosePoints();

			if (values.length == 1) {
				float y = GraphUtils.getPositionYForGlucose(
						(int) values[0].getY(), rect);
				y -= bottomPositionY;

				float valX = (float) (values[0].getX() - minX);
				float ratX = (float) (valX / diffX);
				float x = graphwidth * ratX;

				canvas.drawLine(x, (border - y) + graphheight, x, graphheight,
						paintBackground);

			} else {

				int Color = GraphUtils.getColorId(sections.get(j).getColor());

				float lastEndY = 0;
				float lastEndX = 0;

				Path bgPath = new Path();

				lastEndY = 0;
				lastEndX = 0;
				float firstX = 0;
				for (int i = 0; i < values.length; i++) {
					// float valY = (float) (values[i].getY() - minY);
					// float ratY = (float) (valY / diffY);
					// float y = graphheight * ratY;
					float y = GraphUtils.getPositionYForGlucose(
							(int) values[i].getY(), rect);
					y -= bottomPositionY;

					float valX = (float) (values[i].getX() - minX);
					float ratX = (float) (valX / diffX);
					float x = graphwidth * ratX;

					if (i > 0) {
						float startX = (float) lastEndX;
						float startY = (float) (border - lastEndY)
								+ graphheight;
						float endX = (float) x;
						float endY = (float) (border - y) + graphheight;

						// draw data point
						if (drawDataPoints) {
							canvas.drawCircle(startX, startY, dataPointsRadius,
									paint);
						}

						// canvas.drawLine(startX, startY, endX, endY, paint);
						if (bgPath != null) {
							if (i == 1) {
								firstX = startX;
								bgPath.moveTo(startX, startY);
								linePath.moveTo(startX, startY);
							}
							bgPath.lineTo(endX, endY);
							linePath.lineTo(endX, endY);
						}
					}
					lastEndY = y;
					lastEndX = x;
				}

				if (drawBackground) {
					// end / close path
					paintBackground.setColor(getResources().getColor(Color));
					bgPath.lineTo(lastEndX, graphheight);
					bgPath.lineTo(firstX, graphheight);
					bgPath.close();
					canvas.drawPath(bgPath, paintBackground);
				}

			}
		}
		if (sections.size() > 0) {
			GraphViewDataInterface[] firstSection = sections.get(0)
					.getGlucosePoints();

			if (firstSection.length > 0) {
				// float valY = (float) (firstSection[0].getY() - minY);
				// float ratY = (float) (valY / diffY);
				// float y = graphheight * ratY;
				// y -= bottomPositionY;
				float y = GraphUtils.getPositionYForGlucose(
						(int) firstSection[0].getY(), rect);
				y -= bottomPositionY;

				float valX = (float) (firstSection[0].getX() - minX);
				float ratX = (float) (valX / diffX);
				float x = graphwidth * ratX;

                // draw right black disruption point
				drawDisruptionPoint(canvas, border, graphheight, x, y);
			}

			GraphViewDataInterface[] lastSection = sections.get(
					sections.size() - 1).getGlucosePoints();
			if (lastSection.length > 0) {
				GraphViewDataInterface lastGlucose = lastSection[lastSection.length - 1];

				// float valY = (float) (lastGlucose.getY() - minY);
				// float ratY = (float) (valY / diffY);
				// float y = graphheight * ratY;
				// y -= bottomPositionY;
				float y = GraphUtils.getPositionYForGlucose(
						(int) lastGlucose.getY(), rect);
				y -= bottomPositionY;

				float valX = (float) (lastGlucose.getX() - minX);
				float ratX = (float) (valX / diffX);
				float x = graphwidth * ratX;

				Calendar cal = GraphUtils.getDateForPositionX(rect.width(),
						start, end, x);
				
				// draw disruption point - black point
				if (lastSectionBOOL
						&& MainActivity.glucoseLevel == Utils.GLUCOSE_LEVEL_UNKNOWN
						&& Utils.currentDate.getTimeInMillis()
								- cal.getTimeInMillis() >= GraphUtils.disruptionTime)
					drawDisruptionPoint(canvas, border, graphheight, x, y);
				else if (!lastSectionBOOL) {
					// draw right black disruption point
                    drawDisruptionPoint(canvas, border, graphheight, x, y);
			    }
            }
		}
		canvas.drawPath(linePath, graphLinePaint);
	}

	public void drawDisruptionPoint(Canvas canvas, float border,
			float graphHeight, float x, float y) {
		canvas.drawBitmap(GraphUtils.disruptionBitmap, x
				- GraphUtils.disruptionBitmapSize / 2, border - y
				- GraphUtils.disruptionBitmapSize / 2 + graphHeight,
				graphLinePaint);
	}

	public int getBackgroundColor() {
		return paintBackground.getColor();
	}

	public float getDataPointsRadius() {
		return dataPointsRadius;
	}

	public boolean getDrawBackground() {
		return drawBackground;
	}

	public boolean getDrawDataPoints() {
		return drawDataPoints;
	}

	/**
	 * sets the background color for the series. This is not the background
	 * color of the whole graph.
	 * 
	 * @see #setDrawBackground(boolean)
	 */
	@Override
	public void setBackgroundColor(int color) {
		paintBackground.setColor(color);
	}

	/**
	 * sets the radius of the circles at the data points.
	 * 
	 * @see #setDrawDataPoints(boolean)
	 * @param dataPointsRadius
	 */
	public void setDataPointsRadius(float dataPointsRadius) {
		this.dataPointsRadius = dataPointsRadius;
	}

	/**
	 * @param drawBackground
	 *            true for a light blue background under the graph line
	 * @see #setBackgroundColor(int)
	 */
	public void setDrawBackground(boolean drawBackground) {
		this.drawBackground = drawBackground;
	}

	/**
	 * You can set the flag to let the GraphView draw circles at the data points
	 * 
	 * @see #setDataPointsRadius(float)
	 * @param drawDataPoints
	 */
	public void setDrawDataPoints(boolean drawDataPoints) {
		this.drawDataPoints = drawDataPoints;
	}
}
