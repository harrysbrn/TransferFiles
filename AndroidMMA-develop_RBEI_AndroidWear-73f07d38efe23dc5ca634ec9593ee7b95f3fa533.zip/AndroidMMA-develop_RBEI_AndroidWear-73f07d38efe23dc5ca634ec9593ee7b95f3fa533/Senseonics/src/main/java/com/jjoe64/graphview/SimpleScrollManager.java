package com.jjoe64.graphview;

import com.senseonics.events.EventPoint;
import com.senseonics.graph.util.Glucose;

import java.util.Calendar;
import java.util.Date;

public class SimpleScrollManager implements com.senseonics.graph.GraphView.ScrollManager {
    @Override
    public void showEventPopUpTop(float x, EventPoint eventPoint) {
        
    }

    @Override
    public void showGlucosePopUpTop(float x, Glucose glucose) {

    }

    @Override
    public void showNoGlucoseReadingPopUp(float x) {

    }

    @Override
    public void hideEventGlucosePopUpTop() {

    }

    @Override
    public void onEventSelected(EventPoint eventPoint) {

    }

    @Override
    public void dayChanged(Date fromDay, Date toDay) {

    }

    @Override
    public void dayChanged(Date day) {

    }

    @Override
    public void refreshGlucoseData() {

    }

    @Override
    public void tapAddNewEvent(Calendar calendar) {

    }
}
