/**
 * This file is part of GraphView.
 * <p/>
 * GraphView is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p/>
 * GraphView is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p/>
 * You should have received a copy of the GNU General Public License
 * along with GraphView.  If not, see <http://www.gnu.org/licenses/lgpl.html>.
 * <p/>
 * Copyright Jonas Gehring
 */

package com.jjoe64.graphview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v4.view.GestureDetectorCompat;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import com.jjoe64.graphview.GraphViewSeries.GraphViewSeriesStyle;
import com.jjoe64.graphview.LineGraphView.EventsManager;
import com.senseonics.gen12androidapp.R;
import com.senseonics.events.EventPoint;
import com.senseonics.graph.GraphView.DAY_TYPE;
import com.senseonics.graph.GraphView.ScrollManager;
import com.senseonics.graph.VerticalLineManager;
import com.senseonics.graph.util.Glucose;
import com.senseonics.graph.util.GraphUtils;
import com.senseonics.graph.util.GraphUtils.COLOR;
import com.senseonics.graph.util.GraphUtils.DIRECTION;
import com.senseonics.util.Utils;
import com.senseonics.util.Utils.EVENT_TYPE;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

/**
 * GraphView is a Android View for creating zoomable and scrollable graphs. This
 * is the abstract base class for all graphs. Extend this class and implement
 * {@link #drawSeries(Canvas, GraphViewDataInterface[], float, float, float, double, double, double, double, float)}
 * to display a custom graph. Use {@link LineGraphView} for creating a line
 * chart.
 *
 * @author jjoe64 - jonas gehring - http://www.jjoe64.com
 *
 *         Copyright (C) 2011 Jonas Gehring Licensed under the GNU Lesser
 *         General Public License (LGPL) http://www.gnu.org/licenses/lgpl.html
 */
abstract public class Graph extends LinearLayout {

    private Rect rect;
    protected float graphwidth;
    protected List<List<Glucose>> glucosePoints;
    private Calendar startDate, endDate;
    private int paddingTop;
    protected EventsManager eventsManager;
    private ScrollManager manager;
    private VerticalLineManager verticalLineManager;
    protected boolean scrollableGraph = false;

    protected float bottomPositionY;

    static final private class GraphViewConfig {
        static final float BORDER = 20;
    }

    public void setStartDate(Calendar startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(Calendar endDate) {
        this.endDate = endDate;
    }

    private class GraphViewContentView extends View {
        private float lastTouchEventX;

        private boolean scrollingStarted;
        private Paint horizontalLinePaint;
        private Paint dashedLinePaint, horizontalDashedLinePaint;
        private Paint textPaint, bottomTextPaint, levelTextPaint;
        private Paint horizontalThickLinePaint, eventPaint;

        private float textHeight;

        private float clickedX, clickedY;
        private boolean shouldDrawVerticalLines;

        private GestureDetectorCompat gestureDetector;

        private boolean isTapAddEventInProgress;
        private float singleTappedX, singleTappedY;
        private int tappingEffectAlpha;

        private static final int TAPPING_CIRCLE_RADIUS = 100;
        private static final int TAPPING_ALPHT_START = 255;
        private static final int ADD_EVENT_DELAY_MILLISECONDS = 250;
        private static final int SINGLE_TAP_LOCK_MILLISECONDS = 750;
        private static final int FADE_MILLISECONDS = 100; // seconds of fade effect
        private static final int ALPHA_STEP = 50;
        private static final int FADE_STEP = ALPHA_STEP * FADE_MILLISECONDS / TAPPING_ALPHT_START;

        /**
         * @param context
         * @param shouldDrawVerticalLines
         */
        public GraphViewContentView(Context context, boolean shouldDrawVerticalLines) {
            super(context);
            this.shouldDrawVerticalLines = shouldDrawVerticalLines;
            super.setBackgroundColor(getResources().getColor(
                    android.R.color.white));
            setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
                    LayoutParams.MATCH_PARENT));

            horizontalLinePaint = new Paint();
            horizontalLinePaint.setAntiAlias(true);
            horizontalLinePaint.setStrokeWidth(1);
            horizontalLinePaint.setColor(context.getResources().getColor(
                    R.color.light_gray));

            int dashSize = 12;
            dashedLinePaint = new Paint();
            dashedLinePaint.setARGB(255, 0, 0, 0);
            dashedLinePaint.setStyle(Style.STROKE);
            dashedLinePaint.setPathEffect(new DashPathEffect(new float[]{
                    dashSize, dashSize}, 1));
            dashedLinePaint.setStrokeWidth(1);
            dashedLinePaint.setColor(context.getResources().getColor(
                    R.color.light_gray));

            horizontalDashedLinePaint = new Paint();
            horizontalDashedLinePaint.setARGB(255, 0, 0, 0);
            horizontalDashedLinePaint.setStyle(Style.STROKE);
            horizontalDashedLinePaint.setPathEffect(new DashPathEffect(
                    new float[]{dashSize, dashSize}, 1));
            horizontalDashedLinePaint.setStrokeWidth(6);
            horizontalDashedLinePaint.setColor(context.getResources().getColor(
                    R.color.light_gray));

            eventPaint = new Paint();
            eventPaint.setAntiAlias(true);
            eventPaint.setFilterBitmap(true);
            eventPaint.setDither(true);

            textPaint = new Paint();
            textPaint.setAntiAlias(true);
            textPaint.setTextAlign(Align.CENTER);
            textPaint.setColor(context.getResources().getColor(R.color.black));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);

            bottomTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG
                    | Paint.LINEAR_TEXT_FLAG);
            bottomTextPaint.setColor(getResources().getColor(R.color.black));
            bottomTextPaint.setTextSize(getResources().getDimension(
                    R.dimen.graph_glucose_value_size));
            bottomTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
            bottomTextPaint.setTextAlign(Align.CENTER);

            levelTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG
                    | Paint.LINEAR_TEXT_FLAG);
            levelTextPaint.setAntiAlias(true);
            levelTextPaint.setTextAlign(Align.CENTER);
            levelTextPaint.setShadowLayer(5, 0, 0, Color.WHITE);
            levelTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
            levelTextPaint.setColor(context.getResources().getColor(
                    R.color.black));
            levelTextPaint.setTextSize(getResources().getDimension(
                    R.dimen.graph_glucose_value_size));

            horizontalThickLinePaint = new Paint();
            horizontalThickLinePaint.setAntiAlias(true);
            horizontalThickLinePaint.setStrokeWidth(6);
            horizontalThickLinePaint.setColor(context.getResources().getColor(
                    R.color.gray));

            textPaint.setTextSize(getResources().getDimension(R.dimen.graph_time_size));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textHeight = GraphUtils.measureText("12PMg", textPaint).height();
            manager = new SimpleScrollManager();

            isTapAddEventInProgress = false;
            tappingEffectAlpha = TAPPING_ALPHT_START;

            gestureDetector = new GestureDetectorCompat(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    float currentPointX = GraphUtils.getCurrentPointXfromOnScreenX(e.getX(),
                            getMaxX(false), getMinX(false), graphwidth);

                    final Calendar currentDate = GraphUtils.getCalendarFromPositionX(rect.width(), startDate, endDate, currentPointX);
                    Log.i("Tap Test", "onSingleTapConfirmed->current point X:" + currentPointX + "|calendar:" + Utils.formatDate_TimeZone(currentDate, TimeZone.getDefault()));

                    if (isTapAddEventInProgress == true) {
                        // do nothing
                    }
                    else {
                        isTapAddEventInProgress = true;
                        singleTappedX = e.getX();
                        singleTappedY = e.getY();
                        tappingEffectAlpha = TAPPING_ALPHT_START;

                        // redraw the graph
                        invalidate();

                        Handler tapDelayHandler = new Handler();
                        tapDelayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                isTapAddEventInProgress = false;
                                // redraw the graph
                                invalidate();
                            }
                        }, SINGLE_TAP_LOCK_MILLISECONDS);

                        Handler addEventDelayHandler = new Handler();
                        addEventDelayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                eventsManager.tapAddNewEvent(currentDate);
                            }
                        }, ADD_EVENT_DELAY_MILLISECONDS);
                    }

                    return true;
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    Log.i("Tap Test", "onDoubleTap");
                    return true;
                }

                @Override
                public boolean onDown(MotionEvent e) {
                    return true; // must return true if need to detect onSingleTapUp
                }
            });
        }

        /**
         * @param canvas
         */
        @Override
        protected void onDraw(Canvas canvas) {

            float height = getHeight();
            float width = getWidth() - 1;
            double maxY = getMaxY();
            double minY = getMinY();
            double maxX = getMaxX(false);
            double minX = getMinX(false);
            double diffX = maxX - minX;

            float graphheight = height;
            graphwidth = width;

            if (maxY == minY) {
                // if min/max is the same, fake it so that we can render a line
                if (maxY == 0) {
                    // if both are zero, change the values to prevent division
                    // by zero
                    maxY = 1.0d;
                    minY = 0.0d;
                } else {
                    maxY = maxY * 1.05d;
                    minY = minY * 0.95d;
                }
            }

            double diffY = maxY - minY;
            paint.setStrokeCap(Paint.Cap.ROUND);

            // Draw glucose threshold lines first
            drawHorizontalLevelLines(canvas, rect, bottomPositionY);

            // draw the vertical date/time lines
            if (shouldDrawVerticalLines)
                drawSectionLines(canvas);

            boolean lastSection;
            for (int i = 0; i < graphSeries.size(); i++) {
                if (i == graphSeries.size() - 1)
                    lastSection = true;
                else
                    lastSection = false;

                // draw graph: connect points
                drawSeries(canvas, subDivideGlucosePoints(getValues(i)),
                        graphwidth, graphheight, 0, minX, minY, diffX, diffY,
                        0, graphSeries.get(i).style, lastSection);
            }

            // Draw glucose threshold text after drawing the glucose graph, but before drawing event icons
            drawGlucoseThreholdText(canvas, rect, bottomPositionY);

            setUpEventGroups();
            for (EventGroup eventGroup : eventGroups) {
                drawEventGroup(canvas, eventGroup, bottomPositionY);
            }

            // draw the tapping effect
            DrawTappingEffect(canvas);
        }

        private void DrawTappingEffect(Canvas canvas) {
            if (isTapAddEventInProgress == true) {
                int radius = TAPPING_CIRCLE_RADIUS;
                Paint paint = new Paint();
                paint.setColor(getResources().getColor(R.color.blue_light));
                paint.setStyle(Paint.Style.FILL);
                paint.setFlags(Paint.ANTI_ALIAS_FLAG);

                if (tappingEffectAlpha < 0) {
                    paint.setAlpha(0);
                }
                else {
                    paint.setAlpha(tappingEffectAlpha);
                }
                tappingEffectAlpha -= ALPHA_STEP;

                canvas.drawCircle(singleTappedX, singleTappedY, radius, paint);
                postInvalidateDelayed(FADE_STEP, (int) (singleTappedX - radius), (int) (singleTappedY - radius), (int) (singleTappedX + radius), (int) (singleTappedY + radius));
            }
        }

        public void drawEventGroup(Canvas canvas, EventGroup eventGroup,
                                   float bottomPosition) {

            ArrayList<EventPoint> eventPoints = eventGroup.getEvents();

            // group event
            if (eventPoints.size() > 1) {
                float posX = eventGroup.xOnScreen;
                float posY = eventGroup.yOnScreen - bottomPosition;
                drawBitmap(canvas, posX, posY,
                        new EventPoint(Calendar.getInstance(), 0,
                                EVENT_TYPE.GROUP_EVENT));

            } else {
                // single event
                EventPoint glucosePoint = eventPoints.get(0);
                float posX = glucosePoint.getxOnScreen();
                float posY = glucosePoint.getyOnScreen() - bottomPosition;
                drawBitmap(canvas, posX, posY, glucosePoint);
            }
        }

        public void drawBitmap(Canvas canvas, float x, float y,
                               EventPoint eventPoint) {
            Bitmap bitmap = GraphUtils.getBitmapForEvent(eventPoint);
            if (bitmap != null) {
                canvas.drawBitmap(bitmap, x - bitmap.getWidth() / 2,
                        rect.bottom - y - bitmap.getHeight() / 2, eventPaint);
            }
        }

        private void drawSectionLines(Canvas canvas) {
            Calendar start = GraphUtils.getDateForPositionX(rect.width(),
                    startDate, endDate, (float) viewportStart);
            Calendar end = GraphUtils.getDateForPositionX(rect.width(),
                    startDate, endDate,
                    (float) (viewportStart + GraphUtils.viewportSize));

            currentDayType = getDayType((int) GraphUtils.viewportSize);

            // int offset = calendar.get(Calendar.DST_OFFSET);

            double maxX = getMaxX(false);
            double minX = getMinX(false);
            double diffX = maxX - minX;
            Calendar startNull = Calendar.getInstance();
            startNull.setTimeInMillis(start.getTimeInMillis() - GraphUtils.DAY);
            startNull.set(Calendar.HOUR_OF_DAY, 0);
            startNull.set(Calendar.MINUTE, 0);
            startNull.set(Calendar.SECOND, 0);
            startNull.set(Calendar.MILLISECOND, 0);
            end.setTimeInMillis(end.getTimeInMillis() + GraphUtils.DAY);

            long startTime = startNull.getTimeInMillis();
            long endTime = end.getTimeInMillis();
            int startDSTOffset = startNull.get(Calendar.DST_OFFSET);
            int endDSTOffset = end.get(Calendar.DST_OFFSET);

            if (currentDayType == DAY_TYPE.WIDTHX4_24SECTION
                    || currentDayType == DAY_TYPE.WIDTHX8_TO_WIDTHX12_48SECTION
                    || currentDayType == DAY_TYPE.WIDTHX2_12SECTION) {
                long i = startTime;
                long lastDST = startDSTOffset;
                while (i <= endTime) {
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(i);

                    int offset = cal.get(Calendar.DST_OFFSET);
                    if (startDSTOffset != endDSTOffset && lastDST != offset) {
                        boolean DSTime = false;
                        if (startDSTOffset == 0) {
                            i -= offset;
                            DSTime = true;
                        } else if (endDSTOffset == 0) {
                            drawLine12Section(i, canvas, cal, start, end, minX,
                                    diffX, true);
                            i += lastDST;
                        }
                        lastDST = offset;
                        cal.setTimeInMillis(i);
                        drawLine12Section(i, canvas, cal, start, end, minX,
                                diffX, DSTime);
                    } else
                        drawLine12Section(i, canvas, cal, start, end, minX,
                                diffX, false);

                    i += GraphUtils.HOUR * ((currentDayType == DAY_TYPE.WIDTHX2_12SECTION) ? 2 : 1);
                }
            }

            if (currentDayType == DAY_TYPE.HALFWIDTH_6SECTION) {
                long i = startTime;
                long lastDST = startDSTOffset;
                while (i <= endTime) {
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(i);
                    int offset = cal.get(Calendar.DST_OFFSET);
                    if (startDSTOffset != endDSTOffset && lastDST != offset) {
                        boolean DSTime = false;
                        if (startDSTOffset == 0) {
                            i -= offset;
                            DSTime = true;
                        } else if (endDSTOffset == 0) {
                            drawLine6Section(i, canvas, cal, start, end, minX,
                                    diffX, true);
                            i += lastDST;
                        }
                        lastDST = offset;
                        cal.setTimeInMillis(i);
                        drawLine6Section(i, canvas, cal, start, end, minX,
                                diffX, DSTime);
                    } else
                        drawLine6Section(i, canvas, cal, start, end, minX,
                                diffX, false);

                    i += GraphUtils.HOUR * 3;
                }
            }

            if (currentDayType == DAY_TYPE.THIRDWIDTH_2SECTION) {
                long i = startTime;
                long lastDST = startDSTOffset;
                while (i <= endTime) {

                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(i);
                    int offset = cal.get(Calendar.DST_OFFSET);
                    if (startDSTOffset != endDSTOffset && lastDST != offset) {

                        if (startDSTOffset == 0)
                            i -= offset;
                        else if (endDSTOffset == 0)
                            i += lastDST;
                        lastDST = offset;
                        cal.setTimeInMillis(i);
                        drawDayLineForCalendar(i, canvas, cal, start, end,
                                minX, diffX, false);
                    } else
                        drawDayLineForCalendar(i, canvas, cal, start, end,
                                minX, diffX, false);
                    i += GraphUtils.DAY / 2;
                }
            }

        }

        public void drawLine12Section(long i, Canvas canvas, Calendar cal,
                                      Calendar start, Calendar end, double minX, double diffX,
                                      boolean DS) {

            if (i >= start.getTimeInMillis() && i < end.getTimeInMillis()) {
                float x = GraphUtils.getPositionX(rect.width(), startDate,
                        endDate, cal);

                float valX = (float) (x - minX);
                float ratX = (float) (valX / diffX);
                float X = graphwidth * ratX;
                if (DateFormat.format("H", cal).toString().equals("0")) {
                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalThickLinePaint);
                } else {

                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalLinePaint);
                }
                String hour = getHour(cal);
                canvas.drawText(hour, X, (0 + paddingTop) - textHeight,
                        textPaint);

                if (DS)
                    canvas.drawText(
                            getContext().getString(R.string.daylight_saving),
                            X, (0 + paddingTop) - 2 * textHeight, textPaint);
            }
        }

        public void drawLine6Section(long i, Canvas canvas, Calendar cal,
                                     Calendar start, Calendar end, double minX, double diffX,
                                     boolean DS) {
            if (i >= start.getTimeInMillis() && i < end.getTimeInMillis()) {
                float x = GraphUtils.getPositionX(rect.width(), startDate,
                        endDate, cal);

                float valX = (float) (x - minX);
                float ratX = (float) (valX / diffX);
                float X = graphwidth * ratX;
                if (DateFormat.format("H", cal).toString().equals("0")) {
                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalThickLinePaint);
                } else {
                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalLinePaint);
                }
                String hour = getHour(cal);
                canvas.drawText(hour, X, (0 + paddingTop) - textHeight,
                        textPaint);

                if (DS)
                    canvas.drawText(
                            getContext().getString(R.string.daylight_saving),
                            X, (0 + paddingTop) - 2 * textHeight, textPaint);
            }
        }

        public void drawDayLineForCalendar(long i, Canvas canvas, Calendar cal,
                                           Calendar start, Calendar end, double minX, double diffX,
                                           boolean DS) {
            if (i >= start.getTimeInMillis() && i < end.getTimeInMillis()) {
                float x = GraphUtils.getPositionX(rect.width(), startDate,
                        endDate, cal);

                float valX = (float) (x - minX);
                float ratX = (float) (valX / diffX);
                float X = graphwidth * ratX;

                if (DateFormat.format("H", cal).toString().equals("0")) {
                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalThickLinePaint);
                    String hour = getDate(cal);

                    canvas.drawText(hour, X, (0 + paddingTop) - textHeight,
                            textPaint);
                } else {
                    canvas.drawLine(X, 0 + paddingTop, X, getHeight(),
                            horizontalLinePaint);
                }
                if (DS)
                    canvas.drawText(
                            getContext().getString(R.string.daylight_saving),
                            X, (0 + paddingTop) - 2 * textHeight, textPaint);
            }
        }

        public String getHour(Calendar calendar) {
            // int offset = calendar.get(Calendar.DST_OFFSET);
            // calendar.setTimeInMillis(calendar.getTimeInMillis() - offset);
            return Utils.getHour24HrFormat(calendar, TimeZone.getDefault(), getContext());

        }

        private boolean isSameDay(Calendar cal1, Calendar cal2) {
            if (cal1 == null || cal2 == null) {
                throw new IllegalArgumentException("The dates must not be null");
            }
            return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
                    cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                    cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
        }

        private String getDate(Calendar calendar) {
            String retVal = DateFormat.format("EEE M/dd", calendar).toString().toUpperCase();

            if(isSameDay(calendar, Calendar.getInstance())) {
                retVal = getContext().getString(R.string.today);
            }

            return retVal;
        }

        public void drawGlucoseThreholdText(Canvas canvas, Rect rect,
                                            float bottomPositionY) {

            if (GraphUtils.glucoseLevels != null
                    && GraphUtils.glucoseLevels.size() > 0) {

                for (Map.Entry<Integer, COLOR> entry : GraphUtils.glucoseLevels
                        .entrySet()) {
                    int level = entry.getKey();
                    if (level != GraphUtils.glucoseMinimumLevel
                            && level != GraphUtils.glucoseMaximumLevel) {
                        float y = GraphUtils.getPositionYForGlucose(
                                entry.getKey(), rect)
                                - bottomPositionY;

                        // text
                        String text = Utils
                                .getGlucoseLevelValue(entry.getKey());
                        float textHeight = GraphUtils.measureText(text,
                                levelTextPaint).height();
                        canvas.drawText(text, textRect.left + textRect.width()
                                        / 2, rect.bottom - y - textHeight / 2,
                                levelTextPaint);
                    }
                }
            }
        }

        public void drawHorizontalLevelLines(Canvas canvas, Rect rect,
                                             float bottomPositionY) {

            if (GraphUtils.glucoseLevels != null
                    && GraphUtils.glucoseLevels.size() > 0) {

                for (Map.Entry<Integer, COLOR> entry : GraphUtils.glucoseLevels
                        .entrySet()) {
                    int level = entry.getKey();
                    if (level != GraphUtils.glucoseMinimumLevel
                            && level != GraphUtils.glucoseMaximumLevel) {
                        float y = GraphUtils.getPositionYForGlucose(
                                entry.getKey(), rect)
                                - bottomPositionY;

                        int colorId = getResources().getColor(
                                GraphUtils.getLineColorId(entry.getValue()));
                        horizontalDashedLinePaint.setColor(colorId);

                        if (colorId == getResources().getColor(R.color.graph_red) || colorId == getResources().getColor(R.color.graph_green)) {
                            levelTextPaint.setColor(getResources().getColor(R.color.black));
                        } else {
                            levelTextPaint.setColor(colorId);
                        }

                        // line
                        path.reset();
                        path.moveTo(0, rect.bottom - y);

                        // line
                        path.lineTo(canvas.getWidth(), rect.bottom - y);
                        canvas.drawPath(path, horizontalDashedLinePaint);
                    }
                }
            }
        }

        private void slideBackToStart() {
            final double minX = getMinX(true);
            final double min = minX + GraphUtils.viewportSize * 0.1f;

            if (viewportStart < min) {
                final float move = 3;
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {

                    @Override
                    public void run() {
                        if (viewportStart < min) {
                            Graph.this.post(new Runnable() {

                                @Override
                                public void run() {
                                    slide(-move);
                                }
                            });
                        } else {
                            viewportStart = min;
                            GraphUtils.viewportStart = viewportStart;
                            this.cancel();
                        }

                    }
                }, 0, 5);
            }
        }

        private void slideBackToEnd() {
            final double maxX = getMaxScroll();
            final double max = maxX - GraphUtils.viewportSize * 0.1f;

            if (viewportStart + GraphUtils.viewportSize > max) {
                final float move = 3;
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {

                    @Override
                    public void run() {
                        if (viewportStart + GraphUtils.viewportSize > max) {
                            Graph.this.post(new Runnable() {

                                @Override
                                public void run() {
                                    slide(move);
                                }
                            });
                        } else {
                            viewportStart = max - GraphUtils.viewportSize;
                            GraphUtils.viewportStart = viewportStart;
                            this.cancel();
                        }

                    }
                }, 0, 5);
            }
        }

        public double getMaxScroll() {

            float x = GraphUtils.getPositionX(rect.width(), startDate, endDate,
                    Utils.currentDate);
            float max = (float) (x + GraphUtils.viewportSize * 0.1f + GraphUtils.viewportSize / 5);
            return max;
        }

        private void onMoveGesture(float f) {
            // view port update

            if (GraphUtils.viewportSize != 0) {
                viewportStart -= f * GraphUtils.viewportSize / graphwidth;
                GraphUtils.viewportStart = viewportStart;
                // minimal and maximal view limit

                double minX = getMinX(true);
                double maxX = getMaxScroll();

                if (viewportStart < minX) {
                    viewportStart = minX;
                } else if (viewportStart + GraphUtils.viewportSize > maxX) {
                    viewportStart = maxX - GraphUtils.viewportSize;
                }
                GraphUtils.viewportStart = viewportStart;

                Calendar start = GraphUtils.getDateForPositionX(rect.width(),
                        startDate, endDate, (float) viewportStart);

                Calendar end = GraphUtils
                        .getDateForPositionX(
                                rect.width(),
                                startDate,
                                endDate,
                                (float) ((float) viewportStart + GraphUtils.viewportSize));

                Calendar middle = GraphUtils
                        .getDateForPositionX(
                                rect.width(),
                                startDate,
                                endDate,
                                (float) ((float) viewportStart + GraphUtils.viewportSize / 2));

                long timestampDiff = end.getTimeInMillis()
                        - start.getTimeInMillis();
                if (timestampDiff > GraphUtils.DAY) {
                    manager.dayChanged(start.getTime(), end.getTime());
                } else {
                    manager.dayChanged(middle.getTime());
                }

                invalidate();
            }
        }

        private void slide(float f) {

            if (GraphUtils.viewportSize != 0) {
                viewportStart -= f * GraphUtils.viewportSize / graphwidth;

                GraphUtils.viewportStart = viewportStart;
                invalidate();
            }
        }

        private boolean isEventClicked = false;
        private Runnable runnable;
        private Handler handler;
        private boolean isLongTap;
        private Point firstPointStart;
        private int clickDetectDistance = 10;
        private int longPressDetectDistance = clickDetectDistance - 2;

        /**
         * @param event
         */
        @Override
        public boolean onTouchEvent(final MotionEvent event) {
            if (handler == null)
                handler = new Handler();

            if (!isScrollable() || isDisableTouch()) {
                return super.onTouchEvent(event);
            }

            boolean handled = false;
            // first scale
            if (scalable && scaleDetector != null) {
                scaleDetector.onTouchEvent(event);
                handled = scaleDetector.isInProgress();
            }
            if (!handled) {
                // ACTION_DOWN
                if (event.getAction() == MotionEvent.ACTION_DOWN) {

                    if (event.getPointerCount() < 2) {
                        isEventClicked = ifEventClick(event.getX(),
                                event.getY() - bottomPositionY);
                        if (isEventClicked) {
                            clickedX = event.getX();
                            clickedY = event.getY();
                        }
                    }
                    if (handler != null)
                        handler.removeCallbacksAndMessages(null);
                    isLongTap = true;
                    firstPointStart = new Point();
                    firstPointStart.x = (int) event.getX(0);
                    firstPointStart.y = (int) event.getY(0);

                    runnable = new Runnable() {

                        @Override
                        public void run() {

                            if (isLongTap && event.getPointerCount() < 2) {
                                Log.i("Tap Test","isEventClicked: false 1");
                                isEventClicked = false;
                                hideEvent();
                                verticalLineManager
                                        .drawVerticalLine(firstPointStart.x);
                            }
                        }
                    };
                    handler.postDelayed(runnable, 600);

                }
                if ((event.getAction() & MotionEvent.ACTION_DOWN) == MotionEvent.ACTION_DOWN
                        && (event.getAction() & MotionEvent.ACTION_MOVE) == 0) {
                    Log.i("Tap Test","scrollingStarted = true");
                    scrollingStarted = true;
                    handled = true;
                }
                if ((event.getAction() & MotionEvent.ACTION_UP) == MotionEvent.ACTION_UP) {
                    scrollingStarted = false;
                    lastTouchEventX = 0;
                    handled = true;
                }

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getPointerCount() < 2) {
                        if (isEventClicked) {
                            Log.i("Tap Test","isEventClicked: false 2");
                            isEventClicked = false;
                            Log.i("Tap Test","isEventClicked: false 2 |diffX:" + Math.abs(event.getX() - clickedX)
                            + "|diffY:"+Math.abs(event.getY() - clickedY));
                            if (Math.abs(event.getX() - clickedX) <= clickDetectDistance
                                    && Math.abs(event.getY() - clickedY) <= clickDetectDistance) {
                                clickEvent(event.getX(), event.getY());
                            }
                        }
                    }
                    if (verticalLineManager.verticalLineIsVisible())
                        verticalLineManager.hideVerticalLine();
                    isLongTap = false;

                    slideBackToStart();
                    slideBackToEnd();
                }

                if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                    Log.i("Tap Test","isEventClicked: false 3");
                    isEventClicked = false;
                    if (verticalLineManager.verticalLineIsVisible())
                        verticalLineManager.hideVerticalLine();
                    isLongTap = false;
                    slideBackToStart();
                    slideBackToEnd();
                }
                // ACTION_MOVE
                if ((event.getAction() & MotionEvent.ACTION_MOVE) == MotionEvent.ACTION_MOVE) {

                    // if vertical line is visible
                    int distance1 = (int) (firstPointStart.x - event.getX());
                    int distance2 = (int) (firstPointStart.y - event.getY());

                    firstPointStart.x = (int) event.getX();
                    firstPointStart.y = (int) event.getY();

                    if (isLongTap
                            && !verticalLineManager.verticalLineIsVisible())
                        if (Math.abs(distance1) > longPressDetectDistance || Math.abs(distance2) > longPressDetectDistance) {
                            isLongTap = false;
                        }

                    if (Math.abs(distance1) > (clickDetectDistance-1) || Math.abs(distance2) > (clickDetectDistance-1)) {
                        Log.i("Tap Test","isEventClicked: false 4");
                        isEventClicked = false;
                        hideEvent();
                    }

                    if (isLongTap
                            && verticalLineManager.verticalLineIsVisible()) {
                        verticalLineManager.drawVerticalLine(event.getX());
                        return true;
                    }

                    // simple scroll
                    if (scrollingStarted) {
                        if (lastTouchEventX != 0) {

                            float f = 2.5f;
                            Log.i("Tap Test","isEventClicked: false 5");
//                            isEventClicked = false;
                            long distance = (long) Math.abs(event.getX()
                                    - lastTouchEventX);

                            if(distance <= 20) {
                                isEventClicked = true;
                            }

                            if (distance < 25) {
                                f = 1.2f;
                            } else if (distance < 40) {
                                f = 2.0f;
                            } else {
                                f = 2.5f;
                            }
                            onMoveGesture((float) (f * (event.getX() - lastTouchEventX)));
                        }
                        lastTouchEventX = event.getX();
                        handled = true;
                    }

                }

                // only trigger gesture detector if it's not tapping on an event
                if(isEventClicked == false) {
                    gestureDetector.onTouchEvent(event);
                    Log.d("Tap", "gestureDetector onTouchEvent:" + event.getAction() + "; handled:" + handled);
                }

                if (handled)
                    invalidate();
            } else {
                // currently scaling
                scrollingStarted = false;
                lastTouchEventX = 0;
            }
            return handled;
        }
    }

    public int getRectWidth() {
        return rect.width();
    }

    public double getMaxScroll() {
        return graphViewContentView.getMaxScroll();
    }

    public void slide(float value) {
        graphViewContentView.onMoveGesture(value);
    }

    public void setVerticalLineManager(VerticalLineManager verticalLineManager) {
        this.verticalLineManager = verticalLineManager;
    }

    public DAY_TYPE getDayType(int dayWidth) {
        if (dayWidth >= Utils.daySubviewWidth) {
            return DAY_TYPE.THIRDWIDTH_2SECTION;
        }
        if (dayWidth > Utils.daySubviewWidth / 2)
            return DAY_TYPE.HALFWIDTH_6SECTION;
        if (dayWidth > Utils.daySubviewWidth / 4)
            return DAY_TYPE.WIDTHX2_12SECTION;
        if (dayWidth > Utils.daySubviewWidth / 8)
            return DAY_TYPE.WIDTHX4_24SECTION;
        if (dayWidth >= Utils.daySubviewWidth / 12)
            return DAY_TYPE.WIDTHX8_TO_WIDTHX12_48SECTION;
        if (dayWidth < Utils.daySubviewWidth / 12)
            return DAY_TYPE.WIDTHX8_TO_WIDTHX12_48SECTION;

        return DAY_TYPE.THIRDWIDTH_2SECTION;
    }

    /**
     * one data set for a graph series
     */
    static public class GraphViewData implements GraphViewDataInterface {
        public final double valueX;
        public final double valueY;

        public GraphViewData(double valueX, double valueY) {
            super();
            this.valueX = valueX;
            this.valueY = valueY;
        }

        @Override
        public double getX() {
            return valueX;
        }

        @Override
        public double getY() {
            return valueY;
        }
    }

    public enum LegendAlign {
        TOP, MIDDLE, BOTTOM
    }

    protected final Paint paint;
    private boolean scrollable;
    private boolean isLandscape = false;
    private boolean disableTouch;
    private double viewportStart;
    private ScaleGestureDetector scaleDetector;
    private boolean scalable;
    private final NumberFormat[] numberformatter = new NumberFormat[2];
    private final List<GraphViewSeries> graphSeries;
    private boolean showLegend = false;
    private LegendAlign legendAlign = LegendAlign.MIDDLE;
    private boolean manualYAxis;
    private double manualMinYValue;
    protected GraphViewStyle graphViewStyle;
    private final GraphViewContentView graphViewContentView;
    private CustomLabelFormatter customLabelFormatter;

    private DAY_TYPE currentDayType;

    private List<EventPoint> eventPoints;
    protected ArrayList<EventGroup> eventGroups;

    private Path path;
    private Rect textRect;
    private Paint dashedLinePaint;
    private int dashSize;

    /**
     * @param context
     * @param title
     * @param shouldDrawVerticalLines
     */
    public Graph(Context context, String title, Calendar start, Calendar end,
                 int height, int width, int paddingTop, boolean scrollableGraph, boolean shouldDrawVerticalLines) {
        super(context);
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT);
        setLayoutParams(params);

        this.scrollableGraph = scrollableGraph;

        path = new Path();

        int paddingLeft, textWidth;
        paddingLeft = Utils.screenWidth / 25;

        if (Utils.screenWidth > 600) {
            dashSize = 3;
            textWidth = Utils.screenWidth / 15;
        } else {
            dashSize = 2;
            textWidth = Utils.screenWidth / 10;
        }
        textRect = new Rect(0, paddingTop, textWidth + paddingLeft, height);

        dashedLinePaint = new Paint();
        dashedLinePaint.setARGB(255, 0, 0, 0);
        dashedLinePaint.setStyle(Style.STROKE);
        dashedLinePaint.setPathEffect(new DashPathEffect(new float[]{
                dashSize, dashSize}, 1));
        dashedLinePaint.setStrokeWidth(2);
        dashedLinePaint.setColor(context.getResources().getColor(
                R.color.light_gray));

        graphViewStyle = new GraphViewStyle();
        graphViewStyle.useTextColorFromTheme(context);

        paint = new Paint();
        paint.setAntiAlias(true);
        graphSeries = new ArrayList<GraphViewSeries>();

        this.startDate = start;
        this.endDate = end;

        this.paddingTop = paddingTop;

        rect = new Rect(0, paddingTop, width, height);

        bottomPositionY = GraphUtils.getPositionYForGlucose(
                Utils.GRAPH_GLUCOSE_MIN, rect);

        glucosePoints = new ArrayList<>();

        eventPoints = new ArrayList<>();
        eventGroups = new ArrayList<>();

        graphViewContentView = new GraphViewContentView(context, shouldDrawVerticalLines);
        // addView(graphViewContentView, new LayoutParams(
        // LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 1));
        addView(graphViewContentView, new LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

    }

    private GraphViewDataInterface[] getValues(int idxSeries) {
        GraphViewDataInterface[] values = graphSeries.get(idxSeries).values;
        synchronized (values) {
            if (scrollableGraph == false) {
                return values;
            } else {
                // viewport
                List<GraphViewDataInterface> listData = new ArrayList<GraphViewDataInterface>();
                for (int i = 0; i < values.length; i++) {
                    if (values[i].getX() >= viewportStart) {
                        if (values[i].getX() > viewportStart
                                + GraphUtils.viewportSize) {
                            listData.add(values[i]); // one more for nice
                            // scrolling
                            break;
                        } else {
                            listData.add(values[i]);
                        }
                    } else {
                        if (listData.isEmpty()) {
                            listData.add(values[i]);
                        }
                        listData.set(0, values[i]); // one before, for nice
                        // scrolling
                    }
                }
                GraphViewDataInterface[] list = new GraphViewDataInterface[listData
                        .size()];
                listData.toArray(list);
                return list;
            }
        }
    }

    /**
     * add a series of data to the graph
     *
     * @param series
     */
    public void addSeries(List<List<Glucose>> points) {
        // configure the graph x and y for the database fetched glucose points
        setGlucosePoints(points);

        graphSeries.clear();
        for (int i = 0; i < points.size(); ++i) {
            List<Glucose> p = points.get(i);
            GraphViewData[] data = new GraphViewData[p.size()];

            for (int j = 0; j < p.size(); j++) {
                data[j] = new GraphViewData(p.get(j).getX(), p.get(j)
                        .getGlucoseLevel());
            }
            GraphViewSeries series = new GraphViewSeries(data);
            series.addGraphView(this);
            graphSeries.add(series);
        }
        redrawAll();
    }

    public void setEventPoints(List<EventPoint> eventPoints,
                               Calendar startDate, Calendar endDate) {

        if (eventPoints != null) {
            this.eventPoints = eventPoints;
            for (EventPoint eventPoint : this.eventPoints)
                eventPoint.setRect(rect, startDate, endDate);
            eventGroups.clear();

            setUpEventGroups();
        }
        redrawAll();
    }

    public void setUpEventGroups() {

        double maxX = getMaxX(false);
        double minX = getMinX(false);
        double diffX = maxX - minX;

        List<EventPoint> events = eventPoints;

        for (int i = 0; i < events.size(); i++) {
            EventPoint ep = events.get(i);
            EVENT_TYPE eventType = ep.getEventType();

            // My glucose graph or landscape graph
            if (this.isScrollable() || this.isLandscape) {

                // #2084 Changed this block not to show high or low alarms on the graph.
                if (eventType == EVENT_TYPE.ALARM_EVENT) {
                    ep.setxOnScreen(-50);
                    ep.setyOnScreen(-50);
                    continue;
                }
            }

            // #2230 Hide Rate Alert icon on the graph
            if (eventType == EVENT_TYPE.RATE_ALERT_EVENT_FALLING
                    || eventType == EVENT_TYPE.RATE_ALERT_EVENT_RISING) {
                ep.setxOnScreen(-50);
                ep.setyOnScreen(-50);
                continue;
            }

            float y = 0;
            int glucoseLevel = ep.getGlucoseLevel();
            //Log.i("Graph Debug", ep.toString());

            // out of range high and low glucose alarms
            if(eventType == EVENT_TYPE.NOTIFICATION_EVENT_RED) {
                Utils.TransmitterMessageCode notificationEventType = ep.getNotificationEventType();
                if ((notificationEventType == Utils.TransmitterMessageCode.SeriouslyLowAlarm) ||
                        (notificationEventType == Utils.TransmitterMessageCode.SeriouslyHighAlarm)) {
                    // No glucose
                    if(glucoseLevel == Utils.GLUCOSE_LEVEL_UNKNOWN) {
                        if (notificationEventType == Utils.TransmitterMessageCode.SeriouslyHighAlarm) {
                            glucoseLevel = Utils.GLUCOSE_MAX + 1; // draw at the top of the graph
                        }
                        // SeriouslyLowAlarm would use height for GLUCOSE_LEVEL_UNKNOWN which is fine
                    }
                }
            }

            if (glucoseLevel == Utils.GLUCOSE_LEVEL_UNKNOWN) {
                y = GraphUtils.getPositionYForGlucose(Utils.EVENT_POSITION,
                        rect);
            } else {
                if (glucoseLevel > Utils.GLUCOSE_MAX) {
                    y = GraphUtils.getPositionYForGlucose(Utils.GLUCOSE_MAX, rect);
                } else if (glucoseLevel < Utils.GLUCOSE_MIN_Y) {
                    y = GraphUtils.getPositionYForGlucose(Utils.GLUCOSE_MIN_Y, rect);
                } else {
                    y = GraphUtils.getPositionYForGlucose(glucoseLevel, rect);
                }
            }

            float valX = (float) (ep.getX() - minX);
            float ratX = (float) (valX / diffX);
            float x = graphwidth * ratX;

            ep.setxOnScreen(x);
            ep.setyOnScreen(y);
        }

        setEventGroups(events);
    }

    abstract public EventPoint ifEventAtPosition(float x);

    abstract public Glucose ifGlucoseAtPosition(float x);

    abstract public boolean ifEventClick(float x, float y);

    abstract public void clickEvent(float x, float y);

    abstract public void hideEvent();

    public void setEventGroups(List<EventPoint> eventPoints) {

        eventGroups.clear();
        for (EventPoint eventPoint : eventPoints) {
            boolean addedToGroup = false;
            //for (EventGroup eventGroup : eventGroups)
            //if (eventGroup.isNearOnScreen(eventPoint)) {
            //if (addedToGroup == false) {
            //eventGroup.addEvent(eventPoint);
            //int eventGroupSize = eventGroup.getEvents().size();
            //int sumX = 0, sumY = 0, sumXOnScreen = 0, sumYOnScreen = 0;
            //for (int i = 0; i < eventGroup.getEvents().size(); ++i) {
            //EventPoint event = eventGroup.getEvents().get(i);
            //sumX += event.getX();
            //sumY += event.getY();
            //sumXOnScreen += event.getxOnScreen();
            //sumYOnScreen += event.getyOnScreen();
            //}
            //eventGroup.x = sumX / eventGroupSize;
            //eventGroup.y = sumY / eventGroupSize;
            //eventGroup.xOnScreen = sumXOnScreen / eventGroupSize;
            //eventGroup.yOnScreen = sumYOnScreen / eventGroupSize;
            //
            //addedToGroup = true;
            //}
            //}

            for (EventGroup eventGroup : eventGroups)
                if (eventGroup.isNearOnScreen(eventPoint)) {
                    eventGroup.addEvent(eventPoint);
                    addedToGroup = true;
                    break;
                }

            if (!addedToGroup) {
                EventGroup eventGroup = new EventGroup(eventPoint.getX(),
                        eventPoint.getGlucoseLevel(),
                        eventPoint.getxOnScreen(), eventPoint.getyOnScreen());
                eventGroup.addEvent(eventPoint);
                eventGroups.add(eventGroup);
            }
        }
    }

    public void setGlucosePoints(List<List<Glucose>> glucosePoints) {

        this.glucosePoints = glucosePoints;
        for (List<Glucose> arrayList : this.glucosePoints) {
            for (Glucose glucose : arrayList) {
                glucose.setRect(rect, startDate, endDate);
            }
        }
        // invalidate();
    }

    public ArrayList<GlucoseSection> subDivideGlucosePoints(
            GraphViewDataInterface[] glucosePoints) {
        ArrayList<GlucoseSection> arrayList = new ArrayList<GlucoseSection>();

        if (glucosePoints != null && glucosePoints.length > 1) {

            DIRECTION direction = DIRECTION.ASCENDANT;

            float y1 = (float) glucosePoints[0].getY();
            float y2 = (float) glucosePoints[1].getY();

            COLOR colorForSection;

            direction = getDirection(y1, y2, direction);
            colorForSection = GraphUtils.getGlucoseLevelColor(
                    (int) glucosePoints[0].getY(), direction);

            ArrayList<GraphViewData> pointsInSection = new ArrayList<GraphViewData>();
            pointsInSection.add(new GraphViewData(glucosePoints[0].getX(),
                    glucosePoints[0].getY()));

            int i = 1, glucoseLevel;

            while (i < glucosePoints.length) {
                COLOR color;

                y1 = (float) pointsInSection.get(pointsInSection.size() - 1)
                        .getY();
                y2 = (float) glucosePoints[i].getY();

                direction = getDirection(y1, y2, direction);

                glucoseLevel = GraphUtils.getGlucoseLevelBetween(y1, y2, rect);

                if (glucoseLevel == 0) {
                    colorForSection = GraphUtils.getGlucoseLevelColor((int) y1,
                            direction);
                    glucoseLevel = (int) glucosePoints[i].getY();
                }
                color = GraphUtils
                        .getGlucoseLevelColor(glucoseLevel, direction);

                if (colorForSection != color) {

                    // Dispart the section
                    float x1 = (float) pointsInSection.get(
                            pointsInSection.size() - 1).getX();
                    float x2 = (float) glucosePoints[i].getX();

                    glucoseLevel = GraphUtils.getGlucoseLevelBetween(y1, y2,
                            rect);
                    float y = glucoseLevel;
                    float x = GraphUtils.getXOnLine(x2, GraphUtils
                                    .getPositionYForGlucose((int) y2, rect), x1,
                            GraphUtils.getPositionYForGlucose((int) y1, rect),
                            (float) GraphUtils.getPositionYForGlucose((int) y,
                                    rect));

                    if (y == 0) {
                        glucoseLevel = GraphUtils.getGlucoseLevelBetween(y1,
                                y2, rect);
                    }

                    GraphViewData glucosePoint = new GraphViewData(x, y);
                    pointsInSection.add(glucosePoint);

                    // Add current section to array
                    GlucoseSection glucoseSection = new GlucoseSection(
                            pointsInSection, colorForSection);
                    arrayList.add(glucoseSection);

                    // Starting new section
                    pointsInSection = new ArrayList<GraphViewData>();
                    pointsInSection.add(glucosePoint);
                    if (y == y2 && i + 1 < glucosePoints.length) {
                        y2 = (float) glucosePoints[i + 1].getY();
                    }
                    direction = getDirection(y, y2, direction);
                    colorForSection = GraphUtils.getGlucoseLevelColor(
                            glucoseLevel, direction);
                } else {

                    pointsInSection.add(new GraphViewData(glucosePoints[i]
                            .getX(), glucosePoints[i].getY()));

                    if (i == glucosePoints.length - 1) {
                        GlucoseSection glucoseSection = new GlucoseSection(
                                pointsInSection, colorForSection);
                        arrayList.add(glucoseSection);
                    }
                    ++i;
                }

            }
        } else if (glucosePoints != null) {

            COLOR colorForSection = GraphUtils.getGlucoseLevelColor(
                    (int) glucosePoints[0].getY(), DIRECTION.ASCENDANT);

            ArrayList<GraphViewData> pointsInSection = new ArrayList<GraphViewData>();
            pointsInSection.add(new GraphViewData(glucosePoints[0].getX(),
                    glucosePoints[0].getY()));

            // Add section to array
            GlucoseSection glucoseSection = new GlucoseSection(pointsInSection,
                    colorForSection);
            arrayList.add(glucoseSection);

        }

        return arrayList;
    }

    public static class GlucoseSection {
        private ArrayList<GraphViewData> glucosePoints;
        private COLOR color;

        public GlucoseSection(ArrayList<GraphViewData> glucosePoints,
                              COLOR color) {
            super();
            this.setGlucosePoints(glucosePoints);
            this.setColor(color);
        }

        public GraphViewDataInterface[] getGlucosePoints() {
            return new GraphViewSeries(
                    glucosePoints.toArray(new GraphViewData[glucosePoints
                            .size()])).values;
        }

        public void setGlucosePoints(ArrayList<GraphViewData> glucosePoints) {
            this.glucosePoints = glucosePoints;
        }

        public COLOR getColor() {
            return color;
        }

        public void setColor(COLOR color) {
            this.color = color;
        }
    }

    public DIRECTION getDirection(float y1, float y2, DIRECTION currentDirection) {
        if (y1 < y2)
            return DIRECTION.ASCENDANT;
        else if (y1 > y2)
            return DIRECTION.DESCENDANT;
        return currentDirection;
    }

    protected void drawHorizontalLabels(Canvas canvas, float border,
                                        float horstart, float height, String[] horlabels, float graphwidth) {
        // horizontal labels + lines
        int hors = horlabels.length - 1;
        for (int i = 0; i < horlabels.length; i++) {
            paint.setColor(graphViewStyle.getGridColor());
            float x = ((graphwidth / hors) * i) + horstart;
            canvas.drawLine(x, height - border, x, border, paint);
            paint.setTextAlign(Align.CENTER);
            if (i == horlabels.length - 1)
                paint.setTextAlign(Align.RIGHT);
            if (i == 0)
                paint.setTextAlign(Align.LEFT);
            paint.setColor(graphViewStyle.getHorizontalLabelsColor());
            canvas.drawText(horlabels[i], x, height - 4, paint);
        }
    }

    protected void drawLegend(Canvas canvas, float height, float width) {
        float textSize = paint.getTextSize();
        int spacing = getGraphViewStyle().getLegendSpacing();
        int border = getGraphViewStyle().getLegendBorder();
        int legendWidth = getGraphViewStyle().getLegendWidth();

        int shapeSize = (int) (textSize * 0.8d);
        Log.d("GraphView", "draw legend size: " + paint.getTextSize());

        // rect
        paint.setARGB(180, 100, 100, 100);
        float legendHeight = (shapeSize + spacing) * graphSeries.size() + 2
                * border - spacing;
        float lLeft = width - legendWidth - border * 2;
        float lTop;
        switch (legendAlign) {
            case TOP:
                lTop = 0;
                break;
            case MIDDLE:
                lTop = height / 2 - legendHeight / 2;
                break;
            default:
                lTop = height - GraphViewConfig.BORDER - legendHeight
                        - getGraphViewStyle().getLegendMarginBottom();
        }
        float lRight = lLeft + legendWidth;
        float lBottom = lTop + legendHeight;
        canvas.drawRoundRect(new RectF(lLeft, lTop, lRight, lBottom), 8, 8,
                paint);

        for (int i = 0; i < graphSeries.size(); i++) {
            paint.setColor(graphSeries.get(i).style.color);
            canvas.drawRect(new RectF(lLeft + border, lTop + border
                            + (i * (shapeSize + spacing)), lLeft + border + shapeSize,
                            lTop + border + (i * (shapeSize + spacing)) + shapeSize),
                    paint);
            if (graphSeries.get(i).description != null) {
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Align.LEFT);
                canvas.drawText(graphSeries.get(i).description, lLeft + border
                        + shapeSize + spacing, lTop + border + shapeSize
                        + (i * (shapeSize + spacing)), paint);
            }
        }
    }

    abstract protected void drawSeries(Canvas canvas,
                                       ArrayList<GlucoseSection> values, float graphwidth,
                                       float graphheight, float border, double minX, double minY,
                                       double diffX, double diffY, float horstart,
                                       GraphViewSeriesStyle style, boolean lastSection);

    /**
     * formats the label use #setCustomLabelFormatter or static labels if you
     * want custom labels
     *
     * @param value
     *            x and y values
     * @param isValueX
     *            if false, value y wants to be formatted
     * @deprecated use {@link #setCustomLabelFormatter(CustomLabelFormatter)}
     * @return value to display
     */
    @Deprecated
    protected String formatLabel(double value, boolean isValueX) {
        if (customLabelFormatter != null) {
            String label = customLabelFormatter.formatLabel(value, isValueX);
            if (label != null) {
                return label;
            }
        }
        int i = isValueX ? 1 : 0;
        if (numberformatter[i] == null) {
            numberformatter[i] = NumberFormat.getNumberInstance();
            double highestvalue = isValueX ? getMaxX(false) : getMaxY();
            double lowestvalue = isValueX ? getMinX(false) : getMinY();
            if (highestvalue - lowestvalue < 0.1) {
                numberformatter[i].setMaximumFractionDigits(6);
            } else if (highestvalue - lowestvalue < 1) {
                numberformatter[i].setMaximumFractionDigits(4);
            } else if (highestvalue - lowestvalue < 20) {
                numberformatter[i].setMaximumFractionDigits(3);
            } else if (highestvalue - lowestvalue < 100) {
                numberformatter[i].setMaximumFractionDigits(1);
            } else {
                numberformatter[i].setMaximumFractionDigits(0);
            }
        }
        return numberformatter[i].format(value);
    }

    /**
     * @return the custom label formatter, if there is one. otherwise null
     */
    public CustomLabelFormatter getCustomLabelFormatter() {
        return customLabelFormatter;
    }

    /**
     * @return the graphview style. it will never be null.
     */
    public GraphViewStyle getGraphViewStyle() {
        return graphViewStyle;
    }

    /**
     * get the position of the legend
     *
     * @return
     */
    public LegendAlign getLegendAlign() {
        return legendAlign;
    }

    /**
     * @return legend width
     * @deprecated use {@link GraphViewStyle#getLegendWidth()}
     */
    @Deprecated
    public float getLegendWidth() {
        return getGraphViewStyle().getLegendWidth();
    }

    /**
     * returns the maximal X value of the current viewport (if viewport is set)
     * otherwise maximal X value of all data.
     *
     * @param ignoreViewport
     *
     *            warning: only override this, if you really know want you're
     *            doing!
     */
    protected double getMaxX(boolean ignoreViewport) {
        // if viewport is set, use this
        if (scrollableGraph == true &&
                !ignoreViewport
                && GraphUtils.viewportSize != 0) {
            return viewportStart + GraphUtils.viewportSize;
        } else {
            return rect.width();
        }
    }

    /**
     * returns the maximal Y value of all data.
     *
     * warning: only override this, if you really know want you're doing!
     */
    protected double getMaxY() {
        return GraphUtils.glucoseMaximumLevel;
    }

    /**
     * returns the minimal X value of the current viewport (if viewport is set)
     * otherwise minimal X value of all data.
     *
     * @param ignoreViewport
     *
     *            warning: only override this, if you really know want you're
     *            doing!
     */
    protected double getMinX(boolean ignoreViewport) {
        // if viewport is set, use this
        if (!ignoreViewport && GraphUtils.viewportSize != 0) {
            return viewportStart;
        } else {
            return 0;
        }
    }

    /**
     * returns the minimal Y value of all data.
     *
     * warning: only override this, if you really know want you're doing!
     */
    protected double getMinY() {
        double smallest;
        if (manualYAxis) {
            smallest = manualMinYValue;
        } else {
            smallest = Integer.MAX_VALUE;
            for (int i = 0; i < graphSeries.size(); i++) {
                GraphViewDataInterface[] values = getValues(i);
                for (int ii = 0; ii < values.length; ii++)
                    if (values[ii].getY() < smallest)
                        smallest = values[ii].getY();
            }
        }
        return GraphUtils.glucoseMinimumLevel;
    }

    public boolean isDisableTouch() {
        return disableTouch;
    }

    public boolean isScrollable() {
        return scrollable;
    }

    public boolean isShowLegend() {
        return showLegend;
    }

    /**
     * forces graphview to invalide all views and caches. Normally there is no
     * need to call this manually.
     */
    public void redrawAll() {
        numberformatter[0] = null;
        numberformatter[1] = null;

        invalidate();
        graphViewContentView.invalidate();
    }

    /**
     * removes all series
     */
    public void removeAllSeries() {
        for (GraphViewSeries s : graphSeries) {
            s.removeGraphView(this);
        }
        while (!graphSeries.isEmpty()) {
            graphSeries.remove(0);
        }
        redrawAll();
    }

    /**
     * removes a series
     *
     * @param series
     *            series to remove
     */
    public void removeSeries(GraphViewSeries series) {
        series.removeGraphView(this);
        graphSeries.remove(series);
        redrawAll();
    }

    /**
     * removes series
     *
     * @param index
     */
    public void removeSeries(int index) {
        if (index < 0 || index >= graphSeries.size()) {
            throw new IndexOutOfBoundsException("No series at index " + index);
        }

        removeSeries(graphSeries.get(index));
    }

    /**
     * scrolls to the last x-value
     *
     * @throws IllegalStateException
     *             if scrollable == false
     */
    public void scrollToEnd() {
        if (!scrollable)
            throw new IllegalStateException("This GraphView is not scrollable.");
        double max = getMaxX(true);
        viewportStart = max - GraphUtils.viewportSize;

        // don't clear labels width/height cache
        // so that the display is not flickering

        invalidate();
        graphViewContentView.invalidate();
    }

    /**
     * set a custom label formatter
     *
     * @param customLabelFormatter
     */
    public void setCustomLabelFormatter(
            CustomLabelFormatter customLabelFormatter) {
        this.customLabelFormatter = customLabelFormatter;
    }

    /**
     * The user can disable any touch gestures, this is useful if you are using
     * a real time graph, but don't want the user to interact
     *
     * @param disableTouch
     */
    public void setDisableTouch(boolean disableTouch) {
        this.disableTouch = disableTouch;
    }

    /**
     * set custom graphview style
     *
     * @param style
     */
    public void setGraphViewStyle(GraphViewStyle style) {
        graphViewStyle = style;
    }

    /**
     * set's static horizontal labels (from left to right)
     *
     * @param horlabels
     *            if null, labels were generated automatically
     */

    /**
     * legend position
     *
     * @param legendAlign
     */
    public void setLegendAlign(LegendAlign legendAlign) {
        this.legendAlign = legendAlign;
    }

    /**
     * legend width
     *
     * @param legendWidth
     * @deprecated use {@link GraphViewStyle#setLegendWidth(int)}
     */
    @Deprecated
    public void setLegendWidth(float legendWidth) {
        getGraphViewStyle().setLegendWidth((int) legendWidth);
    }

    /**
     * you have to set the bounds {@link #setManualYAxisBounds(double, double)}.
     * That automatically enables manualYAxis-flag. if you want to disable the
     * menual y axis, call this method with false.
     *
     * @param manualYAxis
     */
    public void setManualYAxis(boolean manualYAxis) {
        this.manualYAxis = manualYAxis;
    }

    /**
     * set manual Y axis limit
     *
     * @param max
     * @param min
     */

    /**
     * this forces scrollable = true
     *
     * @param scalable
     */
    private ScaleManager scaleManager;

    public interface ScaleManager {
        public void onScaleEvent();
    }

    public void setScaleManager(ScaleManager scaleManager) {
        this.scaleManager = scaleManager;
    }

    synchronized public void setScalable(boolean scalable) {
        this.scalable = scalable;

        if (scalable == true && scaleDetector == null) {
            scrollable = true; // automatically forces this
            scaleDetector = new ScaleGestureDetector(getContext(),
                    new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                        @Override
                        public boolean onScale(ScaleGestureDetector detector) {
                            double center = viewportStart
                                    + GraphUtils.viewportSize / 2;

                            float size = (float) (GraphUtils.viewportSize / detector
                                    .getScaleFactor());
                            if (size > GraphUtils.maxViewPortSize
                                    || size < GraphUtils.minViewPortSize) {
                                return false;
                            }
                            GraphUtils.viewportSize /= detector
                                    .getScaleFactor();

                            viewportStart = center - GraphUtils.viewportSize
                                    / 2;

                            // viewportStart must not be < minX
                            double minX = getMinX(true);
                            if (viewportStart < minX) {
                                viewportStart = minX;
                            }

                            // viewportStart + viewportSize must not be > maxX
                            double maxX = getMaxX(true);
                            if (GraphUtils.viewportSize == 0) {
                                GraphUtils.viewportSize = maxX;
                            }
                            double overlap = viewportStart
                                    + GraphUtils.viewportSize - maxX;
                            if (overlap > 0) {
                                // scroll left
                                if (viewportStart - overlap > minX) {
                                    viewportStart -= overlap;
                                } else {
                                    // maximal scale
                                    viewportStart = minX;
                                    GraphUtils.viewportSize = maxX
                                            - viewportStart;
                                }
                            }

                            GraphUtils.viewportStart = viewportStart;

                            Calendar start = GraphUtils.getDateForPositionX(
                                    rect.width(), startDate, endDate,
                                    (float) viewportStart);

                            Calendar end = GraphUtils.getDateForPositionX(
                                    rect.width(),
                                    startDate,
                                    endDate,
                                    (float) ((float) viewportStart + GraphUtils.viewportSize));
                            Calendar middle = GraphUtils.getDateForPositionX(
                                    rect.width(),
                                    startDate,
                                    endDate,
                                    (float) ((float) viewportStart + GraphUtils.viewportSize / 2));

                            long timestampDiff = end.getTimeInMillis()
                                    - start.getTimeInMillis();
                            if (timestampDiff > GraphUtils.DAY) {
                                manager.dayChanged(start.getTime(),
                                        end.getTime());
                            } else {
                                manager.dayChanged(middle.getTime());
                            }

                            GraphUtils.glucoseDataInterval = GraphUtils
                                    .getDiffTime();
                            if (GraphUtils.glucoseDataIntervalChanged) {
                                GraphUtils.glucoseDataIntervalChanged = false;
                                scaleManager.onScaleEvent();
                            } else
                                redrawAll();
                            return true;
                        }
                    });
        }
    }

    /**
     * the user can scroll (horizontal) the graph. This is only useful if you
     * use a viewport {@link #setViewPort(double, double)} which doesn't
     * displays all data.
     *
     * @param scrollable
     */
    public void setScrollable(boolean scrollable) {
        this.scrollable = scrollable;
    }

    public void setIsLandscape(boolean isLandscape) {
        this.isLandscape = isLandscape;
    }

    public void setShowLegend(boolean showLegend) {
        this.showLegend = showLegend;
    }

    /**
     * sets the title of graphview
     *
     * @param title
     */

    /**
     * set's static vertical labels (from top to bottom)
     *
     * @param verlabels
     *            if null, labels were generated automatically
     */

    /**
     * set's the viewport for the graph.
     *
     * @see #setManualYAxisBounds(double, double) to limit the y-viewport
     * @param start
     *            x-value
     * @param size
     */
    public void setViewPort(double start, double size) {
        if (size < 0) {
            throw new IllegalArgumentException(
                    "Viewport size must be greater than 0!");
        }

        viewportStart = start;

        if (manager != null) {
            GraphUtils.viewportStart = viewportStart;
            GraphUtils.viewportSize = size;

            Calendar startCal = GraphUtils.getDateForPositionX(rect.width(),
                    startDate, endDate, (float) viewportStart);

            Calendar end = GraphUtils.getDateForPositionX(rect.width(),
                    startDate, endDate,
                    (float) ((float) viewportStart + GraphUtils.viewportSize));

            Calendar middle = GraphUtils
                    .getDateForPositionX(
                            rect.width(),
                            startDate,
                            endDate,
                            (float) ((float) viewportStart + GraphUtils.viewportSize / 2));

            long timestampDiff = end.getTimeInMillis()
                    - startCal.getTimeInMillis();
            if (timestampDiff > GraphUtils.DAY) {
                manager.dayChanged(startCal.getTime(), end.getTime());
            } else {
                manager.dayChanged(middle.getTime());
            }
        }
    }

    public float getPosOnScreen(float x) {
        double maxX = getMaxX(false);
        double minX = getMinX(false);
        double diffX = maxX - minX;

        float valX = (float) (x - minX);
        float ratX = (float) (valX / diffX);
        return graphwidth * ratX;
    }

    public void slideBackToStart() {
        graphViewContentView.slideBackToStart();
    }

    public void slideBackToEnd() {
        graphViewContentView.slideBackToEnd();
    }

    public EventsManager getEventsManager() {
        return eventsManager;
    }

    public void setEventsManager(EventsManager eventsManager) {
        this.eventsManager = eventsManager;
    }

    public ScrollManager getManager() {
        return manager;
    }

    public void setManager(ScrollManager manager) {
        this.manager = manager;
    }

    public class EventGroup {

        public float x;
        float y;
        float xOnScreen;
        float yOnScreen;
        private ArrayList<EventPoint> events;

        public EventGroup(float x, float y) {
            super();
            this.x = x;
            this.y = y;
            events = new ArrayList<EventPoint>();
        }

        public EventGroup(float x, float y, float xOnScreen, float yOnScreen) {
            super();
            this.x = x;
            this.y = y;
            this.xOnScreen = xOnScreen;
            this.yOnScreen = yOnScreen;
            events = new ArrayList<EventPoint>();
        }

        public void addEvent(EventPoint event) {
            events.add(event);
        }

        public boolean isNear(EventPoint event) {
            float distanceX = Math.abs(x - event.getX());
            float distanceY = Math.abs(y - event.getY());

            if (distanceX <= GraphUtils.eventBitmapSize
                    && distanceY <= GraphUtils.eventBitmapSize)
                return true;
            else
                return false;
        }

        public boolean isNearOnScreen(EventPoint event) {
            float distanceX = Math.abs(xOnScreen - event.getxOnScreen());
            float distanceY = Math.abs(yOnScreen - event.getyOnScreen());

            if (distanceX <= GraphUtils.eventBitmapSize
                    && distanceY <= GraphUtils.eventBitmapSize)
                return true;
            else
                return false;
        }

        public ArrayList<EventPoint> getEvents() {
            return events;
        }
    }
}
