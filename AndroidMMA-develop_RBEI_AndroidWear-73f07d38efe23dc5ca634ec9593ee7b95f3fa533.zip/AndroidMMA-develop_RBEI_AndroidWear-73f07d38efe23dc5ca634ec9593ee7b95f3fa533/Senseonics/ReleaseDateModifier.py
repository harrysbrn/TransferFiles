import time
from sys import argv

script, filename = argv

# Read the file
file = open(filename, "r")
txtString = file.read()
file.close()

# Get the Today's date
timestring = time.strftime("%m/%d/%Y")

# Replace the old date in the file
txtString = txtString.replace("04/15/2014", timestring)
print txtString

# Write to the file
file = open(filename, "w")
file.write(txtString)
file.close()
